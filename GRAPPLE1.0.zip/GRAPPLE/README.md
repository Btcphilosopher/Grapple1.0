# GRAPPLE 1.0

**Grape Research, Production, Processing, Logistics & Enology** — an English
vineyard & winery digital twin.

GRAPPLE is a decision-support simulation for cool-climate English
viticulture and winemaking. It models the full chain — soil → vine →
canopy → flowers → fruit → ripening → harvest → pressing → juice →
fermentation → maturation → blending → bottling → finished wine — as an
interconnected system rather than a set of arbitrary numbers, so that a
change to one input (a warmer vintage, a delayed harvest, a different
yeast) propagates realistically through everything downstream.

It ships with a synthetic example estate (**Wessex Crown Vineyard**, 48.6ha
in southern England), a FastAPI + WebSocket server, a Monte Carlo vintage
engine, a harvest-timing optimiser, a digital-twin calibration layer for
connecting real vineyard data, and a full pytest suite.

> **This is a simulation, not a laboratory.** Every number GRAPPLE produces
> is either OBSERVED (real data you've fed in), MODELLED (computed by a
> transparent process model), ESTIMATED, SYNTHETIC (demo data), or
> PREDICTED (a forward projection with uncertainty). See
> [Scientific honesty](#scientific-honesty-and-simplifications) below.

---

## Contents

- [Quick start](#quick-start)
- [Running the API server](#running-the-api-server)
- [Example API requests](#example-api-requests)
- [The console "watch a vintage" experience](#the-console-watch-a-vintage-experience)
- [Data import / export](#data-import--export)
- [Real Vineyard Mode & calibration](#real-vineyard-mode--calibration)
- [Project structure](#project-structure)
- [Design principles](#design-principles)
- [Scientific honesty and simplifications](#scientific-honesty-and-simplifications)
- [Tests](#tests)
- [What's deliberately out of scope for 1.0](#whats-deliberately-out-of-scope-for-10)

---

## Quick start

Requires **Python 3.12+** (tested against 3.11/3.12).

```bash
cd GRAPPLE
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Run the full test suite
pytest -q

# Watch a full vintage narrated to the console (Section 75 "first-run experience")
python -m grapple.main --console-vintage --vintage-year 2031 --seed 20310817

# Start the API server
python -m grapple.main --host 0.0.0.0 --port 8000
# then open http://localhost:8000/docs for interactive OpenAPI docs
```

There is no database migration step required for development — GRAPPLE
runs entirely in-memory by default (`grapple/config.py` sets a SQLite URL
for future persistence work; nothing currently requires it to exist).

---

## Running the API server

```bash
python -m grapple.main --port 8000
```

The server exposes one live simulation per process (matching the "control
room watching one estate" model). Everything starts from
`POST /simulation/start`.

Interactive documentation: `http://localhost:8000/docs` (FastAPI's
auto-generated Swagger UI) — the fastest way to explore every endpoint and
try requests directly in the browser.

## Example API requests

```bash
BASE=http://localhost:8000

# 1. Start a vintage on the seeded Wessex Crown Vineyard estate
curl -s -X POST $BASE/simulation/start \
  -H 'Content-Type: application/json' \
  -d '{"vintage_year": 2031, "seed": 20310817, "scenario_key": "average", "use_seed_estate": true}'

# 2. Advance the simulation 220 days (into ripening season)
curl -s -X POST $BASE/simulation/step -H 'Content-Type: application/json' -d '{"days": 220}'

# 3. Look at the estate and one block
curl -s $BASE/estate
curl -s $BASE/blocks/B01

# 4. Today's weather and harvest readiness for a target style
curl -s $BASE/weather
curl -s "$BASE/harvest/readiness?block_id=B01&style_key=traditional_sparkling"

# 5. Ask the harvest optimiser to rank "harvest today .. +10 days"
curl -s -X POST $BASE/harvest/optimise -H 'Content-Type: application/json' \
  -d '{"block_id": "B01", "style_key": "traditional_sparkling", "max_days": 10}'

# 6. Actually harvest a block (creates a HarvestLot, presses it, starts fermentation)
curl -s -X POST $BASE/harvest/execute -H 'Content-Type: application/json' \
  -d '{"block_id": "B01", "style_key": "traditional_sparkling", "yeast_key": "ec1118", "fermentation_temp_c": 16}'

# 7. Check on the fermentation
curl -s $BASE/fermentation/FB-00001

# 8. Run a non-destructive "what if we irrigate Block 05 with 20mm?" scenario
curl -s -X POST $BASE/scenario/run -H 'Content-Type: application/json' \
  -d '{"irrigation_block_id": "B05", "irrigation_mm": 20, "days_forward": 14}'

# 9. Run a 200-trial Monte Carlo vintage-planning batch
curl -s -X POST $BASE/monte-carlo/run -H 'Content-Type: application/json' \
  -d '{"vintage_year": 2031, "n_trials": 200, "master_seed": 20310101}'

# 10. Alerts / economics
curl -s $BASE/alerts
curl -s $BASE/economics
```

**WebSocket streaming** (Section 67/68): connect to `ws://localhost:8000/ws/simulation`
and send `{"cmd": "step", "days": 1}` to advance the live simulation and
receive back the updated estate snapshot plus any newly raised alerts, or
`{"cmd": "snapshot"}` to just read the current state.

---

## The console "watch a vintage" experience

```bash
python -m grapple.main --console-vintage --vintage-year 2031 --seed 20310817
```

This loads Wessex Crown Vineyard, then walks January → December day by
day: weather generation, phenology, canopy growth, soil moisture, disease
pressure and grape chemistry all update every simulated day; a monthly
dashboard prints; each block is harvested, pressed and sent to
fermentation as it becomes ready; and a `VINTAGE REPORT` prints at the
end — the full Section 75 lifecycle.

---

## Data import / export

`grapple.digital_twin.telemetry.TelemetryBus` ingests CSV or JSON
observations (Section 40/65), tagging each row `DataProvenance.OBSERVED`:

```python
from grapple.digital_twin.telemetry import TelemetryBus

bus = TelemetryBus()
csv_text = """date,time,block,temperature,humidity,soil_moisture
2031-07-14,12:00,B07,21.4,62,31.7
"""
bus.ingest_csv(csv_text, source="weather_station_1")
```

`TelemetryBus.export_json()` and the various domain objects
(`VintageReport`, `HarvestOutcome`, `AnalysisReport`, ...) are all plain
dataclasses of JSON-serialisable fields for straightforward export
(Section 66) — every API response is already JSON.

The protocol layer is intentionally a thin, swappable boundary: CSV/JSON
work today; MQTT/OPC-UA/REST producers (Section 40) can be added as
additional `TelemetryBus.publish(...)` callers without changing anything
downstream.

---

## Real Vineyard Mode & calibration

`grapple.digital_twin.synchronization.DigitalTwinSync` wraps a live
`EstateState` and is the entry point for replacing synthetic inputs with a
real vineyard's own data (Section 64): real weather-station history via
`ingest_weather_observation`, and lab results via `ingest_lab_result`,
which feeds `digital_twin.calibration.CalibrationEngine` — a scalar Kalman
filter *and* a simple linear regression per metric, both transparent by
design (Section 42/77): with few observations the Kalman filter's
confidence interval stays wide rather than pretending to be precise.

```python
sync.ingest_lab_result("brix", predicted_value=18.4, observed_value=18.1, date=vintage_date)
# -> {"calibrated_value": 18.15, "bias_estimate": -0.28, "confidence_95": (-1.9, 1.3), "n_observations": 1}
```

---

## Project structure

```
GRAPPLE/
├── grapple/
│   ├── main.py, config.py
│   ├── core/            simulation orchestrator, clock, events, seeded randomness, EstateState
│   ├── vineyard/        estate/blocks/vines/varieties/phenology/canopy/soil/water/nutrition/disease/yield
│   ├── weather/         daily weather engine, rainfall, frost, forecast, climate scenarios
│   ├── viticulture/     flowering, veraison, ripening (grape chemistry), berry, harvest readiness, ops
│   ├── winery/          reception → sorting → destemming → crushing → pressing → juice → fermentation →
│   │                    yeast → malolactic → clarification → maturation → blending → bottling → cellar →
│   │                    sparkling (traditional-method module)
│   ├── wine/            composition, chemistry, sensory panel, quality model, bottle-ageing projection
│   ├── equipment/       tractors, harvesters, presses, tanks, pumps, refrigeration, bottling line
│   ├── laboratory/       samples/chain-of-custody, test methods + uncertainty, QC, analysis service
│   ├── logistics/       harvest transport, inventory ledger, warehouse
│   ├── economics/       costs, revenue, capex/depreciation, profitability, sustainability
│   ├── optimisation/     harvest-timing optimiser, canopy/vineyard optimiser, fermentation-strategy
│   │                    search, blend optimiser (scipy), production scheduler, Monte Carlo engine
│   ├── digital_twin/     synthetic sensors, telemetry bus (CSV/JSON import+export), calibration
│   │                    (Kalman + regression), state-plausibility anomaly checks, Real Vineyard Mode
│   ├── api/              FastAPI routes, WebSocket streaming, request schemas
│   ├── ui/               text "control room" dashboard renderers (main dashboard, block detail,
│   │                    weather map, harvest readiness, winery/cellar, fermentation curve, alerts...)
│   └── data/              seed reference tables: varieties, rootstocks, soils, climate normals,
│                          wine-style targets, yeast strains, oak profiles, the seed estate
├── tests/                 pytest suite (70+ tests)
├── requirements.txt
└── pyproject.toml
```

`tests/` lives at the project root (not nested under `grapple/`) so a
plain `pytest` from `GRAPPLE/` just works — functionally identical to a
`grapple/tests/` layout.

## Design principles

**The chain is real** (Section 76): weather drives phenology, phenology
drives canopy state, canopy state and weather together drive water/disease
dynamics, all of that drives grape chemistry via `viticulture.ripening`,
grape chemistry at harvest becomes the fermentation engine's starting
point, fermentation outcome becomes the wine's composition, composition
feeds the quality model, and the quality model exposes *why* it produced
each score. Changing a block's aspect, or picking five days later,
visibly changes everything downstream — nothing is a fixed constant that
ignores upstream state.

**Every prediction carries uncertainty** (Section 43): laboratory
measurements (`laboratory.chemistry.measure`) add realistic analytical
noise; bottle-ageing projections (`wine.ageing.project_ageing`) widen
their uncertainty band with horizon; Monte Carlo output
(`optimisation.monte_carlo`) reports percentile ranges, never a single
number pretending to be certain.

**"What if" never touches the live twin** (Section 62): `POST
/scenario/run` and the optimisers in `optimisation/` all operate on a
`copy.deepcopy()` of the live `VintageSimulation` — a shadow run can
irrigate a block, delay a harvest, or switch climate scenario entirely
without perturbing the actual running vintage.

**Capacity is a real constraint** (Section 47): `winery.cellar.Cellar`
tracks fermentation/cellar volume in use against declared capacity;
`core.simulation.VintageSimulation.harvest_block` will refuse to start a
fermentation it has no tank for rather than silently exceeding capacity,
and raises a CRITICAL alert instead.

## Scientific honesty and simplifications

GRAPPLE is a decision-support simulation, not a laboratory or a
guaranteed wine-quality predictor. Where a relationship is deliberately
simplified, it's documented in the module docstring — for example:

- **Phenology** (`vineyard/phenology.py`) uses a base-0°C "spring forcing"
  sum to trigger budbreak and a base-10°C growing-degree-day sum
  (restarted at budbreak) for everything after, because a single base-10
  sum from 1 January — fine for whole-season heat-summation classification
  — badly under-predicts how early budbreak actually happens in a cool
  maritime climate.
- **Grape chemistry** (`viticulture/ripening.py`) uses transparent
  empirical approximations for the pH/TA/malic-acid relationships, not a
  full acid-dissociation model, and exposes every named driver
  contribution (heat, solar exposure, crop load, water stress, variety
  coefficient) behind each day's Brix change (Section 70).
- **Sensory scores** (`wine/sensory.py`) are explicitly labelled `modelled
  sensory estimates`, generated with independent panel-judge noise, never
  presented as an objective measurement.
- **Native/spontaneous fermentation** (`winery/yeast.py`) stochastically
  perturbs the nominal strain parameters per batch, representing genuine
  unpredictability rather than pretending to know which flora will
  dominate.

## Tests

```bash
pytest -q                 # run everything (70+ tests)
pytest tests/test_fermentation.py -v
```

Coverage includes phenology timing, weather/frost/rainfall plausibility,
soil water balance, the yield model, harvest-timing optimisation
(including "does NOT mutate the live simulation"), pressing, fermentation
mass-balance and stuck-fermentation risk, wine chemistry, blend
optimisation, inventory mass-balance, economics, Monte Carlo
reproducibility, digital-twin calibration, the FastAPI surface and
WebSocket streaming, and the seed estate itself.

## What's deliberately out of scope for 1.0

- **A graphical/browser front-end.** The API + WebSocket layer is the
  contract a rich web control-room UI would be built against; `ui/`
  ships the text-based "control room" renderers used by the console
  experience, and every domain object is already JSON-serialisable for a
  future graphical client.
- **Persistent storage.** Everything runs in-memory per process; the
  config layer is written against a SQLite URL so a real deployment can
  add SQLAlchemy models/migrations without changing the domain layer.
- **Individual-row/individual-vine simulation.** Blocks are modelled as
  homogeneous vine populations (density + per-vine statistics), which is
  the right resolution for a block-scale digital twin and keeps Monte
  Carlo runs of thousands of vintages fast (~0.15s/vintage for the full
  10-block seed estate on a laptop).
