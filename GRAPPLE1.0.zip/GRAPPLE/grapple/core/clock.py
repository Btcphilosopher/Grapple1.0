"""
grapple.core.clock
===================

Simulation time (Section 68).

GRAPPLE advances one calendar day at a time internally — this is the
natural resolution for phenology, weather and soil-water models. "Speed"
(1x .. 1000x, or REAL TIME) only governs how fast a *wall-clock* driven run
(e.g. behind the WebSocket) advances the SimulationClock; a synchronous
`run_vintage()` call just steps every day back-to-back regardless of speed.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from enum import Enum


class SimulationSpeed(Enum):
    REAL_TIME = 0
    X1 = 1
    X5 = 5
    X10 = 10
    X50 = 50
    X100 = 100
    X1000 = 1000


@dataclass
class SimulationClock:
    """Tracks the current simulated date and vintage year."""

    current_date: dt.date
    vintage_year: int
    speed: SimulationSpeed = SimulationSpeed.X1
    day_index: int = 0  # days since vintage start (1 Jan of vintage_year by convention)
    paused: bool = False

    @classmethod
    def start_of_vintage(cls, vintage_year: int, start_month: int = 1, start_day: int = 1) -> "SimulationClock":
        return cls(current_date=dt.date(vintage_year, start_month, start_day), vintage_year=vintage_year)

    def tick(self) -> dt.date:
        """Advance one simulated day and return the new date."""
        self.current_date += dt.timedelta(days=1)
        self.day_index += 1
        return self.current_date

    def is_end_of_vintage(self) -> bool:
        """Vintage runs 1 Jan -> 31 Dec of the vintage year (Section 44)."""
        return self.current_date >= dt.date(self.vintage_year, 12, 31)

    def day_of_year(self) -> int:
        return self.current_date.timetuple().tm_yday

    def month_name(self) -> str:
        return self.current_date.strftime("%B")
