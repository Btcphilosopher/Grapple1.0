"""
grapple.core.events
====================

Lightweight event bus + Alert system (Section 58).

Any subsystem can `raise_alert(...)` during a simulation day. Alerts are
collected on the EstateState's EventLog and are what the API's `/alerts`
endpoint and the control-room dashboard read from.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict, List


class AlertLevel(str, Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"


@dataclass
class Alert:
    level: AlertLevel
    source: str          # e.g. "disease", "harvest", "winery.tank_14"
    message: str
    date: dt.date
    context: dict = field(default_factory=dict)


class EventLog:
    """Append-only alert/event log for one simulation run."""

    def __init__(self, max_len: int = 5000):
        self._alerts: List[Alert] = []
        self._max_len = max_len
        self._subscribers: List[Callable[[Alert], None]] = []

    def raise_alert(self, level: AlertLevel, source: str, message: str, date: dt.date, **context) -> Alert:
        alert = Alert(level=level, source=source, message=message, date=date, context=context)
        self._alerts.append(alert)
        if len(self._alerts) > self._max_len:
            self._alerts = self._alerts[-self._max_len:]
        for sub in self._subscribers:
            sub(alert)
        return alert

    def info(self, source: str, message: str, date: dt.date, **context) -> Alert:
        return self.raise_alert(AlertLevel.INFO, source, message, date, **context)

    def warning(self, source: str, message: str, date: dt.date, **context) -> Alert:
        return self.raise_alert(AlertLevel.WARNING, source, message, date, **context)

    def critical(self, source: str, message: str, date: dt.date, **context) -> Alert:
        return self.raise_alert(AlertLevel.CRITICAL, source, message, date, **context)

    def subscribe(self, callback: Callable[[Alert], None]) -> None:
        self._subscribers.append(callback)

    def recent(self, n: int = 50) -> List[Alert]:
        return self._alerts[-n:]

    def all(self) -> List[Alert]:
        return list(self._alerts)

    def by_level(self, level: AlertLevel) -> List[Alert]:
        return [a for a in self._alerts if a.level == level]

    def counts(self) -> Dict[str, int]:
        out = {lvl.value: 0 for lvl in AlertLevel}
        for a in self._alerts:
            out[a.level.value] += 1
        return out
