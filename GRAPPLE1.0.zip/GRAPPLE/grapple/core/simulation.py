"""
grapple.core.simulation
==========================

The vintage simulation orchestrator (Section 44). `VintageSimulation.step_day()`
propagates one simulated day through the full chain (Section 76):

    Weather -> Phenology -> Canopy -> Photosynthesis/Water/Nutrition ->
    Berry Development -> Sugar/Acid/Aroma -> Disease -> [Harvest Decision] ->
    Pressing -> Juice Chemistry -> Fermentation -> Wine Chemistry ->
    Maturation -> Wine Quality

`harvest_block()` is the explicit harvest *decision* (never automatic
inside `step_day()` unless `auto_harvest=True` is requested) that carries a
block's fruit through reception -> sorting -> destemming -> crushing ->
pressing -> juice -> fermentation, respecting winery capacity constraints
(Section 47) and building the full traceability chain (Section 50).
"""
from __future__ import annotations

import dataclasses
import datetime as dt
from dataclasses import dataclass
from typing import Dict, List, Optional

import numpy as np

from grapple.config import settings
from grapple.core.clock import SimulationClock
from grapple.core.events import AlertLevel
from grapple.core.random import RandomStreams
from grapple.core.state import EstateState
from grapple.data.recipes import get_style, get_yeast
from grapple.vineyard.blocks import Block
from grapple.vineyard.canopy import update_canopy
from grapple.vineyard.disease import update_disease_pressure
from grapple.vineyard.nutrition import assess_nutrient_status, daily_uptake
from grapple.vineyard.phenology import PhenologyStage, mark_harvested, update_phenology
from grapple.vineyard.water import update_water_balance
from grapple.vineyard.yield_model import estimate_yield
from grapple.viticulture.berry import berry_weight_g
from grapple.viticulture.flowering import update_flowering
from grapple.viticulture.harvest import assess_readiness
from grapple.viticulture.ripening import update_ripening
from grapple.viticulture.veraison import record_veraison_if_new, update_colour_change
from grapple.weather.climate import get_scenario
from grapple.weather.frost import FrostProtectionMethod, assess_frost
from grapple.weather.weather import DailyWeather, WeatherEngine
from grapple.winery.cellar import Cellar
from grapple.winery.crushing import crush
from grapple.winery.destemming import DestemmingMode, apply_destemming
from grapple.winery.fermentation import FermentationStatus, new_batch, step as ferment_step
from grapple.winery.juice import blend_juice_lots, new_juice_lot
from grapple.winery.malolactic import step_mlf
from grapple.winery.pressing import run_press
from grapple.winery.reception import receive_grapes
from grapple.winery.sorting import sort_lot
from grapple.winery.yeast import instantiate_strain

FROST_VULNERABLE_STAGES = {PhenologyStage.BUDBREAK, PhenologyStage.SHOOT_GROWTH, PhenologyStage.FLOWERING}
RIPENING_STAGES = {PhenologyStage.VERAISON, PhenologyStage.RIPENING}


@dataclass
class HarvestOutcome:
    block_id: str
    harvest_lot_id: str
    juice_lot_id: str
    fermentation_batch_id: Optional[str]
    tonnes: float
    accepted_kg: float
    juice_l: float
    refused_reason: Optional[str] = None


class VintageSimulation:
    def __init__(
        self,
        estate,
        vintage_year: int,
        seed: int = settings.default_vintage_seed,
        scenario_key: str = "average",
        fermentation_capacity_l: float = settings.default_fermentation_capacity_l,
        cellar_capacity_l: float = settings.default_cellar_capacity_l,
        bottling_capacity_bottles_per_day: float = settings.default_bottling_capacity_bottles_per_day,
        press_capacity_kg_per_day: float = settings.default_press_capacity_kg_per_day,
        latitude_deg: float = settings.latitude_deg,
    ):
        self.random = RandomStreams(seed)
        clock = SimulationClock.start_of_vintage(vintage_year)
        weather = WeatherEngine(self.random.stream("weather"), latitude_deg=latitude_deg,
                                 scenario=get_scenario(scenario_key))
        cellar = Cellar(fermentation_capacity_l, cellar_capacity_l, bottling_capacity_bottles_per_day)
        self.press_capacity_kg_per_day = press_capacity_kg_per_day
        self.state = EstateState(estate=estate, weather=weather, clock=clock, cellar=cellar)
        self.state.random = self.random

    # ------------------------------------------------------------------
    # Daily vineyard step
    # ------------------------------------------------------------------
    def step_day(self) -> dict:
        st = self.state
        today = st.clock.current_date
        day = st.weather.step(today)

        day_summary = {"date": today.isoformat(), "blocks": {}}

        for block in st.estate.blocks.values():
            self._step_block(block, day, today)
            day_summary["blocks"][block.block_id] = block.phenology.stage.value

        self._step_fermentations(today)

        st.clock.tick()
        return day_summary

    def _block_weather(self, block: Block, day: DailyWeather) -> DailyWeather:
        offset = block.local_temperature_offset_c(self.state.estate.min_elevation_m, self.state.estate.max_elevation_m)
        return dataclasses.replace(day, tmean_c=day.tmean_c + offset, tmin_c=day.tmin_c + offset,
                                    tmax_c=day.tmax_c + offset)

    def _step_block(self, block: Block, day: DailyWeather, today: dt.date) -> None:
        st = self.state
        bw = self._block_weather(block, day)
        variety = block.variety

        update_phenology(block.phenology, variety, bw.tmean_c, today)
        stage = block.phenology.stage

        solar_boost = block.solar_exposure_multiplier()
        wr = update_water_balance(block.soil, day.rainfall_mm, bw.tmean_c, bw.tmax_c, bw.tmin_c,
                                   day.solar_mj_m2 * solar_boost, block.canopy.leaf_area_index)

        growing_season = stage not in (PhenologyStage.DORMANCY, PhenologyStage.LEAF_FALL)
        if growing_season:
            daily_uptake(block.soil)
        nutrient_status = assess_nutrient_status(block.soil)

        update_canopy(block.canopy, stage, bw.tmean_c, block.soil.water_stress_index)

        tracker = st.flowering_for(block.block_id)
        update_flowering(tracker, stage, bw)
        if tracker.finalised:
            block.fruit_set_fraction = tracker.fruit_set_fraction

        veraison_record = st.veraison_for(block.block_id)
        record_veraison_if_new(veraison_record, today, stage == PhenologyStage.VERAISON)
        is_black = variety.colour == "black"
        update_colour_change(veraison_record, today, is_black, bw.tmean_c)

        # Frost (Section 12)
        if stage in FROST_VULNERABLE_STAGES:
            frost_multiplier = block.frost_pooling_multiplier(st.estate.min_elevation_m, st.estate.max_elevation_m)
            scenario_mult = st.weather.scenario.frost_risk_multiplier
            assessment = assess_frost(day.tmin_c, day.cloud_cover_pct, day.wind_ms, day.humidity_pct,
                                       frost_multiplier, self.random.stream("frost"), True,
                                       FrostProtectionMethod.NONE, scenario_mult)
            if assessment.is_frost_event:
                block.phenology.frost_damage_pct = min(100.0, block.phenology.frost_damage_pct + assessment.damage_pct)
                block.frost_damage_pct = block.phenology.frost_damage_pct
                st.events.critical("frost", f"Frost event on {block.name}: {assessment.damage_pct}% damage "
                                             f"(vine temp est. {assessment.estimated_min_vine_temp_c}C)", today,
                                    block_id=block.block_id)

        # Disease (Section 16)
        near_harvest = stage in RIPENING_STAGES
        disease_result = update_disease_pressure(block.disease, variety, block.canopy, bw.tmean_c, day.humidity_pct,
                                                   day.rainfall_mm, self.random.stream("disease"), near_harvest)
        if disease_result.overall_risk_label in ("HIGH", "SEVERE"):
            st.events.warning("disease", f"{block.name}: {disease_result.overall_risk_label} disease risk "
                                          f"(downy {disease_result.downy_risk}, powdery {disease_result.powdery_risk}, "
                                          f"botrytis {disease_result.botrytis_risk})", today, block_id=block.block_id)

        # Ripening (Section 19) — only once veraison has occurred
        if stage in RIPENING_STAGES and veraison_record.veraison_date is not None:
            days_since_v = veraison_record.days_since(today)
            days_since_fs = max(0, (today - today).days)  # placeholder; fruit-set date not tracked separately
            weight = berry_weight_g(variety, stage, days_since_fruit_set=days_since_v + 60,
                                     days_since_veraison=days_since_v, water_stress_index=block.soil.water_stress_index,
                                     recent_rain_mm_7day=day.rainfall_mm * 5)
            crop_load_factor = 1.0 + max(0.0, (1.0 - block.canopy.bunch_thinned_fraction) - block.canopy.photosynthetic_capacity())
            update_ripening(block.chemistry, variety, stage, days_since_v, bw.tmean_c, bw.tmin_c, bw.tmax_c,
                             day.solar_mj_m2 * solar_boost, block.canopy.fruit_exposure, crop_load_factor,
                             block.soil.water_stress_index, nutrient_status.nitrogen_status, weight)

    # ------------------------------------------------------------------
    # Harvest decision + winery pipeline (Sections 20-25, 47, 50)
    # ------------------------------------------------------------------
    def harvest_readiness(self, block_id: str, style_key: str):
        block = self.state.estate.get_block(block_id)
        return assess_readiness(block, get_style(style_key))

    def harvest_block(
        self, block_id: str, style_key: str = "traditional_sparkling", mechanical: bool = False,
        yeast_key: str = "ec1118", fermentation_temp_c: float = 16.0,
        destem_mode: DestemmingMode = DestemmingMode.WHOLE_CLUSTER,
    ) -> HarvestOutcome:
        st = self.state
        today = st.clock.current_date
        block = st.estate.get_block(block_id)
        variety = block.variety

        disease_idx = max(block.disease.downy_mildew_pressure, block.disease.powdery_mildew_pressure,
                           block.disease.botrytis_pressure)
        yield_est = estimate_yield(
            variety, block.vines, today.year, block.area_ha, fruit_set_fraction=block.fruit_set_fraction,
            berry_weight_g=block.chemistry.berry_weight_g or variety.berry_weight_g_mean,
            bunch_thinned_fraction=block.canopy.bunch_thinned_fraction,
            frost_loss_pct=block.frost_damage_pct, disease_loss_pct=disease_idx * 25.0,
        )
        weight_kg = yield_est.net_kg_per_ha * block.area_ha

        # Section 47: winery cannot process more than press capacity in a day.
        if weight_kg > self.press_capacity_kg_per_day:
            st.events.warning("winery", f"Harvest of {block.name} ({weight_kg:.0f}kg) exceeds daily press capacity "
                                         f"({self.press_capacity_kg_per_day:.0f}kg) — split across multiple days "
                                         f"in a real harvest plan.", today, block_id=block_id)

        lot = receive_grapes(block_id, block.variety_key, today, weight_kg, block.chemistry.brix, block.chemistry.ph,
                              block.chemistry.ta_gl, intake_temperature_c=14.0, disease_risk_index=disease_idx,
                              mechanical_harvest=mechanical)
        st.harvest_lots[lot.lot_id] = lot

        sorted_result = sort_lot(lot)
        destem = apply_destemming(destem_mode)
        crushed = crush(sorted_result.accepted_kg, destem)
        press_result = run_press(f"PRESS-{lot.lot_id}", sorted_result.accepted_kg, crushed, lot.brix, lot.ph, lot.ta_gl)
        st.cellar.trace.link(press_result.press_id, lot.lot_id, "pressed_from")

        keep_fractions = press_result.fractions[:2]  # free-run + press-1 by default (Section 23)
        juice_lots = [new_juice_lot(lot.lot_id, press_result.press_id, f, yan_mg_l=block.chemistry.yan_mg_l or 180.0,
                                     temperature_c=lot.intake_temperature_c) for f in keep_fractions]
        for jl in juice_lots:
            st.juice_lots[jl.juice_lot_id] = jl
            st.cellar.trace.link(jl.juice_lot_id, press_result.press_id, "pressed_from")

        juice = blend_juice_lots(juice_lots)
        st.juice_lots[juice.juice_lot_id] = juice

        mark_harvested(block.phenology, today)
        block.harvested = True
        block.harvest_date = today.isoformat()

        tank = st.cellar.find_free_tank(juice.volume_l)
        if tank is None:
            st.events.critical("winery", f"No free fermentation tank for {juice.volume_l:.0f}L from {block.name} "
                                          f"— fermentation capacity exceeded (Section 47).", today, block_id=block_id)
            return HarvestOutcome(block_id=block_id, harvest_lot_id=lot.lot_id, juice_lot_id=juice.juice_lot_id,
                                   fermentation_batch_id=None, tonnes=weight_kg / 1000.0,
                                   accepted_kg=sorted_result.accepted_kg, juice_l=juice.volume_l,
                                   refused_reason="no_tank_capacity")

        tank.occupy(juice.juice_lot_id)
        strain = instantiate_strain(yeast_key, self.random.stream("yeast"))
        batch = new_batch(juice, tank.equipment_id, strain, temperature_target_c=fermentation_temp_c)
        batch.cooling_capacity_adequate = True
        st.fermentation_batches[batch.batch_id] = batch
        st.cellar.trace.link(batch.batch_id, juice.juice_lot_id, "fermented_from")

        st.events.info("harvest", f"Harvested {block.name}: {weight_kg:.0f}kg -> {juice.volume_l:.0f}L juice, "
                                   f"fermentation {batch.batch_id} started in {tank.equipment_id}.", today,
                        block_id=block_id, style=style_key)

        return HarvestOutcome(block_id=block_id, harvest_lot_id=lot.lot_id, juice_lot_id=juice.juice_lot_id,
                               fermentation_batch_id=batch.batch_id, tonnes=weight_kg / 1000.0,
                               accepted_kg=sorted_result.accepted_kg, juice_l=juice.volume_l)

    def _step_fermentations(self, today: dt.date) -> None:
        for batch in self.state.fermentation_batches.values():
            if batch.status not in (FermentationStatus.COMPLETE, FermentationStatus.STUCK):
                snap = ferment_step(batch, self.random.stream("fermentation"), ambient_c=self.state.weather.last().tmean_c)
                if snap.status == FermentationStatus.STUCK:
                    self.state.events.critical("fermentation", f"Batch {batch.batch_id} appears STUCK at day "
                                                                 f"{batch.day} ({batch.sugar_gl:.1f}g/L sugar "
                                                                 f"remaining).", today, batch_id=batch.batch_id)
                elif snap.status == FermentationStatus.COMPLETE and batch.day > 1 and len(batch.history) >= 2 \
                        and batch.history[-2].status != FermentationStatus.COMPLETE:
                    tank = self.state.cellar.tanks.get(batch.tank_id)
                    self.state.events.info("fermentation", f"Batch {batch.batch_id} completed: "
                                                             f"{batch.ethanol_pct:.2f}% ABV.", today,
                                            batch_id=batch.batch_id)
                    if tank:
                        tank.start_cleaning(hours=0.0)  # frees the tank; cleaning workflow tracked by scheduler

    # Note: malolactic fermentation (Section 28) is an explicit winemaker decision made
    # per batch after primary fermentation completes — see winery.malolactic.step_mlf,
    # driven from the API/optimisation layer rather than auto-applied every day here.

    # ------------------------------------------------------------------
    def run_days(self, n: int) -> List[dict]:
        return [self.step_day() for _ in range(n)]

    def run_to_date(self, target: dt.date) -> List[dict]:
        out = []
        while self.state.clock.current_date < target:
            out.append(self.step_day())
        return out

    def run_vintage(self, harvest_plan: Optional[Dict[dt.date, List[str]]] = None) -> "VintageReport":
        """
        Run the full 1 Jan -> 31 Dec vintage (Section 44). `harvest_plan` maps a date to the
        list of block_ids to harvest that day; if omitted, blocks are auto-harvested the first
        day their readiness for `traditional_sparkling` crosses 80% (a simple default policy —
        real decisions should use `optimisation.harvest` instead).
        """
        harvest_plan = harvest_plan or {}
        outcomes: List[HarvestOutcome] = []
        target = dt.date(self.state.clock.vintage_year, 12, 31)

        while self.state.clock.current_date < target:
            today = self.state.clock.current_date
            self.step_day()

            for block_id in harvest_plan.get(today, []):
                block = self.state.estate.blocks.get(block_id)
                if block and not block.harvested:
                    outcomes.append(self.harvest_block(block_id))

            if not harvest_plan:
                for block in self.state.estate.blocks.values():
                    if block.harvested or block.phenology.stage.value not in ("Veraison", "Ripening"):
                        continue
                    readiness = self.harvest_readiness(block.block_id, "traditional_sparkling")
                    # Simple default fallback policy: pick once readiness looks reasonable, or force
                    # a decision by mid-November regardless (a real grower will not leave fruit hanging
                    # indefinitely into deteriorating autumn conditions). Real harvest-timing decisions
                    # should go through optimisation.harvest (Section 46) rather than this fallback.
                    if readiness.overall_readiness_pct >= 55.0 or today >= dt.date(today.year, 11, 15):
                        outcomes.append(self.harvest_block(block.block_id))

        return build_vintage_report(self, outcomes)


@dataclass
class VintageReport:
    vintage_year: int
    total_area_ha: float
    blocks_harvested: int
    total_tonnes: float
    average_brix: float
    average_ph: float
    average_ta_gl: float
    frost_events: int
    disease_critical_events: int
    fermentations_started: int
    fermentations_stuck: int
    outcomes: List[HarvestOutcome]


def build_vintage_report(sim: "VintageSimulation", outcomes: List[HarvestOutcome]) -> VintageReport:
    st = sim.state
    harvested_blocks = [st.estate.get_block(o.block_id) for o in outcomes]
    total_tonnes = sum(o.tonnes for o in outcomes)

    def _avg(values: List[float]) -> float:
        return round(sum(values) / len(values), 3) if values else 0.0

    frost_events = len([a for a in st.events.all() if a.source == "frost"])
    disease_critical = len([a for a in st.events.all() if a.source == "disease" and a.level == AlertLevel.CRITICAL])
    stuck = len([b for b in st.fermentation_batches.values() if b.status == FermentationStatus.STUCK])

    return VintageReport(
        vintage_year=st.clock.vintage_year, total_area_ha=st.estate.total_area_ha,
        blocks_harvested=len(outcomes), total_tonnes=round(total_tonnes, 2),
        average_brix=_avg([b.chemistry.brix for b in harvested_blocks]),
        average_ph=_avg([b.chemistry.ph for b in harvested_blocks]),
        average_ta_gl=_avg([b.chemistry.ta_gl for b in harvested_blocks]),
        frost_events=frost_events, disease_critical_events=disease_critical,
        fermentations_started=len(st.fermentation_batches),
        fermentations_stuck=stuck, outcomes=outcomes,
    )
