"""
grapple.core.random
====================

Seeded, reproducible randomness (Section 69).

A vintage is identified by an integer "Vintage Seed". From that single seed
we derive independent numpy Generator streams for each subsystem (weather,
disease, yeast/fermentation, sensors, economics...) so that:

  * the same seed always reproduces the same vintage exactly (deterministic
    mode), and
  * subsystems don't accidentally correlate with each other just because
    they happen to draw from the same stream in the same order.

Use `RandomStreams(seed)` and then `.stream("weather")`, `.stream("disease")`
etc. New stream names are derived deterministically from the master seed via
NumPy's SeedSequence.spawn-like hashing, so callers never have to pre-declare
every stream name up front.
"""
from __future__ import annotations

import hashlib
from typing import Dict

import numpy as np


def _substream_seed(master_seed: int, name: str) -> int:
    """Deterministically derive a 63-bit sub-seed for `name` from the master seed."""
    h = hashlib.sha256(f"{master_seed}:{name}".encode("utf-8")).digest()
    return int.from_bytes(h[:8], "big") & 0x7FFF_FFFF_FFFF_FFFF


class RandomStreams:
    """A registry of independent, reproducible random streams keyed by name."""

    def __init__(self, seed: int, deterministic: bool = True):
        self.seed = int(seed)
        self.deterministic = deterministic
        self._generators: Dict[str, np.random.Generator] = {}

    def stream(self, name: str) -> np.random.Generator:
        if not self.deterministic:
            # Non-deterministic mode: still namespaced, but re-seeded from OS entropy.
            return np.random.default_rng()
        if name not in self._generators:
            self._generators[name] = np.random.default_rng(_substream_seed(self.seed, name))
        return self._generators[name]

    def child(self, name: str) -> "RandomStreams":
        """A derived RandomStreams (e.g. per Monte Carlo trial) with a distinct seed."""
        return RandomStreams(_substream_seed(self.seed, name), self.deterministic)
