"""
grapple.core.state
=====================

`EstateState` is the single container for "everything GRAPPLE currently
knows about the estate" (Section 2) — the vineyard, the weather engine,
the winery cellar, the laboratory, inventory ledgers and event log. The
simulation orchestrator (`core.simulation.VintageSimulation`) mutates this
object day by day; the API/UI layers read `snapshot()` off it.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional

from grapple.core.clock import SimulationClock
from grapple.core.events import EventLog
from grapple.core.random import RandomStreams
from grapple.economics.capex import CapexRegister
from grapple.laboratory.analysis import LabAnalysisService
from grapple.logistics.inventory import InventoryLedger
from grapple.logistics.warehouse import Warehouse
from grapple.vineyard.estate import Estate
from grapple.viticulture.flowering import FloweringTracker
from grapple.viticulture.veraison import VeraisonRecord
from grapple.weather.weather import WeatherEngine
from grapple.winery.cellar import Cellar
from grapple.winery.fermentation import FermentationBatch
from grapple.winery.juice import JuiceLot
from grapple.winery.reception import HarvestLot
from grapple.winery.sparkling import SparklingBatch


@dataclass
class EstateState:
    estate: Estate
    weather: WeatherEngine
    clock: SimulationClock
    events: EventLog = field(default_factory=EventLog)
    random: RandomStreams = field(default_factory=lambda: RandomStreams(0))
    cellar: Optional[Cellar] = None
    lab: LabAnalysisService = field(default_factory=LabAnalysisService)
    inventory: InventoryLedger = field(default_factory=InventoryLedger)
    warehouse: Optional[Warehouse] = None
    capex: CapexRegister = field(default_factory=CapexRegister)

    # Per-block tracking
    veraison_records: Dict[str, VeraisonRecord] = field(default_factory=dict)
    flowering_trackers: Dict[str, FloweringTracker] = field(default_factory=dict)

    # Traceable entities
    harvest_lots: Dict[str, HarvestLot] = field(default_factory=dict)
    juice_lots: Dict[str, JuiceLot] = field(default_factory=dict)
    fermentation_batches: Dict[str, FermentationBatch] = field(default_factory=dict)
    sparkling_batches: Dict[str, SparklingBatch] = field(default_factory=dict)
    bottled_batches: Dict[str, dict] = field(default_factory=dict)

    def veraison_for(self, block_id: str) -> VeraisonRecord:
        if block_id not in self.veraison_records:
            self.veraison_records[block_id] = VeraisonRecord()
        return self.veraison_records[block_id]

    def flowering_for(self, block_id: str) -> FloweringTracker:
        if block_id not in self.flowering_trackers:
            self.flowering_trackers[block_id] = FloweringTracker()
        return self.flowering_trackers[block_id]

    def snapshot(self) -> dict:
        """A serialisable summary of current estate state, for the API/dashboards."""
        last_weather = self.weather.last()
        return {
            "vintage_year": self.clock.vintage_year,
            "date": self.clock.current_date.isoformat(),
            "day_of_year": self.clock.day_of_year(),
            "estate": self.estate.summary(),
            "weather_today": None if last_weather is None else {
                "tmean_c": last_weather.tmean_c, "tmin_c": last_weather.tmin_c, "tmax_c": last_weather.tmax_c,
                "rainfall_mm": last_weather.rainfall_mm, "humidity_pct": last_weather.humidity_pct,
                "wind_ms": last_weather.wind_ms, "solar_mj_m2": last_weather.solar_mj_m2,
                "cloud_cover_pct": last_weather.cloud_cover_pct, "provenance": last_weather.provenance.value,
            },
            "blocks": {
                b.block_id: {
                    "name": b.name, "variety": b.variety.name, "area_ha": b.area_ha,
                    "stage": b.phenology.stage.value, "brix": b.chemistry.brix, "ph": b.chemistry.ph,
                    "ta_gl": b.chemistry.ta_gl, "disease_overall": max(
                        b.disease.downy_mildew_pressure, b.disease.powdery_mildew_pressure, b.disease.botrytis_pressure
                    ), "harvested": b.harvested,
                } for b in self.estate.blocks.values()
            },
            "cellar_capacity": self.cellar.capacity_summary() if self.cellar else None,
            "active_fermentations": len([b for b in self.fermentation_batches.values()
                                          if b.status.value in ("lag_phase", "active", "slowing")]),
            "alerts_recent": [
                {"level": a.level.value, "source": a.source, "message": a.message, "date": a.date.isoformat()}
                for a in self.events.recent(10)
            ],
        }
