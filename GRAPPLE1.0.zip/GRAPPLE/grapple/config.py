"""
grapple.config
==============

Central configuration for GRAPPLE 1.0.

Design note (Section 77 — Scientific Honesty):
GRAPPLE distinguishes between OBSERVED, MODELLED, ESTIMATED, SYNTHETIC and
PREDICTED data throughout. The `DataProvenance` enum below is imported
everywhere a value needs to declare which of those categories it belongs to,
so that the UI/API never presents a simulated number as if it were a lab
measurement.
"""
from __future__ import annotations

from enum import Enum
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class DataProvenance(str, Enum):
    """Every quantity flowing through GRAPPLE is tagged with its origin."""

    OBSERVED = "observed"       # a real sensor / lab measurement ingested from the field
    MODELLED = "modelled"       # produced by a transparent physical/process model
    ESTIMATED = "estimated"     # a statistical estimate derived from modelled + observed data
    SYNTHETIC = "synthetic"     # generated for demonstration purposes (no real vineyard behind it)
    PREDICTED = "predicted"     # a forward-looking projection with an explicit uncertainty range


class Settings(BaseSettings):
    """Runtime configuration, overridable via environment variables (prefix GRAPPLE_)."""

    model_config = SettingsConfigDict(env_prefix="GRAPPLE_", env_file=".env", extra="ignore")

    app_name: str = "GRAPPLE 1.0"
    environment: str = "development"

    # --- Persistence -------------------------------------------------
    # SQLite is used for development; the schema (grapple/core + SQLAlchemy
    # models referenced from digital_twin/synchronization.py) is written to
    # be PostgreSQL-compatible so a real estate can move to Postgres by
    # changing this URL alone.
    database_url: str = "sqlite:///./grapple.db"

    # --- Simulation defaults ------------------------------------------
    default_vintage_seed: int = 20310101
    simulation_start_month: int = 1
    simulation_start_day: int = 1

    # --- English climate baseline (southern England, ~51.0N) ----------
    # Used by weather.climate as the "Average Vintage" anchor. Sources:
    # broadly representative of Met Office 1991-2020 averages for
    # southern England wine-growing areas (Sussex / Kent / Hampshire
    # chalk belt). These are deliberately approximate and clearly
    # SYNTHETIC baseline parameters, not a specific station's data.
    latitude_deg: float = 51.0
    longitude_deg: float = -0.4
    elevation_m: float = 60.0

    # --- Winery capacity (seed estate defaults) ------------------------
    default_press_capacity_kg_per_day: float = 40_000.0
    default_fermentation_capacity_l: float = 220_000.0
    default_cellar_capacity_l: float = 300_000.0
    default_bottling_capacity_bottles_per_day: float = 12_000.0

    # --- Paths ----------------------------------------------------------
    data_dir: Path = Path(__file__).parent / "data"


settings = Settings()
