"""
grapple.weather.frost
========================

Spring frost model (Section 12). English vineyards are most at risk of
*radiative* frost: clear skies (low cloud -> rapid nighttime radiative
cooling), low wind (no mixing to bring warmer air down) and low humidity,
combined with a terrain-driven cold-air-pooling multiplier from the block
(see `vineyard.blocks.Block.frost_pooling_multiplier`).

Only budbreak-to-flowering stages are frost-vulnerable to any meaningful
degree; damage severity also depends on how far below 0C the estimated
minimum temperature at the vine (not the screen-height forecast minimum)
falls.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

import numpy as np


class FrostProtectionMethod(str, Enum):
    NONE = "none"
    PASSIVE = "passive"       # site selection / air drainage management — already reflected in terrain multiplier
    WIND_MACHINE = "wind_machine"
    SPRINKLERS = "sprinklers"
    CANDLES_HEATERS = "candles_heaters"
    FROST_FANS = "frost_fans"


# capital cost (GBP, one-off, per hectare protected) and operating cost (GBP per protection night, per ha)
PROTECTION_ECONOMICS = {
    FrostProtectionMethod.NONE: (0.0, 0.0, 0.0),
    FrostProtectionMethod.PASSIVE: (0.0, 0.0, 0.15),
    FrostProtectionMethod.WIND_MACHINE: (18000.0, 45.0, 0.65),
    FrostProtectionMethod.SPRINKLERS: (9000.0, 60.0, 0.75),
    FrostProtectionMethod.CANDLES_HEATERS: (2500.0, 180.0, 0.55),
    FrostProtectionMethod.FROST_FANS: (22000.0, 40.0, 0.7),
}
# tuple = (capex_per_ha, opex_per_protection_night_per_ha, effectiveness_fraction)


@dataclass
class FrostAssessment:
    estimated_min_vine_temp_c: float
    frost_risk_probability: float   # 0-1, probability tonight produces a damaging frost at the vine
    is_frost_event: bool
    damage_pct: float               # % of primary buds/shoots lost, after any protection applied
    protection_effectiveness_applied: float


def estimate_frost_risk_probability(
    tmin_c: float,
    cloud_cover_pct: float,
    wind_ms: float,
    humidity_pct: float,
    terrain_multiplier: float,
    scenario_multiplier: float = 1.0,
) -> float:
    """A 0-1 heuristic risk probability, highest on clear (low cloud), still, dry, cold nights."""
    if tmin_c > 4.0:
        return 0.0
    cold_term = max(0.0, (4.0 - tmin_c) / 6.0)
    clear_sky_term = max(0.0, (60.0 - cloud_cover_pct) / 60.0)
    calm_term = max(0.0, (3.0 - wind_ms) / 3.0)
    dry_term = max(0.0, (75.0 - humidity_pct) / 75.0) * 0.5 + 0.5  # dry air radiates heat away faster, but weighted less

    base = 0.5 * cold_term + 0.25 * clear_sky_term + 0.15 * calm_term + 0.10 * dry_term
    risk = base * terrain_multiplier * scenario_multiplier
    return max(0.0, min(1.0, risk))


def assess_frost(
    tmin_c: float,
    cloud_cover_pct: float,
    wind_ms: float,
    humidity_pct: float,
    terrain_multiplier: float,
    rng: np.random.Generator,
    frost_vulnerable_stage: bool,
    protection: FrostProtectionMethod = FrostProtectionMethod.NONE,
    scenario_multiplier: float = 1.0,
) -> FrostAssessment:
    # Radiative cooling can bring the vine canopy several degrees below screen-height minimum on a clear, calm night.
    clear_calm = max(0.0, (60 - cloud_cover_pct) / 60) * max(0.0, (3 - wind_ms) / 3)
    radiative_depression = 2.5 * clear_calm
    vine_temp = tmin_c - radiative_depression

    risk = estimate_frost_risk_probability(tmin_c, cloud_cover_pct, wind_ms, humidity_pct,
                                            terrain_multiplier, scenario_multiplier)

    is_event = frost_vulnerable_stage and vine_temp < 0.0 and rng.random() < max(risk, 0.0)

    damage = 0.0
    effectiveness_applied = 0.0
    if is_event:
        severity = min(1.0, abs(vine_temp) / 5.0)   # -5C or colder ~= total exposed-bud loss without protection
        _, _, effectiveness = PROTECTION_ECONOMICS[protection]
        effectiveness_applied = effectiveness
        damage = max(0.0, severity * (1.0 - effectiveness) * 100.0)

    return FrostAssessment(
        estimated_min_vine_temp_c=round(vine_temp, 1),
        frost_risk_probability=round(risk, 3),
        is_frost_event=is_event,
        damage_pct=round(damage, 1),
        protection_effectiveness_applied=effectiveness_applied,
    )


def protection_cost_gbp(method: FrostProtectionMethod, area_ha: float, protection_nights: int, include_capex: bool = False) -> float:
    capex, opex, _ = PROTECTION_ECONOMICS[method]
    total = opex * protection_nights * area_ha
    if include_capex:
        total += capex * area_ha
    return round(total, 2)
