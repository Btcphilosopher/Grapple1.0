"""
grapple.weather.climate
=========================

Climate scenarios (Section 10) — wholesale modifiers applied on top of the
southern-England monthly normals (`grapple.data.weather`). A scenario is
just a bundle of offsets/multipliers, so new ones are trivial to add and
thousands of synthetic vintages can be drawn by sampling scenario mixtures
(see `optimisation.monte_carlo`).
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


@dataclass(frozen=True)
class ClimateScenario:
    key: str
    name: str
    temp_offset_c: float = 0.0          # added to every day's mean/min/max temperature
    rainfall_multiplier: float = 1.0
    variability_multiplier: float = 1.0  # scales day-to-day stochastic noise
    frost_risk_multiplier: float = 1.0
    sunshine_multiplier: float = 1.0
    description: str = ""


SCENARIOS: dict[str, ClimateScenario] = {}


def register_scenario(s: ClimateScenario) -> None:
    SCENARIOS[s.key] = s


def get_scenario(key: str) -> ClimateScenario:
    try:
        return SCENARIOS[key]
    except KeyError as e:
        raise KeyError(f"Unknown climate scenario '{key}'. Registered: {sorted(SCENARIOS)}") from e


for _s in [
    ClimateScenario("average", "Average Vintage", description="Southern-England climate normals, unmodified."),
    ClimateScenario("cool", "Cool Vintage", temp_offset_c=-1.3, sunshine_multiplier=0.85, frost_risk_multiplier=1.3,
                     description="Below-average heat accumulation; delayed ripening, elevated frost risk."),
    ClimateScenario("warm", "Warm Vintage", temp_offset_c=1.6, sunshine_multiplier=1.15, frost_risk_multiplier=0.6,
                     description="Above-average heat accumulation; earlier, riper harvest."),
    ClimateScenario("wet", "Wet Vintage", rainfall_multiplier=1.45, sunshine_multiplier=0.85, variability_multiplier=1.2,
                     description="Elevated rainfall throughout the season; higher disease pressure, dilution risk."),
    ClimateScenario("dry", "Dry Vintage", rainfall_multiplier=0.55, sunshine_multiplier=1.1,
                     description="Below-average rainfall; water stress risk on free-draining soils."),
    ClimateScenario("late_frost", "Late Spring Frost", frost_risk_multiplier=2.5, temp_offset_c=-0.2,
                     description="Elevated late-frost probability around budbreak/early shoot growth."),
    ClimateScenario("warm_autumn", "Warm Autumn", temp_offset_c=0.4, rainfall_multiplier=0.8,
                     description="Extended warm, dry autumn — favours late-season ripening and reduces botrytis pressure. "
                                 "(Modelled as a flat seasonal shift; a more granular month-weighted version could bias "
                                 "the offset toward Sep-Nov specifically.)"),
    ClimateScenario("wet_harvest", "Wet Harvest", rainfall_multiplier=1.6, variability_multiplier=1.3,
                     description="Heavy rainfall concentrated around the harvest window; dilution and botrytis risk."),
    ClimateScenario("exceptional", "Exceptional Vintage", temp_offset_c=1.2, sunshine_multiplier=1.2,
                     rainfall_multiplier=0.75, frost_risk_multiplier=0.5,
                     description="A rare, highly favourable combination — warm, sunny, low disease pressure."),
]:
    register_scenario(_s)
