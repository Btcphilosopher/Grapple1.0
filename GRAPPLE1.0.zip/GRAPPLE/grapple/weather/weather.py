"""
grapple.weather.weather
==========================

The daily weather engine (Section 9). Generates a full English weather
day — temperature, rainfall, humidity, wind, solar radiation, cloud cover,
soil temperature — anchored to the southern-England monthly normals
(`grapple.data.weather`) and perturbed by an AR(1) stochastic process so
that warm spells and cold snaps persist realistically across several days,
rather than each day being drawn independently.

Three related but distinct outputs (Section 9):
  * `WeatherEngine.step()` — the "Simulated Vintage" (stochastic, seeded).
  * `WeatherEngine.from_observations()` — ingests a "Historical Vintage" or
    real observed record (DataProvenance.OBSERVED) day by day, disabling
    the stochastic generator for those days.
  * `weather.forecast` — short-range probabilistic look-ahead built from
    the engine's current autocorrelated state.
"""
from __future__ import annotations

import datetime as dt
import math
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from grapple.config import DataProvenance
from grapple.data.weather import SOUTHERN_ENGLAND_NORMALS, MonthlyNormal
from grapple.weather.climate import ClimateScenario, get_scenario
from grapple.weather.rainfall import sample_rainfall_mm


@dataclass
class DailyWeather:
    date: dt.date
    tmean_c: float
    tmin_c: float
    tmax_c: float
    rainfall_mm: float
    humidity_pct: float
    wind_ms: float
    solar_mj_m2: float
    cloud_cover_pct: float
    soil_temp_c: float
    provenance: DataProvenance = DataProvenance.SYNTHETIC


def _clear_sky_radiation_mj_m2(day_of_year: int, latitude_deg: float) -> float:
    """Simplified extraterrestrial-radiation-based clear-sky solar estimate."""
    lat = math.radians(latitude_deg)
    decl = math.radians(23.45) * math.sin(math.radians(360 * (284 + day_of_year) / 365))
    try:
        sunset_angle = math.acos(-math.tan(lat) * math.tan(decl))
    except ValueError:
        sunset_angle = math.pi / 2
    dr = 1 + 0.033 * math.cos(math.radians(360 * day_of_year / 365))
    ra = (24 * 60 / math.pi) * 0.0820 * dr * (
        sunset_angle * math.sin(lat) * math.sin(decl) + math.cos(lat) * math.cos(decl) * math.sin(sunset_angle)
    )
    return max(0.5, ra * 0.75)  # atmospheric transmission factor for a typical clear UK sky


class WeatherEngine:
    """Stateful day-by-day weather generator for one estate/vintage."""

    def __init__(self, rng: np.random.Generator, latitude_deg: float = 51.0,
                 scenario: Optional[ClimateScenario] = None):
        self.rng = rng
        self.latitude_deg = latitude_deg
        self.scenario = scenario or get_scenario("average")
        self._temp_anomaly = 0.0    # AR(1) state, degrees C
        self._was_wet_yesterday = False
        self.history: list[DailyWeather] = []

    def _normal(self, date: dt.date) -> MonthlyNormal:
        return SOUTHERN_ENGLAND_NORMALS[date.month]

    def step(self, date: dt.date) -> DailyWeather:
        """Generate one stochastic simulated day and append it to history."""
        normal = self._normal(date)

        # AR(1) temperature anomaly: persists day to day, mean-reverting to zero.
        phi = 0.75
        noise_sd = 1.8 * self.scenario.variability_multiplier
        self._temp_anomaly = phi * self._temp_anomaly + self.rng.normal(0, noise_sd)

        tmean = (normal.tmin_c + normal.tmax_c) / 2 + self.scenario.temp_offset_c + self._temp_anomaly
        trange = max(2.0, (normal.tmax_c - normal.tmin_c) * (1 + 0.1 * self.rng.normal()))
        tmin = tmean - trange / 2
        tmax = tmean + trange / 2

        rainfall, is_wet = sample_rainfall_mm(
            normal, self._was_wet_yesterday, self.rng,
            rainfall_multiplier=self.scenario.rainfall_multiplier,
            variability_multiplier=self.scenario.variability_multiplier,
        )
        self._was_wet_yesterday = is_wet

        cloud = normal.cloud_cover_pct + (25 if is_wet else -8) + self.rng.normal(0, 8)
        cloud = max(5.0, min(100.0, cloud / max(0.3, self.scenario.sunshine_multiplier)))

        humidity = normal.humidity_pct + (10 if is_wet else -4) + self.rng.normal(0, 5)
        humidity = max(30.0, min(100.0, humidity))

        wind = max(0.3, normal.wind_ms + self.rng.normal(0, 1.1))

        clear_sky = _clear_sky_radiation_mj_m2(date.timetuple().tm_yday, self.latitude_deg)
        solar = clear_sky * (1 - 0.75 * cloud / 100.0) * self.scenario.sunshine_multiplier
        solar = max(0.3, solar)

        # Soil temperature lags air temperature (10-day damped rolling average).
        if self.history:
            prev_soil = self.history[-1].soil_temp_c
        else:
            prev_soil = tmean
        soil_temp = prev_soil + (tmean - prev_soil) * 0.12

        day = DailyWeather(
            date=date, tmean_c=round(tmean, 2), tmin_c=round(tmin, 2), tmax_c=round(tmax, 2),
            rainfall_mm=rainfall, humidity_pct=round(humidity, 1), wind_ms=round(wind, 2),
            solar_mj_m2=round(solar, 2), cloud_cover_pct=round(cloud, 1), soil_temp_c=round(soil_temp, 2),
            provenance=DataProvenance.SYNTHETIC,
        )
        self.history.append(day)
        return day

    def ingest_observation(self, day: DailyWeather) -> None:
        """Ingest a real, OBSERVED weather day (Section 40/64) instead of generating one."""
        day.provenance = DataProvenance.OBSERVED
        self._was_wet_yesterday = day.rainfall_mm >= 1.0
        self._temp_anomaly = day.tmean_c - (self._normal(day.date).tmin_c + self._normal(day.date).tmax_c) / 2
        self.history.append(day)

    def last(self) -> Optional[DailyWeather]:
        return self.history[-1] if self.history else None

    def series(self, start: Optional[dt.date] = None, end: Optional[dt.date] = None) -> list[DailyWeather]:
        out = self.history
        if start:
            out = [d for d in out if d.date >= start]
        if end:
            out = [d for d in out if d.date <= end]
        return out
