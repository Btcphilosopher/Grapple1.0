"""
grapple.weather.rainfall
===========================

Stochastic daily rainfall generator (Section 9). Two-stage model calibrated
to the monthly normals:

  1. A first-order Markov chain for wet/dry-day occurrence (rain tends to
     cluster in England — a wet day is more likely to follow another wet
     day than the unconditional monthly wet-day frequency would suggest).
  2. Gamma-distributed rainfall amount on wet days, whose mean matches the
     monthly normal's (rain_mm / rain_days).
"""
from __future__ import annotations

import numpy as np

from grapple.data.weather import MonthlyNormal, DAYS_IN_MONTH


def wet_day_probability(normal: MonthlyNormal) -> float:
    return min(0.95, normal.rain_days / DAYS_IN_MONTH[normal.month - 1])


def transition_probabilities(normal: MonthlyNormal, persistence: float = 0.35) -> tuple[float, float]:
    """
    Returns (P(wet | wet yesterday), P(wet | dry yesterday)) such that the
    unconditional wet-day probability still matches the monthly normal.
    `persistence` controls how much more likely rain is to continue than to start.
    """
    p = wet_day_probability(normal)
    p_wet_given_wet = min(0.98, p + persistence * (1 - p))
    # Solve for p_wet_given_dry so the stationary probability equals p:
    # p = p_wet_given_wet * p + p_wet_given_dry * (1 - p)  =>
    if p >= 0.999:
        p_wet_given_dry = p
    else:
        p_wet_given_dry = max(0.0, (p - p_wet_given_wet * p) / (1 - p))
    return p_wet_given_wet, p_wet_given_dry


def sample_rainfall_mm(
    normal: MonthlyNormal,
    was_wet_yesterday: bool,
    rng: np.random.Generator,
    rainfall_multiplier: float = 1.0,
    variability_multiplier: float = 1.0,
) -> tuple[float, bool]:
    """Returns (rainfall_mm, is_wet_day)."""
    p_wet_given_wet, p_wet_given_dry = transition_probabilities(normal)
    p_today = p_wet_given_wet if was_wet_yesterday else p_wet_given_dry
    is_wet = rng.random() < p_today
    if not is_wet:
        return 0.0, False

    mean_amount = max(0.5, (normal.rain_mm / max(1.0, normal.rain_days)) * rainfall_multiplier)
    # Gamma shape controls skew; lower shape = more heavy-rain outliers.
    shape = 1.3 / max(0.3, variability_multiplier)
    scale = mean_amount / shape
    amount = float(rng.gamma(shape, scale))
    return round(amount, 1), True
