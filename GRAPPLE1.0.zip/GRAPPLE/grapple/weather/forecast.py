"""
grapple.weather.forecast
===========================

Short-range probabilistic forecast (Section 9, 43). Blends the monthly
climate normal with the current AR(1) anomaly (persistence), widening the
uncertainty band the further ahead the forecast looks — a transparent,
honest stand-in for a numerical weather-prediction feed that a real estate
would eventually substitute via the REST/CSV ingestion path (Section 40).
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from typing import List

from grapple.data.weather import SOUTHERN_ENGLAND_NORMALS
from grapple.weather.weather import WeatherEngine


@dataclass
class ForecastDay:
    date: dt.date
    tmean_c: float
    tmean_uncertainty_c: float
    rain_probability: float
    expected_rainfall_mm: float


def generate_forecast(engine: WeatherEngine, start_date: dt.date, days: int = 7) -> List[ForecastDay]:
    """
    Persistence-decay forecast: today's anomaly carries forward but decays
    toward the climate normal, and uncertainty grows with lead time
    (Section 43 — never claim more precision than the lead time supports).
    """
    last = engine.last()
    current_anomaly = (last.tmean_c - (
        SOUTHERN_ENGLAND_NORMALS[last.date.month].tmin_c + SOUTHERN_ENGLAND_NORMALS[last.date.month].tmax_c
    ) / 2) if last else 0.0

    out: List[ForecastDay] = []
    for lead in range(1, days + 1):
        date = start_date + dt.timedelta(days=lead)
        normal = SOUTHERN_ENGLAND_NORMALS[date.month]
        decay = 0.8 ** lead
        tmean = (normal.tmin_c + normal.tmax_c) / 2 + current_anomaly * decay
        uncertainty = 0.6 + 0.35 * lead   # degrees C, grows roughly linearly with lead time
        rain_prob = min(0.95, normal.rain_days / _days_in(date.month))
        expected_rain = (normal.rain_mm / max(1, normal.rain_days)) * rain_prob
        out.append(ForecastDay(
            date=date, tmean_c=round(tmean, 1), tmean_uncertainty_c=round(uncertainty, 1),
            rain_probability=round(rain_prob, 2), expected_rainfall_mm=round(expected_rain, 1),
        ))
    return out


def _days_in(month: int) -> int:
    from grapple.data.weather import DAYS_IN_MONTH
    return DAYS_IN_MONTH[month - 1]
