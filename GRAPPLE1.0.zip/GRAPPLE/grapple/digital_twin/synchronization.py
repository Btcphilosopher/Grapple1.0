"""
grapple.digital_twin.synchronization
=======================================

Real Vineyard Mode (Section 64): merges real observed data (estate
dimensions, block maps, weather-station history, lab results, harvest
records) into a running `EstateState`, keeping every value's
`DataProvenance` explicit so a block built from a real block map with a
few real lab samples visibly carries less uncertainty than one running
entirely on SYNTHETIC seed data (Section 77).

This is the layer a real estate would grow into over successive vintages:
more OBSERVED inputs each year -> tighter `digital_twin.calibration`
corrections -> a MODELLED/ESTIMATED digital twin that increasingly reflects
that specific vineyard rather than the generic English-climate baseline.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from grapple.config import DataProvenance
from grapple.core.state import EstateState
from grapple.digital_twin.calibration import CalibrationEngine
from grapple.weather.weather import DailyWeather


@dataclass
class DataCoverage:
    """Tracks how much of the estate's picture currently rests on real observations."""

    observed_days: int = 0
    synthetic_days: int = 0
    lab_samples_ingested: int = 0

    @property
    def total_days(self) -> int:
        return self.observed_days + self.synthetic_days

    @property
    def observed_fraction(self) -> float:
        return round(self.observed_days / self.total_days, 3) if self.total_days else 0.0


class DigitalTwinSync:
    """
    Wraps an `EstateState` + `CalibrationEngine`, providing the ingestion
    entry points a real vineyard uses to move from SYNTHETIC toward
    OBSERVED/MODELLED data (Section 64).
    """

    def __init__(self, state: EstateState):
        self.state = state
        self.calibration = CalibrationEngine()
        self.coverage = DataCoverage()

    def ingest_weather_observation(self, day: DailyWeather) -> None:
        """Replace/insert a real observed weather day, tagged OBSERVED, in place of a synthetic one."""
        self.state.weather.ingest_observation(day)
        self.coverage.observed_days += 1

    def ingest_lab_result(self, metric: str, predicted_value: float, observed_value: float,
                           date: dt.date, measurement_variance: float = 0.1) -> dict:
        """
        Feed one real lab measurement against the model's own prediction for that day into
        calibration (Section 42), and return the resulting bias-corrected prediction.
        """
        self.calibration.record(metric, predicted_value, observed_value, date.isoformat(), measurement_variance)
        self.coverage.lab_samples_ingested += 1
        return self.calibration.calibrated_prediction(metric, predicted_value)

    def ingest_historical_yield(self, block_id: str, year: int, tonnes: float) -> None:
        """Real historical yield records — stored for reference/back-testing against the yield model."""
        history = self.state.__dict__.setdefault("historical_yields", {})
        history.setdefault(block_id, {})[year] = tonnes

    def data_provenance_report(self) -> dict:
        return {
            "observed_weather_days": self.coverage.observed_days,
            "synthetic_weather_days": self.coverage.synthetic_days,
            "observed_fraction": self.coverage.observed_fraction,
            "lab_samples_ingested": self.coverage.lab_samples_ingested,
            "calibrated_metrics": list(self.calibration.filters.keys()),
        }
