"""
grapple.digital_twin.anomaly
===============================

Simulation-state plausibility / anomaly detection (Section 72). Distinct
from `laboratory.qc` (which checks a single lab *result*), this module
checks the *simulation state itself* for physically impossible conditions:
temperatures outside any plausible range, negative or over-capacity
volumes, invalid wine chemistry, and unrealistic yield — surfacing them as
alerts so a runaway parameter combination doesn't silently produce
nonsense output.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

from grapple.vineyard.blocks import Block
from grapple.weather.weather import DailyWeather
from grapple.winery.cellar import Cellar
from grapple.winery.fermentation import FermentationBatch
from grapple.wine.composition import WineComposition


@dataclass
class AnomalyFlag:
    category: str
    entity_id: str
    message: str
    severity: str   # "WARNING" or "CRITICAL"


def check_weather(day: DailyWeather) -> List[AnomalyFlag]:
    flags = []
    if not (-30.0 <= day.tmin_c <= 45.0) or not (-25.0 <= day.tmax_c <= 48.0):
        flags.append(AnomalyFlag("weather", day.date.isoformat(),
                                  f"Implausible temperature range [{day.tmin_c}, {day.tmax_c}]C", "CRITICAL"))
    if day.tmin_c > day.tmax_c:
        flags.append(AnomalyFlag("weather", day.date.isoformat(), "tmin exceeds tmax", "CRITICAL"))
    if day.rainfall_mm < 0 or day.rainfall_mm > 300:
        flags.append(AnomalyFlag("weather", day.date.isoformat(), f"Implausible rainfall {day.rainfall_mm}mm", "WARNING"))
    if not (0 <= day.humidity_pct <= 100):
        flags.append(AnomalyFlag("weather", day.date.isoformat(), f"Humidity {day.humidity_pct}% out of range", "WARNING"))
    return flags


def check_block(block: Block) -> List[AnomalyFlag]:
    flags = []
    c = block.chemistry
    if c.brix and not (0 <= c.brix <= 35):
        flags.append(AnomalyFlag("grape_chemistry", block.block_id, f"Brix {c.brix} implausible", "WARNING"))
    if c.ph and not (2.5 <= c.ph <= 4.5):
        flags.append(AnomalyFlag("grape_chemistry", block.block_id, f"pH {c.ph} implausible", "WARNING"))
    if c.ta_gl and not (2.0 <= c.ta_gl <= 25.0):
        flags.append(AnomalyFlag("grape_chemistry", block.block_id, f"TA {c.ta_gl}g/L implausible", "WARNING"))
    if block.soil.moisture_mm < -0.01:
        flags.append(AnomalyFlag("soil_water", block.block_id, "Negative soil moisture", "CRITICAL"))
    return flags


def check_fermentation(batch: FermentationBatch) -> List[AnomalyFlag]:
    flags = []
    if batch.sugar_gl < -0.01:
        flags.append(AnomalyFlag("fermentation", batch.batch_id, "Negative residual sugar", "CRITICAL"))
    if batch.ethanol_pct > 20.0:
        flags.append(AnomalyFlag("fermentation", batch.batch_id, f"Ethanol {batch.ethanol_pct}% implausibly high", "WARNING"))
    if batch.population_index < 0 or batch.population_index > 1.0001:
        flags.append(AnomalyFlag("fermentation", batch.batch_id, "Yeast population index out of [0,1]", "WARNING"))
    return flags


def check_wine_composition(comp: WineComposition, batch_id: str) -> List[AnomalyFlag]:
    flags = []
    if not (0.0 <= comp.ph <= 5.0):
        flags.append(AnomalyFlag("wine_chemistry", batch_id, f"Wine pH {comp.ph} implausible", "WARNING"))
    if comp.volatile_acidity_gl > 1.5:
        flags.append(AnomalyFlag("wine_chemistry", batch_id, f"VA {comp.volatile_acidity_gl}g/L — spoilage risk", "CRITICAL"))
    if comp.free_so2_mg_l > comp.total_so2_mg_l + 0.01:
        flags.append(AnomalyFlag("wine_chemistry", batch_id, "Free SO2 exceeds total SO2 — mass-balance error", "CRITICAL"))
    return flags


def check_cellar_capacity(cellar: Cellar) -> List[AnomalyFlag]:
    flags = []
    if cellar.fermentation_volume_in_use() > cellar.fermentation_capacity_l + 1e-6:
        flags.append(AnomalyFlag("winery_capacity", "fermentation", "Fermentation volume exceeds declared capacity "
                                                                      "— mass-balance/capacity error", "CRITICAL"))
    if cellar.cellar_volume_in_use() > cellar.cellar_capacity_l + 1e-6:
        flags.append(AnomalyFlag("winery_capacity", "cellar", "Cellar volume exceeds declared capacity", "CRITICAL"))
    return flags
