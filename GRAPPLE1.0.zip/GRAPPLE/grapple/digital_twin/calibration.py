"""
grapple.digital_twin.calibration
===================================

Model calibration (Section 42) — GRAPPLE's mechanism for a real vineyard to
improve the digital twin using its own lab/field observations. Two
deliberately transparent techniques (Section 42/77 — "keep the mathematics
transparent"):

  1. A scalar Kalman filter per metric (e.g. Brix, harvest date) that
     tracks a running "model bias" estimate — updated each time a
     predicted value is compared against an observed one — and shrinks its
     uncertainty as more observations accumulate.
  2. A simple linear regression (`numpy.polyfit`) fit across accumulated
     (predicted, observed) pairs, giving an interpretable
     `observed ≈ slope * predicted + intercept` correction and an R².

Neither technique claims to know more than the data supports: with few
observations, the Kalman filter's uncertainty stays wide and the
regression is reported alongside its R² so a thin data history is visibly
thin, not silently overconfident.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np

from grapple.config import DataProvenance


@dataclass
class Deviation:
    metric: str
    predicted: float
    observed: float
    deviation: float
    date: str


class ScalarKalmanFilter:
    """
    Tracks a scalar "model bias" (observed - predicted) as a Kalman-filtered
    estimate. process_variance controls how much the true bias is assumed to
    drift between observations; measurement_variance reflects the lab's
    measurement uncertainty (see laboratory.chemistry's per-test std devs).
    """

    def __init__(self, process_variance: float = 0.01, initial_variance: float = 10.0):
        self.estimate = 0.0
        self.variance = initial_variance
        self.process_variance = process_variance
        self.n_observations = 0

    def update(self, measured_bias: float, measurement_variance: float) -> float:
        # Predict step (bias assumed to drift slowly)
        predicted_variance = self.variance + self.process_variance
        # Update step
        kalman_gain = predicted_variance / (predicted_variance + measurement_variance)
        self.estimate = self.estimate + kalman_gain * (measured_bias - self.estimate)
        self.variance = (1 - kalman_gain) * predicted_variance
        self.n_observations += 1
        return self.estimate

    def confidence_interval_95(self) -> Tuple[float, float]:
        half_width = 1.96 * (self.variance ** 0.5)
        return (round(self.estimate - half_width, 3), round(self.estimate + half_width, 3))


@dataclass
class RegressionCalibration:
    slope: float
    intercept: float
    r_squared: float
    n_points: int


def fit_linear_calibration(predicted: List[float], observed: List[float]) -> Optional[RegressionCalibration]:
    if len(predicted) < 3:
        return None
    x = np.array(predicted)
    y = np.array(observed)
    slope, intercept = np.polyfit(x, y, 1)
    y_hat = slope * x + intercept
    ss_res = float(np.sum((y - y_hat) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2)) or 1e-9
    r_squared = 1 - ss_res / ss_tot
    return RegressionCalibration(slope=round(float(slope), 4), intercept=round(float(intercept), 4),
                                  r_squared=round(r_squared, 4), n_points=len(predicted))


class CalibrationEngine:
    """Per-metric calibration state, fed by (predicted, observed) pairs as lab results come in."""

    def __init__(self):
        self.filters: Dict[str, ScalarKalmanFilter] = {}
        self.history: Dict[str, List[Deviation]] = {}

    def record(self, metric: str, predicted: float, observed: float, date: str,
               measurement_variance: float = 0.1) -> Deviation:
        dev = Deviation(metric=metric, predicted=predicted, observed=observed,
                         deviation=round(observed - predicted, 4), date=date)
        self.history.setdefault(metric, []).append(dev)
        self.filters.setdefault(metric, ScalarKalmanFilter()).update(dev.deviation, measurement_variance)
        return dev

    def calibrated_prediction(self, metric: str, raw_prediction: float) -> dict:
        kf = self.filters.get(metric)
        if kf is None or kf.n_observations == 0:
            return {"calibrated_value": round(raw_prediction, 3), "bias_estimate": 0.0,
                    "confidence_95": None, "n_observations": 0}
        ci = kf.confidence_interval_95()
        return {
            "calibrated_value": round(raw_prediction + kf.estimate, 3),
            "bias_estimate": round(kf.estimate, 3), "confidence_95": ci, "n_observations": kf.n_observations,
        }

    def regression_for(self, metric: str) -> Optional[RegressionCalibration]:
        devs = self.history.get(metric, [])
        return fit_linear_calibration([d.predicted for d in devs], [d.observed for d in devs])
