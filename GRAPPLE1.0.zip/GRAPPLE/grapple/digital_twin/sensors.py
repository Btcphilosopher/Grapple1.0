"""
grapple.digital_twin.sensors
===============================

Synthetic vineyard/winery sensor network (Section 40/41). Generates
plausible sensor readings from the simulation's true state plus realistic
noise — standing in for real weather stations, soil-moisture probes,
leaf-wetness sensors, canopy sensors and tank sensors until a real estate
connects its own hardware (Section 40 — no hardware required for the
prototype).
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from typing import Optional

import numpy as np

from grapple.config import DataProvenance
from grapple.vineyard.blocks import Block
from grapple.weather.weather import DailyWeather

_SENSOR_NOISE = {
    "temperature_c": 0.3, "humidity_pct": 3.0, "soil_moisture_pct": 4.0,
    "solar_radiation_w_m2": 25.0, "tank_temperature_c": 0.2,
}


@dataclass
class SensorReading:
    sensor_id: str
    block_id: Optional[str]
    metric: str
    value: float
    unit: str
    timestamp: dt.datetime
    provenance: DataProvenance = DataProvenance.SYNTHETIC


def _noisy(value: float, key: str, rng: np.random.Generator) -> float:
    return float(value + rng.normal(0, _SENSOR_NOISE.get(key, max(0.01, abs(value) * 0.02))))


def read_block_sensors(block: Block, weather: DailyWeather, timestamp: dt.datetime,
                        rng: np.random.Generator) -> dict:
    """A Section 41-style sensor dashboard reading for one block."""
    leaf_wetness_hours = min(24.0, weather.rainfall_mm * 1.2 + (6.0 if weather.humidity_pct > 90 else 0.0))
    leaf_wetness_label = "HIGH" if leaf_wetness_hours > 8 else "MODERATE" if leaf_wetness_hours > 3 else "LOW"

    solar_w_m2 = weather.solar_mj_m2 * 1e6 / (12 * 3600)   # rough MJ/m2/12h-daylight -> average W/m2

    return {
        "sensor_id": f"SENS-{block.block_id}", "block_id": block.block_id, "timestamp": timestamp.isoformat(),
        "temperature_c": round(_noisy(weather.tmean_c, "temperature_c", rng), 1),
        "humidity_pct": round(max(0.0, min(100.0, _noisy(weather.humidity_pct, "humidity_pct", rng))), 1),
        "soil_moisture_pct": round(max(0.0, min(105.0, _noisy(block.soil.moisture_fraction * 100, "soil_moisture_pct", rng))), 1),
        "leaf_wetness_label": leaf_wetness_label,
        "solar_radiation_w_m2": round(max(0.0, _noisy(solar_w_m2, "solar_radiation_w_m2", rng)), 0),
        "disease_risk_label": ("LOW" if max(block.disease.downy_mildew_pressure, block.disease.powdery_mildew_pressure,
                                             block.disease.botrytis_pressure) < 0.2 else "ELEVATED"),
        "frost_risk_label": "NONE" if weather.tmin_c > 3 else "WATCH",
        "model_ripeness_pct": round(block.chemistry.sugar_maturity * 100, 1),
        "provenance": DataProvenance.SYNTHETIC.value,
    }


def read_tank_sensor(tank_id: str, temperature_c: float, timestamp: dt.datetime,
                      rng: np.random.Generator) -> SensorReading:
    return SensorReading(sensor_id=f"SENS-{tank_id}", block_id=None, metric="tank_temperature_c",
                          value=round(_noisy(temperature_c, "tank_temperature_c", rng), 2), unit="C",
                          timestamp=timestamp)
