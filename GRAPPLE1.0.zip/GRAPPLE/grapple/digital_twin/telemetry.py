"""
grapple.digital_twin.telemetry
=================================

Telemetry bus (Section 40/41): collects synthetic sensor readings into a
queryable feed, and ingests external data (CSV/JSON today; the schema is
written so MQTT/OPC-UA/REST feeds — Section 40 — can be added as additional
producers without changing this bus's interface). Real Vineyard Mode
(`digital_twin.synchronization`) reads ingested rows from here.
"""
from __future__ import annotations

import csv
import io
import json
from dataclasses import dataclass, field
from typing import Dict, List

from grapple.config import DataProvenance


@dataclass
class TelemetryRecord:
    source: str          # e.g. "weather_station_1", "soil_probe_B07", "csv_import"
    metric: str
    value: float
    timestamp: str
    provenance: DataProvenance
    raw: dict = field(default_factory=dict)


class TelemetryBus:
    def __init__(self):
        self.records: List[TelemetryRecord] = []

    def publish(self, record: TelemetryRecord) -> None:
        self.records.append(record)

    def publish_reading(self, source: str, metric: str, value: float, timestamp: str,
                         provenance: DataProvenance = DataProvenance.SYNTHETIC, **raw) -> None:
        self.publish(TelemetryRecord(source=source, metric=metric, value=value, timestamp=timestamp,
                                      provenance=provenance, raw=raw))

    def query(self, source: str | None = None, metric: str | None = None) -> List[TelemetryRecord]:
        out = self.records
        if source:
            out = [r for r in out if r.source == source]
        if metric:
            out = [r for r in out if r.metric == metric]
        return out

    # --- Import (Section 65) --------------------------------------------
    def ingest_csv(self, csv_text: str, source: str, timestamp_field: str = "date",
                    provenance: DataProvenance = DataProvenance.OBSERVED) -> int:
        """
        Ingest a CSV of the form: date,time,block,temperature,humidity,soil_moisture,...
        Every non-identifier column becomes one TelemetryRecord per row.
        """
        reader = csv.DictReader(io.StringIO(csv_text))
        identifier_fields = {timestamp_field, "time", "block"}
        count = 0
        for row in reader:
            ts = row.get(timestamp_field, "") + ("T" + row["time"] if "time" in row else "")
            for key, value in row.items():
                if key in identifier_fields or value in (None, ""):
                    continue
                try:
                    numeric = float(value)
                except ValueError:
                    continue
                self.publish_reading(source=source, metric=key, value=numeric, timestamp=ts,
                                      provenance=provenance, block=row.get("block"))
                count += 1
        return count

    def ingest_json(self, json_text: str, source: str,
                     provenance: DataProvenance = DataProvenance.OBSERVED) -> int:
        """Ingest a JSON array of flat {timestamp, metric, value, ...} objects."""
        data = json.loads(json_text)
        count = 0
        for row in data:
            self.publish_reading(source=source, metric=row["metric"], value=float(row["value"]),
                                  timestamp=row.get("timestamp", ""), provenance=provenance,
                                  **{k: v for k, v in row.items() if k not in ("metric", "value", "timestamp")})
            count += 1
        return count

    # --- Export (Section 66) --------------------------------------------
    def export_json(self) -> str:
        return json.dumps([
            {"source": r.source, "metric": r.metric, "value": r.value, "timestamp": r.timestamp,
             "provenance": r.provenance.value, **r.raw}
            for r in self.records
        ], default=str)
