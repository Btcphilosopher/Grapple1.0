"""
grapple.vineyard.vines
========================

Block-level vine population representation. GRAPPLE models vines as a
homogeneous population per block (density + per-vine statistics) rather
than simulating individual plants — realistic for a block-scale digital
twin while remaining computationally tractable for Monte Carlo runs of
thousands of vintages.
"""
from __future__ import annotations

from dataclasses import dataclass


TRAINING_SYSTEMS = ("VSP", "Scott Henry", "Geneva Double Curtain", "Guyot", "Cordon")


@dataclass
class VinePopulation:
    vines_per_ha: float
    training_system: str = "VSP"        # Vertical Shoot Position — most common in England
    planting_year: int = 2015
    clone: str = "unknown"

    def age_years(self, current_year: int) -> int:
        return max(0, current_year - self.planting_year)

    def maturity_factor(self, current_year: int) -> float:
        """
        Young vines crop lightly and ramp up to full potential; simplistic
        logistic maturity curve reaching ~full potential around year 6-7.
        """
        age = self.age_years(current_year)
        if age <= 0:
            return 0.0
        if age == 1:
            return 0.0  # establishment year, no crop
        # logistic ramp
        import math
        return 1.0 / (1.0 + math.exp(-0.9 * (age - 4)))
