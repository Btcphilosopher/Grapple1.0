"""
grapple.vineyard.canopy
=========================

Canopy development model (Section 13). Tracks leaf-area index (LAI) growth
through the season and lets the user apply canopy operations that feed
forward into disease risk, fruit sun exposure, ripening rate and yield.
"""
from __future__ import annotations

from dataclasses import dataclass

from grapple.vineyard.phenology import PhenologyStage


@dataclass
class CanopyState:
    leaf_area_index: float = 0.0        # m2 leaf / m2 ground, typical mature English VSP canopy peaks ~1.8-2.5
    density_index: float = 0.5          # 0-1 relative canopy density/porosity (1 = very dense/shaded)
    fruit_exposure: float = 0.5         # 0-1 fraction of fruit zone in direct sun
    shoot_thinned: bool = False
    leaves_removed: bool = False
    hedged: bool = False
    bunch_thinned_fraction: float = 0.0  # fraction of clusters removed by green harvest

    def photosynthetic_capacity(self) -> float:
        """Relative (0-1-ish) capacity, peaking at moderate LAI and falling off if overly dense/shaded."""
        if self.leaf_area_index <= 0:
            return 0.0
        # Peaks around LAI ~2.2, penalised by high density (self-shading)
        lai_term = min(1.0, self.leaf_area_index / 2.2) * (1.0 - max(0.0, self.leaf_area_index - 2.2) * 0.15)
        density_penalty = 1.0 - 0.3 * self.density_index
        return max(0.0, min(1.0, lai_term * density_penalty))


def update_canopy(canopy: CanopyState, stage: PhenologyStage, tmean_c: float, water_stress: float) -> CanopyState:
    """Daily canopy growth increment, driven by warmth and slowed by water stress."""
    growing_stages = {
        PhenologyStage.BUDBREAK, PhenologyStage.SHOOT_GROWTH, PhenologyStage.FLOWERING,
        PhenologyStage.FRUIT_SET, PhenologyStage.BERRY_DEVELOPMENT,
    }
    if stage in growing_stages and tmean_c > 8:
        growth = 0.03 * max(0.0, (tmean_c - 8) / 10.0) * (1.0 - 0.6 * water_stress)
        cap = 1.4 if canopy.hedged else 2.6
        canopy.leaf_area_index = min(cap, canopy.leaf_area_index + growth)
        canopy.density_index = min(1.0, 0.3 + canopy.leaf_area_index / 3.0)
        if canopy.shoot_thinned:
            canopy.density_index *= 0.8
        if canopy.leaves_removed:
            canopy.density_index *= 0.75

    canopy.fruit_exposure = max(0.05, min(0.95, 1.0 - canopy.density_index * (0.7 if not canopy.leaves_removed else 0.4)))
    return canopy


def apply_shoot_thinning(canopy: CanopyState) -> None:
    canopy.shoot_thinned = True
    canopy.density_index = max(0.1, canopy.density_index * 0.8)


def apply_leaf_removal(canopy: CanopyState) -> None:
    canopy.leaves_removed = True
    canopy.density_index = max(0.1, canopy.density_index * 0.75)
    canopy.fruit_exposure = min(0.95, canopy.fruit_exposure + 0.2)


def apply_hedging(canopy: CanopyState) -> None:
    canopy.hedged = True
    canopy.leaf_area_index = min(canopy.leaf_area_index, 1.4)


def apply_bunch_thinning(canopy: CanopyState, fraction: float) -> None:
    canopy.bunch_thinned_fraction = max(canopy.bunch_thinned_fraction, min(1.0, fraction))
