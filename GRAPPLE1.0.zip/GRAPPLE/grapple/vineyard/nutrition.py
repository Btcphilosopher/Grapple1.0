"""
grapple.vineyard.nutrition
=============================

Nutrient model (Section 15). Tracks plant-available N/K/Mg/(P via a
combined soil-fertility index) pools per block, lets the user apply
amendments, and derives a vine vigour/health multiplier used by canopy,
disease and yield models.
"""
from __future__ import annotations

from dataclasses import dataclass

from grapple.vineyard.soil import SoilState

# Approximate seasonal uptake by a mature, moderate-yield vineyard (kg/ha/season)
SEASONAL_UPTAKE_N = 45.0
SEASONAL_UPTAKE_K = 60.0
SEASONAL_UPTAKE_MG = 12.0

GROWING_SEASON_DAYS = 200  # roughly budbreak to harvest


@dataclass
class NutrientStatus:
    nitrogen_status: float   # 0-1, 1 = fully adequate
    potassium_status: float
    magnesium_status: float
    vigour_multiplier: float  # relative multiplier applied to canopy growth / yield potential
    deficiency_flags: list


def daily_uptake(soil: SoilState) -> None:
    """Vines draw down soil nutrient pools during the growing season."""
    soil.nitrogen_kg_ha = max(0.0, soil.nitrogen_kg_ha - SEASONAL_UPTAKE_N / GROWING_SEASON_DAYS)
    soil.potassium_kg_ha = max(0.0, soil.potassium_kg_ha - SEASONAL_UPTAKE_K / GROWING_SEASON_DAYS)
    soil.magnesium_kg_ha = max(0.0, soil.magnesium_kg_ha - SEASONAL_UPTAKE_MG / GROWING_SEASON_DAYS)


def apply_amendment(soil: SoilState, nitrogen_kg_ha: float = 0.0, potassium_kg_ha: float = 0.0,
                     magnesium_kg_ha: float = 0.0, organic_matter_pct_increase: float = 0.0) -> None:
    soil.nitrogen_kg_ha += nitrogen_kg_ha
    soil.potassium_kg_ha += potassium_kg_ha
    soil.magnesium_kg_ha += magnesium_kg_ha
    soil.organic_matter_pct += organic_matter_pct_increase


def assess_nutrient_status(soil: SoilState) -> NutrientStatus:
    # Reference "adequate" pool sizes for a well-managed English vineyard soil.
    n_status = min(1.0, soil.nitrogen_kg_ha / 50.0)
    k_status = min(1.0, soil.potassium_kg_ha / 150.0)
    mg_status = min(1.0, soil.magnesium_kg_ha / 70.0)

    flags = []
    if n_status < 0.4:
        flags.append("nitrogen deficiency")
    if k_status < 0.4:
        flags.append("potassium deficiency")
    if mg_status < 0.4:
        flags.append("magnesium deficiency")

    vigour = 0.5 + 0.5 * (0.4 * n_status + 0.35 * k_status + 0.25 * mg_status)
    return NutrientStatus(
        nitrogen_status=n_status, potassium_status=k_status, magnesium_status=mg_status,
        vigour_multiplier=max(0.4, min(1.15, vigour)), deficiency_flags=flags,
    )
