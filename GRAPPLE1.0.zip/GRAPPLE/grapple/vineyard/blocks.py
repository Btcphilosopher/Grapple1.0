"""
grapple.vineyard.blocks
==========================

The vineyard Block — the fundamental spatial unit of the digital twin
(Section 4, 8). Each block carries its own terrain, soil, variety,
rootstock, vine population and day-to-day state (phenology, canopy,
disease, soil moisture/nutrients, and grape chemistry).

Terrain -> microclimate (Section 8): elevation, slope and aspect are turned
into simple multipliers that the weather/frost/ripening models apply on top
of the estate-wide weather signal, so low-lying blocks pool cold air and
south-facing slopes run warmer and ripen faster than the estate average.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

from grapple.data.soils import get_soil
from grapple.data.varieties import VarietyData, RootstockData, get_variety, get_rootstock
from grapple.vineyard.soil import SoilState, new_soil_state
from grapple.vineyard.vines import VinePopulation
from grapple.vineyard.canopy import CanopyState
from grapple.vineyard.phenology import PhenologyState
from grapple.vineyard.disease import DiseaseState


@dataclass
class BerryChemistryState:
    """Grape chemistry as the fruit ripens (Section 19). Populated/updated by viticulture.ripening."""

    brix: float = 0.0
    ph: float = 3.0
    ta_gl: float = 12.0            # titratable acid, g/L tartaric equivalent
    malic_acid_gl: float = 6.0
    tartaric_acid_gl: float = 6.0
    yan_mg_l: float = 150.0
    berry_weight_g: float = 0.0

    # Five maturity dimensions (Section 19) — each 0-1
    sugar_maturity: float = 0.0
    acid_maturity: float = 0.0
    phenolic_maturity: float = 0.0
    aromatic_maturity: float = 0.0
    physiological_maturity: float = 0.0


@dataclass
class Block:
    block_id: str
    name: str
    area_ha: float

    latitude: float
    longitude: float
    elevation_m: float
    slope_pct: float = 5.0
    aspect_deg: float = 180.0          # compass bearing the slope faces, 180 = due south
    row_orientation_deg: float = 0.0   # 0 = N-S rows

    soil_key: str = "chalk"
    variety_key: str = "chardonnay"
    rootstock_key: str = "SO4"
    irrigation_installed: bool = False

    vines: VinePopulation = field(default_factory=lambda: VinePopulation(vines_per_ha=4500))

    soil: SoilState = field(init=False)
    canopy: CanopyState = field(default_factory=CanopyState)
    phenology: PhenologyState = field(default_factory=PhenologyState)
    disease: DiseaseState = field(default_factory=DiseaseState)
    chemistry: BerryChemistryState = field(default_factory=BerryChemistryState)

    fruit_set_fraction: float = 1.0
    frost_damage_pct: float = 0.0
    harvested: bool = False
    harvest_date: Optional[str] = None

    def __post_init__(self):
        self.soil = new_soil_state(self.soil_key)

    @property
    def variety(self) -> VarietyData:
        return get_variety(self.variety_key)

    @property
    def rootstock(self) -> RootstockData:
        return get_rootstock(self.rootstock_key)

    @property
    def vine_count(self) -> int:
        return int(round(self.vines.vines_per_ha * self.area_ha))

    # --- Terrain-derived microclimate multipliers (Section 8) ------------

    def solar_exposure_multiplier(self) -> float:
        """
        South-facing (aspect ~180) slopes receive more effective solar radiation
        than north-facing ones, scaled by slope steepness; northern-hemisphere model.
        """
        aspect_factor = math.cos(math.radians(self.aspect_deg - 180.0))  # +1 due south, -1 due north
        slope_weight = min(1.0, self.slope_pct / 20.0)
        return 1.0 + 0.12 * aspect_factor * slope_weight

    def frost_pooling_multiplier(self, estate_min_elevation_m: float, estate_max_elevation_m: float) -> float:
        """Lower-lying blocks accumulate cold air on still, clear nights -> higher frost risk."""
        span = max(1.0, estate_max_elevation_m - estate_min_elevation_m)
        relative_low = 1.0 - (self.elevation_m - estate_min_elevation_m) / span  # 1 = lowest block
        # A very gentle/flat block traps more cold air than a steep one that drains it away.
        drainage_relief = min(1.0, self.slope_pct / 15.0)
        return 1.0 + 0.6 * relative_low * (1.0 - 0.5 * drainage_relief)

    def wind_exposure_multiplier(self) -> float:
        """Higher elevation -> more wind exposure (roughly)."""
        return 1.0 + min(0.4, self.elevation_m / 400.0)

    def local_temperature_offset_c(self, estate_min_elevation_m: float, estate_max_elevation_m: float) -> float:
        """
        Combines a standard elevation lapse rate (~0.6C/100m) with a small
        south-facing-slope solar bonus, applied on top of the estate-wide
        daily weather signal to produce this block's microclimate.
        """
        lapse = -0.6 * (self.elevation_m - estate_min_elevation_m) / 100.0
        aspect_bonus = 0.3 * math.cos(math.radians(self.aspect_deg - 180.0)) * min(1.0, self.slope_pct / 20.0)
        return lapse + aspect_bonus
