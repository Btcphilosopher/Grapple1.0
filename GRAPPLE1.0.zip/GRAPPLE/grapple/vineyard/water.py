"""
grapple.vineyard.water
=========================

Vineyard water balance (Section 14). A single-bucket soil-moisture model
per block:

    moisture[t] = moisture[t-1] + rainfall + irrigation - ET - drainage

Evapotranspiration uses a simplified Hargreaves-style estimate from mean
temperature and a canopy/crop coefficient, which is sufficient fidelity for
a digital twin without requiring full radiation/humidity Penman-Monteith
inputs (those are available in the weather engine and could be substituted
later without changing this module's interface).
"""
from __future__ import annotations

from dataclasses import dataclass

from grapple.vineyard.soil import SoilState


@dataclass
class WaterBalanceResult:
    rainfall_mm: float
    irrigation_mm: float
    et_mm: float
    drainage_mm: float
    runoff_mm: float
    moisture_mm: float


def reference_et_mm(tmean_c: float, tmax_c: float, tmin_c: float, solar_mj_m2: float) -> float:
    """Simplified Hargreaves reference evapotranspiration (mm/day)."""
    trange = max(0.0, tmax_c - tmin_c)
    et0 = 0.0023 * (tmean_c + 17.8) * (trange ** 0.5) * solar_mj_m2
    return max(0.0, et0)


def crop_coefficient(canopy_lai: float) -> float:
    """Crop coefficient scales reference ET to actual vine water use, rising with canopy cover."""
    return 0.25 + 0.35 * min(1.0, canopy_lai / 2.2)


def update_water_balance(
    soil: SoilState,
    rainfall_mm: float,
    tmean_c: float,
    tmax_c: float,
    tmin_c: float,
    solar_mj_m2: float,
    canopy_lai: float,
    irrigation_mm: float = 0.0,
) -> WaterBalanceResult:
    et0 = reference_et_mm(tmean_c, tmax_c, tmin_c, solar_mj_m2)
    kc = crop_coefficient(canopy_lai)
    et_actual = et0 * kc

    # Heavy rainfall runs off faster than it can infiltrate on impeded soils.
    runoff_frac = {"free": 0.03, "moderate": 0.08, "impeded": 0.2}.get(soil.profile.drainage, 0.08)
    runoff = rainfall_mm * runoff_frac if rainfall_mm > 15 else rainfall_mm * runoff_frac * 0.3
    infiltration = max(0.0, rainfall_mm - runoff) + irrigation_mm

    moisture = soil.moisture_mm + infiltration - et_actual
    moisture = max(0.0, moisture)

    drainage = 0.0
    fc = soil.field_capacity_mm
    if moisture > fc:
        surplus = moisture - fc
        drainage = surplus * soil.drainage_coefficient()
        moisture -= drainage

    soil.moisture_mm = moisture

    return WaterBalanceResult(
        rainfall_mm=rainfall_mm, irrigation_mm=irrigation_mm, et_mm=et_actual,
        drainage_mm=drainage, runoff_mm=runoff, moisture_mm=moisture,
    )
