"""
grapple.vineyard.varieties
============================

Thin access layer over the variety/rootstock reference data (Section 5, 6).
Kept as its own module (rather than importing grapple.data.varieties
everywhere) so vineyard code has one place to add variety-level *behaviour*
(e.g. derived coefficients) without touching the raw seed data.
"""
from __future__ import annotations

from grapple.data.varieties import (
    VARIETY_LIBRARY,
    ROOTSTOCK_LIBRARY,
    VarietyData,
    RootstockData,
    get_variety,
    get_rootstock,
    register_variety,
    register_rootstock,
)

__all__ = [
    "VARIETY_LIBRARY", "ROOTSTOCK_LIBRARY", "VarietyData", "RootstockData",
    "get_variety", "get_rootstock", "register_variety", "register_rootstock",
]


def list_varieties() -> list[str]:
    return sorted(VARIETY_LIBRARY)


def list_rootstocks() -> list[str]:
    return sorted(ROOTSTOCK_LIBRARY)
