"""
grapple.vineyard.disease
===========================

Probabilistic vineyard disease-pressure model (Section 16). Deliberately
kept at the level of *risk dynamics and treatment decisions*, not a
pesticide-programme recommender: each disease has a daily risk index
(0-1) driven by humidity, rainfall, temperature, canopy density, cultivar
susceptibility and an autoregressive carry-over from previous infection
pressure, plus a stochastic infection-event draw.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from grapple.data.varieties import VarietyData
from grapple.vineyard.canopy import CanopyState


@dataclass
class DiseaseState:
    downy_mildew_pressure: float = 0.0     # 0-1 running pressure index
    powdery_mildew_pressure: float = 0.0
    botrytis_pressure: float = 0.0
    trunk_disease_index: float = 0.05      # slow-moving, mostly a function of vine age, not simulated daily
    cumulative_yield_loss_pct: float = 0.0
    treatment_applications: int = 0


@dataclass
class DiseaseDailyResult:
    downy_risk: float
    powdery_risk: float
    botrytis_risk: float
    overall_risk_label: str
    infection_events: list = field(default_factory=list)


def _risk_label(overall: float) -> str:
    if overall < 0.2:
        return "LOW"
    if overall < 0.45:
        return "MODERATE"
    if overall < 0.7:
        return "HIGH"
    return "SEVERE"


def update_disease_pressure(
    state: DiseaseState,
    variety: VarietyData,
    canopy: CanopyState,
    tmean_c: float,
    humidity_pct: float,
    rainfall_mm: float,
    rng: np.random.Generator,
    near_harvest: bool = False,
    treated_today: bool = False,
) -> DiseaseDailyResult:
    """Advance disease pressure by one day and draw stochastic infection events."""

    # Downy mildew: favoured by warm, wet, humid conditions (rain-splash driven).
    downy_env = max(0.0, (tmean_c - 10) / 15) * max(0.0, (humidity_pct - 70) / 30) * min(1.0, rainfall_mm / 10)
    downy_target = downy_env * (0.5 + 0.5 * variety.downy_mildew_susceptibility) * (0.7 + 0.3 * canopy.density_index)

    # Powdery mildew: favoured by warm, humid but *not necessarily wet* conditions; dense canopy shading worsens it.
    powdery_env = max(0.0, (tmean_c - 12) / 15) * max(0.0, (humidity_pct - 55) / 40)
    powdery_target = powdery_env * (0.5 + 0.5 * variety.powdery_mildew_susceptibility) * (0.6 + 0.4 * canopy.density_index)

    # Botrytis: humidity + rain around/after veraison is the dominant driver; much worse near harvest.
    botrytis_env = max(0.0, (humidity_pct - 75) / 25) * min(1.0, rainfall_mm / 8)
    harvest_multiplier = 1.8 if near_harvest else 1.0
    botrytis_target = botrytis_env * (0.5 + 0.5 * variety.botrytis_susceptibility) * harvest_multiplier * (0.7 + 0.3 * canopy.density_index)

    # Exponential smoothing toward the day's environmental target (pressure builds/decays gradually),
    # with a treatment knocking pressure back down.
    alpha = 0.35
    state.downy_mildew_pressure = max(0.0, (1 - alpha) * state.downy_mildew_pressure + alpha * downy_target)
    state.powdery_mildew_pressure = max(0.0, (1 - alpha) * state.powdery_mildew_pressure + alpha * powdery_target)
    state.botrytis_pressure = max(0.0, (1 - alpha) * state.botrytis_pressure + alpha * botrytis_target)

    if treated_today:
        state.downy_mildew_pressure *= 0.25
        state.powdery_mildew_pressure *= 0.25
        state.botrytis_pressure *= 0.4
        state.treatment_applications += 1

    events = []
    for name, pressure in [
        ("downy_mildew", state.downy_mildew_pressure),
        ("powdery_mildew", state.powdery_mildew_pressure),
        ("botrytis", state.botrytis_pressure),
    ]:
        if rng.random() < pressure * 0.05:  # daily probability of a new visible infection event
            events.append(name)
            state.cumulative_yield_loss_pct = min(40.0, state.cumulative_yield_loss_pct + pressure * 2.0)

    overall = max(state.downy_mildew_pressure, state.powdery_mildew_pressure, state.botrytis_pressure)
    return DiseaseDailyResult(
        downy_risk=round(state.downy_mildew_pressure, 3),
        powdery_risk=round(state.powdery_mildew_pressure, 3),
        botrytis_risk=round(state.botrytis_pressure, 3),
        overall_risk_label=_risk_label(overall),
        infection_events=events,
    )
