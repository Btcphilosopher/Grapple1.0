"""
grapple.vineyard.yield_model
===============================

Yield is *emergent* rather than fixed (Section 18) — it is derived each day
from vine population statistics, fruit-set outcome, berry weight (itself a
function of ripening/water status — see viticulture.berry), and losses from
frost, disease, wildlife and harvest mechanics.
"""
from __future__ import annotations

from dataclasses import dataclass

from grapple.data.varieties import VarietyData
from grapple.vineyard.vines import VinePopulation


@dataclass
class YieldEstimate:
    clusters_per_vine: float
    berries_per_cluster: float
    berry_weight_g: float
    gross_kg_per_ha: float
    frost_loss_pct: float
    disease_loss_pct: float
    wildlife_loss_pct: float
    harvest_loss_pct: float
    net_kg_per_ha: float
    net_tonnes_per_block: float


def estimate_yield(
    variety: VarietyData,
    vines: VinePopulation,
    current_year: int,
    area_ha: float,
    fruit_set_fraction: float = 1.0,
    berry_weight_g: float | None = None,
    bunch_thinned_fraction: float = 0.0,
    frost_loss_pct: float = 0.0,
    disease_loss_pct: float = 0.0,
    wildlife_loss_pct: float = 3.0,
    harvest_loss_pct: float = 2.0,
) -> YieldEstimate:
    maturity = vines.maturity_factor(current_year)
    clusters_per_vine = variety.clusters_per_vine_mean * maturity * (1.0 - bunch_thinned_fraction)
    berries_per_cluster = variety.berries_per_cluster_mean * max(0.15, fruit_set_fraction)
    bw = berry_weight_g if berry_weight_g is not None else variety.berry_weight_g_mean

    gross_kg_per_vine = clusters_per_vine * berries_per_cluster * bw / 1000.0
    gross_kg_per_ha = gross_kg_per_vine * vines.vines_per_ha

    total_loss_frac = 1.0
    for pct in (frost_loss_pct, disease_loss_pct, wildlife_loss_pct, harvest_loss_pct):
        total_loss_frac *= max(0.0, 1.0 - pct / 100.0)

    net_kg_per_ha = gross_kg_per_ha * total_loss_frac
    net_tonnes_per_block = net_kg_per_ha * area_ha / 1000.0

    return YieldEstimate(
        clusters_per_vine=round(clusters_per_vine, 2),
        berries_per_cluster=round(berries_per_cluster, 1),
        berry_weight_g=round(bw, 3),
        gross_kg_per_ha=round(gross_kg_per_ha, 1),
        frost_loss_pct=frost_loss_pct,
        disease_loss_pct=disease_loss_pct,
        wildlife_loss_pct=wildlife_loss_pct,
        harvest_loss_pct=harvest_loss_pct,
        net_kg_per_ha=round(net_kg_per_ha, 1),
        net_tonnes_per_block=round(net_tonnes_per_block, 3),
    )
