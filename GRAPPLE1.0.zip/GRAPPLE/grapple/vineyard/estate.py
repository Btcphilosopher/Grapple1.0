"""
grapple.vineyard.estate
==========================

The Estate — top of the digital twin hierarchy (Section 2):

    Estate -> Blocks -> Rows -> Vines

("Rows" are represented implicitly through vine density / row orientation
on each Block rather than simulated individually — a row-by-row model
would add no predictive fidelity at this scale and would be computationally
wasteful for Monte Carlo runs of thousands of vintages.)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from grapple.vineyard.blocks import Block


@dataclass
class Estate:
    name: str
    region: str
    country: str = "England"
    blocks: Dict[str, Block] = field(default_factory=dict)

    def add_block(self, block: Block) -> None:
        self.blocks[block.block_id] = block

    def get_block(self, block_id: str) -> Block:
        return self.blocks[block_id]

    @property
    def total_area_ha(self) -> float:
        return sum(b.area_ha for b in self.blocks.values())

    @property
    def total_vines(self) -> int:
        return sum(b.vine_count for b in self.blocks.values())

    @property
    def min_elevation_m(self) -> float:
        return min((b.elevation_m for b in self.blocks.values()), default=0.0)

    @property
    def max_elevation_m(self) -> float:
        return max((b.elevation_m for b in self.blocks.values()), default=0.0)

    def blocks_by_variety(self, variety_key: str) -> List[Block]:
        return [b for b in self.blocks.values() if b.variety_key == variety_key]

    def varieties_planted(self) -> List[str]:
        return sorted({b.variety_key for b in self.blocks.values()})

    def summary(self) -> dict:
        return {
            "name": self.name,
            "region": self.region,
            "country": self.country,
            "total_area_ha": round(self.total_area_ha, 2),
            "total_vines": self.total_vines,
            "block_count": len(self.blocks),
            "varieties": self.varieties_planted(),
            "elevation_range_m": [self.min_elevation_m, self.max_elevation_m],
        }
