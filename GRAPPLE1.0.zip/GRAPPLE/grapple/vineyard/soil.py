"""
grapple.vineyard.soil
=======================

Spatial soil digital twin (Section 7). `SoilState` is the per-block mutable
soil state (moisture + nutrients); the static texture/chemistry profile
comes from `grapple.data.soils.SoilTypeData`. Moisture dynamics themselves
live in `vineyard.water` (which mutates `SoilState.moisture_mm` each day);
nutrient dynamics live in `vineyard.nutrition`.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from grapple.data.soils import SoilTypeData, get_soil


@dataclass
class SoilState:
    """Mutable, block-specific soil state layered on top of a static SoilTypeData profile."""

    profile: SoilTypeData
    moisture_mm: float = 0.0            # plant-available water currently stored, mm
    nitrogen_kg_ha: float = 60.0
    potassium_kg_ha: float = 180.0
    magnesium_kg_ha: float = 90.0
    calcium_kg_ha: float = 900.0
    organic_matter_pct: float = None    # defaults to profile value if left None

    def __post_init__(self):
        if self.organic_matter_pct is None:
            self.organic_matter_pct = self.profile.organic_matter_pct
        # Initialise moisture at ~65% of field capacity (a plausible winter-recharge state).
        if self.moisture_mm == 0.0:
            self.moisture_mm = 0.65 * self.profile.water_holding_capacity_mm

    @property
    def field_capacity_mm(self) -> float:
        return self.profile.water_holding_capacity_mm

    @property
    def moisture_fraction(self) -> float:
        """Current moisture as a fraction of field capacity, clipped to [0, 1.05]."""
        if self.field_capacity_mm <= 0:
            return 0.0
        return max(0.0, min(1.05, self.moisture_mm / self.field_capacity_mm))

    @property
    def water_stress_index(self) -> float:
        """0 = no stress, 1 = severe stress. Stress begins below ~40% field capacity."""
        frac = self.moisture_fraction
        if frac >= 0.4:
            return 0.0
        return min(1.0, (0.4 - frac) / 0.4)

    def drainage_coefficient(self) -> float:
        """Fraction of surplus water (above field capacity) draining away per day."""
        return {"free": 0.6, "moderate": 0.35, "impeded": 0.15}.get(self.profile.drainage, 0.35)


def new_soil_state(soil_key: str, **overrides) -> SoilState:
    return SoilState(profile=get_soil(soil_key), **overrides)
