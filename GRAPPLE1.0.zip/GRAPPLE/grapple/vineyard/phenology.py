"""
grapple.vineyard.phenology
=============================

Seasonal vine development model (Section 11):

    Dormancy -> Budbreak -> Shoot Growth -> Flowering -> Fruit Set ->
    Berry Development -> Veraison -> Ripening -> Harvest -> Leaf Fall -> Dormancy

SIMPLIFICATION NOTE (Section 77 — Scientific Honesty): a single base-10C
growing-degree-day (GDD) sum from 1 January, as commonly used for
whole-season heat-summation classification (the Winkler Index), is a poor
predictor of *budbreak timing* in a cool maritime climate — southern
England's daily mean temperature rarely exceeds 10C before May, so a
base-10 sum from January would push simulated budbreak into June, months
later than observed English budburst (typically mid-to-late April).

GRAPPLE therefore uses two accumulators, matching how forcing-based
phenology models are commonly structured:

  1. A base-0C "spring forcing" sum from 1 January, used only to trigger
     BUDBREAK — capturing the gentler early-spring warmth that actually
     initiates bud growth.
  2. A base-10C GDD sum restarted at the moment of budbreak, used for every
     subsequent stage (shoot growth, flowering, fruit set, veraison) —
     this is the conventional viticultural GDD convention, just anchored
     to the vine's own start-of-season rather than the calendar year.

Harvest is a *decision* (Section 20/46), not a phenological trigger, so the
model stops auto-advancing at RIPENING; the simulation orchestrator moves a
block to HARVESTED when a harvest actually occurs, and to LEAF_FALL /
DORMANCY based on autumn temperature decline thereafter.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from enum import Enum

from grapple.data.varieties import VarietyData


class PhenologyStage(str, Enum):
    DORMANCY = "Dormancy"
    BUDBREAK = "Budbreak"
    SHOOT_GROWTH = "Shoot Growth"
    FLOWERING = "Flowering"
    FRUIT_SET = "Fruit Set"
    BERRY_DEVELOPMENT = "Berry Development"
    VERAISON = "Veraison"
    RIPENING = "Ripening"
    HARVESTED = "Harvested"
    LEAF_FALL = "Leaf Fall"


_STAGE_ORDER = list(PhenologyStage)

SPRING_FORCING_BASE_C = 0.0    # base for the pre-budbreak accumulator
GDD_BASE_C = 10.0              # base for the post-budbreak accumulator (conventional viticultural GDD)


@dataclass
class PhenologyState:
    stage: PhenologyStage = PhenologyStage.DORMANCY
    spring_forcing_accumulated: float = 0.0   # base-0C sum from 1 Jan, drives BUDBREAK only
    gdd_accumulated: float = 0.0              # base-10C sum, RESET at budbreak, drives everything after
    stage_entered_date: dict = field(default_factory=dict)  # stage.value -> date
    frost_damage_pct: float = 0.0    # cumulative % of primary buds/shoots lost to frost this season

    def days_in_stage(self, today: dt.date) -> int:
        entered = self.stage_entered_date.get(self.stage.value)
        if entered is None:
            return 0
        return (today - entered).days


def daily_gdd(tmean_c: float, base: float) -> float:
    return max(0.0, tmean_c - base)


def _advance_stage(state: PhenologyState, new_stage: PhenologyStage, today: dt.date) -> None:
    if state.stage != new_stage:
        state.stage = new_stage
        state.stage_entered_date[new_stage.value] = today


def update_phenology(
    state: PhenologyState,
    variety: VarietyData,
    tmean_c: float,
    today: dt.date,
) -> PhenologyState:
    """Advance one day of phenological development. Mutates and returns `state`."""

    # Reset accumulation at the start of a new vintage (1 Jan).
    if today.month == 1 and today.day == 1:
        state.spring_forcing_accumulated = 0.0
        state.gdd_accumulated = 0.0
        state.stage = PhenologyStage.DORMANCY
        state.stage_entered_date = {}
        state.frost_damage_pct = 0.0

    if state.stage == PhenologyStage.DORMANCY:
        state.spring_forcing_accumulated += daily_gdd(tmean_c, SPRING_FORCING_BASE_C)
        if state.spring_forcing_accumulated >= variety.gdd_budbreak:
            _advance_stage(state, PhenologyStage.BUDBREAK, today)
            state.gdd_accumulated = 0.0   # restart the base-10 accumulator at budbreak
        return state

    # From budbreak onward, accumulate base-10 GDD anchored to the vine's own start of season.
    if state.stage not in (PhenologyStage.HARVESTED, PhenologyStage.LEAF_FALL):
        state.gdd_accumulated += daily_gdd(tmean_c, GDD_BASE_C)
    gdd = state.gdd_accumulated

    if state.stage == PhenologyStage.BUDBREAK and gdd >= 15:
        _advance_stage(state, PhenologyStage.SHOOT_GROWTH, today)
    elif state.stage == PhenologyStage.SHOOT_GROWTH and gdd >= variety.gdd_flowering:
        _advance_stage(state, PhenologyStage.FLOWERING, today)
    elif state.stage == PhenologyStage.FLOWERING and gdd >= variety.gdd_flowering + 40:
        _advance_stage(state, PhenologyStage.FRUIT_SET, today)
    elif state.stage == PhenologyStage.FRUIT_SET and gdd >= variety.gdd_flowering + 70:
        _advance_stage(state, PhenologyStage.BERRY_DEVELOPMENT, today)
    elif state.stage == PhenologyStage.BERRY_DEVELOPMENT and gdd >= variety.gdd_veraison:
        _advance_stage(state, PhenologyStage.VERAISON, today)
    elif state.stage == PhenologyStage.VERAISON:
        # Ripening begins the day after veraison onset.
        _advance_stage(state, PhenologyStage.RIPENING, today)
    elif state.stage == PhenologyStage.RIPENING:
        pass  # remains in RIPENING until harvested by the simulation orchestrator
    elif state.stage == PhenologyStage.LEAF_FALL and today.month == 12 and today.day >= 15:
        _advance_stage(state, PhenologyStage.DORMANCY, today)

    # Autumn senescence: once harvested (or very late season) and mean temp
    # drops persistently, move to leaf fall irrespective of GDD.
    if state.stage == PhenologyStage.HARVESTED and (tmean_c < 9.0 or today.month >= 11):
        _advance_stage(state, PhenologyStage.LEAF_FALL, today)

    return state


def mark_harvested(state: PhenologyState, today: dt.date) -> None:
    _advance_stage(state, PhenologyStage.HARVESTED, today)


def stage_progress_fraction(state: PhenologyState) -> float:
    """0-1 progress of the current stage index through the full season sequence (for dashboards)."""
    idx = _STAGE_ORDER.index(state.stage)
    return idx / (len(_STAGE_ORDER) - 1)
