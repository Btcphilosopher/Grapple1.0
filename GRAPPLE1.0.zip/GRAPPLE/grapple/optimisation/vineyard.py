"""
grapple.optimisation.vineyard
================================

Vineyard-management optimisation (Section 63 — "OPTIMISE VINEYARD"):
searches a small set of canopy/crop-load decisions (bunch-thinning
fraction, leaf removal) for the option that best serves a chosen
objective, by running each candidate forward on a deep-copied shadow
simulation through to a fixed evaluation date and comparing projected
outcomes — the same "shadow simulation" pattern used by
`optimisation.harvest`.
"""
from __future__ import annotations

import copy
import datetime as dt
from dataclasses import dataclass
from typing import List

from grapple.viticulture.vineyard_operations import OperationType, apply_operation


@dataclass
class VineyardOption:
    label: str
    bunch_thin_fraction: float
    leaf_removal: bool
    projected_brix: float
    projected_disease_risk: float
    projected_yield_kg_ha: float
    score: float


def optimise_canopy_strategy(sim, block_id: str, evaluate_days: int = 30,
                              objective: str = "quality") -> List[VineyardOption]:
    """
    `objective`: "quality" (favour ripeness/lower disease risk), "yield" (favour crop retained),
    or "balanced".
    """
    candidates = [
        ("baseline", 0.0, False),
        ("light_thinning", 0.2, False),
        ("moderate_thinning", 0.35, True),
        ("heavy_thinning", 0.5, True),
    ]

    results: List[VineyardOption] = []
    for label, thin_fraction, leaf_removal in candidates:
        shadow = copy.deepcopy(sim)
        block = shadow.state.estate.get_block(block_id)

        if thin_fraction > 0:
            apply_operation(block, OperationType.BUNCH_THINNING, bunch_thin_fraction=thin_fraction)
        if leaf_removal:
            apply_operation(block, OperationType.LEAF_REMOVAL)

        for _ in range(evaluate_days):
            shadow.step_day()

        block_after = shadow.state.estate.get_block(block_id)
        disease_risk = max(block_after.disease.downy_mildew_pressure, block_after.disease.powdery_mildew_pressure,
                            block_after.disease.botrytis_pressure)
        yield_proxy_kg_ha = block_after.vines.vines_per_ha * (1 - thin_fraction) * 1.3  # simplified relative proxy

        if objective == "yield":
            score = yield_proxy_kg_ha / 100.0 - disease_risk * 20
        elif objective == "quality":
            score = block_after.chemistry.brix * 3 - disease_risk * 40
        else:
            score = block_after.chemistry.brix * 1.5 + yield_proxy_kg_ha / 200.0 - disease_risk * 30

        results.append(VineyardOption(
            label=label, bunch_thin_fraction=thin_fraction, leaf_removal=leaf_removal,
            projected_brix=round(block_after.chemistry.brix, 2), projected_disease_risk=round(disease_risk, 3),
            projected_yield_kg_ha=round(yield_proxy_kg_ha, 1), score=round(score, 2),
        ))

    return sorted(results, key=lambda r: r.score, reverse=True)
