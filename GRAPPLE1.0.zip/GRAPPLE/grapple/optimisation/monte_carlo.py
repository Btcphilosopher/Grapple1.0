"""
grapple.optimisation.monte_carlo
===================================

Monte Carlo vintage analysis (Section 45): runs many independent,
reproducibly-seeded vintages and returns probability distributions for
harvest date, yield, Brix, acidity, disease/frost loss and a simple
quality proxy — the core input to vineyard investment planning
(Section 45/64).

Every trial gets its own derived seed (`RandomStreams.child`), so results
are reproducible as a batch (from the parent seed) while each individual
trial is still an independent stochastic draw (Section 69).
"""
from __future__ import annotations

import copy
import datetime as dt
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

import numpy as np

from grapple.core.random import RandomStreams
from grapple.core.simulation import VintageSimulation


@dataclass
class TrialResult:
    seed: int
    scenario: str
    harvest_dates: List[str]
    total_tonnes: float
    average_brix: float
    average_ta_gl: float
    frost_events: int
    fermentations_stuck: int


@dataclass
class MonteCarloSummary:
    n_trials: int
    trials: List[TrialResult]

    def distribution(self, field_name: str) -> Dict[str, float]:
        values = np.array([getattr(t, field_name) for t in self.trials], dtype=float)
        if len(values) == 0:
            return {}
        return {
            "mean": round(float(np.mean(values)), 3),
            "std": round(float(np.std(values)), 3),
            "p5": round(float(np.percentile(values, 5)), 3),
            "p50": round(float(np.percentile(values, 50)), 3),
            "p95": round(float(np.percentile(values, 95)), 3),
            "min": round(float(np.min(values)), 3),
            "max": round(float(np.max(values)), 3),
        }

    def summary(self) -> dict:
        return {
            "n_trials": self.n_trials,
            "total_tonnes": self.distribution("total_tonnes"),
            "average_brix": self.distribution("average_brix"),
            "average_ta_gl": self.distribution("average_ta_gl"),
            "frost_events": self.distribution("frost_events"),
            "fermentations_stuck": self.distribution("fermentations_stuck"),
        }


def run_monte_carlo(
    estate_factory: Callable[[], object], vintage_year: int, n_trials: int = 100, master_seed: int = 20310101,
    scenario_keys: Optional[List[str]] = None, **sim_kwargs,
) -> MonteCarloSummary:
    """
    `estate_factory` returns a fresh Estate (deep-copyable / freshly built) for each trial.
    `scenario_keys`, if given, is sampled uniformly across trials (e.g. to blend "average",
    "cool", "warm" years into one investment-planning distribution); otherwise every trial
    uses the "average" scenario with only weather noise varying trial to trial.
    """
    master = RandomStreams(master_seed)
    scenario_keys = scenario_keys or ["average"]
    trials: List[TrialResult] = []

    for i in range(n_trials):
        trial_streams = master.child(f"trial_{i}")
        trial_seed = trial_streams.seed
        scenario = scenario_keys[i % len(scenario_keys)]

        estate = estate_factory()
        sim = VintageSimulation(estate, vintage_year=vintage_year, seed=trial_seed, scenario_key=scenario,
                                 **sim_kwargs)
        report = sim.run_vintage()

        trials.append(TrialResult(
            seed=trial_seed, scenario=scenario,
            harvest_dates=[o.harvest_lot_id.split("-")[1] for o in report.outcomes],
            total_tonnes=report.total_tonnes, average_brix=report.average_brix, average_ta_gl=report.average_ta_gl,
            frost_events=report.frost_events, fermentations_stuck=report.fermentations_stuck,
        ))

    return MonteCarloSummary(n_trials=n_trials, trials=trials)
