"""
grapple.optimisation.harvest
===============================

Harvest decision optimiser (Section 46): evaluates "Harvest Today, +1, +2,
... +10 days" for a block against a target wine style, without disturbing
the live simulation — a deep-copied "shadow" simulation is stepped forward
day by day so the *real* weather/phenology/ripening/disease models produce
each option's projected chemistry, rather than a separate extrapolation
model that could disagree with the live twin.
"""
from __future__ import annotations

import copy
import datetime as dt
from dataclasses import dataclass
from typing import List

from grapple.data.recipes import get_style
from grapple.viticulture.harvest import HarvestReadiness, assess_readiness


@dataclass
class HarvestOption:
    days_from_now: int
    date: dt.date
    brix: float
    ph: float
    ta_gl: float
    overall_readiness_pct: float
    chemistry_fit_pct: float
    disease_risk_index: float
    disease_risk_label: str
    projected_score: float
    notes: str = ""


def evaluate_harvest_options(sim, block_id: str, style_key: str = "traditional_sparkling",
                              max_days: int = 10) -> List[HarvestOption]:
    """`sim` is a live `core.simulation.VintageSimulation`. Returns one option per day 0..max_days."""
    style = get_style(style_key)
    shadow = copy.deepcopy(sim)
    options: List[HarvestOption] = []

    for day_offset in range(0, max_days + 1):
        block = shadow.state.estate.get_block(block_id)
        readiness = assess_readiness(block, style)
        disease_idx = max(block.disease.downy_mildew_pressure, block.disease.powdery_mildew_pressure,
                           block.disease.botrytis_pressure)

        # A simple, transparent combined score (Section 70): rewards style fit and maturity,
        # penalises rising disease risk the longer fruit hangs.
        score = 0.7 * readiness.overall_readiness_pct + 0.3 * readiness.chemistry_fit_pct - disease_idx * 25 * (1 + day_offset * 0.05)

        options.append(HarvestOption(
            days_from_now=day_offset, date=shadow.state.clock.current_date,
            brix=block.chemistry.brix, ph=block.chemistry.ph, ta_gl=block.chemistry.ta_gl,
            overall_readiness_pct=readiness.overall_readiness_pct, chemistry_fit_pct=readiness.chemistry_fit_pct,
            disease_risk_index=round(disease_idx, 3), disease_risk_label=readiness.disease_risk_label,
            projected_score=round(score, 1),
        ))

        if day_offset < max_days:
            shadow.step_day()

    return options


def recommend_harvest_window(options: List[HarvestOption], min_readiness_pct: float = 60.0) -> dict:
    """Ranks options and identifies a recommended window (Section 20's '7-11 days' style output)."""
    ranked = sorted(options, key=lambda o: o.projected_score, reverse=True)
    best = ranked[0]

    viable = [o for o in options if o.overall_readiness_pct >= min_readiness_pct]
    window = None
    if viable:
        window = {"earliest_day": min(o.days_from_now for o in viable),
                  "latest_day": max(o.days_from_now for o in viable)}

    return {
        "best_option": best, "ranked": ranked, "recommended_window_days_from_now": window,
        "all_options": options,
    }
