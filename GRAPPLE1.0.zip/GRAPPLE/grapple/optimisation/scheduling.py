"""
grapple.optimisation.scheduling
==================================

Winery production scheduler (Section 48/49): sequences harvest -> press ->
fermentation-tank-assignment tasks against press/tank/labour capacity,
respecting that equipment needs cleaning between incompatible batches and
cannot run two jobs at once — preventing the schedule from claiming
impossible simultaneous equipment use.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional


class TaskType(str, Enum):
    HARVEST = "harvest"
    PRESS = "press"
    FERMENTATION_START = "fermentation_start"
    CLEANING = "cleaning"
    BOTTLING = "bottling"


@dataclass
class ScheduledTask:
    task_id: str
    task_type: TaskType
    block_id: Optional[str]
    resource_id: str            # press id / tank id / bottling line id
    start: dt.datetime
    end: dt.datetime
    notes: str = ""


class ProductionScheduler:
    """Greedy earliest-available-slot scheduler across named resources."""

    def __init__(self):
        self._resource_free_at: Dict[str, dt.datetime] = {}
        self.tasks: List[ScheduledTask] = []
        self._counter = 0

    def _next_id(self) -> str:
        self._counter += 1
        return f"TASK-{self._counter:04d}"

    def resource_free_at(self, resource_id: str, earliest: dt.datetime) -> dt.datetime:
        return max(earliest, self._resource_free_at.get(resource_id, earliest))

    def schedule(self, task_type: TaskType, resource_id: str, duration_hours: float,
                 earliest_start: dt.datetime, block_id: Optional[str] = None,
                 cleaning_hours_after: float = 0.0, notes: str = "") -> ScheduledTask:
        start = self.resource_free_at(resource_id, earliest_start)
        end = start + dt.timedelta(hours=duration_hours)
        task = ScheduledTask(task_id=self._next_id(), task_type=task_type, block_id=block_id,
                              resource_id=resource_id, start=start, end=end, notes=notes)
        self.tasks.append(task)

        resource_free_from = end
        if cleaning_hours_after > 0:
            clean_task = ScheduledTask(
                task_id=self._next_id(), task_type=TaskType.CLEANING, block_id=None, resource_id=resource_id,
                start=end, end=end + dt.timedelta(hours=cleaning_hours_after), notes=f"post-{task_type.value} cleaning",
            )
            self.tasks.append(clean_task)
            resource_free_from = clean_task.end

        self._resource_free_at[resource_id] = resource_free_from
        return task

    def schedule_harvest_to_press_to_ferment(
        self, block_id: str, harvest_start: dt.datetime, harvest_hours: float, press_id: str,
        press_hours: float, tank_id: str, transfer_hours: float = 1.0, press_cleaning_hours: float = 1.5,
    ) -> List[ScheduledTask]:
        harvest = self.schedule(TaskType.HARVEST, f"crew-{block_id}", harvest_hours, harvest_start, block_id,
                                 notes=f"hand/mechanical harvest of {block_id}")
        press = self.schedule(TaskType.PRESS, press_id, press_hours, harvest.end, block_id,
                               cleaning_hours_after=press_cleaning_hours, notes=f"pressing {block_id} fruit")
        ferment = self.schedule(TaskType.FERMENTATION_START, tank_id, transfer_hours,
                                 press.end, block_id, notes=f"juice transferred to {tank_id}")
        return [harvest, press, ferment]

    def schedule_summary(self) -> List[dict]:
        return [
            {"task_id": t.task_id, "type": t.task_type.value, "block_id": t.block_id, "resource": t.resource_id,
             "start": t.start.isoformat(), "end": t.end.isoformat(), "notes": t.notes}
            for t in sorted(self.tasks, key=lambda t: t.start)
        ]
