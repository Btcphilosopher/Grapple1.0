"""
grapple.optimisation.fermentation
====================================

Fermentation strategy optimiser (Section 63/27): grid-searches temperature
target x yeast strain combinations, running each to completion on an
independent fermentation batch, and ranks them against a target style
profile (favouring a clean finish, low stuck-fermentation risk, and an
ethanol/aromatic outcome consistent with the chosen style).
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import List

import numpy as np

from grapple.winery.fermentation import FermentationBatch, FermentationStatus, run_to_completion
from grapple.winery.yeast import instantiate_strain

DEFAULT_TEMP_CANDIDATES = [12.0, 14.0, 16.0, 18.0, 22.0]
DEFAULT_YEAST_CANDIDATES = ["ec1118", "qa23", "d47", "native"]


@dataclass
class FermentationOption:
    temperature_target_c: float
    yeast_key: str
    final_ethanol_pct: float
    final_sugar_gl: float
    days_to_complete: int
    status: str
    score: float


def optimise_fermentation_strategy(
    base_batch: FermentationBatch, target_ethanol_pct: float, seed: int = 1,
    temperature_candidates: List[float] | None = None, yeast_candidates: List[str] | None = None,
) -> List[FermentationOption]:
    temperature_candidates = temperature_candidates or DEFAULT_TEMP_CANDIDATES
    yeast_candidates = yeast_candidates or DEFAULT_YEAST_CANDIDATES

    results: List[FermentationOption] = []
    for temp in temperature_candidates:
        for yeast_key in yeast_candidates:
            rng = np.random.default_rng(seed)
            batch = copy.deepcopy(base_batch)
            batch.temperature_target_c = temp
            batch.temperature_actual_c = temp
            batch.yeast_strain = instantiate_strain(yeast_key, rng)
            run_to_completion(batch, rng)

            ethanol_penalty = abs(batch.ethanol_pct - target_ethanol_pct) * 8
            stuck_penalty = 60.0 if batch.status == FermentationStatus.STUCK else 0.0
            speed_bonus = max(0.0, 10 - batch.day * 0.15)
            score = 100 - ethanol_penalty - stuck_penalty + speed_bonus

            results.append(FermentationOption(
                temperature_target_c=temp, yeast_key=yeast_key, final_ethanol_pct=round(batch.ethanol_pct, 2),
                final_sugar_gl=round(batch.sugar_gl, 1), days_to_complete=batch.day, status=batch.status.value,
                score=round(score, 1),
            ))

    return sorted(results, key=lambda r: r.score, reverse=True)
