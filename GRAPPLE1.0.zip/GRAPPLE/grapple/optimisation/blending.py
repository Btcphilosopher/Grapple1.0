"""
grapple.optimisation.blending
================================

"OPTIMISE BLEND" (Section 34): finds blend fractions that best hit a
user-defined target composition subject to constraints (fractions sum to
1, per-component bounds), using constrained least-squares via
scipy.optimize.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy.optimize import minimize

from grapple.winery.blending import BlendComponent, build_blend, BlendPlan
from grapple.wine.composition import WineComposition

# (attribute, target-relative weight) — larger weight = more important to hit exactly
_DEFAULT_OBJECTIVE_WEIGHTS = {
    "ethanol_pct": 1.0, "ph": 3.0, "ta_gl": 1.5, "residual_sugar_gl": 0.5,
}


@dataclass
class BlendOptimisationResult:
    fractions: Dict[str, float]
    plan: BlendPlan
    objective_value: float


def optimise_blend(
    components: List[BlendComponent], target: WineComposition,
    bounds: Optional[Dict[str, Tuple[float, float]]] = None,
    objective_weights: Optional[Dict[str, float]] = None,
) -> BlendOptimisationResult:
    weights = objective_weights or _DEFAULT_OBJECTIVE_WEIGHTS
    bounds = bounds or {}
    n = len(components)

    def objective(x: np.ndarray) -> float:
        predicted = build_blend(components, list(x)).predicted_composition
        total = 0.0
        for attr, w in weights.items():
            total += w * (getattr(predicted, attr) - getattr(target, attr)) ** 2
        return total

    x0 = np.full(n, 1.0 / n)
    bound_list = [bounds.get(c.batch_id, (0.0, 1.0)) for c in components]
    constraints = [{"type": "eq", "fun": lambda x: np.sum(x) - 1.0}]

    result = minimize(objective, x0, method="SLSQP", bounds=bound_list, constraints=constraints,
                       options={"maxiter": 200, "ftol": 1e-9})

    fractions = {c.batch_id: round(float(f), 4) for c, f in zip(components, result.x)}
    plan = build_blend(components, list(result.x))
    return BlendOptimisationResult(fractions=fractions, plan=plan, objective_value=round(float(result.fun), 5))
