"""
grapple.laboratory.chemistry
===============================

Laboratory test methods (Section 39). Every method takes the simulation's
*true* modelled value and returns a realistic MEASURED result with
method-appropriate uncertainty (Section 24 — "measurements should have
realistic measurement uncertainty"), explicitly tagged
`DataProvenance.OBSERVED` so downstream code (and calibration —
Section 42) can distinguish it from the underlying modelled value.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

from grapple.config import DataProvenance

# (test name -> typical analytical standard deviation, in the test's native units)
_TEST_UNCERTAINTY = {
    "brix": 0.15,
    "ph": 0.02,
    "ta": 0.3,           # g/L
    "malic_acid": 0.25,  # g/L
    "yan": 8.0,           # mg/L
    "alcohol": 0.08,      # %v/v
    "residual_sugar": 0.4,  # g/L
    "va": 0.03,            # g/L
    "so2_free": 1.5,        # mg/L
    "so2_total": 2.5,        # mg/L
    "turbidity": 3.0,          # NTU
    "temperature": 0.2,         # C
}


@dataclass
class LabResult:
    test: str
    measured_value: float
    true_value: float
    uncertainty_sd: float
    provenance: DataProvenance = DataProvenance.OBSERVED


def measure(test: str, true_value: float, rng: Optional[np.random.Generator] = None) -> LabResult:
    rng = rng or np.random.default_rng()
    sd = _TEST_UNCERTAINTY.get(test, max(0.01, abs(true_value) * 0.02))
    measured = float(true_value + rng.normal(0, sd))
    return LabResult(test=test, measured_value=round(measured, 3), true_value=round(true_value, 3),
                      uncertainty_sd=sd)


def measure_panel(true_values: dict, rng: Optional[np.random.Generator] = None) -> dict:
    """`true_values` maps test name -> true value. Returns test name -> LabResult."""
    return {test: measure(test, value, rng) for test, value in true_values.items()}
