"""
grapple.laboratory.analysis
==============================

Lab analysis service (Section 39): orchestrates sample requests, applies
the appropriate test methods, runs QC plausibility checks, and keeps a
per-source result history for calibration (Section 42) and traceability.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np

from grapple.laboratory.chemistry import LabResult, measure_panel
from grapple.laboratory.qc import QCFlag, check_panel
from grapple.laboratory.samples import Sample, SampleSource, draw_sample, log_custody


@dataclass
class AnalysisReport:
    sample: Sample
    results: Dict[str, LabResult]
    qc_flags: List[QCFlag]


class LabAnalysisService:
    def __init__(self, rng: Optional[np.random.Generator] = None):
        self.rng = rng or np.random.default_rng()
        self.history: List[AnalysisReport] = []

    def request_analysis(
        self, source: SampleSource, source_id: str, drawn_date: dt.date, true_values: Dict[str, float],
        drawn_by: str = "cellar_hand",
    ) -> AnalysisReport:
        sample = draw_sample(source, source_id, drawn_date, drawn_by)
        results = measure_panel(true_values, self.rng)
        log_custody(sample, "laboratory", f"analysed: {', '.join(results)}")
        flags = check_panel(results)
        report = AnalysisReport(sample=sample, results=results, qc_flags=flags)
        self.history.append(report)
        return report

    def history_for_source(self, source_id: str) -> List[AnalysisReport]:
        return [r for r in self.history if r.sample.source_id == source_id]
