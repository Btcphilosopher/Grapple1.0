"""
grapple.laboratory.samples
=============================

Virtual laboratory sample management (Section 39): sample IDs and a
chain-of-custody record from the point a sample is drawn (vineyard block,
juice lot, fermentation tank, maturation vessel, bottle) through to result
reporting.
"""
from __future__ import annotations

import datetime as dt
import itertools
from dataclasses import dataclass, field
from enum import Enum
from typing import List

_sample_counter = itertools.count(1)


class SampleSource(str, Enum):
    VINEYARD_BLOCK = "vineyard_block"
    JUICE_LOT = "juice_lot"
    FERMENTATION_TANK = "fermentation_tank"
    MATURATION_VESSEL = "maturation_vessel"
    BOTTLE = "bottle"


@dataclass
class CustodyEvent:
    timestamp: dt.datetime
    actor: str
    action: str


@dataclass
class Sample:
    sample_id: str
    source: SampleSource
    source_id: str
    drawn_date: dt.date
    custody: List[CustodyEvent] = field(default_factory=list)


def draw_sample(source: SampleSource, source_id: str, drawn_date: dt.date, drawn_by: str = "cellar_hand") -> Sample:
    sample = Sample(
        sample_id=f"SMP-{drawn_date:%Y%m%d}-{next(_sample_counter):05d}",
        source=source, source_id=source_id, drawn_date=drawn_date,
    )
    sample.custody.append(CustodyEvent(dt.datetime.combine(drawn_date, dt.time(9, 0)), drawn_by, "sample drawn"))
    return sample


def log_custody(sample: Sample, actor: str, action: str, when: dt.datetime | None = None) -> None:
    sample.custody.append(CustodyEvent(when or dt.datetime.now(), actor, action))
