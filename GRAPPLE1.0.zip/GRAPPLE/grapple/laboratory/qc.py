"""
grapple.laboratory.qc
========================

Laboratory result plausibility checks (part of Section 72 — "Quality
Control"). Flags a lab result that falls outside physically plausible
bounds, e.g. a transcription error or sensor fault, distinct from the
broader simulation-state plausibility checks in `digital_twin.anomaly`.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

PLAUSIBLE_RANGES = {
    "brix": (0.0, 35.0),
    "ph": (2.5, 4.5),
    "ta": (2.0, 20.0),
    "malic_acid": (0.0, 15.0),
    "yan": (0.0, 500.0),
    "alcohol": (0.0, 18.0),
    "residual_sugar": (0.0, 250.0),
    "va": (0.0, 2.0),
    "so2_free": (0.0, 80.0),
    "so2_total": (0.0, 250.0),
    "turbidity": (0.0, 2000.0),
    "temperature": (-5.0, 45.0),
}


@dataclass
class QCFlag:
    test: str
    value: float
    message: str


def check_result(test: str, value: float) -> List[QCFlag]:
    flags: List[QCFlag] = []
    bounds = PLAUSIBLE_RANGES.get(test)
    if bounds and not (bounds[0] <= value <= bounds[1]):
        flags.append(QCFlag(test=test, value=value,
                             message=f"{test}={value} outside plausible range {bounds} — check for a transcription "
                                     f"or measurement error before trusting this result"))
    return flags


def check_panel(results: dict) -> List[QCFlag]:
    """`results` maps test name -> measured value (e.g. from laboratory.chemistry.measure_panel)."""
    flags: List[QCFlag] = []
    for test, result in results.items():
        value = getattr(result, "measured_value", result)
        flags.extend(check_result(test, value))
    return flags
