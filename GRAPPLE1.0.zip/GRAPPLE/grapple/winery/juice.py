"""
grapple.winery.juice
=======================

Juice lot chemistry (Section 24) — the traceable link between a pressed
fraction and the fermentation batch it feeds. True (modelled) values live
here; realistic laboratory measurement uncertainty is applied by
`laboratory.chemistry` when a sample is drawn, not baked into this state.
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass

from grapple.winery.pressing import JuiceFraction

_juice_counter = itertools.count(1)


@dataclass
class JuiceLot:
    juice_lot_id: str
    harvest_lot_id: str
    press_id: str
    fraction_name: str
    volume_l: float
    brix: float
    ph: float
    ta_gl: float
    malic_acid_gl: float
    yan_mg_l: float
    turbidity_ntu: float
    temperature_c: float
    dissolved_oxygen_mg_l: float


def new_juice_lot(harvest_lot_id: str, press_id: str, fraction: JuiceFraction,
                   yan_mg_l: float, temperature_c: float, dissolved_oxygen_mg_l: float = 3.0) -> JuiceLot:
    return JuiceLot(
        juice_lot_id=f"JL-{next(_juice_counter):05d}", harvest_lot_id=harvest_lot_id, press_id=press_id,
        fraction_name=fraction.name, volume_l=fraction.volume_l, brix=fraction.brix, ph=fraction.ph,
        ta_gl=fraction.ta_gl, malic_acid_gl=round(fraction.ta_gl * 0.65, 2), yan_mg_l=yan_mg_l,
        turbidity_ntu=fraction.turbidity_ntu, temperature_c=temperature_c,
        dissolved_oxygen_mg_l=dissolved_oxygen_mg_l,
    )


def blend_juice_lots(lots: list[JuiceLot], new_id: str | None = None) -> JuiceLot:
    """Combine several juice lots (e.g. free-run + press-1) into a single fermentation charge."""
    total_v = sum(l.volume_l for l in lots) or 1.0
    def wavg(attr):
        return sum(getattr(l, attr) * l.volume_l for l in lots) / total_v

    return JuiceLot(
        juice_lot_id=new_id or f"JL-{next(_juice_counter):05d}",
        harvest_lot_id="+".join(sorted({l.harvest_lot_id for l in lots})),
        press_id="+".join(sorted({l.press_id for l in lots})),
        fraction_name="+".join(sorted({l.fraction_name for l in lots})),
        volume_l=round(total_v, 1), brix=round(wavg("brix"), 2), ph=round(wavg("ph"), 3),
        ta_gl=round(wavg("ta_gl"), 2), malic_acid_gl=round(wavg("malic_acid_gl"), 2),
        yan_mg_l=round(wavg("yan_mg_l"), 1), turbidity_ntu=round(wavg("turbidity_ntu"), 1),
        temperature_c=round(wavg("temperature_c"), 1), dissolved_oxygen_mg_l=round(wavg("dissolved_oxygen_mg_l"), 2),
    )
