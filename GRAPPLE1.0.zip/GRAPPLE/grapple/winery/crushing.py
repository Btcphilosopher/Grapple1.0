"""grapple.winery.crushing — crush/must preparation ahead of pressing (Section 23)."""
from __future__ import annotations

from dataclasses import dataclass

from grapple.winery.destemming import DestemmingResult


@dataclass
class CrushResult:
    input_kg: float
    must_kg: float
    phenolic_extraction_index: float   # 0-1, relative starting phenolic load carried into pressing


def crush(input_kg: float, destemming: DestemmingResult, gentle: bool = True) -> CrushResult:
    """Whole-cluster fruit skips crushing entirely (straight to press); crushed fruit gains phenolics."""
    if destemming.whole_cluster_fraction >= 0.999:
        return CrushResult(input_kg=input_kg, must_kg=input_kg, phenolic_extraction_index=0.05)

    crush_intensity = 0.15 if gentle else 0.35
    phenolic = crush_intensity * (1.0 - destemming.whole_cluster_fraction) + destemming.stem_phenolic_risk
    return CrushResult(input_kg=input_kg, must_kg=input_kg, phenolic_extraction_index=round(min(1.0, phenolic), 3))
