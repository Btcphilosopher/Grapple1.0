"""
grapple.winery.sparkling
===========================

Traditional-method sparkling wine module (Section 30):

    Base Wine -> Assemblage -> Tirage -> Secondary Fermentation ->
    Lees Ageing -> Remuage -> Disgorgement -> Dosage -> Bottle Ageing

Central to English sparkling production, so this gets a dedicated module
rather than being squeezed into the generic still-wine pathway.
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

import numpy as np

from grapple.wine.composition import WineComposition

_sparkling_counter = itertools.count(1)

TIRAGE_SUGAR_GL_STANDARD = 24.0     # g/L added sugar, standard tirage liqueur for ~6 bar at 20C
CO2_TO_PRESSURE_BAR_PER_GL_SUGAR = 6.0 / 24.0   # calibration point: 24g/L sugar -> ~6 bar at 12C in a 750ml bottle


class DosageStyle(str, Enum):
    BRUT_NATURE = "brut_nature"     # 0-3 g/L
    EXTRA_BRUT = "extra_brut"       # 0-6 g/L
    BRUT = "brut"                   # <12 g/L
    EXTRA_DRY = "extra_dry"         # 12-17 g/L
    DEMI_SEC = "demi_sec"           # 32-50 g/L


DOSAGE_TARGET_GL = {
    DosageStyle.BRUT_NATURE: 1.5, DosageStyle.EXTRA_BRUT: 4.0, DosageStyle.BRUT: 9.0,
    DosageStyle.EXTRA_DRY: 15.0, DosageStyle.DEMI_SEC: 40.0,
}


@dataclass
class SparklingBatch:
    sparkling_id: str
    base_wine_batch_id: str
    volume_l: float
    tirage_sugar_gl: float = TIRAGE_SUGAR_GL_STANDARD
    secondary_ferment_progress_pct: float = 0.0
    pressure_bar: float = 0.0
    lees_age_days: int = 0
    autolytic_character: float = 0.0   # 0-1 index — brioche/biscuit/toast development from lees contact
    remuage_progress_pct: float = 0.0
    disgorged: bool = False
    dosage_style: Optional[DosageStyle] = None
    dosage_gl: float = 0.0
    composition: WineComposition = field(default_factory=WineComposition)


def start_tirage(base_wine_batch_id: str, volume_l: float, base_composition: WineComposition,
                  tirage_sugar_gl: float = TIRAGE_SUGAR_GL_STANDARD) -> SparklingBatch:
    comp = base_composition.clone()
    comp.residual_sugar_gl += tirage_sugar_gl
    return SparklingBatch(
        sparkling_id=f"SP-{next(_sparkling_counter):04d}", base_wine_batch_id=base_wine_batch_id,
        volume_l=volume_l, tirage_sugar_gl=tirage_sugar_gl, composition=comp,
    )


def step_secondary_fermentation(batch: SparklingBatch, temperature_c: float, rng: np.random.Generator) -> None:
    """Slow, cool, closed-bottle secondary fermentation — several weeks to complete."""
    if batch.secondary_ferment_progress_pct >= 100.0:
        return
    temp_factor = max(0.2, min(1.3, (temperature_c - 8) / 8))
    daily_progress = max(0.3, 6.0 * temp_factor + rng.normal(0, 0.4))
    batch.secondary_ferment_progress_pct = min(100.0, batch.secondary_ferment_progress_pct + daily_progress)

    consumed_sugar = batch.tirage_sugar_gl * batch.secondary_ferment_progress_pct / 100.0
    batch.composition.residual_sugar_gl = max(0.0, batch.composition.residual_sugar_gl - consumed_sugar / 100.0)
    batch.composition.ethanol_pct += (daily_progress / 100.0) * (batch.tirage_sugar_gl / 17.0)
    batch.pressure_bar = min(6.5, batch.tirage_sugar_gl * CO2_TO_PRESSURE_BAR_PER_GL_SUGAR
                              * batch.secondary_ferment_progress_pct / 100.0)


def step_lees_ageing(batch: SparklingBatch) -> None:
    if batch.secondary_ferment_progress_pct < 100.0:
        return
    batch.lees_age_days += 1
    months = batch.lees_age_days / 30.0
    # Autolysis develops with diminishing returns, broadly plateauing well beyond ~36 months.
    batch.autolytic_character = round(min(1.0, 1 - pow(2.71828, -months / 18.0)), 4)
    batch.composition.aroma_compounds["autolytic_brioche"] = batch.autolytic_character


def run_remuage(batch: SparklingBatch, days: int = 21) -> None:
    """Riddling — purely operational (moves sediment to the neck); no chemistry effect modelled."""
    batch.remuage_progress_pct = 100.0


def disgorge(batch: SparklingBatch, dosage_style: DosageStyle, volume_loss_l_per_bottle: float = 0.02,
             bottle_volume_l: float = 0.75) -> None:
    if batch.remuage_progress_pct < 99.0:
        raise ValueError("Cannot disgorge before remuage is complete")
    bottles = batch.volume_l / bottle_volume_l
    loss_l = bottles * volume_loss_l_per_bottle
    batch.volume_l = max(0.0, batch.volume_l - loss_l)
    batch.disgorged = True
    batch.dosage_style = dosage_style
    apply_dosage(batch, dosage_style)


def apply_dosage(batch: SparklingBatch, dosage_style: DosageStyle) -> None:
    target = DOSAGE_TARGET_GL[dosage_style]
    batch.dosage_gl = target
    batch.composition.residual_sugar_gl += target
