"""grapple.winery.bottling — bottling line process model (Section 37)."""
from __future__ import annotations

import itertools
from dataclasses import dataclass
from enum import Enum

from grapple.wine.composition import WineComposition

_bottle_batch_counter = itertools.count(1)


class BottleFormat(str, Enum):
    STANDARD_750ML = "750ml"
    MAGNUM_1500ML = "1500ml"
    HALF_375ML = "375ml"


class ClosureType(str, Enum):
    CORK_NATURAL = "cork_natural"
    CORK_TECHNICAL = "cork_technical"
    SCREWCAP = "screwcap"
    CROWN_CAP = "crown_cap"     # traditional-method sparkling during tirage/lees ageing


BOTTLE_VOLUME_L = {BottleFormat.STANDARD_750ML: 0.75, BottleFormat.MAGNUM_1500ML: 1.5, BottleFormat.HALF_375ML: 0.375}

# oxygen pickup at bottling, mg/L, by closure (screwcap lowest, natural cork highest/most variable)
_CLOSURE_OXYGEN_PICKUP = {
    ClosureType.SCREWCAP: 0.3, ClosureType.CROWN_CAP: 0.2,
    ClosureType.CORK_TECHNICAL: 0.6, ClosureType.CORK_NATURAL: 1.1,
}


@dataclass
class BottlingResult:
    bottled_batch_id: str
    source_batch_id: str
    format: BottleFormat
    closure: ClosureType
    input_volume_l: float
    bottles_produced: int
    bottling_loss_l: float
    oxygen_pickup_mg_l: float


def bottle_batch(source_batch_id: str, comp: WineComposition, volume_l: float, format: BottleFormat,
                  closure: ClosureType, filtration_loss_pct: float = 2.0, line_loss_pct: float = 1.5) -> BottlingResult:
    total_loss_pct = filtration_loss_pct + line_loss_pct
    usable_volume = volume_l * (1 - total_loss_pct / 100.0)
    unit_volume = BOTTLE_VOLUME_L[format]
    bottles = int(usable_volume / unit_volume)

    o2_pickup = _CLOSURE_OXYGEN_PICKUP[closure]
    comp.dissolved_oxygen_mg_l += o2_pickup

    return BottlingResult(
        bottled_batch_id=f"BB-{next(_bottle_batch_counter):05d}", source_batch_id=source_batch_id,
        format=format, closure=closure, input_volume_l=round(volume_l, 1), bottles_produced=bottles,
        bottling_loss_l=round(volume_l - usable_volume, 1), oxygen_pickup_mg_l=o2_pickup,
    )
