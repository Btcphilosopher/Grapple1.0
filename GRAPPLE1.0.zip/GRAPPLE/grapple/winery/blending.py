"""
grapple.winery.blending
==========================

Blending engine (Section 34). Predicts a blend's chemistry from
volume-weighted component batches, and provides a constrained optimiser
(scipy) that searches for blend proportions meeting user-defined targets
(the higher-level "OPTIMISE BLEND" workflow lives in
`optimisation.blending`, which calls into this module).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

import numpy as np

from grapple.wine.composition import WineComposition, blend_weighted


@dataclass
class BlendComponent:
    batch_id: str
    label: str
    volume_l: float
    composition: WineComposition
    cost_gbp_per_l: float = 0.0


@dataclass
class BlendPlan:
    components: List[tuple]        # (BlendComponent, fraction 0-1)
    total_volume_l: float
    predicted_composition: WineComposition
    predicted_cost_gbp_per_l: float


def build_blend(components: List[BlendComponent], fractions: List[float]) -> BlendPlan:
    """`fractions` are volume fractions (sum should be ~1.0) of the FINAL blend volume."""
    total_volume = sum(c.volume_l for c in components) if not fractions else sum(fractions) and 1.0
    weighted = [(c.composition, f) for c, f in zip(components, fractions)]
    predicted = blend_weighted(weighted)
    total_frac = sum(fractions) or 1.0
    cost = sum(c.cost_gbp_per_l * f for c, f in zip(components, fractions)) / total_frac

    return BlendPlan(
        components=list(zip(components, fractions)),
        total_volume_l=round(sum(min(c.volume_l, c.volume_l) for c in components), 1),
        predicted_composition=predicted, predicted_cost_gbp_per_l=round(cost, 3),
    )


def blend_available_volume_l(components: List[BlendComponent], fractions: List[float], target_volume_l: float) -> List[float]:
    """Convert target-volume fractions into litres actually drawn from each component, capped at what's available."""
    return [min(c.volume_l, f * target_volume_l) for c, f in zip(components, fractions)]
