"""grapple.winery.destemming — whole-cluster vs. destemmed processing path (Section 23)."""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class DestemmingMode(str, Enum):
    WHOLE_CLUSTER = "whole_cluster"     # straight to press, no destemming (classic sparkling base method)
    DESTEMMED = "destemmed"
    PARTIAL = "partial"


@dataclass
class DestemmingResult:
    mode: DestemmingMode
    whole_cluster_fraction: float
    stem_phenolic_risk: float    # 0-1, higher whole-cluster fraction raises harsh/green phenolic extraction risk


def apply_destemming(mode: DestemmingMode, whole_cluster_fraction: float = 0.0) -> DestemmingResult:
    frac = 1.0 if mode == DestemmingMode.WHOLE_CLUSTER else (
        0.0 if mode == DestemmingMode.DESTEMMED else max(0.0, min(1.0, whole_cluster_fraction))
    )
    return DestemmingResult(mode=mode, whole_cluster_fraction=frac, stem_phenolic_risk=round(frac * 0.4, 3))
