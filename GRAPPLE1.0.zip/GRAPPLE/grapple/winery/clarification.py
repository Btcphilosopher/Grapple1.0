"""grapple.winery.clarification — settling, fining and filtration (Section 24/37)."""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from grapple.wine.composition import WineComposition


class ClarificationMethod(str, Enum):
    COLD_SETTLING = "cold_settling"
    FINING = "fining"
    FILTRATION_COARSE = "filtration_coarse"
    FILTRATION_STERILE = "filtration_sterile"


_METHOD_EFFECT = {
    # (turbidity reduction fraction, volume loss fraction, phenolic loss fraction)
    ClarificationMethod.COLD_SETTLING: (0.55, 0.03, 0.05),
    ClarificationMethod.FINING: (0.65, 0.02, 0.12),
    ClarificationMethod.FILTRATION_COARSE: (0.75, 0.015, 0.03),
    ClarificationMethod.FILTRATION_STERILE: (0.95, 0.02, 0.06),
}


@dataclass
class ClarificationResult:
    method: ClarificationMethod
    turbidity_before_ntu: float
    turbidity_after_ntu: float
    volume_before_l: float
    volume_after_l: float


def apply_clarification(comp: WineComposition, volume_l: float, method: ClarificationMethod) -> ClarificationResult:
    turbidity_reduction, volume_loss, phenolic_loss = _METHOD_EFFECT[method]
    before_turbidity = comp.turbidity_ntu
    before_volume = volume_l

    comp.turbidity_ntu = max(0.5, comp.turbidity_ntu * (1 - turbidity_reduction))
    comp.phenolics_index = max(0.0, comp.phenolics_index * (1 - phenolic_loss))
    new_volume = volume_l * (1 - volume_loss)

    return ClarificationResult(
        method=method, turbidity_before_ntu=round(before_turbidity, 1),
        turbidity_after_ntu=round(comp.turbidity_ntu, 1), volume_before_l=round(before_volume, 1),
        volume_after_l=round(new_volume, 1),
    )
