"""grapple.winery.sorting — fruit sorting on intake (Section 22 -> 23 pipeline)."""
from __future__ import annotations

from dataclasses import dataclass

from grapple.winery.reception import HarvestLot


@dataclass
class SortingResult:
    input_kg: float
    accepted_kg: float
    rejected_kg: float
    rejected_pct: float


def sort_lot(lot: HarvestLot, optical_sorting: bool = False) -> SortingResult:
    """Remove MOG (material other than grapes) and damaged/diseased fruit before crush/press."""
    base_reject = max(0.5, (100 - lot.quality_score) * 0.35)
    if lot.mechanical_harvest:
        base_reject += 2.0
    if optical_sorting:
        base_reject *= 0.4   # optical sorters catch substantially more than manual triage

    rejected_pct = min(25.0, base_reject)
    rejected_kg = lot.weight_kg * rejected_pct / 100.0
    accepted_kg = lot.weight_kg - rejected_kg
    return SortingResult(
        input_kg=lot.weight_kg, accepted_kg=round(accepted_kg, 1), rejected_kg=round(rejected_kg, 1),
        rejected_pct=round(rejected_pct, 2),
    )
