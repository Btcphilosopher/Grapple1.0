"""
grapple.winery.pressing
==========================

Pressing simulation (Section 23). Splits the must/whole-cluster charge
into successive juice fractions of rising pressure — each fraction yields
less juice but carries more turbidity and phenolic extraction than the
last, which is why sparkling/delicate white production typically keeps
only the free-run and first press fractions ("cuvée"/"tête de cuvée")
separate from the harder-pressed, coarser "tailles".
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

from grapple.winery.crushing import CrushResult

# (fraction name, yield L/tonne, turbidity NTU baseline, phenolic extraction multiplier)
_FRACTION_PROFILE = [
    ("free_run", 200.0, 60.0, 0.5),
    ("press_1", 280.0, 140.0, 0.9),
    ("press_2", 180.0, 280.0, 1.3),
    ("press_hard", 90.0, 550.0, 1.8),
]
WASTE_L_PER_TONNE = 40.0   # pomace-retained liquid, unrecoverable


@dataclass
class JuiceFraction:
    name: str
    volume_l: float
    turbidity_ntu: float
    phenolic_index: float     # 0-1 relative phenolic extraction of this fraction
    brix: float
    ph: float
    ta_gl: float


@dataclass
class PressResult:
    press_id: str
    input_kg: float
    pressure_bar: float
    cycle_time_hours: float
    fractions: List[JuiceFraction]
    total_juice_l: float
    juice_yield_l_per_tonne: float
    waste_l: float


def run_press(
    press_id: str,
    input_kg: float,
    crush_result: CrushResult,
    base_brix: float,
    base_ph: float,
    base_ta_gl: float,
    pressure_bar: float = 1.6,
    cycle_time_hours: float = 3.5,
    keep_hard_press: bool = True,
) -> PressResult:
    tonnes = input_kg / 1000.0
    pressure_factor = max(0.6, min(1.6, pressure_bar / 1.6))

    fractions: List[JuiceFraction] = []
    for name, yield_lt, turbidity_base, phenolic_mult in _FRACTION_PROFILE:
        if name == "press_hard" and not keep_hard_press:
            continue
        volume = yield_lt * tonnes * (0.85 + 0.3 * (pressure_factor if name != "free_run" else 1.0))
        turbidity = turbidity_base * pressure_factor
        phenolic = min(1.0, phenolic_mult * crush_result.phenolic_extraction_index * pressure_factor
                       if crush_result.phenolic_extraction_index > 0 else phenolic_mult * 0.15)
        # Harder-pressed fractions extract slightly more sugar (less-ripe pulp) and less acid (skin/pulp dilution).
        brix = base_brix * (1.0 - 0.01 * _FRACTION_PROFILE.index((name, yield_lt, turbidity_base, phenolic_mult)))
        ph = base_ph + 0.02 * _FRACTION_PROFILE.index((name, yield_lt, turbidity_base, phenolic_mult))
        ta = base_ta_gl * (1.0 - 0.03 * _FRACTION_PROFILE.index((name, yield_lt, turbidity_base, phenolic_mult)))

        fractions.append(JuiceFraction(
            name=name, volume_l=round(volume, 1), turbidity_ntu=round(turbidity, 1),
            phenolic_index=round(phenolic, 3), brix=round(brix, 2), ph=round(ph, 3), ta_gl=round(ta, 2),
        ))

    total_juice = sum(f.volume_l for f in fractions)
    waste = WASTE_L_PER_TONNE * tonnes

    return PressResult(
        press_id=press_id, input_kg=input_kg, pressure_bar=pressure_bar, cycle_time_hours=cycle_time_hours,
        fractions=fractions, total_juice_l=round(total_juice, 1),
        juice_yield_l_per_tonne=round(total_juice / max(0.001, tonnes), 1), waste_l=round(waste, 1),
    )
