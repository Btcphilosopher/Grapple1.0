"""
grapple.winery.maturation
============================

Maturation model (Section 32/33) across stainless steel, oak, concrete,
other neutral vessels and bottle. Oak vessels (Section 33) add
configurable extraction and oxygen transfer on top of the generic vessel
oxidative/evaporative model.
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from grapple.data.recipes import OakData, get_oak
from grapple.wine.chemistry import apply_oxidative_drift, apply_so2_consumption
from grapple.wine.composition import WineComposition

_vessel_counter = itertools.count(1)


class VesselType(str, Enum):
    STAINLESS_STEEL = "stainless_steel"
    OAK_BARREL = "oak_barrel"
    CONCRETE = "concrete"
    NEUTRAL = "neutral"
    BOTTLE = "bottle"


# Annual oxygen transfer rate (mg/L/year) and evaporation ("angel's share", %/year) by vessel type,
# for vessels without an explicit OakData profile.
_VESSEL_BASELINE = {
    VesselType.STAINLESS_STEEL: (2.0, 0.0),
    VesselType.CONCRETE: (8.0, 0.5),
    VesselType.NEUTRAL: (15.0, 1.0),
    VesselType.BOTTLE: (0.8, 0.0),
}


@dataclass
class MaturationVessel:
    vessel_id: str
    vessel_type: VesselType
    volume_l: float
    oak_profile: Optional[OakData] = None
    fill_history_uses: int = 0     # 0 = new/first-fill barrel
    contents_batch_id: Optional[str] = None
    days_in_vessel: int = 0


def new_vessel(vessel_type: VesselType, volume_l: float, oak_key: Optional[str] = None,
               fill_history_uses: int = 0) -> MaturationVessel:
    oak = get_oak(oak_key) if (vessel_type == VesselType.OAK_BARREL and oak_key) else None
    return MaturationVessel(
        vessel_id=f"VES-{next(_vessel_counter):04d}", vessel_type=vessel_type, volume_l=volume_l,
        oak_profile=oak, fill_history_uses=fill_history_uses,
    )


def _oxygen_and_evaporation_rates(vessel: MaturationVessel) -> tuple[float, float]:
    if vessel.vessel_type == VesselType.OAK_BARREL and vessel.oak_profile:
        # Older/more-used barrels transfer less oxygen and extract less flavour (neutralised wood).
        age_decay = max(0.25, 1.0 - 0.15 * vessel.fill_history_uses)
        o2_rate = vessel.oak_profile.oxygen_transfer_rate_mg_l_year * age_decay
        evap_pct_year = 3.0 * age_decay + 1.0
        return o2_rate, evap_pct_year
    return _VESSEL_BASELINE[vessel.vessel_type]


def step_maturation(vessel: MaturationVessel, comp: WineComposition, volume_l: float,
                     temperature_c: float = 13.0) -> dict:
    """Advance maturation by one day: oxygen ingress, evaporation, oak extraction, SO2 consumption."""
    vessel.days_in_vessel += 1
    o2_rate_year, evap_pct_year = _oxygen_and_evaporation_rates(vessel)

    daily_o2 = o2_rate_year / 365.0
    apply_oxidative_drift(comp, daily_o2)
    apply_so2_consumption(comp, temperature_c)

    daily_evap_fraction = (evap_pct_year / 100.0) / 365.0
    new_volume = volume_l * (1 - daily_evap_fraction)

    extraction_delta = 0.0
    if vessel.vessel_type == VesselType.OAK_BARREL and vessel.oak_profile:
        age_decay = max(0.25, 1.0 - 0.15 * vessel.fill_history_uses)
        extraction_delta = 0.0008 * vessel.oak_profile.extraction_rate * age_decay
        comp.phenolics_index = min(1.0, comp.phenolics_index + extraction_delta)
        comp.tannins_index = min(1.0, comp.tannins_index + extraction_delta * 0.6)
        comp.aroma_compounds["oak"] = min(1.0, comp.aroma_compounds.get("oak", 0.0) + extraction_delta * 1.5)

    return {
        "volume_l": round(new_volume, 2), "oxygen_added_mg_l": round(daily_o2, 4),
        "evaporation_l": round(volume_l - new_volume, 3), "extraction_delta": round(extraction_delta, 5),
    }
