"""
grapple.winery.reception
===========================

Winery reception (Section 22): weigh, sample, inspect and record incoming
fruit, creating the root node of the lot/batch traceability chain
(Section 50):

    Bottle -> Batch -> Blend -> Tank -> Fermentation -> Juice -> Press ->
    Harvest Lot -> Vineyard Block -> Vineyard
"""
from __future__ import annotations

import datetime as dt
import itertools
from dataclasses import dataclass, field
from typing import Optional

_lot_counter = itertools.count(1)


@dataclass
class HarvestLot:
    lot_id: str
    block_id: str
    variety_key: str
    harvest_date: dt.date
    weight_kg: float
    brix: float
    ph: float
    ta_gl: float
    intake_temperature_c: float
    quality_score: float          # 0-100, from visual inspection at reception
    disease_notes: str = ""
    mechanical_harvest: bool = False


def new_lot_id(block_id: str, harvest_date: dt.date) -> str:
    return f"HL-{harvest_date:%Y%m%d}-{block_id}-{next(_lot_counter):04d}"


def receive_grapes(
    block_id: str,
    variety_key: str,
    harvest_date: dt.date,
    weight_kg: float,
    brix: float,
    ph: float,
    ta_gl: float,
    intake_temperature_c: float,
    disease_risk_index: float = 0.0,
    mechanical_harvest: bool = False,
) -> HarvestLot:
    """Log an incoming load of fruit at the winery gate."""
    quality_score = max(30.0, 100.0 - disease_risk_index * 60.0 - (8.0 if mechanical_harvest else 0.0))
    notes = "elevated disease pressure observed" if disease_risk_index > 0.45 else ""
    return HarvestLot(
        lot_id=new_lot_id(block_id, harvest_date), block_id=block_id, variety_key=variety_key,
        harvest_date=harvest_date, weight_kg=round(weight_kg, 1), brix=round(brix, 2), ph=round(ph, 3),
        ta_gl=round(ta_gl, 2), intake_temperature_c=round(intake_temperature_c, 1),
        quality_score=round(quality_score, 1), disease_notes=notes, mechanical_harvest=mechanical_harvest,
    )
