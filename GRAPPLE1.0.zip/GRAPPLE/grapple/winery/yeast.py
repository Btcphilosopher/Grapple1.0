"""
grapple.winery.yeast
======================

Behavioural layer over the yeast-strain reference data (Section 26).
Strain parameters here are explicitly simulation parameters, not a
laboratory certificate — this is most visible for `native` fermentation,
where GRAPPLE stochastically perturbs the strain's nominal parameters each
time it is used, representing the genuine unpredictability of spontaneous
fermentation rather than pretending to know in advance which flora will
dominate.
"""
from __future__ import annotations

from dataclasses import dataclass, replace

import numpy as np

from grapple.data.recipes import YeastStrainData, get_yeast


def temperature_suitability(strain: YeastStrainData, temp_c: float) -> float:
    """Gaussian suitability (0-1) around the strain's optimum, zero outside its tolerated range."""
    if temp_c < strain.temp_min_c or temp_c > strain.temp_max_c:
        return 0.0
    sigma = max(2.0, (strain.temp_max_c - strain.temp_min_c) / 4.0)
    return float(np.exp(-0.5 * ((temp_c - strain.temp_optimum_c) / sigma) ** 2))


def instantiate_strain(key: str, rng: np.random.Generator | None = None) -> YeastStrainData:
    """
    Returns the effective strain to use for a fermentation. For `native`,
    draws a randomised variant around the nominal native-flora parameters
    (Section 26) — labelled clearly as a stochastic simulation choice.
    """
    base = get_yeast(key)
    if key != "native" or rng is None:
        return base

    return replace(
        base,
        temp_optimum_c=float(np.clip(rng.normal(base.temp_optimum_c, 2.5), base.temp_min_c, base.temp_max_c)),
        fermentation_speed=float(max(0.3, rng.normal(base.fermentation_speed, 0.15))),
        attenuation=float(np.clip(rng.normal(base.attenuation, 0.03), 0.8, 0.999)),
        stress_sensitivity=float(np.clip(rng.normal(base.stress_sensitivity, 0.1), 0.3, 0.99)),
    )
