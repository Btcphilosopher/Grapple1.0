"""
grapple.winery.fermentation
==============================

The fermentation engine (Section 25-27) — the most sophisticated subsystem
in GRAPPLE. Simulates daily (sub-daily via `steps_per_day`) sugar
depletion, yeast population growth, ethanol/CO2 production and nutrient
drawdown, with temperature actively shaping every rate, so user control
choices (temperature target, cooling capacity, nutrient additions, yeast
choice) visibly change the resulting wine.

Stoichiometry: fermentation of glucose/fructose by S. cerevisiae yields
(per gram of sugar consumed) ~0.51g ethanol and ~0.49g CO2 (standard
textbook yield coefficients from C6H12O6 -> 2 C2H5OH + 2 CO2).
~17g/L of sugar consumed raises ethanol by ~1% v/v (a standard cellar
approximation), used here to convert the ethanol mass balance to %ABV.
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional

import numpy as np

from grapple.data.recipes import YeastStrainData
from grapple.winery.juice import JuiceLot
from grapple.winery.yeast import temperature_suitability
from grapple.wine.composition import WineComposition

_batch_counter = itertools.count(1)

ETHANOL_YIELD_G_PER_G_SUGAR = 0.51
CO2_YIELD_G_PER_G_SUGAR = 0.49
SUGAR_GL_PER_ABV_PERCENT = 17.0
YAN_CONSUMED_PER_ABV_PERCENT = 8.0   # mg/L YAN drawn down per %ABV produced, roughly


class FermentationStatus(str, Enum):
    NOT_STARTED = "not_started"
    LAG = "lag_phase"
    ACTIVE = "active"
    SLOWING = "slowing"
    COMPLETE = "complete"
    STUCK = "stuck"


@dataclass
class FermentationDaySnapshot:
    day: int
    sugar_gl: float
    ethanol_pct: float
    temperature_c: float
    co2_rate_g_l_day: float
    population_index: float
    yan_mg_l: float
    status: FermentationStatus


@dataclass
class FermentationBatch:
    batch_id: str
    juice_lot_id: str
    tank_id: str
    yeast_strain: YeastStrainData
    volume_l: float
    starting_brix: float
    starting_yan_mg_l: float
    temperature_target_c: float = 16.0
    cooling_capacity_adequate: bool = True

    sugar_gl: float = field(init=False)
    yan_mg_l: float = field(init=False)
    ethanol_pct: float = 0.0
    population_index: float = 0.01     # 0-1 relative yeast population
    temperature_actual_c: float = field(init=False)
    day: int = 0
    status: FermentationStatus = FermentationStatus.NOT_STARTED
    stuck_check_streak: int = 0
    history: List[FermentationDaySnapshot] = field(default_factory=list)
    composition: WineComposition = field(default_factory=WineComposition)

    def __post_init__(self):
        self.sugar_gl = self.starting_brix * 10.5
        self.yan_mg_l = self.starting_yan_mg_l
        self.temperature_actual_c = self.temperature_target_c


def new_batch(juice: JuiceLot, tank_id: str, yeast_strain: YeastStrainData,
              temperature_target_c: float = 16.0) -> FermentationBatch:
    return FermentationBatch(
        batch_id=f"FB-{next(_batch_counter):05d}", juice_lot_id=juice.juice_lot_id, tank_id=tank_id,
        yeast_strain=yeast_strain, volume_l=juice.volume_l, starting_brix=juice.brix,
        starting_yan_mg_l=juice.yan_mg_l, temperature_target_c=temperature_target_c,
    )


def _apply_temperature_control(batch: FermentationBatch, ambient_c: float, fermentation_rate_g_l_day: float) -> float:
    """
    Actual tank temperature drifts toward target if cooling capacity is
    adequate; if not (Section 47 — winery capacity constraints), heat from
    active fermentation pushes the actual temperature above target,
    raising stuck-fermentation risk.
    """
    heat_load = fermentation_rate_g_l_day * 0.008   # crude proportionality: faster ferment -> more exotherm
    if batch.cooling_capacity_adequate:
        batch.temperature_actual_c += (batch.temperature_target_c - batch.temperature_actual_c) * 0.5
    else:
        drift_target = batch.temperature_target_c + heat_load * 3.0
        batch.temperature_actual_c += (drift_target - batch.temperature_actual_c) * 0.3
    return batch.temperature_actual_c


def step(batch: FermentationBatch, rng: np.random.Generator, ambient_c: float = 16.0,
         nutrient_addition_mg_l: float = 0.0) -> FermentationDaySnapshot:
    """Advance fermentation by one day. Mutates and returns a snapshot for the fermentation curve."""
    strain = batch.yeast_strain
    batch.day += 1
    batch.yan_mg_l += nutrient_addition_mg_l

    if batch.status in (FermentationStatus.COMPLETE, FermentationStatus.STUCK):
        snap = FermentationDaySnapshot(batch.day, round(batch.sugar_gl, 1), round(batch.ethanol_pct, 2),
                                        round(batch.temperature_actual_c, 1), 0.0,
                                        round(batch.population_index, 3), round(batch.yan_mg_l, 1), batch.status)
        batch.history.append(snap)
        return snap

    if batch.status == FermentationStatus.NOT_STARTED:
        batch.status = FermentationStatus.LAG

    temp_suit = temperature_suitability(strain, batch.temperature_actual_c)

    # Population grows logistically while nutrients and temperature allow it.
    nutrient_growth_factor = min(1.0, batch.yan_mg_l / (60.0 * strain.nutrient_demand))
    growth_rate = 0.35 * temp_suit * nutrient_growth_factor
    batch.population_index = min(1.0, batch.population_index + growth_rate * batch.population_index * (1 - batch.population_index) + 0.01 * growth_rate)

    if batch.population_index > 0.15 and batch.status == FermentationStatus.LAG:
        batch.status = FermentationStatus.ACTIVE

    target_sugar_gl = batch.starting_brix * 10.5 * (1 - strain.attenuation)
    sugar_available = max(0.0, batch.sugar_gl - target_sugar_gl)

    ethanol_inhibition = max(0.0, 1.0 - (batch.ethanol_pct / max(1.0, strain.alcohol_tolerance_pct)) ** 2)
    max_rate = 28.0 * strain.fermentation_speed  # g/L/day at full population & optimum conditions
    consumption = (max_rate * batch.population_index * temp_suit * ethanol_inhibition
                   * nutrient_growth_factor * min(1.0, sugar_available / 40.0))
    consumption = max(0.0, min(sugar_available, consumption))

    # Stuck-fermentation risk: elevated by temperature outside range, nutrient depletion, high stress sensitivity.
    stress = (1 - temp_suit) * 0.5 + (1 - nutrient_growth_factor) * 0.5
    stuck_risk = stress * strain.stress_sensitivity * 0.06
    if sugar_available > 5.0 and consumption < 0.5:
        batch.stuck_check_streak += 1
    else:
        batch.stuck_check_streak = 0
    if batch.stuck_check_streak >= 4 or (rng.random() < stuck_risk and batch.day > 3):
        batch.status = FermentationStatus.STUCK

    batch.sugar_gl = max(target_sugar_gl, batch.sugar_gl - consumption)
    d_ethanol = consumption / SUGAR_GL_PER_ABV_PERCENT
    batch.ethanol_pct += d_ethanol
    batch.yan_mg_l = max(5.0, batch.yan_mg_l - d_ethanol * YAN_CONSUMED_PER_ABV_PERCENT)
    co2_rate = consumption * (CO2_YIELD_G_PER_G_SUGAR / max(0.001, ETHANOL_YIELD_G_PER_G_SUGAR)) * (ETHANOL_YIELD_G_PER_G_SUGAR)

    if batch.status not in (FermentationStatus.STUCK,) and (batch.sugar_gl <= target_sugar_gl + 0.5 or consumption < 0.05):
        if batch.day > 2:
            batch.status = FermentationStatus.COMPLETE
    elif batch.status == FermentationStatus.ACTIVE and consumption < max_rate * 0.15:
        batch.status = FermentationStatus.SLOWING

    _apply_temperature_control(batch, ambient_c, consumption)

    batch.composition.ethanol_pct = round(batch.ethanol_pct, 2)
    batch.composition.residual_sugar_gl = round(batch.sugar_gl, 1)

    snap = FermentationDaySnapshot(
        day=batch.day, sugar_gl=round(batch.sugar_gl, 1), ethanol_pct=round(batch.ethanol_pct, 2),
        temperature_c=round(batch.temperature_actual_c, 1), co2_rate_g_l_day=round(co2_rate, 2),
        population_index=round(batch.population_index, 3), yan_mg_l=round(batch.yan_mg_l, 1), status=batch.status,
    )
    batch.history.append(snap)
    return snap


def run_to_completion(batch: FermentationBatch, rng: np.random.Generator, ambient_c: float = 16.0,
                       max_days: int = 40) -> FermentationBatch:
    for _ in range(max_days):
        step(batch, rng, ambient_c=ambient_c)
        if batch.status in (FermentationStatus.COMPLETE, FermentationStatus.STUCK):
            break
    return batch


def fermentation_curve(batch: FermentationBatch) -> dict:
    """Data for the Section 25 sugar-depletion curve chart."""
    return {
        "days": [s.day for s in batch.history],
        "sugar_gl": [s.sugar_gl for s in batch.history],
        "ethanol_pct": [s.ethanol_pct for s in batch.history],
        "temperature_c": [s.temperature_c for s in batch.history],
        "status": batch.status.value,
    }
