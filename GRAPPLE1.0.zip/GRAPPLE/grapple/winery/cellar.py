"""
grapple.winery.cellar
========================

Cellar inventory manager: tanks, maturation vessels and bottled stock, plus
the traceability graph (Section 22/50):

    Bottle -> Batch -> Blend -> Tank -> Fermentation -> Juice -> Press ->
    Harvest Lot -> Vineyard Block -> Vineyard

Also enforces winery capacity constraints (Section 47) — the vineyard
cannot produce more wine than the fermentation/cellar/bottling capacity can
actually hold and process.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from grapple.equipment.tanks import Tank
from grapple.winery.maturation import MaturationVessel


@dataclass
class TraceabilityLink:
    child_id: str
    parent_id: str
    relation: str    # e.g. "pressed_from", "fermented_from", "blended_from", "bottled_from"


class TraceabilityGraph:
    def __init__(self):
        self._links: List[TraceabilityLink] = []

    def link(self, child_id: str, parent_id: str, relation: str) -> None:
        self._links.append(TraceabilityLink(child_id, parent_id, relation))

    def trace_back(self, entity_id: str) -> List[TraceabilityLink]:
        """Walk the chain backward from `entity_id` to its ultimate origin(s)."""
        chain: List[TraceabilityLink] = []
        frontier = [entity_id]
        seen = set()
        while frontier:
            current = frontier.pop()
            if current in seen:
                continue
            seen.add(current)
            for link in self._links:
                if link.child_id == current:
                    chain.append(link)
                    for parent in link.parent_id.split("+"):
                        frontier.append(parent)
        return chain


@dataclass
class BottledStock:
    bottled_batch_id: str
    format: str
    bottles_available: int
    bottles_total: int


class Cellar:
    def __init__(self, fermentation_capacity_l: float, cellar_capacity_l: float,
                 bottling_capacity_bottles_per_day: float):
        self.fermentation_capacity_l = fermentation_capacity_l
        self.cellar_capacity_l = cellar_capacity_l
        self.bottling_capacity_bottles_per_day = bottling_capacity_bottles_per_day

        self.tanks: Dict[str, Tank] = {}
        self.vessels: Dict[str, MaturationVessel] = {}
        self.bottled_stock: Dict[str, BottledStock] = {}
        self.trace = TraceabilityGraph()

    def add_tank(self, tank: Tank) -> None:
        self.tanks[tank.equipment_id] = tank

    def add_vessel(self, vessel: MaturationVessel) -> None:
        self.vessels[vessel.vessel_id] = vessel

    def fermentation_volume_in_use(self) -> float:
        return sum(t.volume_l for t in self.tanks.values() if not t.is_free)

    def fermentation_capacity_available(self) -> float:
        return max(0.0, self.fermentation_capacity_l - self.fermentation_volume_in_use())

    def find_free_tank(self, min_volume_l: float) -> Optional[Tank]:
        candidates = [t for t in self.tanks.values() if t.is_free and t.volume_l >= min_volume_l]
        if not candidates:
            return None
        return min(candidates, key=lambda t: t.volume_l)  # smallest tank that fits, to conserve big tanks

    def cellar_volume_in_use(self) -> float:
        return sum(v.volume_l for v in self.vessels.values() if v.contents_batch_id)

    def cellar_capacity_available(self) -> float:
        return max(0.0, self.cellar_capacity_l - self.cellar_volume_in_use())

    def register_bottled_stock(self, bottled_batch_id: str, format: str, bottles: int) -> None:
        self.bottled_stock[bottled_batch_id] = BottledStock(bottled_batch_id, format, bottles, bottles)

    def dispatch_bottles(self, bottled_batch_id: str, quantity: int) -> int:
        stock = self.bottled_stock.get(bottled_batch_id)
        if not stock:
            return 0
        dispatched = min(stock.bottles_available, quantity)
        stock.bottles_available -= dispatched
        return dispatched

    def capacity_summary(self) -> dict:
        return {
            "fermentation_capacity_l": self.fermentation_capacity_l,
            "fermentation_in_use_l": round(self.fermentation_volume_in_use(), 1),
            "fermentation_utilisation_pct": round(100 * self.fermentation_volume_in_use() / max(1, self.fermentation_capacity_l), 1),
            "cellar_capacity_l": self.cellar_capacity_l,
            "cellar_in_use_l": round(self.cellar_volume_in_use(), 1),
            "cellar_utilisation_pct": round(100 * self.cellar_volume_in_use() / max(1, self.cellar_capacity_l), 1),
            "bottling_capacity_bottles_per_day": self.bottling_capacity_bottles_per_day,
        }
