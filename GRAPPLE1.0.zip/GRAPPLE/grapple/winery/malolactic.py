"""
grapple.winery.malolactic
============================

Malolactic fermentation model (Section 28): bacterial conversion of malic
acid to (softer) lactic acid + CO2, optionally run to completion, blocked,
or stopped partway through.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from grapple.wine.composition import WineComposition


class MLFDecision(str, Enum):
    FULL_MLF = "full_mlf"
    NO_MLF = "no_mlf"
    PARTIAL_MLF = "partial_mlf"


@dataclass
class MLFState:
    decision: MLFDecision
    target_completion_pct: float = 100.0
    progress_pct: float = 0.0
    day: int = 0
    complete: bool = False


def start_mlf(decision: MLFDecision, target_completion_pct: float = 100.0) -> MLFState:
    if decision == MLFDecision.NO_MLF:
        return MLFState(decision=decision, target_completion_pct=0.0, complete=True)
    target = target_completion_pct if decision == MLFDecision.PARTIAL_MLF else 100.0
    return MLFState(decision=decision, target_completion_pct=target)


def step_mlf(state: MLFState, comp: WineComposition, temperature_c: float, so2_mg_l: float) -> MLFState:
    if state.complete or state.decision == MLFDecision.NO_MLF:
        return state

    state.day += 1
    # Malolactic bacteria favour warmth (>18C) and are inhibited by high free SO2.
    temp_factor = max(0.0, min(1.5, (temperature_c - 12) / 10))
    so2_inhibition = max(0.1, 1.0 - so2_mg_l / 40.0)
    rate_pct_per_day = 4.0 * temp_factor * so2_inhibition

    state.progress_pct = min(state.target_completion_pct, state.progress_pct + rate_pct_per_day)

    malic_start = comp.malic_acid_gl + comp.lactic_acid_gl / 1.5  # rough carbon-conservation estimate
    converted_fraction = state.progress_pct / 100.0
    comp.malic_acid_gl = max(0.0, malic_start * (1 - converted_fraction))
    comp.lactic_acid_gl = malic_start * converted_fraction * 0.67   # ~2:3 molar conversion by mass, approximated
    comp.ta_gl = max(2.5, comp.ta_gl - 0.3 * (comp.lactic_acid_gl))
    comp.ph = min(4.0, comp.ph + 0.01 * converted_fraction * 10)

    if state.progress_pct >= state.target_completion_pct - 0.01:
        state.complete = True
    return state
