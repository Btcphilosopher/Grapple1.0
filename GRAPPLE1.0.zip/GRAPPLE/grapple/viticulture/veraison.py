"""
grapple.viticulture.veraison
===============================

Veraison — the onset of ripening (Section 11). Phenological timing itself
is handled by `vineyard.phenology` (GDD threshold); this module tracks
*when* veraison happened (for computing days-since-veraison, the primary
clock the ripening model runs on) and, for black varieties, a simple
colour-change progress used by the sensory/phenolic side of ripening.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from typing import Optional


@dataclass
class VeraisonRecord:
    veraison_date: Optional[dt.date] = None
    colour_change_fraction: float = 0.0   # 0-1, black varieties only

    def days_since(self, today: dt.date) -> int:
        if self.veraison_date is None:
            return 0
        return max(0, (today - self.veraison_date).days)


def record_veraison_if_new(record: VeraisonRecord, today: dt.date, at_veraison: bool) -> VeraisonRecord:
    if at_veraison and record.veraison_date is None:
        record.veraison_date = today
    return record


def update_colour_change(record: VeraisonRecord, today: dt.date, is_black_variety: bool, tmean_c: float) -> None:
    if not is_black_variety or record.veraison_date is None:
        return
    days = record.days_since(today)
    # Anthocyanin accumulation roughly logistic over ~30-40 days post-veraison, accelerated by warmth.
    rate = 0.03 * max(0.3, min(1.6, tmean_c / 15.0))
    record.colour_change_fraction = min(1.0, record.colour_change_fraction + rate)
