"""
grapple.viticulture.harvest
==============================

Harvest readiness assessment for a single block "as of today" (Section 20)
— the day-by-day, multi-day-ahead ranking of harvest *timing* options lives
in `optimisation.harvest` (Section 46); this module answers "how ready is
this fruit right now, for this style?".
"""
from __future__ import annotations

from dataclasses import dataclass

from grapple.data.recipes import WineStyleTarget
from grapple.vineyard.blocks import Block


@dataclass
class HarvestReadiness:
    block_id: str
    style_key: str
    brix: float
    ph: float
    ta_gl: float
    sugar_maturity: float
    acid_maturity: float
    phenolic_maturity: float
    aromatic_maturity: float
    physiological_maturity: float
    overall_readiness_pct: float
    disease_risk_label: str
    disease_risk_index: float
    chemistry_fit_pct: float


def _style_fit(brix: float, ph: float, ta_gl: float, style: WineStyleTarget) -> float:
    """0-1 fit score: 1.0 = exactly on target, decaying with distance in tolerance-normalised units."""
    d_brix = abs(brix - style.target_brix) / max(0.1, style.brix_tolerance)
    d_ph = abs(ph - style.target_ph) / max(0.01, style.ph_tolerance)
    d_ta = abs(ta_gl - style.target_ta_gl) / max(0.1, style.ta_tolerance)
    distance = (d_brix ** 2 + d_ph ** 2 + d_ta ** 2) ** 0.5
    return max(0.0, 1.0 - min(1.0, distance / 2.0))


def assess_readiness(block: Block, style: WineStyleTarget) -> HarvestReadiness:
    chem = block.chemistry
    fit = _style_fit(chem.brix, chem.ph, chem.ta_gl, style)

    weighted_maturity = (
        style.weight_sugar * chem.sugar_maturity
        + style.weight_acid * chem.acid_maturity
        + style.weight_phenolic * chem.phenolic_maturity
        + style.weight_aromatic * chem.aromatic_maturity
        + style.weight_physiological * chem.physiological_maturity
    )

    overall = 0.6 * weighted_maturity + 0.4 * fit
    disease_index = max(block.disease.downy_mildew_pressure, block.disease.powdery_mildew_pressure,
                         block.disease.botrytis_pressure)
    disease_label = ("LOW" if disease_index < 0.2 else "MODERATE" if disease_index < 0.45
                      else "HIGH" if disease_index < 0.7 else "SEVERE")

    return HarvestReadiness(
        block_id=block.block_id, style_key=style.key,
        brix=chem.brix, ph=chem.ph, ta_gl=chem.ta_gl,
        sugar_maturity=chem.sugar_maturity, acid_maturity=chem.acid_maturity,
        phenolic_maturity=chem.phenolic_maturity, aromatic_maturity=chem.aromatic_maturity,
        physiological_maturity=chem.physiological_maturity,
        overall_readiness_pct=round(overall * 100, 1),
        disease_risk_label=disease_label, disease_risk_index=round(disease_index, 3),
        chemistry_fit_pct=round(fit * 100, 1),
    )
