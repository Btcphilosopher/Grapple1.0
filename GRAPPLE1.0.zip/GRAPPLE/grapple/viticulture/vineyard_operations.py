"""
grapple.viticulture.vineyard_operations
==========================================

Vineyard operation scheduling (Section 56): pruning, shoot thinning,
canopy work, mowing, cover-crop management, disease monitoring/treatment,
harvesting, irrigation and maintenance. Every operation consumes labour,
machinery time, fuel and money, and (where relevant) mutates block state
via the canopy/water/disease/nutrition modules.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional

from grapple.vineyard.blocks import Block
from grapple.vineyard.canopy import apply_shoot_thinning, apply_leaf_removal, apply_hedging, apply_bunch_thinning
from grapple.vineyard.nutrition import apply_amendment
from grapple.vineyard.water import update_water_balance


class OperationType(str, Enum):
    PRUNING = "pruning"
    SHOOT_THINNING = "shoot_thinning"
    LEAF_REMOVAL = "leaf_removal"
    HEDGING = "hedging"
    BUNCH_THINNING = "bunch_thinning"
    MOWING = "mowing"
    COVER_CROP = "cover_crop"
    DISEASE_TREATMENT = "disease_treatment"
    IRRIGATION = "irrigation"
    FERTILISATION = "fertilisation"
    MAINTENANCE = "maintenance"


# (labour_hours_per_ha, fuel_litres_per_ha, cost_gbp_per_ha)
OPERATION_COSTS = {
    OperationType.PRUNING: (18.0, 0.0, 420.0),
    OperationType.SHOOT_THINNING: (12.0, 0.0, 280.0),
    OperationType.LEAF_REMOVAL: (8.0, 1.5, 190.0),
    OperationType.HEDGING: (1.5, 4.0, 90.0),
    OperationType.BUNCH_THINNING: (14.0, 0.0, 320.0),
    OperationType.MOWING: (1.0, 6.0, 55.0),
    OperationType.COVER_CROP: (2.0, 3.0, 120.0),
    OperationType.DISEASE_TREATMENT: (1.2, 5.0, 95.0),
    OperationType.IRRIGATION: (0.5, 0.0, 15.0),   # per mm applied, scaled separately
    OperationType.FERTILISATION: (1.5, 3.0, 140.0),
    OperationType.MAINTENANCE: (4.0, 2.0, 150.0),
}


@dataclass
class OperationResult:
    operation: OperationType
    block_id: str
    labour_hours: float
    fuel_litres: float
    cost_gbp: float
    notes: str = ""


def apply_operation(block: Block, operation: OperationType, *, bunch_thin_fraction: float = 0.3,
                     irrigation_mm: float = 0.0, nitrogen_kg_ha: float = 0.0,
                     potassium_kg_ha: float = 0.0, magnesium_kg_ha: float = 0.0) -> OperationResult:
    labour_per_ha, fuel_per_ha, cost_per_ha = OPERATION_COSTS[operation]
    labour = labour_per_ha * block.area_ha
    fuel = fuel_per_ha * block.area_ha
    cost = cost_per_ha * block.area_ha
    notes = ""

    if operation == OperationType.SHOOT_THINNING:
        apply_shoot_thinning(block.canopy)
    elif operation == OperationType.LEAF_REMOVAL:
        apply_leaf_removal(block.canopy)
    elif operation == OperationType.HEDGING:
        apply_hedging(block.canopy)
    elif operation == OperationType.BUNCH_THINNING:
        apply_bunch_thinning(block.canopy, bunch_thin_fraction)
        block.fruit_set_fraction = block.fruit_set_fraction  # unchanged; yield model reads canopy.bunch_thinned_fraction
        notes = f"removed {bunch_thin_fraction * 100:.0f}% of clusters (green harvest)"
    elif operation == OperationType.IRRIGATION:
        cost = cost_per_ha * irrigation_mm  # irrigation billed per mm applied, not flat per-ha
        block.soil.moisture_mm += irrigation_mm
        notes = f"applied {irrigation_mm:.1f}mm"
    elif operation == OperationType.FERTILISATION:
        apply_amendment(block.soil, nitrogen_kg_ha=nitrogen_kg_ha, potassium_kg_ha=potassium_kg_ha,
                         magnesium_kg_ha=magnesium_kg_ha)
        notes = f"N+{nitrogen_kg_ha:.0f} K+{potassium_kg_ha:.0f} Mg+{magnesium_kg_ha:.0f} kg/ha"
    elif operation == OperationType.DISEASE_TREATMENT:
        notes = "treatment applied — see disease pressure reduction in today's disease assessment"

    return OperationResult(
        operation=operation, block_id=block.block_id,
        labour_hours=round(labour, 1), fuel_litres=round(fuel, 1), cost_gbp=round(cost, 2), notes=notes,
    )
