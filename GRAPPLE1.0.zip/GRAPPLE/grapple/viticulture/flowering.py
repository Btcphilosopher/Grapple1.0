"""
grapple.viticulture.flowering
================================

Flowering and fruit-set model (Section 11 stage, feeding Section 18 yield).
English flowering (typically early-mid June) is often the single biggest
swing factor on yield: cool, wet, windy weather during the ~10-14 day
flowering window causes poor fruit set ("coulure"/"millerandage"),
directly reducing berries-per-cluster.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from grapple.vineyard.phenology import PhenologyStage
from grapple.weather.weather import DailyWeather


@dataclass
class FloweringTracker:
    days_observed: int = 0
    favourable_days: int = 0
    fruit_set_fraction: float = 1.0
    finalised: bool = False


def update_flowering(tracker: FloweringTracker, stage: PhenologyStage, weather: DailyWeather) -> FloweringTracker:
    if stage != PhenologyStage.FLOWERING or tracker.finalised:
        if stage in (PhenologyStage.FRUIT_SET, PhenologyStage.BERRY_DEVELOPMENT,
                     PhenologyStage.VERAISON, PhenologyStage.RIPENING) and not tracker.finalised:
            _finalise(tracker)
        return tracker

    tracker.days_observed += 1
    favourable = (weather.tmean_c >= 15.0) and (weather.rainfall_mm < 3.0) and (weather.wind_ms < 6.0)
    if favourable:
        tracker.favourable_days += 1
    return tracker


def _finalise(tracker: FloweringTracker) -> None:
    if tracker.days_observed == 0:
        tracker.fruit_set_fraction = 1.0
    else:
        favourable_ratio = tracker.favourable_days / tracker.days_observed
        # Poor weather still yields *some* set; a fully unfavourable flowering
        # period is calibrated to roughly halve potential fruit set.
        tracker.fruit_set_fraction = max(0.4, 0.5 + 0.5 * favourable_ratio)
    tracker.finalised = True
