"""
grapple.viticulture.ripening
===============================

The core grape-chemistry model (Section 19) — arguably the most important
subsystem in GRAPPLE. Sugar maturity is explicitly NOT treated as a proxy
for overall ripeness: five separate maturity dimensions are tracked
(sugar, acid, phenolic, aromatic, physiological), each driven by different
combinations of heat, sunlight, water status and time-since-veraison.

SIMPLIFICATION NOTE (Section 77): the pH/TA/malic relationships below are
transparent empirical approximations calibrated to plausible cool-climate
ranges, not a full acid-dissociation/must-buffering chemical model. Every
driver contribution is returned in `RipeningDrivers` so a user can see
exactly why a number moved (Section 70), rather than treating this as an
opaque black box.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from grapple.data.varieties import VarietyData
from grapple.vineyard.blocks import BerryChemistryState
from grapple.vineyard.phenology import PhenologyStage

INITIAL_TA_GL = 15.0
INITIAL_MALIC_GL = 9.5
INITIAL_TARTARIC_GL = 6.5
INITIAL_YAN_MG_L = 230.0
RIPE_TA_FLOOR_GL = 5.5


@dataclass
class RipeningDrivers:
    """Explains today's Brix change as a sum of named contributions (Section 70)."""

    heat_accumulation: float = 0.0
    solar_exposure: float = 0.0
    crop_load: float = 0.0
    water_stress: float = 0.0
    variety_coefficient: float = 0.0
    total_brix_delta: float = 0.0


def _brix_ceiling(variety: VarietyData) -> float:
    return max(16.0, min(28.0, 22.5 * variety.sugar_accumulation_rate))


def initialise_at_veraison(chem: BerryChemistryState) -> None:
    chem.brix = 7.0
    chem.ta_gl = INITIAL_TA_GL
    chem.malic_acid_gl = INITIAL_MALIC_GL
    chem.tartaric_acid_gl = INITIAL_TARTARIC_GL
    chem.yan_mg_l = INITIAL_YAN_MG_L
    chem.sugar_maturity = 0.0
    chem.acid_maturity = 0.0
    chem.phenolic_maturity = 0.0
    chem.aromatic_maturity = 0.0
    chem.physiological_maturity = 0.0


def update_ripening(
    chem: BerryChemistryState,
    variety: VarietyData,
    stage: PhenologyStage,
    days_since_veraison: int,
    tmean_c: float,
    tmin_c: float,
    tmax_c: float,
    solar_mj_m2: float,
    fruit_exposure: float,
    crop_load_factor: float,
    water_stress_index: float,
    nitrogen_status: float,
    berry_weight_g: float,
) -> RipeningDrivers:
    """Advance grape chemistry by one day during VERAISON/RIPENING. Mutates `chem` in place."""

    if stage not in (PhenologyStage.VERAISON, PhenologyStage.RIPENING):
        return RipeningDrivers()

    if days_since_veraison <= 0 and chem.brix <= 0.0:
        initialise_at_veraison(chem)

    ceiling = _brix_ceiling(variety)

    heat_term = max(0.0, (tmean_c - 10.0) / 8.0)
    heat_term = min(1.6, heat_term)
    solar_term = min(1.3, solar_mj_m2 / 11.0) * (0.6 + 0.4 * fruit_exposure)
    saturation = max(0.05, 1.0 - chem.brix / ceiling)
    crop_penalty = -0.12 * max(0.0, crop_load_factor - 1.0)
    # Mild-to-moderate water stress is largely neutral for sugar loading (and can even help
    # concentration via smaller berries — see viticulture.berry); only sustained severe stress
    # meaningfully slows ripening, since vines draw on stored reserves rather than halting outright.
    water_penalty = -0.15 * max(0.0, water_stress_index - 0.65)

    base_rate = 0.72
    d_heat = base_rate * heat_term * saturation * 0.45
    d_solar = base_rate * solar_term * saturation * 0.35
    d_variety = base_rate * saturation * 0.20 * variety.sugar_accumulation_rate
    d_crop = crop_penalty
    d_water = water_penalty

    total_delta = max(0.0, d_heat + d_solar + d_variety + d_crop + d_water)
    chem.brix = min(ceiling + 1.0, chem.brix + total_delta)

    # Malic acid respires away roughly exponentially with heat; tartaric is far more stable.
    # Calibrated so a typical English ripening season (~60 days veraison-to-harvest) takes TA
    # from ~15g/L down to roughly the 8-10g/L range targeted for traditional-method sparkling.
    malic_k = 0.009 * (0.5 + heat_term)
    chem.malic_acid_gl = max(0.8, chem.malic_acid_gl * (1 - malic_k))
    chem.tartaric_acid_gl = max(3.0, chem.tartaric_acid_gl - 0.01 * chem.tartaric_acid_gl)
    # Rain/water uptake dilutes both; represented via the berry-weight-implied dilution factor.
    if berry_weight_g > 0 and getattr(chem, "_last_berry_weight", None):
        dilution = chem._last_berry_weight / berry_weight_g if berry_weight_g else 1.0
        chem.malic_acid_gl *= min(1.15, max(0.9, dilution))
        chem.tartaric_acid_gl *= min(1.15, max(0.9, dilution))
    chem._last_berry_weight = berry_weight_g  # type: ignore[attr-defined]

    chem.ta_gl = round(max(RIPE_TA_FLOOR_GL, chem.malic_acid_gl + chem.tartaric_acid_gl), 2)

    # Simplified empirical pH relationship (Section 77): rises as acid falls and sugar rises.
    chem.ph = round(min(3.9, max(2.75, 2.85 + 0.55 * (1 - chem.ta_gl / INITIAL_TA_GL) + 0.012 * chem.brix)), 3)

    days_factor = max(0.0, 1.0 - days_since_veraison / 70.0)
    chem.yan_mg_l = round(max(25.0, INITIAL_YAN_MG_L * nitrogen_status * (0.55 + 0.45 * days_factor)), 1)

    chem.berry_weight_g = round(berry_weight_g, 3)

    # --- Five maturity dimensions -----------------------------------
    chem.sugar_maturity = round(min(1.0, chem.brix / _brix_ceiling(variety)), 3)
    chem.acid_maturity = round(min(1.0, max(0.0, (INITIAL_TA_GL - chem.ta_gl) / (INITIAL_TA_GL - RIPE_TA_FLOOR_GL))), 3)

    sun_days_term = min(1.0, days_since_veraison * fruit_exposure / 45.0)
    chem.phenolic_maturity = round(min(1.0, sun_days_term * (0.4 + 0.6 * variety.phenolic_potential)), 3)

    diurnal_range = max(0.0, tmax_c - tmin_c)
    aromatic_term = min(1.0, (0.4 * min(1.0, diurnal_range / 12.0) + 0.6 * min(1.0, days_since_veraison / 50.0)))
    chem.aromatic_maturity = round(min(1.0, aromatic_term * (0.3 + 0.7 * variety.aromatic_potential)), 3)

    chem.physiological_maturity = round(min(1.0, 1.0 / (1.0 + pow(2.71828, -0.09 * (days_since_veraison - 45)))), 3)

    return RipeningDrivers(
        heat_accumulation=round(d_heat, 3), solar_exposure=round(d_solar, 3),
        crop_load=round(d_crop, 3), water_stress=round(d_water, 3),
        variety_coefficient=round(d_variety, 3), total_brix_delta=round(total_delta, 3),
    )
