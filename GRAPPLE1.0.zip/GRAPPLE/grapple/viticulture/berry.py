"""
grapple.viticulture.berry
============================

Berry growth model (Section 13/19). Berry weight follows the well-known
double-sigmoid grape growth curve: rapid cell-division growth pre-veraison,
a lag, then a second (softening) growth phase post-veraison driven mostly
by water uptake — which is also why late-season rain dilutes must and
autumn drought concentrates it.
"""
from __future__ import annotations

import math

from grapple.data.varieties import VarietyData
from grapple.vineyard.phenology import PhenologyStage


def berry_weight_g(
    variety: VarietyData,
    stage: PhenologyStage,
    days_since_fruit_set: int,
    days_since_veraison: int,
    water_stress_index: float,
    recent_rain_mm_7day: float,
) -> float:
    """Estimate current mean berry weight (g) from the double-sigmoid growth curve."""
    target = variety.berry_weight_g_mean

    if stage in (PhenologyStage.DORMANCY, PhenologyStage.BUDBREAK, PhenologyStage.SHOOT_GROWTH,
                 PhenologyStage.FLOWERING):
        return 0.0

    if stage in (PhenologyStage.FRUIT_SET, PhenologyStage.BERRY_DEVELOPMENT):
        # First sigmoid growth phase, reaching ~55% of final weight by veraison.
        progress = 1.0 / (1.0 + math.exp(-0.12 * (days_since_fruit_set - 25)))
        weight = target * 0.55 * progress
    else:
        # Post-veraison: continues growing toward full weight, modulated by water status.
        progress = 1.0 / (1.0 + math.exp(-0.1 * (days_since_veraison - 20)))
        base_weight = target * (0.55 + 0.45 * progress)
        # Water stress shrinks berries (concentration); a wet spell swells them (dilution) —
        # capped so late-season rain can't runaway-inflate weight beyond a plausible bound.
        stress_effect = 1.0 - 0.18 * water_stress_index
        rain_swell = 1.0 + min(0.12, recent_rain_mm_7day / 300.0)
        weight = base_weight * stress_effect * rain_swell

    return round(max(0.0, weight), 3)
