"""
grapple.logistics.inventory
==============================

General-purpose volume/quantity ledger (Section 72 — supports mass-balance
validation). Every juice/wine movement in the winery should be logged here
so `digital_twin.anomaly` can check that nothing is created or destroyed
without an explaining transaction.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import List


@dataclass
class InventoryTransaction:
    timestamp: dt.datetime
    account: str          # e.g. a tank id, juice_lot id, bottled_batch id
    delta: float           # positive = increase, negative = decrease
    unit: str               # "L" or "bottles"
    reason: str
    balance_after: float


class InventoryLedger:
    def __init__(self):
        self._balances: dict[str, float] = {}
        self.transactions: List[InventoryTransaction] = []

    def balance(self, account: str) -> float:
        return self._balances.get(account, 0.0)

    def record(self, account: str, delta: float, unit: str, reason: str,
               timestamp: dt.datetime | None = None) -> InventoryTransaction:
        new_balance = self.balance(account) + delta
        if new_balance < -1e-6:
            raise ValueError(f"Inventory account '{account}' would go negative ({new_balance:.2f}{unit}) "
                              f"applying '{reason}' — mass-balance violation blocked.")
        self._balances[account] = max(0.0, new_balance)
        txn = InventoryTransaction(timestamp or dt.datetime.now(), account, delta, unit, reason,
                                    round(self._balances[account], 3))
        self.transactions.append(txn)
        return txn

    def transfer(self, from_account: str, to_account: str, quantity: float, unit: str, reason: str) -> None:
        self.record(from_account, -quantity, unit, reason)
        self.record(to_account, quantity, unit, reason)

    def history_for(self, account: str) -> List[InventoryTransaction]:
        return [t for t in self.transactions if t.account == account]
