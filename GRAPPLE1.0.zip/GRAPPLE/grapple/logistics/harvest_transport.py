"""
grapple.logistics.harvest_transport
======================================

Harvest logistics (Section 21): picking crews, picking speed, mechanical
harvesting, bins/trailers, transport, and winery intake capacity. Grape
temperature rises during transport, which matters for juice oxidation and
fermentation kinetics downstream.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class PickingMethod(str, Enum):
    HAND = "hand"
    MECHANICAL = "mechanical"


# kg/hour per picker (hand) or per machine (mechanical)
HAND_PICKING_RATE_KG_PER_HOUR = 45.0
MECHANICAL_PICKING_RATE_KG_PER_HOUR = 4500.0

BIN_CAPACITY_KG = 400.0
TRAILER_CAPACITY_KG = 8000.0


@dataclass
class HarvestPlan:
    block_id: str
    method: PickingMethod
    crew_size: int
    estimated_kg: float
    estimated_hours: float
    bins_required: int
    trailer_loads: int


def plan_harvest(block_id: str, estimated_kg: float, method: PickingMethod, crew_size: int = 12) -> HarvestPlan:
    if method == PickingMethod.HAND:
        rate = HAND_PICKING_RATE_KG_PER_HOUR * crew_size
    else:
        rate = MECHANICAL_PICKING_RATE_KG_PER_HOUR

    hours = estimated_kg / max(1.0, rate)
    bins = int(-(-estimated_kg // BIN_CAPACITY_KG))     # ceiling division
    trailers = int(-(-estimated_kg // TRAILER_CAPACITY_KG))

    return HarvestPlan(block_id=block_id, method=method, crew_size=crew_size, estimated_kg=estimated_kg,
                        estimated_hours=round(hours, 2), bins_required=bins, trailer_loads=trailers)


def estimate_transport_temperature_rise_c(transit_minutes: float, ambient_temp_c: float, harvest_temp_c: float,
                                           insulated: bool = False) -> float:
    """Fruit warms toward ambient temperature during transit; insulated bins slow the rise."""
    if ambient_temp_c <= harvest_temp_c:
        return 0.0
    rate_per_minute = 0.006 if insulated else 0.015
    rise = (ambient_temp_c - harvest_temp_c) * min(1.0, rate_per_minute * transit_minutes)
    return round(rise, 2)


def check_intake_capacity(scheduled_kg_today: float, winery_intake_capacity_kg_per_day: float) -> dict:
    utilisation = scheduled_kg_today / max(1.0, winery_intake_capacity_kg_per_day)
    return {
        "scheduled_kg": scheduled_kg_today, "capacity_kg_per_day": winery_intake_capacity_kg_per_day,
        "utilisation_pct": round(utilisation * 100, 1), "over_capacity": utilisation > 1.0,
        "overflow_kg": max(0.0, scheduled_kg_today - winery_intake_capacity_kg_per_day),
    }
