"""
grapple.logistics.warehouse
==============================

Finished-goods warehouse (Section 37/50): case-packed bottled inventory,
storage capacity, and dispatch. Builds on `winery.cellar.BottledStock`.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import Dict, List

BOTTLES_PER_CASE = 12


@dataclass
class DispatchRecord:
    date: dt.date
    bottled_batch_id: str
    cases: int
    destination: str


class Warehouse:
    def __init__(self, storage_capacity_cases: float):
        self.storage_capacity_cases = storage_capacity_cases
        self.cases_in_stock: Dict[str, int] = {}
        self.dispatch_log: List[DispatchRecord] = []

    def receive_bottles(self, bottled_batch_id: str, bottles: int) -> int:
        cases = bottles // BOTTLES_PER_CASE
        self.cases_in_stock[bottled_batch_id] = self.cases_in_stock.get(bottled_batch_id, 0) + cases
        return cases

    def total_cases(self) -> int:
        return sum(self.cases_in_stock.values())

    def capacity_available_cases(self) -> float:
        return max(0.0, self.storage_capacity_cases - self.total_cases())

    def dispatch(self, bottled_batch_id: str, cases: int, destination: str, date: dt.date) -> int:
        available = self.cases_in_stock.get(bottled_batch_id, 0)
        sent = min(available, cases)
        self.cases_in_stock[bottled_batch_id] = available - sent
        self.dispatch_log.append(DispatchRecord(date=date, bottled_batch_id=bottled_batch_id, cases=sent,
                                                  destination=destination))
        return sent

    def summary(self) -> dict:
        return {
            "storage_capacity_cases": self.storage_capacity_cases,
            "cases_in_stock": self.total_cases(),
            "utilisation_pct": round(100 * self.total_cases() / max(1, self.storage_capacity_cases), 1),
            "batches": dict(self.cases_in_stock),
        }
