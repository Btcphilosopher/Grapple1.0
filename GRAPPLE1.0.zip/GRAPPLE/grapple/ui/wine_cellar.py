"""grapple.ui.wine_cellar — maturation vessels & bottled inventory (Section 32/50)."""
from __future__ import annotations

from grapple.winery.cellar import Cellar


def render_cellar_inventory(cellar: Cellar) -> str:
    lines = ["WINE CELLAR", "", "  Maturation vessels:"]
    for vessel in cellar.vessels.values():
        contents = vessel.contents_batch_id or "empty"
        lines.append(f"    {vessel.vessel_id:<10} {vessel.vessel_type.value:<16} {vessel.volume_l:>8,.0f}L "
                     f"day {vessel.days_in_vessel:<4} {contents}")

    lines.append("")
    lines.append("  Bottled stock:")
    for stock in cellar.bottled_stock.values():
        lines.append(f"    {stock.bottled_batch_id:<10} {stock.format:<8} {stock.bottles_available:>6}/"
                     f"{stock.bottles_total} bottles available")
    return "\n".join(lines)
