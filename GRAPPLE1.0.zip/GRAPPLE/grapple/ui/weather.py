"""grapple.ui.weather — live simulated weather map across estate blocks (Section 55)."""
from __future__ import annotations

from grapple.core.state import EstateState


def render_weather_map(state: EstateState) -> str:
    day = state.weather.last()
    if day is None:
        return "No weather generated yet."

    lines = [f"WEATHER — {day.date.isoformat()}", "",
             f"Estate mean: {day.tmean_c:.1f}C  Rain: {day.rainfall_mm:.1f}mm  "
             f"Humidity: {day.humidity_pct:.0f}%  Wind: {day.wind_ms:.1f}m/s  "
             f"Solar: {day.solar_mj_m2:.1f}MJ/m2  Cloud: {day.cloud_cover_pct:.0f}%", ""]

    for block in state.estate.blocks.values():
        offset = block.local_temperature_offset_c(state.estate.min_elevation_m, state.estate.max_elevation_m)
        frost_mult = block.frost_pooling_multiplier(state.estate.min_elevation_m, state.estate.max_elevation_m)
        lines.append(f"  {block.block_id:<5} {block.name:<16} {day.tmean_c + offset:5.1f}C  "
                     f"(offset {offset:+.1f}C, frost x{frost_mult:.2f}, elev {block.elevation_m:.0f}m)")
    return "\n".join(lines)
