"""grapple.ui.analytics — alert stream / analytics panel (Section 58)."""
from __future__ import annotations

from grapple.core.events import EventLog


def render_alerts(events: EventLog, limit: int = 20) -> str:
    counts = events.counts()
    lines = ["ALERTS", "", f"  INFO: {counts['INFO']}   WARNING: {counts['WARNING']}   CRITICAL: {counts['CRITICAL']}", ""]
    for alert in events.recent(limit):
        lines.append(f"  [{alert.level.value:<8}] {alert.date.isoformat()}  {alert.source:<12} {alert.message}")
    return "\n".join(lines)
