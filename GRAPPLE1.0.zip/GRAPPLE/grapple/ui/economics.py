"""grapple.ui.economics — cost/revenue/profitability dashboard (Section 51/52)."""
from __future__ import annotations

from grapple.economics.capex import CapexRegister
from grapple.economics.costs import CostBreakdown
from grapple.economics.profitability import ProfitabilitySummary


def render_economics_summary(vineyard_cost: CostBreakdown, capex: CapexRegister,
                              profitability: ProfitabilitySummary | None = None) -> str:
    lines = ["ECONOMICS", "", "  Vineyard annual costs:"]
    for item, value in vineyard_cost.items.items():
        lines.append(f"    {item:<28} £{value:>10,.0f}")
    lines.append(f"    {'TOTAL':<28} £{vineyard_cost.total:>10,.0f}")

    lines.append("")
    lines.append("  Capital expenditure by category:")
    for category, value in capex.by_category().items():
        lines.append(f"    {category:<28} £{value:>10,.0f}")
    lines.append(f"    {'TOTAL CAPEX':<28} £{capex.total_capex_gbp():>10,.0f}")

    if profitability:
        lines += [
            "",
            f"  Gross revenue:            £{profitability.gross_revenue_gbp:,.0f}",
            f"  Gross margin:             £{profitability.gross_margin_gbp:,.0f} ({profitability.gross_margin_pct:.1f}%)",
            f"  Operating profit:         £{profitability.operating_profit_gbp:,.0f} ({profitability.operating_margin_pct:.1f}%)",
            f"  Return on investment:     {profitability.return_on_investment_pct:.1f}%",
        ]
    return "\n".join(lines)
