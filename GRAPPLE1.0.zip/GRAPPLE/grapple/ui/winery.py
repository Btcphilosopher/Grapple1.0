"""grapple.ui.winery — winery/cellar capacity dashboard (Section 47/59)."""
from __future__ import annotations

from grapple.winery.cellar import Cellar


def render_winery_dashboard(cellar: Cellar) -> str:
    cap = cellar.capacity_summary()
    lines = [
        "WINERY",
        "",
        f"  Fermentation capacity   {cap['fermentation_in_use_l']:,.0f} / {cap['fermentation_capacity_l']:,.0f} L "
        f"({cap['fermentation_utilisation_pct']:.0f}%)",
        f"  Cellar capacity         {cap['cellar_in_use_l']:,.0f} / {cap['cellar_capacity_l']:,.0f} L "
        f"({cap['cellar_utilisation_pct']:.0f}%)",
        f"  Bottling capacity       {cap['bottling_capacity_bottles_per_day']:,.0f} bottles/day",
        "",
        "  Tanks:",
    ]
    for tank in cellar.tanks.values():
        status = "free" if tank.is_free else f"in use ({tank.occupied_by_batch_id})"
        lines.append(f"    {tank.equipment_id:<10} {tank.volume_l:>8,.0f} L  {tank.material:<15} {status}")
    return "\n".join(lines)
