"""
grapple.ui.harvest
=====================

Text renderers for the harvest readiness "TODAY" panel (Section 20) and
the end-of-vintage report (Section 44).
"""
from __future__ import annotations

from grapple.viticulture.harvest import HarvestReadiness


def render_harvest_today(readiness: HarvestReadiness, window_days: tuple[int, int] | None = None) -> str:
    lines = [
        "TODAY",
        "",
        f"  Brix:              {readiness.brix:.1f}",
        f"  pH:                {readiness.ph:.2f}",
        f"  TA:                {readiness.ta_gl:.1f} g/L",
        f"  Berry maturity:    {readiness.overall_readiness_pct:.0f}%",
        f"  Disease risk:      {readiness.disease_risk_label} ({readiness.disease_risk_index * 100:.0f}%)",
        "",
    ]
    if window_days:
        lines.append(f"Recommended harvest window:\n{window_days[0]}-{window_days[1]} days")
    return "\n".join(lines)


def render_vintage_report(report) -> str:
    lines = [
        "",
        "=" * 44,
        f"VINTAGE REPORT {report.vintage_year}".center(44),
        "=" * 44,
        f"  Blocks harvested:   {report.blocks_harvested}",
        f"  Total yield:        {report.total_tonnes:.1f} t "
        f"({report.total_tonnes / max(0.01, report.total_area_ha):.2f} t/ha)",
        f"  Average Brix:       {report.average_brix:.1f}",
        f"  Average pH:         {report.average_ph:.2f}",
        f"  Average TA:         {report.average_ta_gl:.1f} g/L",
        f"  Frost events:       {report.frost_events}",
        f"  Disease CRITICALs:  {report.disease_critical_events}",
        f"  Fermentations:      {report.fermentations_started} started, {report.fermentations_stuck} stuck",
        "=" * 44,
        "",
    ]
    return "\n".join(lines)
