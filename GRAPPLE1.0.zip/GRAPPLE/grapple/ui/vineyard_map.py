"""
grapple.ui.vineyard_map
==========================

Block detail panel (Section 54) — what a click on a block in the
interactive estate map would surface.
"""
from __future__ import annotations

from grapple.vineyard.blocks import Block


def render_block_detail(block: Block) -> str:
    disease = max(block.disease.downy_mildew_pressure, block.disease.powdery_mildew_pressure,
                  block.disease.botrytis_pressure)
    disease_label = "LOW" if disease < 0.2 else "MODERATE" if disease < 0.45 else "HIGH" if disease < 0.7 else "SEVERE"
    frost_label = "LOW" if block.frost_damage_pct < 5 else "MODERATE" if block.frost_damage_pct < 20 else "HIGH"

    lines = [
        f"BLOCK {block.block_id}",
        "",
        f"Variety:            {block.variety.name}",
        f"Area:               {block.area_ha:.1f} ha",
        f"Vines:              {block.vine_count:,}",
        f"Soil:               {block.soil.profile.name}",
        f"Elevation:          {block.elevation_m:.0f} m",
        f"Aspect:             {block.aspect_deg:.0f} deg",
        "",
        f"Stage:              {block.phenology.stage.value}",
        f"Current Brix:       {block.chemistry.brix:.1f}",
        f"pH:                 {block.chemistry.ph:.2f}",
        f"TA:                 {block.chemistry.ta_gl:.1f}",
        "",
        f"Disease Risk:       {disease_label}",
        f"Frost Risk:         {frost_label} ({block.frost_damage_pct:.1f}% cumulative damage)",
    ]
    return "\n".join(lines)
