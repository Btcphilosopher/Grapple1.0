"""grapple.ui.laboratory — virtual lab results dashboard (Section 39)."""
from __future__ import annotations

from grapple.laboratory.analysis import LabAnalysisService


def render_lab_report(service: LabAnalysisService, limit: int = 10) -> str:
    if not service.history:
        return "No samples analysed yet."

    lines = ["LABORATORY", ""]
    for report in service.history[-limit:]:
        lines.append(f"  Sample {report.sample.sample_id}  source={report.sample.source.value}:{report.sample.source_id}"
                      f"  drawn={report.sample.drawn_date.isoformat()}")
        for test, result in report.results.items():
            lines.append(f"    {test:<16} {result.measured_value:>8} (uncertainty +/-{result.uncertainty_sd})")
        if report.qc_flags:
            for flag in report.qc_flags:
                lines.append(f"    !! QC FLAG: {flag.message}")
    return "\n".join(lines)
