"""
grapple.ui.estate
====================

Main control-room dashboard (Section 60) — a text rendering of the
estate's current state, used by the console first-run experience and
available to any client that wants a human-readable summary alongside the
JSON API.
"""
from __future__ import annotations

from grapple.core.state import EstateState
from grapple.vineyard.phenology import PhenologyStage


def _overall_disease_risk_label(state: EstateState) -> str:
    if not state.estate.blocks:
        return "UNKNOWN"
    worst = max(
        max(b.disease.downy_mildew_pressure, b.disease.powdery_mildew_pressure, b.disease.botrytis_pressure)
        for b in state.estate.blocks.values()
    )
    if worst < 0.2:
        return "LOW"
    if worst < 0.45:
        return "MODERATE"
    if worst < 0.7:
        return "HIGH"
    return "SEVERE"


def render_main_dashboard(state: EstateState) -> str:
    blocks = state.estate.blocks.values()
    ripening_or_later = [b for b in blocks if b.phenology.stage in (
        PhenologyStage.VERAISON, PhenologyStage.RIPENING, PhenologyStage.HARVESTED,
    )]
    readiness_pct = (
        round(100 * sum(b.chemistry.sugar_maturity for b in ripening_or_later) / len(ripening_or_later), 0)
        if ripening_or_later else 0
    )
    weather = state.weather.last()
    cellar = state.cellar.capacity_summary() if state.cellar else {}
    active_ferments = [b for b in state.fermentation_batches.values() if b.status.value in ("lag_phase", "active", "slowing")]
    wine_in_production_l = sum(b.volume_l for b in state.fermentation_batches.values())

    lines = [
        "",
        "=" * 56,
        "GRAPPLE 1.0 — ENGLISH VINEYARD DIGITAL TWIN".center(56),
        f"VINTAGE {state.clock.vintage_year}".center(56),
        "=" * 56,
        f"  Date                 {state.clock.current_date.isoformat()} ({state.clock.month_name()})",
        f"  Estate               {state.estate.name} — {state.estate.total_area_ha:.1f} ha",
        f"  Vines                {state.estate.total_vines:,}",
        f"  Harvest Readiness    {readiness_pct:.0f}%",
        f"  Disease Risk         {_overall_disease_risk_label(state)}",
        f"  Weather              {weather.tmean_c:.1f}C, {weather.rainfall_mm:.1f}mm rain" if weather else "  Weather              (not yet generated)",
        f"  Winery Fermentation  {cellar.get('fermentation_utilisation_pct', 0):.0f}% utilised "
        f"({len(active_ferments)} active batches)",
        f"  Wine In Production   {wine_in_production_l:,.0f} L",
        "=" * 56,
    ]
    return "\n".join(lines)
