"""grapple.ui.fermentation — ASCII fermentation curve (Section 25)."""
from __future__ import annotations

from grapple.winery.fermentation import FermentationBatch


def render_fermentation_curve(batch: FermentationBatch, height: int = 8, width: int = 40) -> str:
    if not batch.history:
        return f"Batch {batch.batch_id}: no history yet."

    sugars = [s.sugar_gl for s in batch.history]
    max_sugar = max(sugars) or 1.0
    step = max(1, len(sugars) // width)
    sampled = sugars[::step]

    rows = []
    for row in range(height, 0, -1):
        threshold = max_sugar * row / height
        line = "".join("#" if v >= threshold else " " for v in sampled)
        rows.append(f"{threshold:6.0f} |{line}")
    rows.append(" " * 7 + "-" * len(sampled))
    rows.append(f"        Day 0{'Day ' + str(batch.day):>{len(sampled) - 5}}")

    header = (f"Batch {batch.batch_id}  yeast={batch.yeast_strain.name}  status={batch.status.value}  "
              f"day={batch.day}  ethanol={batch.ethanol_pct:.2f}%")
    return header + "\n" + "\n".join(rows)
