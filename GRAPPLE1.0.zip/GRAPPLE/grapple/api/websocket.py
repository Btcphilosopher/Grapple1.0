"""
grapple.api.websocket
========================

WebSocket streaming (Section 67/68). A client connects to `/ws/simulation`
and sends small JSON command messages; GRAPPLE steps the live simulation
and pushes back the updated estate snapshot after each command, plus any
newly raised alerts — the transport a real control-room UI would use for
live updates instead of polling.

Supported client messages: {"cmd": "step", "days": 1}, {"cmd": "snapshot"}.
"""
from __future__ import annotations

import json

from fastapi import WebSocket, WebSocketDisconnect

from grapple.api.routes import context


async def simulation_websocket(websocket: WebSocket) -> None:
    await websocket.accept()
    try:
        if context.sim is not None:
            await websocket.send_json({"type": "snapshot", "data": context.sim.state.snapshot()})

        while True:
            raw = await websocket.receive_text()
            try:
                message = json.loads(raw)
            except json.JSONDecodeError:
                await websocket.send_json({"type": "error", "message": "invalid JSON"})
                continue

            if context.sim is None:
                await websocket.send_json({"type": "error", "message": "no simulation running"})
                continue

            cmd = message.get("cmd")
            if cmd == "step":
                days = int(message.get("days", 1))
                alerts_before = len(context.sim.state.events.all())
                for _ in range(max(1, days)):
                    context.sim.step_day()
                new_alerts = context.sim.state.events.all()[alerts_before:]
                await websocket.send_json({
                    "type": "snapshot", "data": context.sim.state.snapshot(),
                    "new_alerts": [{"level": a.level.value, "source": a.source, "message": a.message}
                                    for a in new_alerts],
                })
            elif cmd == "snapshot":
                await websocket.send_json({"type": "snapshot", "data": context.sim.state.snapshot()})
            else:
                await websocket.send_json({"type": "error", "message": f"unknown command '{cmd}'"})

    except WebSocketDisconnect:
        return
