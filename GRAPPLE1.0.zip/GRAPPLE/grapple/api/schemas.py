"""
grapple.api.schemas
======================

Pydantic request/response models for the FastAPI layer (Section 67).
Most GET endpoints return the rich dicts produced directly by the
simulation/domain layer (already JSON-serialisable); these schemas cover
the POST request bodies, which need validation.
"""
from __future__ import annotations

from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class SimulationStartRequest(BaseModel):
    vintage_year: int = Field(..., ge=2000, le=2100)
    seed: int = 20310817
    scenario_key: str = "average"
    use_seed_estate: bool = True


class SimulationStepRequest(BaseModel):
    days: int = Field(1, ge=1, le=366)


class ScenarioRunRequest(BaseModel):
    """Runs a non-destructive 'what-if' on a deep-copied shadow simulation (Section 62)."""
    scenario_key: Optional[str] = None
    days_forward: int = Field(30, ge=1, le=366)
    bunch_thin_block_id: Optional[str] = None
    bunch_thin_fraction: Optional[float] = None
    irrigation_block_id: Optional[str] = None
    irrigation_mm: Optional[float] = None
    harvest_delay_block_id: Optional[str] = None
    harvest_delay_days: Optional[int] = None


class HarvestOptimiseRequest(BaseModel):
    block_id: str
    style_key: str = "traditional_sparkling"
    max_days: int = Field(10, ge=1, le=30)


class HarvestExecuteRequest(BaseModel):
    block_id: str
    style_key: str = "traditional_sparkling"
    mechanical: bool = False
    yeast_key: str = "ec1118"
    fermentation_temp_c: float = 16.0


class BlendOptimiseRequest(BaseModel):
    component_batch_ids: List[str]
    target_ethanol_pct: float
    target_ph: float
    target_ta_gl: float
    target_residual_sugar_gl: float = 0.0


class MonteCarloRequest(BaseModel):
    vintage_year: int
    n_trials: int = Field(100, ge=1, le=5000)
    master_seed: int = 20310101
    scenario_keys: Optional[List[str]] = None
