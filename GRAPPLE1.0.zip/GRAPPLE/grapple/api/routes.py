"""
grapple.api.routes
=====================

FastAPI routes (Section 67). GRAPPLE runs a single active simulation per
server process (the "control room" is watching one estate at a time,
matching the digital-twin metaphor); `AppContext` holds that live
`VintageSimulation` plus supporting services (lab, calibration, telemetry).
"""
from __future__ import annotations

import copy
import datetime as dt
from typing import Optional

from fastapi import APIRouter, HTTPException

from grapple.api.schemas import (
    BlendOptimiseRequest, HarvestExecuteRequest, HarvestOptimiseRequest, MonteCarloRequest,
    ScenarioRunRequest, SimulationStartRequest, SimulationStepRequest,
)
from grapple.core.simulation import VintageSimulation
from grapple.data.recipes import WINE_STYLE_LIBRARY, YEAST_LIBRARY
from grapple.data.seed_estate import build_wessex_crown_simulation
from grapple.data.varieties import VARIETY_LIBRARY
from grapple.digital_twin.calibration import CalibrationEngine
from grapple.digital_twin.telemetry import TelemetryBus
from grapple.economics import costs, profitability, revenue
from grapple.laboratory.analysis import LabAnalysisService
from grapple.optimisation.harvest import evaluate_harvest_options, recommend_harvest_window
from grapple.optimisation.monte_carlo import run_monte_carlo
from grapple.vineyard.estate import Estate
from grapple.viticulture.vineyard_operations import OperationType, apply_operation
from grapple.weather.climate import SCENARIOS


class AppContext:
    """Process-wide holder for the single live simulation and its support services."""

    def __init__(self):
        self.sim: Optional[VintageSimulation] = None
        self.calibration = CalibrationEngine()
        self.telemetry = TelemetryBus()

    def require_sim(self) -> VintageSimulation:
        if self.sim is None:
            raise HTTPException(status_code=409, detail="No simulation running — call POST /simulation/start first.")
        return self.sim


context = AppContext()
router = APIRouter()


def _public_vars(obj) -> dict:
    """`vars()` filtered to drop private/internal bookkeeping attributes (leading underscore)."""
    return {k: v for k, v in vars(obj).items() if not k.startswith("_")}


# ------------------------------------------------------------------
# Simulation lifecycle
# ------------------------------------------------------------------
@router.post("/simulation/start")
def start_simulation(req: SimulationStartRequest):
    if req.use_seed_estate:
        context.sim = build_wessex_crown_simulation(req.vintage_year, seed=req.seed, scenario_key=req.scenario_key)
    else:
        context.sim = VintageSimulation(Estate(name="New Estate", region="Southern England"),
                                         vintage_year=req.vintage_year, seed=req.seed, scenario_key=req.scenario_key)
    return {"status": "started", "vintage_year": req.vintage_year, "state": context.sim.state.snapshot()}


@router.post("/simulation/step")
def step_simulation(req: SimulationStepRequest):
    sim = context.require_sim()
    days = [sim.step_day() for _ in range(req.days)]
    return {"days_advanced": len(days), "state": sim.state.snapshot()}


@router.post("/simulation/run-vintage")
def run_full_vintage():
    sim = context.require_sim()
    report = sim.run_vintage()
    return {"report": _report_dict(report)}


@router.post("/simulation/pause")
def pause_simulation():
    sim = context.require_sim()
    sim.state.clock.paused = True
    return {"status": "paused", "date": sim.state.clock.current_date.isoformat()}


# ------------------------------------------------------------------
# Estate / vineyard
# ------------------------------------------------------------------
@router.get("/estate")
def get_estate():
    sim = context.require_sim()
    return sim.state.estate.summary()


@router.get("/blocks")
def get_blocks():
    sim = context.require_sim()
    return sim.state.snapshot()["blocks"]


@router.get("/blocks/{block_id}")
def get_block(block_id: str):
    sim = context.require_sim()
    try:
        block = sim.state.estate.get_block(block_id)
    except KeyError:
        raise HTTPException(status_code=404, detail=f"Unknown block '{block_id}'")
    return {
        "block_id": block.block_id, "name": block.name, "area_ha": block.area_ha,
        "variety": block.variety.name, "rootstock": block.rootstock.name, "soil": block.soil.profile.name,
        "elevation_m": block.elevation_m, "aspect_deg": block.aspect_deg, "slope_pct": block.slope_pct,
        "planting_year": block.vines.planting_year, "training_system": block.vines.training_system,
        "stage": block.phenology.stage.value, "chemistry": _public_vars(block.chemistry),
        "disease": {"downy": block.disease.downy_mildew_pressure, "powdery": block.disease.powdery_mildew_pressure,
                    "botrytis": block.disease.botrytis_pressure},
        "soil_moisture_fraction": round(block.soil.moisture_fraction, 3), "harvested": block.harvested,
    }


@router.get("/vineyard/state")
def vineyard_state():
    sim = context.require_sim()
    return sim.state.snapshot()


@router.get("/vineyard/varieties")
def list_varieties():
    return {k: v.name for k, v in VARIETY_LIBRARY.items()}


# ------------------------------------------------------------------
# Weather
# ------------------------------------------------------------------
@router.get("/weather")
def get_weather():
    sim = context.require_sim()
    day = sim.state.weather.last()
    if day is None:
        raise HTTPException(status_code=404, detail="No weather generated yet — step the simulation first.")
    return {"date": day.date.isoformat(), "tmean_c": day.tmean_c, "tmin_c": day.tmin_c, "tmax_c": day.tmax_c,
            "rainfall_mm": day.rainfall_mm, "humidity_pct": day.humidity_pct, "wind_ms": day.wind_ms,
            "solar_mj_m2": day.solar_mj_m2, "cloud_cover_pct": day.cloud_cover_pct,
            "provenance": day.provenance.value}


@router.get("/weather/scenarios")
def list_scenarios():
    return {k: {"name": s.name, "description": s.description} for k, s in SCENARIOS.items()}


# ------------------------------------------------------------------
# Harvest
# ------------------------------------------------------------------
@router.get("/harvest/readiness")
def harvest_readiness(block_id: str, style_key: str = "traditional_sparkling"):
    sim = context.require_sim()
    readiness = sim.harvest_readiness(block_id, style_key)
    return vars(readiness)


@router.post("/harvest/optimise")
def harvest_optimise(req: HarvestOptimiseRequest):
    sim = context.require_sim()
    options = evaluate_harvest_options(sim, req.block_id, req.style_key, req.max_days)
    rec = recommend_harvest_window(options)
    return {
        "best_option": vars(rec["best_option"]),
        "recommended_window_days_from_now": rec["recommended_window_days_from_now"],
        "options": [vars(o) for o in options],
    }


@router.post("/harvest/execute")
def harvest_execute(req: HarvestExecuteRequest):
    sim = context.require_sim()
    outcome = sim.harvest_block(req.block_id, req.style_key, req.mechanical, req.yeast_key, req.fermentation_temp_c)
    return vars(outcome)


# ------------------------------------------------------------------
# Winery / fermentation / wine
# ------------------------------------------------------------------
@router.get("/winery/state")
def winery_state():
    sim = context.require_sim()
    return sim.state.cellar.capacity_summary()


@router.get("/fermentation/{batch_id}")
def fermentation_state(batch_id: str):
    sim = context.require_sim()
    batch = sim.state.fermentation_batches.get(batch_id)
    if batch is None:
        raise HTTPException(status_code=404, detail=f"Unknown fermentation batch '{batch_id}'")
    from grapple.winery.fermentation import fermentation_curve
    return {"batch_id": batch.batch_id, "status": batch.status.value, "day": batch.day,
            "ethanol_pct": batch.ethanol_pct, "sugar_gl": batch.sugar_gl, "yan_mg_l": batch.yan_mg_l,
            "temperature_target_c": batch.temperature_target_c, "temperature_actual_c": batch.temperature_actual_c,
            "curve": fermentation_curve(batch)}


@router.get("/wine/{batch_id}")
def wine_state(batch_id: str):
    sim = context.require_sim()
    batch = sim.state.fermentation_batches.get(batch_id)
    if batch is None:
        raise HTTPException(status_code=404, detail=f"Unknown batch '{batch_id}'")
    return {"batch_id": batch_id, "composition": vars(batch.composition)}


@router.get("/traceability/{entity_id}")
def traceability(entity_id: str):
    sim = context.require_sim()
    chain = sim.state.cellar.trace.trace_back(entity_id)
    return {"entity_id": entity_id, "chain": [vars(l) for l in chain]}


# ------------------------------------------------------------------
# Economics / alerts
# ------------------------------------------------------------------
@router.get("/economics")
def economics_summary():
    sim = context.require_sim()
    vineyard_cost = costs.vineyard_annual_cost(sim.state.estate.total_area_ha)
    return {"vineyard_annual_cost": {"items": vineyard_cost.items, "total": vineyard_cost.total},
            "capex_by_category": sim.state.capex.by_category(), "total_capex_gbp": sim.state.capex.total_capex_gbp()}


@router.get("/alerts")
def alerts(limit: int = 50):
    sim = context.require_sim()
    return [{"level": a.level.value, "source": a.source, "message": a.message, "date": a.date.isoformat(),
             "context": a.context} for a in sim.state.events.recent(limit)]


# ------------------------------------------------------------------
# Scenario / what-if (Section 62) — always runs on a deep-copied shadow, never the live sim
# ------------------------------------------------------------------
@router.post("/scenario/run")
def scenario_run(req: ScenarioRunRequest):
    sim = context.require_sim()
    shadow = copy.deepcopy(sim)

    if req.scenario_key:
        from grapple.weather.climate import get_scenario
        shadow.state.weather.scenario = get_scenario(req.scenario_key)

    if req.bunch_thin_block_id and req.bunch_thin_fraction is not None:
        block = shadow.state.estate.get_block(req.bunch_thin_block_id)
        apply_operation(block, OperationType.BUNCH_THINNING, bunch_thin_fraction=req.bunch_thin_fraction)

    if req.irrigation_block_id and req.irrigation_mm is not None:
        block = shadow.state.estate.get_block(req.irrigation_block_id)
        apply_operation(block, OperationType.IRRIGATION, irrigation_mm=req.irrigation_mm)

    baseline_snapshot = sim.state.snapshot()
    for _ in range(req.days_forward):
        shadow.step_day()
    scenario_snapshot = shadow.state.snapshot()

    return {"baseline": baseline_snapshot, "scenario": scenario_snapshot, "days_forward": req.days_forward}


# ------------------------------------------------------------------
# Monte Carlo (Section 45)
# ------------------------------------------------------------------
@router.post("/monte-carlo/run")
def monte_carlo_run(req: MonteCarloRequest):
    from grapple.data.seed_estate import build_wessex_crown_estate
    summary = run_monte_carlo(build_wessex_crown_estate, req.vintage_year, n_trials=req.n_trials,
                               master_seed=req.master_seed, scenario_keys=req.scenario_keys)
    return summary.summary()


# ------------------------------------------------------------------
def _report_dict(report) -> dict:
    d = vars(report).copy()
    d["outcomes"] = [vars(o) for o in report.outcomes]
    return d
