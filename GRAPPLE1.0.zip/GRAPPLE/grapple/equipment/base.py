"""
grapple.equipment.base
=========================

Shared machine digital-twin base (Section 57). Every equipment type
(tractors, harvesters, presses, tanks, pumps, refrigeration, bottling
lines) tracks operating hours, fuel consumption, a maintenance schedule and
a stochastic breakdown/availability model, so the winery/vineyard
schedulers can't assume infinite, always-available capacity.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np


@dataclass
class Equipment:
    equipment_id: str
    name: str
    category: str
    purchase_cost_gbp: float = 0.0
    operating_hours: float = 0.0
    hours_since_maintenance: float = 0.0
    maintenance_interval_hours: float = 250.0
    fuel_consumption_l_per_hour: float = 0.0
    breakdown_probability_per_hour: float = 0.0008
    available: bool = True
    under_maintenance: bool = False

    def run(self, hours: float, rng: Optional[np.random.Generator] = None) -> dict:
        """Advance operating hours; may trigger a stochastic breakdown. Returns a usage summary."""
        if not self.available:
            return {"ran_hours": 0.0, "fuel_l": 0.0, "breakdown": False, "note": "unavailable"}

        rng = rng or np.random.default_rng()
        breakdown = bool(rng.random() < self.breakdown_probability_per_hour * hours)

        self.operating_hours += hours
        self.hours_since_maintenance += hours
        fuel = hours * self.fuel_consumption_l_per_hour

        if breakdown:
            self.available = False

        due_maintenance = self.hours_since_maintenance >= self.maintenance_interval_hours

        return {
            "ran_hours": hours, "fuel_l": round(fuel, 2), "breakdown": breakdown,
            "due_maintenance": due_maintenance,
        }

    def service(self) -> None:
        self.hours_since_maintenance = 0.0
        self.under_maintenance = False
        self.available = True

    def repair(self) -> None:
        self.available = True
