"""grapple.equipment.pumps — must/wine transfer pumps (Section 57)."""
from __future__ import annotations

from dataclasses import dataclass

from grapple.equipment.base import Equipment


@dataclass
class Pump(Equipment):
    category: str = "pump"
    flow_rate_l_per_min: float = 400.0
    fuel_consumption_l_per_hour: float = 0.0
    power_kw: float = 4.0
    maintenance_interval_hours: float = 500.0

    def transfer_time_minutes(self, volume_l: float) -> float:
        return volume_l / max(1.0, self.flow_rate_l_per_min)


def new_pump(equipment_id: str, name: str = "Transfer Pump", flow_rate_l_per_min: float = 400.0,
             purchase_cost_gbp: float = 8000.0) -> Pump:
    return Pump(equipment_id=equipment_id, name=name, flow_rate_l_per_min=flow_rate_l_per_min,
                purchase_cost_gbp=purchase_cost_gbp)
