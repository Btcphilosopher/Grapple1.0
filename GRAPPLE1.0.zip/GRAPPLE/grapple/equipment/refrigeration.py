"""grapple.equipment.refrigeration — glycol/cooling plant (Section 47, 57)."""
from __future__ import annotations

from dataclasses import dataclass

from grapple.equipment.base import Equipment


@dataclass
class RefrigerationPlant(Equipment):
    category: str = "refrigeration"
    cooling_capacity_kw: float = 60.0
    power_kw: float = 20.0
    maintenance_interval_hours: float = 600.0

    def max_coolable_volume_l_per_day(self, delta_t_c: float = 5.0) -> float:
        """Very approximate: how much fermenting must this plant can hold at target temp per day."""
        # Heat of fermentation ~ 24 kcal/L released per Brix degree consumed; treat as a rough capacity proxy.
        kcal_per_day = self.cooling_capacity_kw * 860 * 24  # kW -> kcal/hr *24h
        return kcal_per_day / max(1.0, 24 * delta_t_c)


def new_refrigeration_plant(equipment_id: str, cooling_capacity_kw: float = 60.0,
                             purchase_cost_gbp: float = 45000.0) -> RefrigerationPlant:
    return RefrigerationPlant(equipment_id=equipment_id, name="Glycol Chiller Plant",
                               cooling_capacity_kw=cooling_capacity_kw, purchase_cost_gbp=purchase_cost_gbp)
