"""grapple.equipment.harvesters — mechanical harvesters (Section 21, 57)."""
from __future__ import annotations

from dataclasses import dataclass

from grapple.equipment.base import Equipment


@dataclass
class Harvester(Equipment):
    category: str = "harvester"
    picking_rate_tonnes_per_hour: float = 4.5
    fuel_consumption_l_per_hour: float = 22.0
    maintenance_interval_hours: float = 200.0
    breakdown_probability_per_hour: float = 0.0012
    fruit_damage_pct: float = 6.0    # mechanical harvesting bruises/damages a higher fruit fraction than hand picking


def new_harvester(equipment_id: str, name: str = "Mechanical Harvester",
                   purchase_cost_gbp: float = 220000.0) -> Harvester:
    return Harvester(equipment_id=equipment_id, name=name, purchase_cost_gbp=purchase_cost_gbp)
