"""grapple.equipment.bottling — bottling line equipment (Section 37, 57)."""
from __future__ import annotations

from dataclasses import dataclass

from grapple.equipment.base import Equipment


@dataclass
class BottlingLineEquipment(Equipment):
    category: str = "bottling_line"
    bottles_per_hour: float = 1500.0
    fuel_consumption_l_per_hour: float = 0.0
    power_kw: float = 12.0
    maintenance_interval_hours: float = 350.0

    def daily_capacity_bottles(self, hours_available: float = 8.0) -> float:
        return self.bottles_per_hour * hours_available


def new_bottling_line(equipment_id: str, bottles_per_hour: float = 1500.0,
                       purchase_cost_gbp: float = 180000.0) -> BottlingLineEquipment:
    return BottlingLineEquipment(equipment_id=equipment_id, name="Bottling Line",
                                  bottles_per_hour=bottles_per_hour, purchase_cost_gbp=purchase_cost_gbp)
