"""grapple.equipment.tractors — vineyard tractors (Section 57)."""
from __future__ import annotations

from dataclasses import dataclass

from grapple.equipment.base import Equipment


@dataclass
class Tractor(Equipment):
    category: str = "tractor"
    power_hp: float = 75.0
    fuel_consumption_l_per_hour: float = 8.0
    maintenance_interval_hours: float = 300.0
    breakdown_probability_per_hour: float = 0.0005


def new_tractor(equipment_id: str, name: str = "Vineyard Tractor", power_hp: float = 75.0,
                 purchase_cost_gbp: float = 55000.0) -> Tractor:
    return Tractor(equipment_id=equipment_id, name=name, power_hp=power_hp, purchase_cost_gbp=purchase_cost_gbp)
