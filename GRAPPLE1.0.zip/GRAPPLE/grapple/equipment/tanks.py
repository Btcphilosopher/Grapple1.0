"""grapple.equipment.tanks — fermentation/storage tanks (Section 47, 57)."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from grapple.equipment.base import Equipment


@dataclass
class Tank(Equipment):
    category: str = "tank"
    volume_l: float = 10000.0
    material: str = "stainless_steel"      # stainless_steel, oak, concrete
    has_cooling_jacket: bool = True
    occupied_by_batch_id: Optional[str] = None
    clean: bool = True
    cleaning_hours_remaining: float = 0.0

    @property
    def is_free(self) -> bool:
        return self.occupied_by_batch_id is None and self.clean and self.cleaning_hours_remaining <= 0

    def occupy(self, batch_id: str) -> None:
        self.occupied_by_batch_id = batch_id
        self.clean = False

    def start_cleaning(self, hours: float = 2.0) -> None:
        self.occupied_by_batch_id = None
        self.cleaning_hours_remaining = hours

    def advance_cleaning(self, hours: float) -> None:
        if self.cleaning_hours_remaining > 0:
            self.cleaning_hours_remaining = max(0.0, self.cleaning_hours_remaining - hours)
            if self.cleaning_hours_remaining <= 0:
                self.clean = True


def new_tank(equipment_id: str, volume_l: float, material: str = "stainless_steel",
             purchase_cost_gbp: Optional[float] = None) -> Tank:
    cost = purchase_cost_gbp if purchase_cost_gbp is not None else volume_l * 2.4
    return Tank(equipment_id=equipment_id, name=f"Tank {equipment_id}", volume_l=volume_l,
                material=material, purchase_cost_gbp=cost)
