"""grapple.equipment.presses — winery presses (Section 23, 57)."""
from __future__ import annotations

from dataclasses import dataclass

from grapple.equipment.base import Equipment


@dataclass
class Press(Equipment):
    category: str = "press"
    capacity_kg: float = 4000.0
    cycle_time_hours: float = 3.5
    fuel_consumption_l_per_hour: float = 0.0
    power_kw: float = 15.0
    maintenance_interval_hours: float = 400.0
    breakdown_probability_per_hour: float = 0.0006

    def cycles_per_day(self, hours_available: float = 20.0) -> float:
        return hours_available / self.cycle_time_hours

    def daily_capacity_kg(self, hours_available: float = 20.0) -> float:
        return self.cycles_per_day(hours_available) * self.capacity_kg


def new_press(equipment_id: str, name: str = "Pneumatic Press", capacity_kg: float = 4000.0,
              purchase_cost_gbp: float = 120000.0) -> Press:
    return Press(equipment_id=equipment_id, name=name, capacity_kg=capacity_kg, purchase_cost_gbp=purchase_cost_gbp)
