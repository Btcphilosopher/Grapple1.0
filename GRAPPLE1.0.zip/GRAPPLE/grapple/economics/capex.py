"""
grapple.economics.capex
==========================

Capital expenditure tracking (Section 51) with straight-line depreciation
— vineyard establishment, machinery, tanks, barrels, winery buildings.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import List


@dataclass
class CapexItem:
    label: str
    category: str
    cost_gbp: float
    year_acquired: int
    useful_life_years: float

    def book_value(self, current_year: int) -> float:
        age = max(0, current_year - self.year_acquired)
        depreciation_fraction = min(1.0, age / max(0.1, self.useful_life_years))
        return round(self.cost_gbp * (1 - depreciation_fraction), 2)

    def annual_depreciation_gbp(self) -> float:
        return round(self.cost_gbp / max(0.1, self.useful_life_years), 2)


class CapexRegister:
    def __init__(self):
        self.items: List[CapexItem] = []

    def add(self, item: CapexItem) -> None:
        self.items.append(item)

    def total_capex_gbp(self) -> float:
        return round(sum(i.cost_gbp for i in self.items), 2)

    def total_book_value(self, current_year: int) -> float:
        return round(sum(i.book_value(current_year) for i in self.items), 2)

    def annual_depreciation_gbp(self) -> float:
        return round(sum(i.annual_depreciation_gbp() for i in self.items), 2)

    def by_category(self) -> dict:
        out: dict[str, float] = {}
        for i in self.items:
            out[i.category] = out.get(i.category, 0.0) + i.cost_gbp
        return {k: round(v, 2) for k, v in out.items()}
