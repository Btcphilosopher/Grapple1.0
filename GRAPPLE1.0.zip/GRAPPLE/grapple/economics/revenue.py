"""
grapple.economics.revenue
============================

Premium English wine product economics (Section 52). SYNTHETIC indicative
UK trade/cellar-door price points per product, used to project revenue
from finished bottled inventory.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict


@dataclass(frozen=True)
class WineProduct:
    key: str
    name: str
    typical_ageing_months: int
    bottle_cost_gbp: float
    expected_price_gbp: float          # indicative average realised price (blend of trade/cellar-door)


PRODUCT_LIBRARY: Dict[str, WineProduct] = {}


def register_product(p: WineProduct) -> None:
    PRODUCT_LIBRARY[p.key] = p


def get_product(key: str) -> WineProduct:
    return PRODUCT_LIBRARY[key]


for _p in [
    WineProduct("sparkling_brut", "English Sparkling Brut", 30, 3.9, 32.0),
    WineProduct("sparkling_rose", "English Sparkling Rosé", 30, 4.0, 36.0),
    WineProduct("chardonnay_still", "Chardonnay Still", 10, 3.2, 22.0),
    WineProduct("bacchus", "Bacchus", 6, 2.9, 18.5),
    WineProduct("reserve_cuvee", "Reserve Cuvée", 48, 4.6, 55.0),
    WineProduct("single_vineyard", "Single Vineyard", 36, 4.8, 48.0),
    WineProduct("late_harvest", "Late Harvest", 18, 4.2, 40.0),
]:
    register_product(_p)


@dataclass
class RevenueProjection:
    product_key: str
    bottles: float
    unit_price_gbp: float
    gross_revenue_gbp: float


def project_revenue(product_key: str, bottles: float, price_override_gbp: float | None = None) -> RevenueProjection:
    product = get_product(product_key)
    price = price_override_gbp if price_override_gbp is not None else product.expected_price_gbp
    return RevenueProjection(product_key=product_key, bottles=bottles, unit_price_gbp=price,
                              gross_revenue_gbp=round(bottles * price, 2))
