"""
grapple.economics.profitability
==================================

Combines costs, revenue and capex into the headline profitability metrics
(Section 51): gross margin, operating margin, and return on vineyard
investment.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

from grapple.economics.capex import CapexRegister
from grapple.economics.revenue import RevenueProjection


@dataclass
class ProfitabilitySummary:
    gross_revenue_gbp: float
    cost_of_goods_gbp: float
    gross_margin_gbp: float
    gross_margin_pct: float
    operating_costs_gbp: float
    operating_profit_gbp: float
    operating_margin_pct: float
    total_capex_gbp: float
    annual_depreciation_gbp: float
    return_on_investment_pct: float


def summarise_profitability(
    revenue_projections: List[RevenueProjection],
    cost_of_goods_gbp: float,
    operating_costs_gbp: float,
    capex: CapexRegister,
) -> ProfitabilitySummary:
    gross_revenue = round(sum(r.gross_revenue_gbp for r in revenue_projections), 2)
    gross_margin = round(gross_revenue - cost_of_goods_gbp, 2)
    gross_margin_pct = round(100 * gross_margin / max(0.01, gross_revenue), 1)

    operating_profit = round(gross_margin - operating_costs_gbp, 2)
    operating_margin_pct = round(100 * operating_profit / max(0.01, gross_revenue), 1)

    total_capex = capex.total_capex_gbp()
    roi_pct = round(100 * operating_profit / max(0.01, total_capex), 2) if total_capex else 0.0

    return ProfitabilitySummary(
        gross_revenue_gbp=gross_revenue, cost_of_goods_gbp=round(cost_of_goods_gbp, 2),
        gross_margin_gbp=gross_margin, gross_margin_pct=gross_margin_pct,
        operating_costs_gbp=round(operating_costs_gbp, 2), operating_profit_gbp=operating_profit,
        operating_margin_pct=operating_margin_pct, total_capex_gbp=total_capex,
        annual_depreciation_gbp=capex.annual_depreciation_gbp(), return_on_investment_pct=roi_pct,
    )
