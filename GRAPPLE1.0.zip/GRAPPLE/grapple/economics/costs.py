"""
grapple.economics.costs
==========================

Vineyard and winery operating cost model (Section 51). SYNTHETIC unit
costs representative of English wine-estate economics (£, 2025-ish price
levels) — a real estate would override these via Real Vineyard Mode.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict


# --- Vineyard costs (£/ha/year unless noted) --------------------------------
VINEYARD_ANNUAL_COSTS_GBP_PER_HA = {
    "labour": 3200.0,
    "machinery_running": 900.0,
    "fertilisation": 350.0,
    "disease_management": 1100.0,
    "irrigation": 150.0,
    "trellising_maintenance": 250.0,
    "insurance": 180.0,
    "land_rent_or_opportunity_cost": 1500.0,
}
VINEYARD_HARVEST_COST_GBP_PER_TONNE_HAND = 350.0
VINEYARD_HARVEST_COST_GBP_PER_TONNE_MECHANICAL = 90.0

VINEYARD_ESTABLISHMENT_COST_GBP_PER_HA = 38000.0   # land prep, vines, trellis, first 3 non-cropping years

# --- Winery costs -------------------------------------------------------------
WINERY_COST_GBP_PER_TONNE_GRAPES = {
    "processing_labour": 65.0,
    "energy": 40.0,
    "water": 8.0,
}
WINERY_COST_GBP_PER_LITRE_WINE = {
    "tank_time_allocation": 0.12,
    "cellar_labour": 0.18,
    "consumables": 0.10,
}
WINERY_COST_GBP_PER_BOTTLE = {
    "glass_bottle": 0.55,
    "closure": 0.18,
    "label": 0.12,
    "packaging": 0.25,
    "bottling_labour_energy": 0.20,
    "warehousing_logistics": 0.15,
}
OAK_BARREL_COST_GBP = 850.0
OAK_BARREL_USEFUL_LIFE_FILLS = 4


@dataclass
class CostBreakdown:
    items: Dict[str, float]
    total: float


def vineyard_annual_cost(area_ha: float) -> CostBreakdown:
    items = {k: round(v * area_ha, 2) for k, v in VINEYARD_ANNUAL_COSTS_GBP_PER_HA.items()}
    return CostBreakdown(items=items, total=round(sum(items.values()), 2))


def harvest_cost(tonnes: float, mechanical: bool) -> float:
    rate = VINEYARD_HARVEST_COST_GBP_PER_TONNE_MECHANICAL if mechanical else VINEYARD_HARVEST_COST_GBP_PER_TONNE_HAND
    return round(rate * tonnes, 2)


def winery_processing_cost(tonnes_grapes: float) -> CostBreakdown:
    items = {k: round(v * tonnes_grapes, 2) for k, v in WINERY_COST_GBP_PER_TONNE_GRAPES.items()}
    return CostBreakdown(items=items, total=round(sum(items.values()), 2))


def winery_maturation_cost(volume_l: float) -> CostBreakdown:
    items = {k: round(v * volume_l, 2) for k, v in WINERY_COST_GBP_PER_LITRE_WINE.items()}
    return CostBreakdown(items=items, total=round(sum(items.values()), 2))


def bottling_cost(bottles: int) -> CostBreakdown:
    items = {k: round(v * bottles, 2) for k, v in WINERY_COST_GBP_PER_BOTTLE.items()}
    return CostBreakdown(items=items, total=round(sum(items.values()), 2))


def cost_per_tonne_grapes(total_vineyard_cost: float, total_tonnes: float) -> float:
    return round(total_vineyard_cost / max(0.001, total_tonnes), 2)


def cost_per_litre_wine(total_production_cost: float, total_litres: float) -> float:
    return round(total_production_cost / max(0.001, total_litres), 3)


def cost_per_bottle(total_production_cost: float, total_bottles: int) -> float:
    return round(total_production_cost / max(1, total_bottles), 3)
