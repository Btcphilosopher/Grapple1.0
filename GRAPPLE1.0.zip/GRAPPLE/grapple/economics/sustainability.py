"""
grapple.economics.sustainability
===================================

Sustainability tracking (Section 53): water, electricity, fuel, fertiliser,
packaging, glass weight, transport and waste, rolled up into per-bottle /
per-tonne metrics so alternative scenarios (lighter glass, electric
tractor, cover-crop nitrogen instead of synthetic fertiliser...) can be
compared. Emission factors are SYNTHETIC, illustrative UK-representative
figures, not an audited carbon methodology.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

# kg CO2e per unit
EMISSION_FACTORS = {
    "diesel_l": 2.68,
    "electricity_kwh": 0.21,     # UK grid average, illustrative
    "glass_bottle_standard_kg": 0.45,     # ~450g bottle
    "glass_bottle_light_kg": 0.30,        # ~300g lightweight bottle
    "nitrogen_fertiliser_kg": 5.6,
    "cardboard_packaging_kg": 0.94,
    "road_transport_tonne_km": 0.10,
}

WATER_L_PER_TONNE_GRAPES_PROCESSED = 3500.0
WATER_L_PER_BOTTLE = 2.8


@dataclass
class SustainabilityInventory:
    diesel_l: float = 0.0
    electricity_kwh: float = 0.0
    glass_bottle_kg_total: float = 0.0
    nitrogen_fertiliser_kg: float = 0.0
    cardboard_packaging_kg: float = 0.0
    road_transport_tonne_km: float = 0.0
    water_l: float = 0.0
    tonnes_grapes_processed: float = 0.0
    bottles_produced: int = 0


def carbon_footprint_kg_co2e(inv: SustainabilityInventory) -> Dict[str, float]:
    # Glass embodied carbon is ~0.7 kg CO2e per kg of glass manufactured (illustrative figure);
    # `glass_bottle_kg_total` is already the total mass of glass used, so it's applied directly.
    glass_embodied_carbon_per_kg = 0.7
    items = {
        "diesel": inv.diesel_l * EMISSION_FACTORS["diesel_l"],
        "electricity": inv.electricity_kwh * EMISSION_FACTORS["electricity_kwh"],
        "glass": inv.glass_bottle_kg_total * glass_embodied_carbon_per_kg,
        "nitrogen": inv.nitrogen_fertiliser_kg * EMISSION_FACTORS["nitrogen_fertiliser_kg"],
        "packaging": inv.cardboard_packaging_kg * EMISSION_FACTORS["cardboard_packaging_kg"],
        "transport": inv.road_transport_tonne_km * EMISSION_FACTORS["road_transport_tonne_km"],
    }
    return {k: round(v, 1) for k, v in items.items()}


def sustainability_metrics(inv: SustainabilityInventory) -> dict:
    footprint = carbon_footprint_kg_co2e(inv)
    total_co2e = sum(footprint.values())
    return {
        "footprint_by_category_kg_co2e": footprint,
        "total_kg_co2e": round(total_co2e, 1),
        "kg_co2e_per_bottle": round(total_co2e / max(1, inv.bottles_produced), 3),
        "litres_water_per_bottle": round(inv.water_l / max(1, inv.bottles_produced), 2),
        "energy_kwh_per_bottle": round(inv.electricity_kwh / max(1, inv.bottles_produced), 3),
        "waste_kg_per_tonne_grapes": round(0.0, 2),  # placeholder aggregate — wire up from pressing waste_l if tracked
    }
