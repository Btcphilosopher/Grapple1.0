"""
grapple.data.soils
===================

Seed soil-type library (Section 7) representative of southern English
vineyard geology: chalk downland, greensand, clay, and river-terrace
loam/gravel. Values are SYNTHETIC representative ranges, not a site survey.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict


@dataclass(frozen=True)
class SoilTypeData:
    key: str
    name: str
    texture: str
    sand_pct: float
    silt_pct: float
    clay_pct: float
    depth_cm: float
    drainage: str                 # "free", "moderate", "impeded"
    water_holding_capacity_mm: float   # plant-available water in the effective root depth
    ph: float
    organic_matter_pct: float
    nitrogen_index: float          # 0-1 relative fertility index
    potassium_index: float
    magnesium_index: float
    calcium_index: float
    notes: str = ""


SOIL_LIBRARY: Dict[str, SoilTypeData] = {}


def register_soil(s: SoilTypeData) -> None:
    SOIL_LIBRARY[s.key] = s


def get_soil(key: str) -> SoilTypeData:
    try:
        return SOIL_LIBRARY[key]
    except KeyError as e:
        raise KeyError(f"Unknown soil type '{key}'. Registered: {sorted(SOIL_LIBRARY)}") from e


for _s in [
    SoilTypeData("chalk", "Chalk Downland", texture="silty clay loam over chalk",
                 sand_pct=20, silt_pct=45, clay_pct=35, depth_cm=45, drainage="free",
                 water_holding_capacity_mm=95, ph=7.9, organic_matter_pct=2.6,
                 nitrogen_index=0.45, potassium_index=0.4, magnesium_index=0.55, calcium_index=0.95,
                 notes="Classic South Downs / North Downs chalk; excellent drainage, high pH, moderate vigour."),
    SoilTypeData("greensand", "Upper Greensand", texture="sandy loam",
                 sand_pct=55, silt_pct=30, clay_pct=15, depth_cm=60, drainage="free",
                 water_holding_capacity_mm=110, ph=6.4, organic_matter_pct=2.2,
                 nitrogen_index=0.5, potassium_index=0.45, magnesium_index=0.4, calcium_index=0.4,
                 notes="Free-draining, warms quickly in spring; found around the Weald."),
    SoilTypeData("clay", "Wealden Clay", texture="heavy clay",
                 sand_pct=15, silt_pct=30, clay_pct=55, depth_cm=70, drainage="impeded",
                 water_holding_capacity_mm=160, ph=6.8, organic_matter_pct=3.4,
                 nitrogen_index=0.7, potassium_index=0.6, magnesium_index=0.65, calcium_index=0.5,
                 notes="High water-holding capacity, prone to waterlogging; vigorous canopies."),
    SoilTypeData("loam", "River Terrace Loam", texture="sandy clay loam",
                 sand_pct=40, silt_pct=35, clay_pct=25, depth_cm=80, drainage="moderate",
                 water_holding_capacity_mm=140, ph=6.6, organic_matter_pct=3.0,
                 nitrogen_index=0.65, potassium_index=0.55, magnesium_index=0.5, calcium_index=0.45,
                 notes="Balanced, fertile, moderate drainage; common on river terraces."),
    SoilTypeData("flint_clay", "Flint over Clay-with-Flints", texture="flinty clay loam",
                 sand_pct=25, silt_pct=35, clay_pct=40, depth_cm=50, drainage="moderate",
                 water_holding_capacity_mm=115, ph=7.0, organic_matter_pct=2.8,
                 nitrogen_index=0.55, potassium_index=0.5, magnesium_index=0.5, calcium_index=0.7,
                 notes="Flinty clay cap over chalk; good heat retention from flint, moderate drainage."),
    SoilTypeData("gravel", "River Gravel", texture="sandy gravel",
                 sand_pct=65, silt_pct=20, clay_pct=15, depth_cm=55, drainage="free",
                 water_holding_capacity_mm=75, ph=6.9, organic_matter_pct=1.8,
                 nitrogen_index=0.35, potassium_index=0.35, magnesium_index=0.35, calcium_index=0.45,
                 notes="Very free-draining, low fertility, low vigour; irrigation-responsive."),
]:
    register_soil(_s)
