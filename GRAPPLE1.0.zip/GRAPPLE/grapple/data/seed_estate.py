"""
grapple.data.seed_estate
===========================

Wessex Crown Vineyard (Section 74) — a SYNTHETIC example English estate
used as GRAPPLE's default demo/first-run data. Every figure here is
illustrative, built to be internally plausible (block areas sum to the
stated estate total, elevations/aspects/soils vary realistically across
blocks) rather than surveyed from a real site.

    Estate:      Wessex Crown Vineyard
    Region:      Southern England (South Downs chalk / Weald greensand belt)
    Area:        48.6 hectares
    Varieties:   Chardonnay, Pinot Noir, Pinot Meunier, Bacchus, Seyval Blanc
    Production:  Traditional-method Sparkling, Still White, Rosé
"""
from __future__ import annotations

from typing import Optional

from grapple.core.simulation import VintageSimulation
from grapple.economics.capex import CapexItem, CapexRegister
from grapple.equipment.presses import new_press
from grapple.equipment.pumps import new_pump
from grapple.equipment.refrigeration import new_refrigeration_plant
from grapple.equipment.tanks import new_tank
from grapple.vineyard.blocks import Block
from grapple.vineyard.estate import Estate
from grapple.vineyard.vines import VinePopulation

ESTATE_NAME = "Wessex Crown Vineyard"
ESTATE_REGION = "Southern England (South Downs / Weald)"
ESTATE_LATITUDE = 50.95
ESTATE_LONGITUDE = -0.55

# (block_id, name, area_ha, variety, soil, elevation_m, slope_pct, aspect_deg, planting_year,
#  rootstock, vines_per_ha, clone)
_BLOCK_SPECS = [
    ("B01", "Chalk Ridge", 6.2, "chardonnay", "chalk", 115, 8, 160, 2012, "SO4", 4200, "95"),
    ("B02", "Church Field", 5.5, "pinot_noir", "chalk", 105, 6, 170, 2014, "101-14", 4400, "115"),
    ("B03", "Mill Meadow", 4.8, "pinot_meunier", "clay", 60, 3, 190, 2015, "3309C", 4000, "unknown"),
    ("B04", "Long Down", 7.0, "chardonnay", "greensand", 130, 10, 175, 2010, "SO4", 4300, "96"),
    ("B05", "Bacchus Bank", 5.0, "bacchus", "greensand", 95, 12, 200, 2016, "3309C", 4600, "unknown"),
    ("B06", "River Terrace", 4.5, "pinot_noir", "loam", 45, 2, 180, 2017, "101-14", 4200, "667"),
    ("B07", "Flint Hanger", 4.0, "pinot_meunier", "flint_clay", 100, 9, 165, 2013, "5BB", 4100, "unknown"),
    ("B08", "South Slope", 6.6, "chardonnay", "chalk", 120, 14, 155, 2011, "SO4", 4400, "76"),
    ("B09", "Seyval Corner", 3.0, "seyval_blanc", "gravel", 80, 5, 185, 2018, "own_root", 4000, "unknown"),
    ("B10", "Home Bacchus", 2.0, "bacchus", "loam", 70, 4, 195, 2019, "3309C", 4500, "unknown"),
]


def build_wessex_crown_estate() -> Estate:
    estate = Estate(name=ESTATE_NAME, region=ESTATE_REGION)
    for block_id, name, area, variety, soil, elev, slope, aspect, planted, rootstock, density, clone in _BLOCK_SPECS:
        block = Block(
            block_id=block_id, name=name, area_ha=area,
            latitude=ESTATE_LATITUDE + (elev - 90) * 0.0002, longitude=ESTATE_LONGITUDE - (elev - 90) * 0.00015,
            elevation_m=elev, slope_pct=slope, aspect_deg=aspect,
            soil_key=soil, variety_key=variety, rootstock_key=rootstock,
            vines=VinePopulation(vines_per_ha=density, planting_year=planted, clone=clone),
        )
        estate.add_block(block)
    return estate


def _default_tank_farm() -> list:
    """A tank farm sized to comfortably hold single-block harvests across the estate's block sizes."""
    specs = [
        ("T-STL-01", 6000), ("T-STL-02", 6000), ("T-STL-03", 8000), ("T-STL-04", 8000),
        ("T-STL-05", 10000), ("T-STL-06", 10000), ("T-STL-07", 15000), ("T-STL-08", 15000),
        ("T-STL-09", 20000), ("T-STL-10", 25000),
    ]
    return [new_tank(tid, vol) for tid, vol in specs]


def build_wessex_crown_capex() -> CapexRegister:
    reg = CapexRegister()
    reg.add(CapexItem("Land & vineyard establishment (48.6ha)", "vineyard_establishment", 1_846_800.0, 2010, 40))
    reg.add(CapexItem("Winery building & fit-out", "winery_building", 1_200_000.0, 2013, 30))
    reg.add(CapexItem("Tank farm (10 vessels)", "tanks", 210_000.0, 2013, 20))
    reg.add(CapexItem("Pneumatic presses (x2)", "presses", 240_000.0, 2013, 15))
    reg.add(CapexItem("Refrigeration/glycol plant", "refrigeration", 90_000.0, 2013, 15))
    reg.add(CapexItem("Bottling line", "bottling_line", 180_000.0, 2016, 12))
    reg.add(CapexItem("Tractors & vineyard machinery", "machinery", 320_000.0, 2015, 10))
    reg.add(CapexItem("Oak barrel stock (40 barriques)", "oak", 34_000.0, 2018, 6))
    return reg


def build_wessex_crown_simulation(vintage_year: int, seed: int = 20310817,
                                   scenario_key: str = "average") -> VintageSimulation:
    """Assembles the full seeded estate + winery, ready to `run_vintage()` or `step_day()`."""
    estate = build_wessex_crown_estate()
    sim = VintageSimulation(
        estate, vintage_year=vintage_year, seed=seed, scenario_key=scenario_key,
        fermentation_capacity_l=220_000.0, cellar_capacity_l=300_000.0,
        bottling_capacity_bottles_per_day=12_000.0, press_capacity_kg_per_day=40_000.0,
        latitude_deg=ESTATE_LATITUDE,
    )
    for tank in _default_tank_farm():
        sim.state.cellar.add_tank(tank)

    sim.state.capex = build_wessex_crown_capex()
    return sim
