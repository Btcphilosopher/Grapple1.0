"""
grapple.data.recipes
=====================

Seed reference data for:
  * Wine style targets (Section 20) — the grape-chemistry targets the
    harvest optimiser scores against for a given desired wine style.
  * Yeast strains (Section 26).
  * Oak vessel origins/toast levels (Section 33).

All SYNTHETIC / illustrative — configurable, not hard-coded to a fixed set.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional


@dataclass(frozen=True)
class WineStyleTarget:
    key: str
    name: str
    target_brix: float
    brix_tolerance: float
    target_ph: float
    ph_tolerance: float
    target_ta_gl: float          # titratable acid, g/L tartaric equivalent
    ta_tolerance: float
    weight_sugar: float = 0.3    # relative importance weights used by the harvest optimiser
    weight_acid: float = 0.3
    weight_phenolic: float = 0.15
    weight_aromatic: float = 0.15
    weight_physiological: float = 0.10
    notes: str = ""


WINE_STYLE_LIBRARY: Dict[str, WineStyleTarget] = {}


def register_style(s: WineStyleTarget) -> None:
    WINE_STYLE_LIBRARY[s.key] = s


def get_style(key: str) -> WineStyleTarget:
    try:
        return WINE_STYLE_LIBRARY[key]
    except KeyError as e:
        raise KeyError(f"Unknown wine style '{key}'. Registered: {sorted(WINE_STYLE_LIBRARY)}") from e


for _s in [
    WineStyleTarget("traditional_sparkling", "Traditional-Method Sparkling",
                     target_brix=18.5, brix_tolerance=1.2, target_ph=3.05, ph_tolerance=0.15,
                     target_ta_gl=9.5, ta_tolerance=1.5,
                     weight_sugar=0.25, weight_acid=0.35, weight_phenolic=0.1, weight_aromatic=0.1,
                     weight_physiological=0.2,
                     notes="Picked early for high natural acidity and freshness; base wine, not final ABV."),
    WineStyleTarget("still_white", "English Still White",
                     target_brix=20.5, brix_tolerance=1.5, target_ph=3.15, ph_tolerance=0.15,
                     target_ta_gl=7.5, ta_tolerance=1.2,
                     weight_sugar=0.3, weight_acid=0.25, weight_phenolic=0.05, weight_aromatic=0.3,
                     weight_physiological=0.1,
                     notes="Balanced ripeness with aromatic development; Bacchus/Ortega-style profile."),
    WineStyleTarget("rose", "Rosé",
                     target_brix=19.5, brix_tolerance=1.3, target_ph=3.1, ph_tolerance=0.15,
                     target_ta_gl=8.0, ta_tolerance=1.3,
                     weight_sugar=0.25, weight_acid=0.3, weight_phenolic=0.2, weight_aromatic=0.15,
                     weight_physiological=0.1,
                     notes="Moderate ripeness with fresh acidity and light skin phenolics."),
    WineStyleTarget("red", "Red",
                     target_brix=22.0, brix_tolerance=1.5, target_ph=3.3, ph_tolerance=0.15,
                     target_ta_gl=6.5, ta_tolerance=1.2,
                     weight_sugar=0.25, weight_acid=0.15, weight_phenolic=0.35, weight_aromatic=0.1,
                     weight_physiological=0.15,
                     notes="Full phenolic ripeness prioritised; challenging in cool English vintages."),
    WineStyleTarget("experimental", "Experimental / Orange",
                     target_brix=20.0, brix_tolerance=2.0, target_ph=3.2, ph_tolerance=0.2,
                     target_ta_gl=7.5, ta_tolerance=1.8,
                     weight_sugar=0.2, weight_acid=0.2, weight_phenolic=0.3, weight_aromatic=0.2,
                     weight_physiological=0.1,
                     notes="Wide tolerance band — user-defined stylistic latitude."),
    WineStyleTarget("late_harvest", "Late Harvest",
                     target_brix=26.0, brix_tolerance=2.5, target_ph=3.4, ph_tolerance=0.2,
                     target_ta_gl=6.5, ta_tolerance=1.5,
                     weight_sugar=0.5, weight_acid=0.15, weight_phenolic=0.1, weight_aromatic=0.15,
                     weight_physiological=0.1,
                     notes="Extended hang time; only reliable in warm/exceptional English vintages."),
]:
    register_style(_s)


@dataclass(frozen=True)
class YeastStrainData:
    key: str
    name: str
    species: str = "Saccharomyces cerevisiae"
    temp_min_c: float = 12.0
    temp_max_c: float = 28.0
    temp_optimum_c: float = 18.0
    fermentation_speed: float = 1.0     # relative multiplier on max fermentation rate
    attenuation: float = 0.99           # fraction of sugar fully consumed under normal conditions
    nutrient_demand: float = 1.0        # relative multiplier (YAN requirement)
    alcohol_tolerance_pct: float = 15.0
    stress_sensitivity: float = 0.5     # 0-1, susceptibility to stuck/sluggish fermentation under stress
    aroma_profile: Dict[str, float] = field(default_factory=dict)  # descriptor -> relative intensity 0-1
    notes: str = ""


YEAST_LIBRARY: Dict[str, YeastStrainData] = {}


def register_yeast(y: YeastStrainData) -> None:
    YEAST_LIBRARY[y.key] = y


def get_yeast(key: str) -> YeastStrainData:
    try:
        return YEAST_LIBRARY[key]
    except KeyError as e:
        raise KeyError(f"Unknown yeast strain '{key}'. Registered: {sorted(YEAST_LIBRARY)}") from e


for _y in [
    YeastStrainData("ec1118", "EC-1118 (neutral, robust)", temp_min_c=10, temp_max_c=30, temp_optimum_c=18,
                     fermentation_speed=1.2, attenuation=0.995, nutrient_demand=0.9, alcohol_tolerance_pct=18,
                     stress_sensitivity=0.2, aroma_profile={"neutral": 0.9, "fruit": 0.3},
                     notes="Champagne-derived, very robust; workhorse for sparkling base wines."),
    YeastStrainData("qa23", "QA23 (aromatic, cool ferment)", temp_min_c=10, temp_max_c=20, temp_optimum_c=15,
                     fermentation_speed=0.85, attenuation=0.99, nutrient_demand=1.1, alcohol_tolerance_pct=14,
                     stress_sensitivity=0.45, aroma_profile={"floral": 0.7, "fruit": 0.6, "thiol": 0.6},
                     notes="Favoured for aromatic English whites fermented cool."),
    YeastStrainData("rc212", "RC212 (red, structured)", temp_min_c=15, temp_max_c=30, temp_optimum_c=24,
                     fermentation_speed=1.0, attenuation=0.99, nutrient_demand=1.15, alcohol_tolerance_pct=15,
                     stress_sensitivity=0.4, aroma_profile={"spice": 0.6, "dark_fruit": 0.6, "tannin": 0.5},
                     notes="Structured extraction profile for reds/rosé."),
    YeastStrainData("d47", "D47 (textural, low volatile acidity)", temp_min_c=12, temp_max_c=22, temp_optimum_c=16,
                     fermentation_speed=0.8, attenuation=0.985, nutrient_demand=1.0, alcohol_tolerance_pct=14,
                     stress_sensitivity=0.5, aroma_profile={"texture": 0.7, "citrus": 0.4},
                     notes="Slow, cool ferment favoured for textured Chardonnay."),
    YeastStrainData("native", "Native / Spontaneous", temp_min_c=8, temp_max_c=26, temp_optimum_c=17,
                     fermentation_speed=0.6, attenuation=0.92, nutrient_demand=1.2, alcohol_tolerance_pct=13,
                     stress_sensitivity=0.85, aroma_profile={"complex": 0.8, "funk": 0.5, "fruit": 0.4},
                     notes="Stochastic native flora fermentation — highest complexity potential, highest risk "
                           "of stuck/off fermentation. Treated as a simulation parameter, not a guaranteed outcome."),
]:
    register_yeast(_y)


@dataclass(frozen=True)
class OakData:
    key: str
    origin: str
    toast_level: str          # "light", "medium", "medium-plus", "heavy"
    extraction_rate: float    # relative multiplier on flavour/tannin extraction per month of contact
    oxygen_transfer_rate_mg_l_year: float
    notes: str = ""


OAK_LIBRARY: Dict[str, OakData] = {}


def register_oak(o: OakData) -> None:
    OAK_LIBRARY[o.key] = o


def get_oak(key: str) -> OakData:
    try:
        return OAK_LIBRARY[key]
    except KeyError as e:
        raise KeyError(f"Unknown oak profile '{key}'. Registered: {sorted(OAK_LIBRARY)}") from e


for _o in [
    OakData("french_light", "French (Allier)", "light", extraction_rate=0.6, oxygen_transfer_rate_mg_l_year=20,
            notes="Subtle, tight-grained; gentle micro-oxygenation."),
    OakData("french_medium", "French (Vosges)", "medium", extraction_rate=1.0, oxygen_transfer_rate_mg_l_year=28,
            notes="Balanced spice/vanilla character; standard barrique choice."),
    OakData("french_heavy", "French (Tronçais)", "heavy", extraction_rate=1.4, oxygen_transfer_rate_mg_l_year=35,
            notes="Pronounced toast character, faster extraction."),
    OakData("american_medium", "American Oak", "medium-plus", extraction_rate=1.3, oxygen_transfer_rate_mg_l_year=30,
            notes="Coconut/vanilla-forward, coarser grain, faster extraction than French equivalents."),
    OakData("neutral", "Neutral (3rd+ fill)", "light", extraction_rate=0.15, oxygen_transfer_rate_mg_l_year=15,
            notes="Effectively neutral wood, used mainly for gentle oxidative ageing."),
]:
    register_oak(_o)
