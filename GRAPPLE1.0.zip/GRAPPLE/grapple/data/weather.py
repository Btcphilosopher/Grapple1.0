"""
grapple.data.weather
=====================

Monthly climate normals used as the baseline for the stochastic weather
engine (Section 9). Figures are SYNTHETIC, deliberately representative of
southern English cool-maritime conditions (broadly consistent with public
1991-2020 averages for the Sussex/Kent/Hampshire chalk belt) rather than
taken from any single named station. `weather.weather.WeatherEngine`
perturbs day-to-day around these normals; `weather.climate` scenarios shift
them wholesale (e.g. "Warm Vintage" adds +1.5C to every month).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List


@dataclass(frozen=True)
class MonthlyNormal:
    month: int
    tmin_c: float
    tmax_c: float
    rain_mm: float
    rain_days: float          # mean number of wet days (>=1mm) in the month
    humidity_pct: float
    wind_ms: float
    sunshine_hours_per_day: float
    cloud_cover_pct: float


# index 0 unused, months 1-12
SOUTHERN_ENGLAND_NORMALS: Dict[int, MonthlyNormal] = {
    1:  MonthlyNormal(1,  2.0,  7.5,  75, 15, 87, 4.2, 1.6, 78),
    2:  MonthlyNormal(2,  1.8,  7.9,  55, 12, 84, 4.3, 2.4, 74),
    3:  MonthlyNormal(3,  3.2, 10.6,  53, 11, 79, 4.1, 3.6, 68),
    4:  MonthlyNormal(4,  4.8, 13.3,  48, 10, 74, 3.8, 5.2, 62),
    5:  MonthlyNormal(5,  7.6, 16.8,  50, 10, 73, 3.5, 6.4, 58),
    6:  MonthlyNormal(6, 10.5, 19.8,  50,  9, 73, 3.3, 6.7, 58),
    7:  MonthlyNormal(7, 12.7, 22.3,  45,  8, 73, 3.1, 6.8, 56),
    8:  MonthlyNormal(8, 12.5, 22.1,  55,  9, 76, 3.1, 6.3, 58),
    9:  MonthlyNormal(9, 10.3, 19.2,  58,  9, 80, 3.4, 5.0, 62),
    10: MonthlyNormal(10, 7.8, 15.3,  80, 12, 85, 3.9, 3.6, 70),
    11: MonthlyNormal(11, 4.3, 10.8,  85, 14, 88, 4.1, 2.2, 78),
    12: MonthlyNormal(12, 2.5,  8.1,  85, 15, 89, 4.2, 1.5, 81),
}

DAYS_IN_MONTH: List[int] = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
