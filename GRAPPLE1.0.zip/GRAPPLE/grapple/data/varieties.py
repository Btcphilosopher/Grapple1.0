"""
grapple.data.varieties
=======================

Seed reference data for grape varieties and rootstocks relevant to English
viticulture (Section 5, 6). These figures are SYNTHETIC / illustrative,
assembled from published viticultural characteristics of each variety in
cool-climate settings — they are a reasonable starting point for a digital
twin, not laboratory-calibrated constants. A real estate should override
them via Real Vineyard Mode (Section 64) as its own trial data accumulates.

New varieties can be registered at runtime with `register_variety(...)` —
the system is not hard-coded to any fixed list.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional


@dataclass(frozen=True)
class VarietyData:
    key: str
    name: str
    colour: str                          # "white", "black", "grey/pink"
    species: str = "Vitis vinifera"

    # --- Phenology thresholds (see vineyard.phenology for the two-accumulator model) ---
    gdd_budbreak: float = 580.0          # base-0C spring forcing sum from 1 Jan that triggers budbreak
    gdd_flowering: float = 140.0         # base-10C GDD from budbreak that triggers flowering
    gdd_veraison: float = 620.0          # base-10C GDD from budbreak that triggers veraison
    gdd_full_ripeness: float = 800.0     # base-10C GDD from budbreak — nominal reference for "typical" full ripeness

    # --- Frost & disease sensitivity (0-1, higher = more sensitive) --------
    frost_sensitivity: float = 0.5
    downy_mildew_susceptibility: float = 0.5
    powdery_mildew_susceptibility: float = 0.5
    botrytis_susceptibility: float = 0.5

    # --- Yield potential -----------------------------------------------
    clusters_per_vine_mean: float = 14.0
    berries_per_cluster_mean: float = 90.0
    berry_weight_g_mean: float = 1.3

    # --- Ripening chemistry characteristics -----------------------------
    sugar_accumulation_rate: float = 1.0   # relative multiplier vs. reference variety
    base_acid_retention: float = 1.0       # relative multiplier - higher retains more acid at a given heat sum
    aromatic_potential: float = 0.6        # 0-1 - propensity for aromatic secondary metabolite development
    phenolic_potential: float = 0.4        # 0-1 - relevant mostly for reds/rosé and skin-contact whites

    suitability_sparkling: float = 0.5     # 0-1 suitability score
    suitability_still: float = 0.5

    notes: str = ""


VARIETY_LIBRARY: Dict[str, VarietyData] = {}


def register_variety(v: VarietyData) -> None:
    VARIETY_LIBRARY[v.key] = v


def get_variety(key: str) -> VarietyData:
    try:
        return VARIETY_LIBRARY[key]
    except KeyError as e:
        raise KeyError(f"Unknown variety '{key}'. Registered: {sorted(VARIETY_LIBRARY)}") from e


# ---------------------------------------------------------------------------
# Seed varieties commonly relevant to English wine production
# ---------------------------------------------------------------------------
for _v in [
    VarietyData(
        key="chardonnay", name="Chardonnay", colour="white",
        gdd_budbreak=620, gdd_flowering=150, gdd_veraison=680, gdd_full_ripeness=860,
        frost_sensitivity=0.55, downy_mildew_susceptibility=0.5, powdery_mildew_susceptibility=0.55,
        botrytis_susceptibility=0.45, clusters_per_vine_mean=15, berries_per_cluster_mean=95,
        berry_weight_g_mean=1.35, sugar_accumulation_rate=1.05, base_acid_retention=1.1,
        aromatic_potential=0.45, phenolic_potential=0.25,
        suitability_sparkling=0.95, suitability_still=0.8,
        notes="Backbone of English traditional-method sparkling; also fine still wine on warmer sites.",
    ),
    VarietyData(
        key="pinot_noir", name="Pinot Noir", colour="black",
        gdd_budbreak=600, gdd_flowering=145, gdd_veraison=660, gdd_full_ripeness=840,
        frost_sensitivity=0.6, downy_mildew_susceptibility=0.55, powdery_mildew_susceptibility=0.6,
        botrytis_susceptibility=0.65, clusters_per_vine_mean=13, berries_per_cluster_mean=85,
        berry_weight_g_mean=1.2, sugar_accumulation_rate=1.0, base_acid_retention=1.0,
        aromatic_potential=0.55, phenolic_potential=0.6,
        suitability_sparkling=0.9, suitability_still=0.55,
        notes="Key sparkling/rosé variety; thin skin makes it botrytis-prone in wet English autumns.",
    ),
    VarietyData(
        key="pinot_meunier", name="Pinot Meunier", colour="black",
        gdd_budbreak=580, gdd_flowering=140, gdd_veraison=630, gdd_full_ripeness=800,
        frost_sensitivity=0.5, downy_mildew_susceptibility=0.5, powdery_mildew_susceptibility=0.5,
        botrytis_susceptibility=0.55, clusters_per_vine_mean=14, berries_per_cluster_mean=88,
        berry_weight_g_mean=1.25, sugar_accumulation_rate=1.0, base_acid_retention=0.95,
        aromatic_potential=0.5, phenolic_potential=0.5,
        suitability_sparkling=0.85, suitability_still=0.45,
        notes="More frost-tolerant and reliable-cropping than Pinot Noir; classic Champagne-style blend component.",
    ),
    VarietyData(
        key="bacchus", name="Bacchus", colour="white",
        gdd_budbreak=560, gdd_flowering=130, gdd_veraison=560, gdd_full_ripeness=700,
        frost_sensitivity=0.45, downy_mildew_susceptibility=0.6, powdery_mildew_susceptibility=0.45,
        botrytis_susceptibility=0.5, clusters_per_vine_mean=16, berries_per_cluster_mean=90,
        berry_weight_g_mean=1.4, sugar_accumulation_rate=1.1, base_acid_retention=0.85,
        aromatic_potential=0.9, phenolic_potential=0.2,
        suitability_sparkling=0.2, suitability_still=0.95,
        notes="England's signature aromatic still white; ripens relatively early and reliably.",
    ),
    VarietyData(
        key="ortega", name="Ortega", colour="white",
        gdd_budbreak=520, gdd_flowering=120, gdd_veraison=480, gdd_full_ripeness=600,
        frost_sensitivity=0.4, downy_mildew_susceptibility=0.55, powdery_mildew_susceptibility=0.5,
        botrytis_susceptibility=0.6, clusters_per_vine_mean=15, berries_per_cluster_mean=95,
        berry_weight_g_mean=1.5, sugar_accumulation_rate=1.2, base_acid_retention=0.75,
        aromatic_potential=0.7, phenolic_potential=0.2,
        suitability_sparkling=0.15, suitability_still=0.85,
        notes="Very early-ripening, high-sugar variety bred for marginal cool climates; low acid retention.",
    ),
    VarietyData(
        key="seyval_blanc", name="Seyval Blanc", colour="white", species="hybrid",
        gdd_budbreak=580, gdd_flowering=145, gdd_veraison=610, gdd_full_ripeness=760,
        frost_sensitivity=0.35, downy_mildew_susceptibility=0.3, powdery_mildew_susceptibility=0.3,
        botrytis_susceptibility=0.35, clusters_per_vine_mean=17, berries_per_cluster_mean=100,
        berry_weight_g_mean=1.3, sugar_accumulation_rate=0.95, base_acid_retention=1.15,
        aromatic_potential=0.4, phenolic_potential=0.2,
        suitability_sparkling=0.55, suitability_still=0.7,
        notes="Hybrid with strong disease resistance and reliable cropping; high natural acidity.",
    ),
    VarietyData(
        key="pinot_precoce", name="Pinot Précoce (Frühburgunder)", colour="black",
        gdd_budbreak=560, gdd_flowering=135, gdd_veraison=560, gdd_full_ripeness=740,
        frost_sensitivity=0.55, downy_mildew_susceptibility=0.5, powdery_mildew_susceptibility=0.55,
        botrytis_susceptibility=0.6, clusters_per_vine_mean=13, berries_per_cluster_mean=85,
        berry_weight_g_mean=1.2, sugar_accumulation_rate=1.1, base_acid_retention=0.95,
        aromatic_potential=0.5, phenolic_potential=0.55,
        suitability_sparkling=0.5, suitability_still=0.75,
        notes="Early-ripening Pinot Noir mutation; a realistic still-red option in the warmest English sites.",
    ),
    VarietyData(
        key="auxerrois", name="Auxerrois", colour="white",
        gdd_budbreak=600, gdd_flowering=145, gdd_veraison=620, gdd_full_ripeness=780,
        frost_sensitivity=0.5, downy_mildew_susceptibility=0.5, powdery_mildew_susceptibility=0.5,
        botrytis_susceptibility=0.5, clusters_per_vine_mean=14, berries_per_cluster_mean=90,
        berry_weight_g_mean=1.35, sugar_accumulation_rate=1.05, base_acid_retention=0.95,
        aromatic_potential=0.5, phenolic_potential=0.2,
        suitability_sparkling=0.5, suitability_still=0.8,
        notes="Soft, low-acid still white, often blended; related to Pinot family.",
    ),
]:
    register_variety(_v)


@dataclass(frozen=True)
class RootstockData:
    key: str
    name: str
    vigour: float = 1.0                # relative multiplier, 1.0 = moderate
    drought_tolerance: float = 0.5      # 0-1
    lime_tolerance: float = 0.5         # 0-1, important on English chalk soils
    nutrient_uptake: float = 1.0        # relative multiplier
    disease_resistance: float = 0.5     # 0-1, phylloxera/nematode etc.
    yield_influence: float = 1.0        # relative multiplier on yield potential
    notes: str = ""


ROOTSTOCK_LIBRARY: Dict[str, RootstockData] = {}


def register_rootstock(r: RootstockData) -> None:
    ROOTSTOCK_LIBRARY[r.key] = r


def get_rootstock(key: str) -> RootstockData:
    try:
        return ROOTSTOCK_LIBRARY[key]
    except KeyError as e:
        raise KeyError(f"Unknown rootstock '{key}'. Registered: {sorted(ROOTSTOCK_LIBRARY)}") from e


for _r in [
    RootstockData("101-14", "101-14 Mgt", vigour=0.85, drought_tolerance=0.35, lime_tolerance=0.4,
                   nutrient_uptake=0.9, disease_resistance=0.6, yield_influence=0.9,
                   notes="Low-moderate vigour, good for wet English soils; poor drought/lime tolerance."),
    RootstockData("3309C", "3309 Couderc", vigour=0.95, drought_tolerance=0.45, lime_tolerance=0.45,
                   nutrient_uptake=0.95, disease_resistance=0.6, yield_influence=1.0,
                   notes="Widely planted moderate-vigour rootstock, good on well-drained soils."),
    RootstockData("SO4", "SO4", vigour=1.1, drought_tolerance=0.5, lime_tolerance=0.65,
                   nutrient_uptake=1.1, disease_resistance=0.65, yield_influence=1.1,
                   notes="Higher vigour, good lime tolerance suited to English chalk."),
    RootstockData("5BB", "5BB Kober", vigour=1.15, drought_tolerance=0.4, lime_tolerance=0.75,
                   nutrient_uptake=1.1, disease_resistance=0.6, yield_influence=1.1,
                   notes="Strong lime tolerance for chalk/limestone blocks; higher vigour needs canopy management."),
    RootstockData("Riparia Gloire", "Riparia Gloire de Montpellier", vigour=0.7, drought_tolerance=0.25,
                   lime_tolerance=0.25, nutrient_uptake=0.85, disease_resistance=0.55, yield_influence=0.85,
                   notes="Low vigour, early ripening influence; poor drought/lime tolerance."),
    RootstockData("own_root", "Own-Rooted / Ungrafted", vigour=1.0, drought_tolerance=0.5, lime_tolerance=0.5,
                   nutrient_uptake=1.0, disease_resistance=0.2, yield_influence=1.0,
                   notes="No rootstock (occasionally used experimentally); no phylloxera resistance."),
]:
    register_rootstock(_r)
