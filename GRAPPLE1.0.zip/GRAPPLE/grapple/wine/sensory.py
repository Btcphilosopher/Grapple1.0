"""
grapple.wine.sensory
=======================

Simulated sensory panel (Section 35). Scores are explicitly MODELLED
SENSORY ESTIMATES (Section 77) derived from wine composition and process
context — never presented as objective, laboratory-measured fact.
A small amount of "panel variance" (independent Gaussian noise per virtual
judge) is included deliberately, echoing the real spread you'd see across
a genuine tasting panel.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional

import numpy as np

from grapple.wine.composition import WineComposition


@dataclass
class SensoryScores:
    # Appearance
    colour: float = 0.0
    clarity: float = 0.0
    # Aroma (0-10 intensity each)
    aroma_fruit: float = 0.0
    aroma_floral: float = 0.0
    aroma_herbal: float = 0.0
    aroma_mineral: float = 0.0
    aroma_oak: float = 0.0
    aroma_fermentation_derived: float = 0.0
    # Palate (0-10)
    palate_acidity: float = 0.0
    palate_sweetness: float = 0.0
    palate_alcohol: float = 0.0
    palate_body: float = 0.0
    palate_bitterness: float = 0.0
    palate_tannin: float = 0.0
    palate_finish: float = 0.0
    # Overall (0-100)
    balance: float = 0.0
    complexity: float = 0.0
    typicity: float = 0.0
    ageing_potential: float = 0.0
    is_modelled_estimate: bool = True


def _clip10(x: float) -> float:
    return round(max(0.0, min(10.0, x)), 2)


def generate_sensory_panel(
    comp: WineComposition,
    variety_aromatic_potential: float,
    variety_phenolic_potential: float,
    is_sparkling: bool,
    rng: Optional[np.random.Generator] = None,
    panel_noise_sd: float = 0.35,
) -> SensoryScores:
    rng = rng or np.random.default_rng()

    def noisy(x: float) -> float:
        return x + rng.normal(0, panel_noise_sd)

    s = SensoryScores()
    s.clarity = _clip10(noisy(10 - comp.turbidity_ntu / 40.0))
    s.colour = _clip10(noisy(comp.colour_intensity * 10))

    s.aroma_fruit = _clip10(noisy(6.0 + 3.0 * comp.aroma_compounds.get("fruit", 0.4)))
    s.aroma_floral = _clip10(noisy(4.0 + 5.0 * comp.aroma_compounds.get("floral", 0.2) * variety_aromatic_potential))
    s.aroma_herbal = _clip10(noisy(2.5 + 3.0 * comp.aroma_compounds.get("herbal", 0.15)))
    s.aroma_mineral = _clip10(noisy(3.5 + 2.5 * (1 - comp.residual_sugar_gl / 40.0)))
    s.aroma_oak = _clip10(noisy(10.0 * comp.aroma_compounds.get("oak", 0.0)))
    s.aroma_fermentation_derived = _clip10(noisy(3.0 + 6.0 * comp.aroma_compounds.get("autolytic_brioche", 0.0)
                                                  + 4.0 * comp.aroma_compounds.get("complex", 0.0)))

    s.palate_acidity = _clip10(noisy(2.0 + comp.ta_gl * 0.7))
    s.palate_sweetness = _clip10(noisy(comp.residual_sugar_gl / 6.0))
    s.palate_alcohol = _clip10(noisy(comp.ethanol_pct * 0.7))
    s.palate_body = _clip10(noisy(3.0 + comp.ethanol_pct * 0.35 + comp.phenolics_index * 3.0))
    s.palate_bitterness = _clip10(noisy(1.5 + comp.tannins_index * 4.0))
    s.palate_tannin = _clip10(noisy(comp.tannins_index * 10))
    finish_base = 4.0 + (comp.phenolics_index * 3.0) + (1.5 if is_sparkling else 0.0)
    s.palate_finish = _clip10(noisy(finish_base))

    acid_sugar_harmony = max(0.0, 10 - abs((comp.ta_gl - comp.residual_sugar_gl / 8) - 5))
    va_penalty = max(0.0, comp.volatile_acidity_gl - 0.6) * 15
    s.balance = round(max(0.0, min(100.0, noisy(55 + acid_sugar_harmony * 3.5 - va_penalty))), 1)

    aroma_sum = (s.aroma_fruit + s.aroma_floral + s.aroma_herbal + s.aroma_mineral
                 + s.aroma_oak + s.aroma_fermentation_derived)
    s.complexity = round(max(0.0, min(100.0, noisy(aroma_sum * 1.6))), 1)
    s.typicity = round(max(0.0, min(100.0, noisy(60 + 30 * variety_aromatic_potential - va_penalty))), 1)
    s.ageing_potential = round(max(0.0, min(100.0, noisy(
        40 + comp.ta_gl * 2.5 + comp.phenolics_index * 20 + (10 if is_sparkling else 0) - va_penalty * 2
    ))), 1)

    return s
