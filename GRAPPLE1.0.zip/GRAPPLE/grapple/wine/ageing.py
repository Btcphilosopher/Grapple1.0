"""
grapple.wine.ageing
======================

Post-bottling ageing digital twin (Section 38). Projects composition and
sensory drift over standard horizons (6mo/1/3/5/10/20yr) with explicitly
widening uncertainty — GRAPPLE never claims to know a wine's exact future
sensory profile (Section 77/43).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from grapple.wine.composition import WineComposition
from grapple.winery.bottling import ClosureType

_CLOSURE_ANNUAL_O2_MG_L = {
    ClosureType.SCREWCAP: 0.4, ClosureType.CROWN_CAP: 0.3,
    ClosureType.CORK_TECHNICAL: 1.0, ClosureType.CORK_NATURAL: 1.8,
}

HORIZONS_MONTHS = [6, 12, 36, 60, 120, 240]


@dataclass
class AgeingProjection:
    horizon_months: int
    predicted_colour_intensity: float
    predicted_colour_uncertainty: float
    predicted_fruit_intensity_pct: float
    predicted_fruit_uncertainty_pct: float
    predicted_tertiary_development_pct: float
    predicted_tertiary_uncertainty_pct: float
    predicted_acidity_perception: float
    predicted_quality_trajectory_pct: float
    predicted_quality_uncertainty_pct: float


def project_ageing(
    comp: WineComposition, closure: ClosureType, current_quality_pct: float, horizons_months: List[int] | None = None,
) -> List[AgeingProjection]:
    horizons_months = horizons_months or HORIZONS_MONTHS
    annual_o2 = _CLOSURE_ANNUAL_O2_MG_L[closure]

    out: List[AgeingProjection] = []
    for months in horizons_months:
        years = months / 12.0
        cumulative_o2 = annual_o2 * years

        colour = min(1.0, comp.colour_intensity + 0.03 * cumulative_o2)
        colour_uncertainty = 0.02 + 0.015 * years   # widens with horizon (Section 43)

        fruit_decay = max(0.05, 1.0 - 0.10 * years)   # primary fruit fades over the decades
        tertiary_rise = min(0.95, 0.06 * years)       # tertiary/developed character rises

        # Quality trajectory: a simple, transparent "rise then plateau then slow decline" heuristic,
        # modulated by the wine's acid/phenolic stability (higher TA/phenolics -> longer plateau).
        stability_years = 3 + comp.ta_gl * 0.4 + comp.phenolics_index * 6
        if years <= stability_years * 0.4:
            trajectory = current_quality_pct * (1 + 0.03 * years)
        elif years <= stability_years:
            trajectory = current_quality_pct * 1.05
        else:
            decline_years = years - stability_years
            trajectory = current_quality_pct * 1.05 * max(0.4, 1 - 0.04 * decline_years)

        uncertainty_pct = 3.0 + 2.2 * years   # grows with horizon — never false precision at 20 years

        out.append(AgeingProjection(
            horizon_months=months,
            predicted_colour_intensity=round(colour, 3), predicted_colour_uncertainty=round(colour_uncertainty, 3),
            predicted_fruit_intensity_pct=round(fruit_decay * 100, 1),
            predicted_fruit_uncertainty_pct=round(5 + 3 * years, 1),
            predicted_tertiary_development_pct=round(tertiary_rise * 100, 1),
            predicted_tertiary_uncertainty_pct=round(4 + 2.5 * years, 1),
            predicted_acidity_perception=round(max(0.0, comp.ta_gl - 0.05 * years), 2),
            predicted_quality_trajectory_pct=round(max(0.0, min(100.0, trajectory)), 1),
            predicted_quality_uncertainty_pct=round(min(35.0, uncertainty_pct), 1),
        ))
    return out
