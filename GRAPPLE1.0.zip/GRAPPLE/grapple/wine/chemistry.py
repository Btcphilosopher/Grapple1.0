"""
grapple.wine.chemistry
=========================

Supporting wine-chemistry equations (Section 29): SO2 equilibrium, VA
formation risk under oxidative/microbial stress, and oxidative colour/
phenolic drift. These are simplified, transparent relationships
(Section 77) intended for digital-twin decision support, not a substitute
for laboratory analysis.
"""
from __future__ import annotations

import math

from grapple.wine.composition import WineComposition


def molecular_so2_mg_l(free_so2_mg_l: float, ph: float) -> float:
    """
    Fraction of free SO2 in the active molecular (antimicrobial) form,
    from the Henderson-Hasselbalch relationship with SO2's pKa ~1.81.
    """
    pka = 1.81
    fraction_molecular = 1.0 / (1.0 + 10 ** (ph - pka))
    return round(free_so2_mg_l * fraction_molecular, 2)


def so2_consumption_mg_l_per_day(dissolved_oxygen_mg_l: float, temperature_c: float) -> float:
    """SO2 is consumed protecting the wine from dissolved oxygen; ~4mg SO2 binds 1mg O2, faster when warm."""
    temp_factor = max(0.3, min(2.0, temperature_c / 15.0))
    return round(dissolved_oxygen_mg_l * 4.0 * temp_factor, 2)


def apply_so2_consumption(comp: WineComposition, temperature_c: float) -> None:
    consumption = so2_consumption_mg_l_per_day(comp.dissolved_oxygen_mg_l, temperature_c)
    comp.free_so2_mg_l = max(0.0, comp.free_so2_mg_l - consumption)
    comp.dissolved_oxygen_mg_l = max(0.0, comp.dissolved_oxygen_mg_l * 0.3)  # O2 scavenged rapidly once introduced


def va_formation_risk(comp: WineComposition, temperature_c: float) -> float:
    """0-1 daily risk of a meaningful VA increase, elevated by low free SO2, warmth and dissolved oxygen."""
    so2_protection = max(0.0, 1.0 - molecular_so2_mg_l(comp.free_so2_mg_l, comp.ph) / 0.8)
    temp_term = max(0.0, (temperature_c - 12) / 15)
    o2_term = min(1.0, comp.dissolved_oxygen_mg_l / 3.0)
    return max(0.0, min(1.0, 0.5 * so2_protection * temp_term + 0.5 * o2_term * so2_protection))


def apply_oxidative_drift(comp: WineComposition, oxygen_exposure_mg_l: float) -> None:
    """Colour deepens (or browns) and phenolics slowly polymerise/precipitate with cumulative O2 exposure."""
    comp.dissolved_oxygen_mg_l += oxygen_exposure_mg_l
    comp.colour_intensity = min(1.0, comp.colour_intensity + 0.002 * oxygen_exposure_mg_l)
    comp.phenolics_index = max(0.0, comp.phenolics_index - 0.0015 * oxygen_exposure_mg_l)
