"""
grapple.wine.quality
=======================

Multi-variable, transparent wine quality model (Section 36). Produces a
component breakdown (Grape Quality / Fermentation / Balance / Aromatic
Potential / Stability -> Overall) with an `explain()` output showing
exactly which drivers moved the score, rather than an opaque black box.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

from grapple.wine.composition import WineComposition
from grapple.wine.sensory import SensoryScores
from grapple.winery.fermentation import FermentationBatch, FermentationStatus


@dataclass
class QualityScore:
    grape_quality: float
    fermentation: float
    balance: float
    aromatic_potential: float
    stability: float
    overall: float
    drivers: Dict[str, float] = field(default_factory=dict)


def score_grape_quality(harvest_readiness_pct: float, disease_risk_index: float, quality_score_at_reception: float) -> float:
    base = 0.5 * harvest_readiness_pct + 0.3 * quality_score_at_reception
    disease_penalty = disease_risk_index * 25.0
    return round(max(0.0, min(100.0, base - disease_penalty + 20)), 1)


def score_fermentation(batch: FermentationBatch) -> float:
    if batch.status == FermentationStatus.STUCK:
        return 35.0
    completeness = 1.0 - abs(batch.sugar_gl - (batch.starting_brix * 10.5 * (1 - batch.yeast_strain.attenuation))) / 50.0
    temp_control_quality = 1.0 if batch.cooling_capacity_adequate else 0.75
    score = 60 + 35 * max(0.0, min(1.0, completeness)) * temp_control_quality
    return round(max(0.0, min(100.0, score)), 1)


def score_balance(sensory: SensoryScores, comp: WineComposition) -> float:
    va_penalty = max(0.0, comp.volatile_acidity_gl - 0.6) * 20
    return round(max(0.0, min(100.0, sensory.balance - va_penalty * 0.3)), 1)


def score_aromatic_potential(sensory: SensoryScores) -> float:
    return round(max(0.0, min(100.0, 0.5 * sensory.complexity + 0.5 * sensory.typicity)), 1)


def score_stability(comp: WineComposition) -> float:
    so2_adequacy = min(1.0, comp.free_so2_mg_l / 25.0)
    va_risk = max(0.0, 1.0 - comp.volatile_acidity_gl / 1.2)
    o2_risk = max(0.0, 1.0 - comp.dissolved_oxygen_mg_l / 4.0)
    score = 100 * (0.4 * so2_adequacy + 0.35 * va_risk + 0.25 * o2_risk)
    return round(max(0.0, min(100.0, score)), 1)


def compute_quality(
    harvest_readiness_pct: float, disease_risk_index: float, quality_score_at_reception: float,
    batch: FermentationBatch, sensory: SensoryScores, comp: WineComposition,
    weights: Dict[str, float] | None = None,
) -> QualityScore:
    weights = weights or {"grape_quality": 0.25, "fermentation": 0.2, "balance": 0.25,
                           "aromatic_potential": 0.15, "stability": 0.15}

    gq = score_grape_quality(harvest_readiness_pct, disease_risk_index, quality_score_at_reception)
    fe = score_fermentation(batch)
    ba = score_balance(sensory, comp)
    ap = score_aromatic_potential(sensory)
    st = score_stability(comp)

    overall = (weights["grape_quality"] * gq + weights["fermentation"] * fe + weights["balance"] * ba
               + weights["aromatic_potential"] * ap + weights["stability"] * st)

    drivers = {
        "grape_quality_contribution": round(weights["grape_quality"] * gq, 2),
        "fermentation_contribution": round(weights["fermentation"] * fe, 2),
        "balance_contribution": round(weights["balance"] * ba, 2),
        "aromatic_potential_contribution": round(weights["aromatic_potential"] * ap, 2),
        "stability_contribution": round(weights["stability"] * st, 2),
    }

    return QualityScore(grape_quality=gq, fermentation=fe, balance=ba, aromatic_potential=ap, stability=st,
                         overall=round(overall, 1), drivers=drivers)
