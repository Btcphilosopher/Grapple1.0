"""
grapple.wine.composition
===========================

Wine composition digital twin (Section 29). `WineComposition` is the
mutable chemistry state carried by a winery batch from the end of
fermentation through maturation, blending, bottling and bottle ageing.
Every field here is a *simulation estimate* (Section 29/77), not a
laboratory-certified value — laboratory.chemistry adds realistic
measurement uncertainty on top when a "sample" is drawn.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict


@dataclass
class WineComposition:
    ethanol_pct: float = 0.0
    residual_sugar_gl: float = 0.0
    ph: float = 3.2
    ta_gl: float = 7.0
    malic_acid_gl: float = 2.0
    lactic_acid_gl: float = 0.0
    volatile_acidity_gl: float = 0.3       # acetic acid equivalent
    dissolved_oxygen_mg_l: float = 0.5
    free_so2_mg_l: float = 0.0
    total_so2_mg_l: float = 0.0
    colour_intensity: float = 0.1          # 0-1 relative index (whites low, reds high)
    phenolics_index: float = 0.1           # 0-1 relative index
    tannins_index: float = 0.0             # 0-1 relative index, reds/skin-contact only
    turbidity_ntu: float = 50.0
    aroma_compounds: Dict[str, float] = field(default_factory=dict)  # descriptor -> relative intensity 0-1

    def clone(self) -> "WineComposition":
        return WineComposition(
            ethanol_pct=self.ethanol_pct, residual_sugar_gl=self.residual_sugar_gl, ph=self.ph,
            ta_gl=self.ta_gl, malic_acid_gl=self.malic_acid_gl, lactic_acid_gl=self.lactic_acid_gl,
            volatile_acidity_gl=self.volatile_acidity_gl, dissolved_oxygen_mg_l=self.dissolved_oxygen_mg_l,
            free_so2_mg_l=self.free_so2_mg_l, total_so2_mg_l=self.total_so2_mg_l,
            colour_intensity=self.colour_intensity, phenolics_index=self.phenolics_index,
            tannins_index=self.tannins_index, turbidity_ntu=self.turbidity_ntu,
            aroma_compounds=dict(self.aroma_compounds),
        )


def blend_weighted(components: list[tuple[WineComposition, float]]) -> WineComposition:
    """Volume-weighted blend of N compositions. `components` is [(composition, volume_fraction), ...]."""
    total_w = sum(w for _, w in components) or 1.0
    out = WineComposition()
    numeric_fields = [
        "ethanol_pct", "residual_sugar_gl", "ph", "ta_gl", "malic_acid_gl", "lactic_acid_gl",
        "volatile_acidity_gl", "dissolved_oxygen_mg_l", "free_so2_mg_l", "total_so2_mg_l",
        "colour_intensity", "phenolics_index", "tannins_index", "turbidity_ntu",
    ]
    for f in numeric_fields:
        setattr(out, f, sum(getattr(c, f) * w for c, w in components) / total_w)

    aroma_keys = set()
    for c, _ in components:
        aroma_keys |= set(c.aroma_compounds)
    out.aroma_compounds = {
        k: sum(c.aroma_compounds.get(k, 0.0) * w for c, w in components) / total_w for k in aroma_keys
    }
    return out
