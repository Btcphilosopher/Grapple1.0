"""
grapple.main
==============

GRAPPLE 1.0 entry point.

  python -m grapple.main                    # start the FastAPI server
  python -m grapple.main --console-vintage   # run the first-run console experience (Section 75)
"""
from __future__ import annotations

import argparse
import sys

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from grapple.api.routes import context, router
from grapple.api.websocket import simulation_websocket
from grapple.config import settings

app = FastAPI(title=settings.app_name, description="English Vineyard & Winery Digital Twin")

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.include_router(router)
app.add_api_websocket_route("/ws/simulation", simulation_websocket)


@app.get("/")
def root():
    return {"app": settings.app_name, "status": "ok", "docs": "/docs"}


def run_console_vintage(vintage_year: int = 2031, seed: int = 20310817) -> None:
    """
    The first-run experience (Section 75): load the seed English estate,
    run a full vintage day by day, and narrate the lifecycle to the
    console — vineyard through to a completed VintageReport.
    """
    from grapple.data.seed_estate import build_wessex_crown_simulation
    from grapple.ui.estate import render_main_dashboard
    from grapple.ui.harvest import render_vintage_report

    print(f"\n{'=' * 60}\nGRAPPLE 1.0 — {settings.app_name}\nEnglish Vineyard & Winery Digital Twin\n{'=' * 60}\n")
    print("Loading Wessex Crown Vineyard (Southern England, 48.6ha, synthetic seed estate)...")
    sim = build_wessex_crown_simulation(vintage_year, seed=seed)
    context.sim = sim
    print(f"Estate loaded: {sim.state.estate.summary()}\n")

    import datetime as _dt
    from grapple.core.simulation import build_vintage_report

    last_month = None
    outcomes = []
    target = _dt.date(vintage_year, 12, 31)
    while sim.state.clock.current_date < target:
        today = sim.state.clock.current_date
        sim.step_day()

        # Same simple default harvest-fallback policy as VintageSimulation.run_vintage().
        for block in sim.state.estate.blocks.values():
            if block.harvested or block.phenology.stage.value not in ("Veraison", "Ripening"):
                continue
            readiness = sim.harvest_readiness(block.block_id, "traditional_sparkling")
            if readiness.overall_readiness_pct >= 55.0 or today >= _dt.date(today.year, 11, 15):
                outcome = sim.harvest_block(block.block_id)
                outcomes.append(outcome)
                print(f"  -> Harvested {block.name} on {today.isoformat()}: "
                      f"{outcome.tonnes:.1f}t, {outcome.juice_l:.0f}L juice"
                      + (f" -> fermentation {outcome.fermentation_batch_id}" if outcome.fermentation_batch_id
                         else f" (refused: {outcome.refused_reason})"))

        if today.month != last_month:
            last_month = today.month
            print(render_main_dashboard(sim.state))

    report = build_vintage_report(sim, outcomes)
    print(render_vintage_report(report))


def main() -> None:
    parser = argparse.ArgumentParser(description="GRAPPLE 1.0 — English Vineyard & Winery Digital Twin")
    parser.add_argument("--console-vintage", action="store_true", help="Run the first-run console vintage narration")
    parser.add_argument("--vintage-year", type=int, default=2031)
    parser.add_argument("--seed", type=int, default=20310817)
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()

    if args.console_vintage:
        run_console_vintage(args.vintage_year, args.seed)
        return

    import uvicorn
    uvicorn.run(app, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
