import numpy as np

from grapple.winery.fermentation import FermentationStatus, new_batch, run_to_completion
from grapple.winery.juice import JuiceLot
from grapple.winery.yeast import instantiate_strain


def _sample_juice(brix=19.0, yan=200.0):
    return JuiceLot(juice_lot_id="JL-TEST", harvest_lot_id="HL-TEST", press_id="P-TEST", fraction_name="free_run",
                     volume_l=1000.0, brix=brix, ph=3.1, ta_gl=8.5, malic_acid_gl=5.5, yan_mg_l=yan,
                     turbidity_ntu=100.0, temperature_c=15.0, dissolved_oxygen_mg_l=3.0)


def test_fermentation_consumes_sugar_and_produces_ethanol():
    rng = np.random.default_rng(1)
    strain = instantiate_strain("ec1118", rng)
    batch = new_batch(_sample_juice(), "T1", strain, temperature_target_c=17.0)
    run_to_completion(batch, rng)
    assert batch.ethanol_pct > 5.0
    assert batch.sugar_gl < batch.starting_brix * 10.5
    assert batch.status in (FermentationStatus.COMPLETE, FermentationStatus.STUCK)


def test_fermentation_mass_balance_sugar_never_negative():
    rng = np.random.default_rng(2)
    strain = instantiate_strain("ec1118", rng)
    batch = new_batch(_sample_juice(), "T1", strain)
    run_to_completion(batch, rng, max_days=60)
    assert batch.sugar_gl >= 0.0
    assert all(s.sugar_gl >= 0.0 for s in batch.history)


def test_low_yan_increases_stuck_risk():
    stuck_count_low_yan = 0
    stuck_count_high_yan = 0
    trials = 12
    for seed in range(trials):
        rng = np.random.default_rng(seed)
        strain = instantiate_strain("native", rng)  # highest stress sensitivity
        low = new_batch(_sample_juice(yan=25.0), "T1", strain)
        run_to_completion(low, rng, max_days=45)
        if low.status == FermentationStatus.STUCK:
            stuck_count_low_yan += 1

        rng2 = np.random.default_rng(seed)
        strain2 = instantiate_strain("native", rng2)
        high = new_batch(_sample_juice(yan=350.0), "T1", strain2)
        run_to_completion(high, rng2, max_days=45)
        if high.status == FermentationStatus.STUCK:
            stuck_count_high_yan += 1

    assert stuck_count_low_yan >= stuck_count_high_yan


def test_fermentation_curve_history_is_monotonic_in_days():
    rng = np.random.default_rng(3)
    strain = instantiate_strain("ec1118", rng)
    batch = new_batch(_sample_juice(), "T1", strain)
    run_to_completion(batch, rng)
    days = [s.day for s in batch.history]
    assert days == sorted(days)
    assert days == list(range(1, len(days) + 1))
