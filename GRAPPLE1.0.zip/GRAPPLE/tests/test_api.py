import pytest
from fastapi.testclient import TestClient

from grapple.main import app


@pytest.fixture
def client():
    return TestClient(app)


def test_requires_simulation_before_estate_query(client):
    # Reset module-level context so this test is independent of ordering.
    from grapple.api.routes import context
    context.sim = None
    r = client.get("/estate")
    assert r.status_code == 409


def test_start_and_query_estate(client):
    r = client.post("/simulation/start", json={"vintage_year": 2031, "seed": 1, "use_seed_estate": True})
    assert r.status_code == 200
    r = client.get("/estate")
    assert r.status_code == 200
    body = r.json()
    assert body["name"] == "Wessex Crown Vineyard"
    assert body["block_count"] == 10


def test_step_advances_date(client):
    client.post("/simulation/start", json={"vintage_year": 2031, "seed": 1})
    r1 = client.post("/simulation/step", json={"days": 5})
    date1 = r1.json()["state"]["date"]
    r2 = client.post("/simulation/step", json={"days": 5})
    date2 = r2.json()["state"]["date"]
    assert date2 > date1


def test_block_detail_endpoint(client):
    client.post("/simulation/start", json={"vintage_year": 2031, "seed": 1})
    r = client.get("/blocks/B01")
    assert r.status_code == 200
    assert r.json()["block_id"] == "B01"

    r404 = client.get("/blocks/NOPE")
    assert r404.status_code == 404


def test_harvest_readiness_endpoint(client):
    client.post("/simulation/start", json={"vintage_year": 2031, "seed": 1})
    client.post("/simulation/step", json={"days": 250})
    r = client.get("/harvest/readiness", params={"block_id": "B01", "style_key": "traditional_sparkling"})
    assert r.status_code == 200
    body = r.json()
    assert "overall_readiness_pct" in body


def test_scenario_run_does_not_disturb_live_simulation(client):
    client.post("/simulation/start", json={"vintage_year": 2031, "seed": 1})
    client.post("/simulation/step", json={"days": 100})
    live_before = client.get("/vineyard/state").json()["date"]

    r = client.post("/scenario/run", json={"days_forward": 10})
    assert r.status_code == 200
    assert r.json()["scenario"]["date"] != live_before  # shadow advanced

    live_after = client.get("/vineyard/state").json()["date"]
    assert live_after == live_before  # live simulation untouched


def test_alerts_endpoint_returns_list(client):
    client.post("/simulation/start", json={"vintage_year": 2031, "seed": 1})
    client.post("/simulation/step", json={"days": 30})
    r = client.get("/alerts")
    assert r.status_code == 200
    assert isinstance(r.json(), list)
