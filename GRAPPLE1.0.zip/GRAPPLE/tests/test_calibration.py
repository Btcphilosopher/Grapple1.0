from grapple.digital_twin.calibration import CalibrationEngine, ScalarKalmanFilter, fit_linear_calibration


def test_kalman_filter_converges_toward_consistent_bias():
    kf = ScalarKalmanFilter(process_variance=0.001, initial_variance=5.0)
    for _ in range(20):
        kf.update(measured_bias=0.5, measurement_variance=0.05)
    assert abs(kf.estimate - 0.5) < 0.1
    assert kf.variance < 5.0


def test_kalman_filter_uncertainty_shrinks_with_observations():
    kf = ScalarKalmanFilter()
    initial_variance = kf.variance
    for _ in range(10):
        kf.update(0.2, 0.1)
    assert kf.variance < initial_variance


def test_linear_calibration_recovers_known_relationship():
    predicted = [10.0, 12.0, 14.0, 16.0, 18.0]
    observed = [9.5, 11.6, 13.4, 15.7, 17.6]  # observed ~= predicted - 0.4ish, close to 1:1
    calib = fit_linear_calibration(predicted, observed)
    assert calib is not None
    assert calib.r_squared > 0.9
    assert 0.8 < calib.slope < 1.2


def test_calibration_engine_produces_bias_corrected_prediction():
    engine = CalibrationEngine()
    for i in range(5):
        engine.record("brix", predicted=18.0, observed=17.7, date=f"2031-09-{10+i}")
    result = engine.calibrated_prediction("brix", raw_prediction=19.0)
    assert result["n_observations"] == 5
    assert result["calibrated_value"] < 19.0  # model has been running slightly high, correction pulls it down
