from grapple.optimisation.monte_carlo import run_monte_carlo
from grapple.vineyard.blocks import Block
from grapple.vineyard.estate import Estate


def _factory():
    estate = Estate(name="MC Estate", region="Test")
    estate.add_block(Block(block_id="B01", name="B1", area_ha=1.0, latitude=51.0, longitude=-0.4,
                            elevation_m=70, variety_key="bacchus", soil_key="chalk"))
    return estate


def test_monte_carlo_reproducible_with_same_seed():
    a = run_monte_carlo(_factory, 2031, n_trials=5, master_seed=777)
    b = run_monte_carlo(_factory, 2031, n_trials=5, master_seed=777)
    assert [t.seed for t in a.trials] == [t.seed for t in b.trials]
    assert [t.total_tonnes for t in a.trials] == [t.total_tonnes for t in b.trials]


def test_monte_carlo_different_seeds_vary():
    a = run_monte_carlo(_factory, 2031, n_trials=5, master_seed=1)
    b = run_monte_carlo(_factory, 2031, n_trials=5, master_seed=2)
    assert [t.seed for t in a.trials] != [t.seed for t in b.trials]


def test_monte_carlo_summary_has_percentiles():
    result = run_monte_carlo(_factory, 2031, n_trials=8, master_seed=42)
    dist = result.distribution("average_brix")
    assert dist["p5"] <= dist["p50"] <= dist["p95"]
