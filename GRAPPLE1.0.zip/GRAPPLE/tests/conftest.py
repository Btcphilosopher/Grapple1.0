from __future__ import annotations

import datetime as dt

import numpy as np
import pytest

from grapple.core.simulation import VintageSimulation
from grapple.equipment.tanks import new_tank
from grapple.vineyard.blocks import Block
from grapple.vineyard.estate import Estate


@pytest.fixture
def rng():
    return np.random.default_rng(1234)


@pytest.fixture
def single_block_estate():
    estate = Estate(name="Test Estate", region="Test Region")
    block = Block(
        block_id="B01", name="Test Block", area_ha=2.0, latitude=51.0, longitude=-0.4,
        elevation_m=70, variety_key="chardonnay", soil_key="chalk",
    )
    estate.add_block(block)
    return estate


@pytest.fixture
def simulation(single_block_estate):
    sim = VintageSimulation(single_block_estate, vintage_year=2031, seed=123)
    sim.state.cellar.add_tank(new_tank("T1", 15000))
    return sim


def run_to_stage(sim: VintageSimulation, block_id: str, stage_value: str, max_days: int = 365):
    block = sim.state.estate.get_block(block_id)
    for _ in range(max_days):
        if block.phenology.stage.value == stage_value:
            return sim
        sim.step_day()
    raise AssertionError(f"Block never reached stage {stage_value}")
