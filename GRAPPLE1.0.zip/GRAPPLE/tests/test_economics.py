from grapple.economics.capex import CapexItem, CapexRegister
from grapple.economics.costs import cost_per_bottle, vineyard_annual_cost
from grapple.economics.profitability import summarise_profitability
from grapple.economics.revenue import project_revenue
from grapple.economics.sustainability import SustainabilityInventory, sustainability_metrics


def test_vineyard_annual_cost_scales_with_area():
    small = vineyard_annual_cost(1.0)
    large = vineyard_annual_cost(10.0)
    assert abs(large.total - small.total * 10) < 1e-6


def test_capex_depreciation_reduces_book_value_over_time():
    reg = CapexRegister()
    reg.add(CapexItem("Tractor", "machinery", 60000.0, 2020, 10))
    assert reg.total_book_value(2020) == 60000.0
    assert reg.total_book_value(2025) == 30000.0
    assert reg.total_book_value(2035) == 0.0


def test_profitability_summary_computes_margins():
    revenue = [project_revenue("sparkling_brut", 10000)]
    capex = CapexRegister()
    capex.add(CapexItem("Winery", "winery_building", 500000.0, 2020, 25))
    summary = summarise_profitability(revenue, cost_of_goods_gbp=150000.0, operating_costs_gbp=80000.0, capex=capex)
    assert summary.gross_revenue_gbp == revenue[0].gross_revenue_gbp
    assert summary.gross_margin_gbp == summary.gross_revenue_gbp - 150000.0
    assert summary.operating_profit_gbp == summary.gross_margin_gbp - 80000.0


def test_cost_per_bottle_positive():
    assert cost_per_bottle(50000.0, 20000) > 0


def test_sustainability_metrics_per_bottle():
    inv = SustainabilityInventory(diesel_l=500, electricity_kwh=2000, glass_bottle_kg_total=4500,
                                   nitrogen_fertiliser_kg=200, cardboard_packaging_kg=300,
                                   road_transport_tonne_km=1000, water_l=280000, bottles_produced=10000)
    metrics = sustainability_metrics(inv)
    assert metrics["kg_co2e_per_bottle"] > 0
    assert metrics["litres_water_per_bottle"] == 28.0
