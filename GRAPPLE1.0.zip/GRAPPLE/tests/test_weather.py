import datetime as dt

import numpy as np

from grapple.weather.climate import get_scenario
from grapple.weather.frost import FrostProtectionMethod, assess_frost
from grapple.weather.rainfall import sample_rainfall_mm
from grapple.weather.weather import WeatherEngine
from grapple.data.weather import SOUTHERN_ENGLAND_NORMALS


def test_weather_engine_produces_plausible_ranges():
    engine = WeatherEngine(np.random.default_rng(1), scenario=get_scenario("average"))
    date = dt.date(2031, 1, 1)
    for _ in range(365):
        day = engine.step(date)
        assert -20.0 <= day.tmin_c <= 40.0
        assert day.tmin_c <= day.tmax_c + 0.01
        assert 0.0 <= day.rainfall_mm <= 200.0
        assert 0.0 <= day.humidity_pct <= 100.0
        assert day.solar_mj_m2 >= 0.0
        date += dt.timedelta(days=1)


def test_scenario_offsets_shift_temperature():
    warm = WeatherEngine(np.random.default_rng(2), scenario=get_scenario("warm"))
    cool = WeatherEngine(np.random.default_rng(2), scenario=get_scenario("cool"))
    date = dt.date(2031, 7, 1)
    warm_temps = [warm.step(date + dt.timedelta(days=i)).tmean_c for i in range(30)]
    cool_temps = [cool.step(date + dt.timedelta(days=i)).tmean_c for i in range(30)]
    assert sum(warm_temps) / len(warm_temps) > sum(cool_temps) / len(cool_temps)


def test_rainfall_wet_day_probability_matches_normal_approximately():
    normal = SOUTHERN_ENGLAND_NORMALS[10]  # October — wet month
    rng = np.random.default_rng(3)
    wet_days = 0
    n = 3000
    was_wet = False
    for _ in range(n):
        amount, is_wet = sample_rainfall_mm(normal, was_wet, rng)
        was_wet = is_wet
        wet_days += int(is_wet)
    empirical_p = wet_days / n
    expected_p = normal.rain_days / 31
    assert abs(empirical_p - expected_p) < 0.08


def test_frost_more_likely_on_clear_calm_cold_nights():
    rng = np.random.default_rng(4)
    clear_calm_cold = assess_frost(-1.0, cloud_cover_pct=5, wind_ms=0.5, humidity_pct=60,
                                    terrain_multiplier=1.0, rng=rng, frost_vulnerable_stage=True)
    cloudy_windy_mild = assess_frost(3.5, cloud_cover_pct=95, wind_ms=8.0, humidity_pct=90,
                                      terrain_multiplier=1.0, rng=rng, frost_vulnerable_stage=True)
    assert clear_calm_cold.frost_risk_probability > cloudy_windy_mild.frost_risk_probability


def test_frost_protection_reduces_damage():
    rng1 = np.random.default_rng(42)
    rng2 = np.random.default_rng(42)
    unprotected = assess_frost(-4.0, 5, 0.3, 50, terrain_multiplier=2.0, rng=rng1,
                                frost_vulnerable_stage=True, protection=FrostProtectionMethod.NONE)
    protected = assess_frost(-4.0, 5, 0.3, 50, terrain_multiplier=2.0, rng=rng2,
                              frost_vulnerable_stage=True, protection=FrostProtectionMethod.WIND_MACHINE)
    if unprotected.is_frost_event and protected.is_frost_event:
        assert protected.damage_pct <= unprotected.damage_pct
