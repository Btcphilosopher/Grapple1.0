from grapple.optimisation.blending import optimise_blend
from grapple.winery.blending import BlendComponent, build_blend
from grapple.wine.composition import WineComposition


def test_build_blend_weighted_average():
    a = BlendComponent("A", "Batch A", 1000, WineComposition(ethanol_pct=11.0, ph=3.0), cost_gbp_per_l=2.0)
    b = BlendComponent("B", "Batch B", 1000, WineComposition(ethanol_pct=13.0, ph=3.4), cost_gbp_per_l=3.0)
    plan = build_blend([a, b], [0.5, 0.5])
    assert abs(plan.predicted_composition.ethanol_pct - 12.0) < 1e-9
    assert abs(plan.predicted_cost_gbp_per_l - 2.5) < 1e-9


def test_optimise_blend_finds_fractions_summing_to_one():
    a = BlendComponent("A", "Batch A", 2000, WineComposition(ethanol_pct=11.0, ph=3.0, ta_gl=9.0))
    b = BlendComponent("B", "Batch B", 2000, WineComposition(ethanol_pct=13.5, ph=3.5, ta_gl=6.0))
    target = WineComposition(ethanol_pct=12.2, ph=3.2, ta_gl=7.5)
    result = optimise_blend([a, b], target)
    total = sum(result.fractions.values())
    assert abs(total - 1.0) < 1e-4
    assert all(0.0 <= f <= 1.0 for f in result.fractions.values())


def test_optimise_blend_improves_on_naive_average():
    a = BlendComponent("A", "Batch A", 2000, WineComposition(ethanol_pct=10.0, ph=2.9, ta_gl=10.0))
    b = BlendComponent("B", "Batch B", 2000, WineComposition(ethanol_pct=14.5, ph=3.6, ta_gl=5.0))
    target = WineComposition(ethanol_pct=10.5, ph=3.0, ta_gl=9.5)  # much closer to A than B
    result = optimise_blend([a, b], target)
    assert result.fractions["A"] > result.fractions["B"]
