from fastapi.testclient import TestClient

from grapple.main import app


def test_websocket_step_command_returns_snapshot():
    client = TestClient(app)
    client.post("/simulation/start", json={"vintage_year": 2031, "seed": 1, "use_seed_estate": True})

    with client.websocket_connect("/ws/simulation") as ws:
        initial = ws.receive_json()
        assert initial["type"] == "snapshot"

        ws.send_json({"cmd": "step", "days": 3})
        response = ws.receive_json()
        assert response["type"] == "snapshot"
        assert "data" in response
        assert "new_alerts" in response


def test_websocket_unknown_command_returns_error():
    client = TestClient(app)
    client.post("/simulation/start", json={"vintage_year": 2031, "seed": 1})

    with client.websocket_connect("/ws/simulation") as ws:
        ws.receive_json()  # initial snapshot
        ws.send_json({"cmd": "not_a_real_command"})
        response = ws.receive_json()
        assert response["type"] == "error"
