from grapple.winery.crushing import crush
from grapple.winery.destemming import DestemmingMode, apply_destemming
from grapple.winery.pressing import run_press


def test_press_yield_is_positive_and_bounded():
    destem = apply_destemming(DestemmingMode.WHOLE_CLUSTER)
    crushed = crush(1000.0, destem)
    result = run_press("P1", 1000.0, crushed, base_brix=19.0, base_ph=3.1, base_ta_gl=8.5)
    assert result.total_juice_l > 0
    # Typical juice yield is roughly 600-800 L/tonne for whole-cluster sparkling pressing.
    assert 400 < result.juice_yield_l_per_tonne < 900


def test_later_press_fractions_have_higher_turbidity():
    destem = apply_destemming(DestemmingMode.DESTEMMED)
    crushed = crush(1000.0, destem, gentle=False)
    result = run_press("P1", 1000.0, crushed, base_brix=19.0, base_ph=3.1, base_ta_gl=8.5)
    turbidities = [f.turbidity_ntu for f in result.fractions]
    assert turbidities == sorted(turbidities)


def test_whole_cluster_reduces_phenolic_extraction_vs_crushed():
    whole = apply_destemming(DestemmingMode.WHOLE_CLUSTER)
    destemmed = apply_destemming(DestemmingMode.DESTEMMED)
    crushed_whole = crush(1000.0, whole)
    crushed_destemmed = crush(1000.0, destemmed, gentle=False)
    assert crushed_whole.phenolic_extraction_index < crushed_destemmed.phenolic_extraction_index
