import datetime as dt
import math

from grapple.data.varieties import get_variety
from grapple.vineyard.phenology import PhenologyStage, PhenologyState, update_phenology


def test_phenology_reaches_budbreak_in_spring_not_january():
    variety = get_variety("chardonnay")
    state = PhenologyState()
    date = dt.date(2031, 1, 1)
    # Simulate a plausible warming spring using representative daily means.
    monthly_means = {1: 4.7, 2: 4.9, 3: 6.9, 4: 9.0, 5: 12.2}
    for day_offset in range(140):
        date = dt.date(2031, 1, 1) + dt.timedelta(days=day_offset)
        tmean = monthly_means.get(date.month, 12.0)
        update_phenology(state, variety, tmean, date)

    # Budbreak should have occurred by day ~140 (mid-May) and NOT still be in January-only dormancy.
    assert state.stage != PhenologyStage.DORMANCY
    assert state.stage_entered_date.get(PhenologyStage.BUDBREAK.value) is not None
    budbreak_date = state.stage_entered_date[PhenologyStage.BUDBREAK.value]
    assert dt.date(2031, 3, 15) <= budbreak_date <= dt.date(2031, 5, 31)


def test_phenology_stage_sequence_is_monotonic():
    variety = get_variety("bacchus")
    state = PhenologyState()
    order = [
        PhenologyStage.DORMANCY, PhenologyStage.BUDBREAK, PhenologyStage.SHOOT_GROWTH,
        PhenologyStage.FLOWERING, PhenologyStage.FRUIT_SET, PhenologyStage.BERRY_DEVELOPMENT,
        PhenologyStage.VERAISON, PhenologyStage.RIPENING,
    ]
    seen_indices = []
    date = dt.date(2031, 1, 1)
    for day_offset in range(300):
        date = dt.date(2031, 1, 1) + dt.timedelta(days=day_offset)
        tmean = 4 + 14 * max(0.0, math.sin((day_offset / 365) * math.pi))
        update_phenology(state, variety, tmean, date)
        if state.stage in order:
            idx = order.index(state.stage)
            if not seen_indices or idx >= seen_indices[-1]:
                seen_indices.append(idx)

    assert seen_indices == sorted(seen_indices)
    assert PhenologyStage.RIPENING in [order[i] for i in seen_indices]


def test_gdd_resets_on_new_year():
    variety = get_variety("chardonnay")
    state = PhenologyState()
    state.gdd_accumulated = 500.0
    state.spring_forcing_accumulated = 500.0
    state.stage = PhenologyStage.RIPENING
    update_phenology(state, variety, 5.0, dt.date(2032, 1, 1))
    assert state.stage == PhenologyStage.DORMANCY
    assert state.spring_forcing_accumulated < 500.0
