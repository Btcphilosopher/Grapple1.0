from grapple.data.varieties import get_variety
from grapple.vineyard.vines import VinePopulation
from grapple.vineyard.yield_model import estimate_yield


def test_yield_is_zero_for_first_year_vines():
    variety = get_variety("chardonnay")
    vines = VinePopulation(vines_per_ha=4500, planting_year=2031)
    est = estimate_yield(variety, vines, current_year=2031, area_ha=2.0)
    assert est.net_kg_per_ha == 0.0


def test_yield_increases_with_vine_maturity():
    variety = get_variety("chardonnay")
    young = VinePopulation(vines_per_ha=4500, planting_year=2029)
    mature = VinePopulation(vines_per_ha=4500, planting_year=2015)
    young_est = estimate_yield(variety, young, current_year=2031, area_ha=2.0)
    mature_est = estimate_yield(variety, mature, current_year=2031, area_ha=2.0)
    assert mature_est.net_kg_per_ha > young_est.net_kg_per_ha


def test_losses_reduce_net_yield_multiplicatively():
    variety = get_variety("chardonnay")
    vines = VinePopulation(vines_per_ha=4500, planting_year=2010)
    clean = estimate_yield(variety, vines, 2031, 2.0, frost_loss_pct=0, disease_loss_pct=0,
                            wildlife_loss_pct=0, harvest_loss_pct=0)
    lossy = estimate_yield(variety, vines, 2031, 2.0, frost_loss_pct=20, disease_loss_pct=15,
                            wildlife_loss_pct=5, harvest_loss_pct=3)
    assert lossy.net_kg_per_ha < clean.net_kg_per_ha
    expected_factor = 0.8 * 0.85 * 0.95 * 0.97
    assert abs(lossy.net_kg_per_ha - clean.net_kg_per_ha * expected_factor) < 1.0


def test_bunch_thinning_reduces_yield():
    variety = get_variety("chardonnay")
    vines = VinePopulation(vines_per_ha=4500, planting_year=2010)
    full = estimate_yield(variety, vines, 2031, 2.0, bunch_thinned_fraction=0.0)
    thinned = estimate_yield(variety, vines, 2031, 2.0, bunch_thinned_fraction=0.4)
    assert thinned.net_kg_per_ha < full.net_kg_per_ha
