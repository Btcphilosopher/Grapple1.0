from grapple.data.seed_estate import build_wessex_crown_estate, build_wessex_crown_simulation


def test_seed_estate_area_matches_stated_total():
    estate = build_wessex_crown_estate()
    assert abs(estate.total_area_ha - 48.6) < 1e-6
    assert len(estate.blocks) == 10


def test_seed_estate_has_multiple_varieties_and_soils():
    estate = build_wessex_crown_estate()
    varieties = {b.variety_key for b in estate.blocks.values()}
    soils = {b.soil_key for b in estate.blocks.values()}
    assert len(varieties) >= 4
    assert len(soils) >= 4


def test_run_vintage_is_reproducible_with_same_seed():
    sim_a = build_wessex_crown_simulation(2031, seed=999)
    sim_b = build_wessex_crown_simulation(2031, seed=999)
    report_a = sim_a.run_vintage()
    report_b = sim_b.run_vintage()
    assert report_a.total_tonnes == report_b.total_tonnes
    assert report_a.average_brix == report_b.average_brix
    assert report_a.blocks_harvested == report_b.blocks_harvested


def test_run_vintage_differs_with_different_seed():
    sim_a = build_wessex_crown_simulation(2031, seed=1)
    sim_b = build_wessex_crown_simulation(2031, seed=2)
    report_a = sim_a.run_vintage()
    report_b = sim_b.run_vintage()
    assert (report_a.total_tonnes, report_a.average_brix) != (report_b.total_tonnes, report_b.average_brix)
