from grapple.optimisation.harvest import evaluate_harvest_options, recommend_harvest_window


def test_evaluate_harvest_options_returns_max_days_plus_one(simulation):
    sim = simulation
    for _ in range(230):
        sim.step_day()
    options = evaluate_harvest_options(sim, "B01", "traditional_sparkling", max_days=5)
    assert len(options) == 6
    assert [o.days_from_now for o in options] == [0, 1, 2, 3, 4, 5]


def test_evaluate_harvest_options_does_not_mutate_live_simulation(simulation):
    sim = simulation
    for _ in range(230):
        sim.step_day()
    live_date_before = sim.state.clock.current_date
    live_brix_before = sim.state.estate.get_block("B01").chemistry.brix

    evaluate_harvest_options(sim, "B01", "traditional_sparkling", max_days=5)

    assert sim.state.clock.current_date == live_date_before
    assert sim.state.estate.get_block("B01").chemistry.brix == live_brix_before


def test_recommend_harvest_window_ranks_by_score(simulation):
    sim = simulation
    for _ in range(230):
        sim.step_day()
    options = evaluate_harvest_options(sim, "B01", "traditional_sparkling", max_days=8)
    rec = recommend_harvest_window(options)
    scores = [o.projected_score for o in rec["ranked"]]
    assert scores == sorted(scores, reverse=True)
