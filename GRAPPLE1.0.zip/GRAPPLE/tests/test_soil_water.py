from grapple.vineyard.soil import new_soil_state
from grapple.vineyard.water import update_water_balance


def test_soil_moisture_never_negative():
    soil = new_soil_state("chalk")
    for _ in range(60):
        update_water_balance(soil, rainfall_mm=0.0, tmean_c=22.0, tmax_c=28.0, tmin_c=16.0,
                              solar_mj_m2=20.0, canopy_lai=2.5)
    assert soil.moisture_mm >= 0.0


def test_heavy_rain_increases_moisture_and_drains_surplus():
    soil = new_soil_state("chalk")
    soil.moisture_mm = 10.0
    result = update_water_balance(soil, rainfall_mm=80.0, tmean_c=12.0, tmax_c=15.0, tmin_c=9.0,
                                   solar_mj_m2=5.0, canopy_lai=1.0)
    assert soil.moisture_mm > 10.0
    assert soil.moisture_mm <= soil.field_capacity_mm + 1e-6


def test_water_stress_index_rises_as_moisture_falls():
    soil = new_soil_state("gravel")
    soil.moisture_mm = soil.field_capacity_mm
    stress_full = soil.water_stress_index
    soil.moisture_mm = 0.0
    stress_empty = soil.water_stress_index
    assert stress_empty > stress_full
    assert stress_full == 0.0
    assert stress_empty == 1.0


def test_impeded_drainage_soil_retains_more_water_than_free_draining():
    from grapple.vineyard.soil import new_soil_state as nss
    clay = nss("clay")
    gravel = nss("gravel")
    clay.moisture_mm = clay.field_capacity_mm
    gravel.moisture_mm = gravel.field_capacity_mm
    update_water_balance(clay, rainfall_mm=60.0, tmean_c=14.0, tmax_c=18.0, tmin_c=10.0, solar_mj_m2=8.0, canopy_lai=1.5)
    update_water_balance(gravel, rainfall_mm=60.0, tmean_c=14.0, tmax_c=18.0, tmin_c=10.0, solar_mj_m2=8.0, canopy_lai=1.5)
    assert clay.drainage_coefficient() < gravel.drainage_coefficient()
