import numpy as np

from grapple.wine.ageing import project_ageing
from grapple.wine.chemistry import apply_oxidative_drift, apply_so2_consumption, molecular_so2_mg_l, va_formation_risk
from grapple.wine.composition import WineComposition, blend_weighted
from grapple.wine.quality import score_stability
from grapple.wine.sensory import generate_sensory_panel
from grapple.winery.bottling import ClosureType


def test_molecular_so2_falls_as_ph_rises():
    low_ph = molecular_so2_mg_l(30.0, 3.0)
    high_ph = molecular_so2_mg_l(30.0, 3.8)
    assert low_ph > high_ph


def test_so2_consumption_reduces_free_so2_and_dissolved_oxygen():
    comp = WineComposition(free_so2_mg_l=30.0, dissolved_oxygen_mg_l=2.0)
    apply_so2_consumption(comp, temperature_c=18.0)
    assert comp.free_so2_mg_l < 30.0
    assert comp.dissolved_oxygen_mg_l < 2.0


def test_va_risk_higher_with_low_so2_and_high_oxygen():
    protected = WineComposition(free_so2_mg_l=35.0, ph=3.2, dissolved_oxygen_mg_l=0.2)
    exposed = WineComposition(free_so2_mg_l=2.0, ph=3.2, dissolved_oxygen_mg_l=4.0)
    assert va_formation_risk(exposed, 20.0) > va_formation_risk(protected, 20.0)


def test_blend_weighted_matches_manual_average():
    a = WineComposition(ethanol_pct=12.0, ph=3.0)
    b = WineComposition(ethanol_pct=14.0, ph=3.4)
    blended = blend_weighted([(a, 0.5), (b, 0.5)])
    assert abs(blended.ethanol_pct - 13.0) < 1e-9
    assert abs(blended.ph - 3.2) < 1e-9


def test_stability_score_penalises_high_va_and_low_so2():
    stable = WineComposition(free_so2_mg_l=30.0, volatile_acidity_gl=0.3, dissolved_oxygen_mg_l=0.3)
    unstable = WineComposition(free_so2_mg_l=2.0, volatile_acidity_gl=1.1, dissolved_oxygen_mg_l=3.5)
    assert score_stability(stable) > score_stability(unstable)


def test_sensory_scores_are_bounded_and_labelled_modelled():
    comp = WineComposition(ethanol_pct=12.5, ta_gl=8.0, residual_sugar_gl=5.0, phenolics_index=0.3)
    scores = generate_sensory_panel(comp, variety_aromatic_potential=0.7, variety_phenolic_potential=0.3,
                                     is_sparkling=True, rng=np.random.default_rng(1))
    assert scores.is_modelled_estimate is True
    assert 0 <= scores.aroma_fruit <= 10
    assert 0 <= scores.balance <= 100


def test_ageing_projection_uncertainty_widens_with_horizon():
    comp = WineComposition(ta_gl=8.0, phenolics_index=0.2)
    projections = project_ageing(comp, ClosureType.CORK_NATURAL, current_quality_pct=88.0)
    uncertainties = [p.predicted_quality_uncertainty_pct for p in projections]
    assert uncertainties == sorted(uncertainties)
    assert projections[0].horizon_months < projections[-1].horizon_months
