import pytest

from grapple.logistics.inventory import InventoryLedger
from grapple.logistics.warehouse import Warehouse, BOTTLES_PER_CASE


def test_inventory_ledger_tracks_balance():
    ledger = InventoryLedger()
    ledger.record("tank-1", 1000.0, "L", "juice received")
    ledger.record("tank-1", -300.0, "L", "racked off")
    assert ledger.balance("tank-1") == 700.0


def test_inventory_ledger_blocks_negative_balance():
    ledger = InventoryLedger()
    ledger.record("tank-1", 100.0, "L", "juice received")
    with pytest.raises(ValueError):
        ledger.record("tank-1", -500.0, "L", "over-draw")


def test_inventory_transfer_conserves_total():
    ledger = InventoryLedger()
    ledger.record("tank-1", 1000.0, "L", "initial fill")
    ledger.transfer("tank-1", "tank-2", 400.0, "L", "rack to tank-2")
    assert ledger.balance("tank-1") == 600.0
    assert ledger.balance("tank-2") == 400.0


def test_warehouse_case_packing_and_dispatch():
    wh = Warehouse(storage_capacity_cases=100)
    cases = wh.receive_bottles("BB-001", BOTTLES_PER_CASE * 10 + 5)  # 5 leftover bottles ignored (not a full case)
    assert cases == 10
    assert wh.total_cases() == 10
    dispatched = wh.dispatch("BB-001", 4, "Trade customer", __import__("datetime").date(2031, 12, 1))
    assert dispatched == 4
    assert wh.total_cases() == 6
