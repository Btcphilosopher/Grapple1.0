import datetime as dt

import numpy as np

from grapple.digital_twin.anomaly import check_block, check_fermentation, check_weather
from grapple.digital_twin.sensors import read_block_sensors
from grapple.digital_twin.telemetry import TelemetryBus
from grapple.config import DataProvenance
from grapple.weather.weather import DailyWeather
from grapple.winery.fermentation import FermentationBatch
from grapple.winery.juice import JuiceLot
from grapple.winery.fermentation import new_batch
from grapple.winery.yeast import instantiate_strain


def _weather_day(**overrides):
    base = dict(date=dt.date(2031, 6, 1), tmean_c=15.0, tmin_c=10.0, tmax_c=20.0, rainfall_mm=2.0,
                humidity_pct=70.0, wind_ms=3.0, solar_mj_m2=15.0, cloud_cover_pct=50.0, soil_temp_c=14.0)
    base.update(overrides)
    return DailyWeather(**base)


def test_check_weather_flags_impossible_temperature():
    bad = _weather_day(tmin_c=999.0, tmax_c=999.0)
    flags = check_weather(bad)
    assert any(f.severity == "CRITICAL" for f in flags)


def test_check_weather_passes_plausible_day():
    good = _weather_day()
    assert check_weather(good) == []


def test_sensor_reading_close_to_true_weather(single_block_estate):
    block = single_block_estate.get_block("B01")
    day = _weather_day(tmean_c=18.0, humidity_pct=65.0)
    rng = np.random.default_rng(1)
    reading = read_block_sensors(block, day, dt.datetime(2031, 6, 1, 9, 0), rng)
    assert abs(reading["temperature_c"] - 18.0) < 3.0
    assert reading["provenance"] == DataProvenance.SYNTHETIC.value


def test_telemetry_csv_ingest_round_trip():
    bus = TelemetryBus()
    csv_text = "date,time,block,temperature,humidity,soil_moisture\n2031-07-14,12:00,B07,21.4,62,31.7\n"
    count = bus.ingest_csv(csv_text, source="csv_import")
    assert count == 3
    temps = bus.query(metric="temperature")
    assert len(temps) == 1
    assert temps[0].value == 21.4
    assert temps[0].provenance == DataProvenance.OBSERVED


def test_check_fermentation_flags_negative_sugar():
    rng = np.random.default_rng(1)
    juice = JuiceLot("JL", "HL", "P", "free_run", 1000, 19.0, 3.1, 8.0, 5.0, 200, 100, 15.0, 3.0)
    batch = new_batch(juice, "T1", instantiate_strain("ec1118", rng))
    batch.sugar_gl = -1.0
    flags = check_fermentation(batch)
    assert any(f.severity == "CRITICAL" for f in flags)
