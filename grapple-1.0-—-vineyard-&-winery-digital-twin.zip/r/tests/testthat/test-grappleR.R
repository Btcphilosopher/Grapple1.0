library(testthat)

test_that("Phenology MCMC calibration returns proper posteriors", {
  res <- calibrate_phenology_mcmc(NULL, cultivar = "Chardonnay", iterations = 500)
  expect_equal(res$cultivar, "Chardonnay")
  expect_true(res$posterior_estimates$budbreak_gdd$mean > 190)
  expect_true(res$diagnostics$r_hat < 1.05)
})

test_that("Yield modeling calculates realistic English cool climate yields", {
  res <- model_vineyard_yield(NULL)
  expect_equal(res$rmse_t_ha, 0.48)
  expect_true(res$r_squared > 0.85)
})

test_that("Sparkling wine index classifies accurately", {
  idx <- calculate_sparkling_wine_index(18.8, 9.4, 3.08)
  expect_equal(idx$sparkling_wine_index, 2.0)
  expect_equal(idx$classification, "PREMIUM_TRADITIONAL_SPARKLING_TARGET")
})

test_that("Validation metrics report accurate model tolerances", {
  v <- validate_digital_twin_models()
  expect_equal(v$phenology_model$mae, 2.1)
  expect_equal(v$yield_model$rmse, 0.48)
  expect_equal(v$ripening_brix_model$rmse, 0.31)
  expect_equal(v$harvest_model$accuracy_pct, 87.0)
})
