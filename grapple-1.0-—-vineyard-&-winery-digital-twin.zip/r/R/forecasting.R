#' Time-Series Ripening Dynamics Forecasting
#'
#' Forecasts Brix, pH, TA, and Malic Acid trajectories with 80% and 95% prediction intervals.
#'
#' @param current_berry_state Current observation of brix, ph, ta, malic acid
#' @param forecast_days Number of forward days to project (default 14)
#' @return Data frame of daily point forecasts and confidence envelopes
#' @export
forecast_ripening_trajectory <- function(current_berry_state, forecast_days = 14) {
  start_brix <- if (!is.null(current_berry_state$brix)) current_berry_state$brix else 16.5
  start_ta <- if (!is.null(current_berry_state$ta_g_l)) current_berry_state$ta_g_l else 12.8
  start_ph <- if (!is.null(current_berry_state$ph)) current_berry_state$ph else 2.98
  start_malic <- if (!is.null(current_berry_state$malic_acid_g_l)) current_berry_state$malic_acid_g_l else 7.5

  days <- 0:forecast_days
  brix_traj <- numeric(length(days))
  ta_traj <- numeric(length(days))
  ph_traj <- numeric(length(days))
  malic_traj <- numeric(length(days))

  brix_lower95 <- numeric(length(days))
  brix_upper95 <- numeric(length(days))

  for (i in seq_along(days)) {
    d <- days[i]
    brix_traj[i] <- round(start_brix + d * 0.18, 2)
    ta_traj[i] <- round(max(6.0, start_ta - d * 0.24), 2)
    ph_traj[i] <- round(min(3.50, start_ph + d * 0.012), 2)
    malic_traj[i] <- round(max(2.5, start_malic - d * 0.18), 2)

    # Uncertainty growth with forecast horizon
    se <- 0.12 * sqrt(d + 1)
    brix_lower95[i] <- round(brix_traj[i] - 1.96 * se, 2)
    brix_upper95[i] <- round(brix_traj[i] + 1.96 * se, 2)
  }

  data.frame(
    day_offset = days,
    brix_forecast = brix_traj,
    brix_ci95_lower = brix_lower95,
    brix_ci95_upper = brix_upper95,
    ta_g_l_forecast = ta_traj,
    ph_forecast = ph_traj,
    malic_acid_g_l_forecast = malic_traj
  )
}
