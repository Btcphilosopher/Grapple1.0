#' Wine Chemistry and Sparkling Wine Balance Indices
#'
#' Computes sparkling wine base harmony index, Malolactic completion percentage, and stability.
#'
#' @param brix Sugar in degrees Brix
#' @param ta_g_l Titratable acidity in g/L (tartaric equivalent)
#' @param ph Must pH
#' @param malic_acid_g_l Malic acid concentration in g/L
#' @return List containing balance indices and cellar classification
#' @export
calculate_sparkling_wine_index <- function(brix, ta_g_l, ph, malic_acid_g_l = 7.0) {
  # Traditional Sparkling Index = Brix / (TA * 0.1)
  # Optimal target in England: 1.85 to 2.15
  sparkling_index <- brix / (ta_g_l * 0.1 + 1e-4)

  balance_classification <- if (sparkling_index >= 1.80 && sparkling_index <= 2.10) {
    "PREMIUM_TRADITIONAL_SPARKLING_TARGET"
  } else if (sparkling_index < 1.80) {
    "HIGH_ACID_EARLY_PICK"
  } else {
    "WARM_VINTAGE_STILL_WINE_PROFILE"
  }

  list(
    sparkling_wine_index = round(sparkling_index, 2),
    sugar_to_acid_ratio = round(brix / max(0.1, ta_g_l), 2),
    classification = balance_classification,
    optimal_sparkling_range = c(1.80, 2.10)
  )
}
