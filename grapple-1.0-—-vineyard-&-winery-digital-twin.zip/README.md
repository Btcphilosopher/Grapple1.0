# GRAPPLE 1.0 — English Vineyard & Winery Digital Twin
### Rust + R Scientific Computing Layer

```
                    GRAPPLE 1.0
                         │
              ┌──────────┼──────────┐
              │          │          │
           Python      Rust         R
              │          │          │
        Orchestration   Engine    Analytics
        API / UI        Simulation Statistics
        Workflow        Physics    Forecasting
        Integration     Performance Experimentation
              │          │          │
              └──────────┼──────────┘
                         │
                    Shared Data
                         │
                PostgreSQL / Parquet / JSON
```

---

## 1. Architectural Philosophy
* **Python**: Orchestration, FastAPI, UI web application, workflows, telemetry streaming, CLI dispatcher.
* **Rust (`grapple-engine`)**: Authoritative high-performance deterministic simulation engine, multi-layer soil-water physics, cultivar phenology, grape ripening kinetics, disease pressure models, winery mass balance, ODE fermentation, Rayon parallel Monte Carlo (10,000+ vintages/sec).
* **R (`grappleR`)**: Statistical calibration, Bayesian MCMC parameter estimation, hierarchical mixed-effects yield modelling, ripening time-series ARIMA/spline forecasts, global sensitivity analysis (Sobol/Morris indices), model validation diagnostics (MAE, RMSE, Brier score).

---

## 2. Mathematical Models & Units
* **Phenology**: Thermal accumulation $GDD = \sum \max(0, T_{\text{mean}} - 10^\circ\text{C})$ from DOY 60.
* **Ripening**: Sugar accumulation ($\frac{d\text{Brix}}{dt}$), malic acid respiration ($Q_{10} \approx 2.0$), $pH = 2.70 + 0.055 \cdot \text{Brix} - 0.045 \cdot \text{TA}$.
* **Sparkling Wine Index**: $\text{Index} = \frac{\text{Brix}}{\text{TA} \cdot 0.1}$ (Target range $1.85 - 2.15$ for English sparkling base).
* **Soil Water Balance**: 4 layers ($0-20\text{ cm}, 20-50\text{ cm}, 50-100\text{ cm}, 100-150\text{ cm}$), moisture % vs field capacity & wilting point.
* **Fermentation Kinetics**: Monod kinetics $\mu = \mu_{\max} \cdot \left(\frac{S}{K_s + S}\right) \cdot \left(\frac{N}{K_n + N}\right) \cdot \left(1 - \frac{E}{K_e}\right)$.

---

## 3. CLI Usage
```bash
# Deterministic vintage simulation
grapple simulate --estate wessex --vintage 2031 --seed 20310825

# Parallel Monte Carlo (10,000 runs)
grapple monte-carlo --runs 10000 --seed 20310825

# What-If scenario matrix (EXP-2031-0042)
grapple scenario

# Bayesian MCMC phenology calibration
grapple calibrate --cultivar Chardonnay

# Digital twin model validation
grapple validate

# High-frequency synthetic sensor telemetry with anomaly detection
grapple telemetry --count 10 --inject-anomaly
```
