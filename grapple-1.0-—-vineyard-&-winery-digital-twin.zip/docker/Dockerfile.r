# R Scientific Computing Container
FROM rocker/r-ver:4.3.2
RUN install2.r --error \
    data.table \
    jsonlite \
    testthat
WORKDIR /app
COPY r/ .
RUN R CMD INSTALL .
CMD ["R"]
