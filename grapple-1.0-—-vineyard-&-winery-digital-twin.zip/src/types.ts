export type ActiveTab =
  | 'COMPUTE'
  | 'MODELS'
  | 'EXPERIMENTS'
  | 'MONTE_CARLO'
  | 'CALIBRATION'
  | 'STATISTICS'
  | 'UNCERTAINTY'
  | 'VALIDATION'
  | 'WINERY_TWIN';

export interface EngineStats {
  rustCpuUsagePct: number;
  rustThreads: number;
  rustSimsPerSec: number;
  rustActiveJobs: number;
  rustMemoryMb: number;
  rModelsRunning: number;
  rDatasets: number;
  rForecasts: number;
  crossLangLatencyMs: number;
  parquetCacheMb: number;
}

export interface BlockState {
  id: string;
  name: string;
  cultivar: 'Chardonnay' | 'Pinot Noir' | 'Pinot Meunier' | 'Bacchus' | 'Seyval Blanc';
  areaHa: number;
  vineCount: number;
  elevationM: number;
  slopeDeg: number;
  aspectDeg: number;
  soil: string;
  stage: 'Dormancy' | 'Budbreak' | 'Flowering' | 'FruitSet' | 'Veraison' | 'Ripening' | 'HarvestReady' | 'Harvested';
  gddAccum: number;
  brix: number;
  taGL: number;
  ph: number;
  malicAcidGL: number;
  berryWeightG: number;
  downyRiskPct: number;
  powderyRiskPct: number;
  botrytisRiskPct: number;
  yieldKgHa: number;
  suitabilityScore: number;
}

export interface MonteCarloSummary {
  mean: number;
  median: number;
  stdDev: number;
  p10: number;
  p25: number;
  p75: number;
  p90: number;
  ci95Lower: number;
  ci95Upper: number;
}

export interface MonteCarloRunReport {
  totalRuns: number;
  durationMs: number;
  throughputSimsPerSec: number;
  threads: number;
  yieldTHa: MonteCarloSummary;
  harvestDoy: MonteCarloSummary;
  brix: MonteCarloSummary;
  taGL: MonteCarloSummary;
  sparklingWineIndex: MonteCarloSummary;
  distributionBins: { range: string; count: number; freq: number }[];
}

export interface ScenarioComparison {
  name: string;
  description: string;
  harvestDoy: number;
  harvestBrix: number;
  harvestTaGL: number;
  harvestPh: number;
  yieldTHa: number;
  diseaseLossPct: number;
  sparklingIndex: number;
  cellarScore: number;
}

export interface FermentationTankState {
  id: string;
  name: string;
  volumeL: number;
  capacityL: number;
  tempC: number;
  targetTempC: number;
  brix: number;
  ethanolPct: number;
  yeastBiomassGL: number;
  yanMgL: number;
  stage: 'ColdSettling' | 'PrimaryFermentation' | 'MalolacticFermentation' | 'LeesAgeing' | 'Stabilisation';
  coolingActive: boolean;
  stuck: boolean;
  co2Rate: number;
}

export interface SensorTelemetry {
  id: string;
  sensorId: string;
  type: string;
  location: string;
  value: number;
  unit: string;
  status: 'GOOD' | 'WARNING' | 'ANOMALY_DETECTED';
  anomalyScore: number;
  message?: string;
  timestamp: string;
}
