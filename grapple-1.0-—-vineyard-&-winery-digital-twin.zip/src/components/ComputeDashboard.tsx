import React from 'react';
import { EngineStats } from '../types';
import { Cpu, Server, Activity, Database, CheckCircle2, Zap, ArrowRightLeft } from 'lucide-react';

interface Props {
  engineStats: EngineStats;
  onBenchmark: () => void;
}

export const ComputeDashboard: React.FC<Props> = ({ engineStats, onBenchmark }) => {
  return (
    <div id="compute-dashboard" className="space-y-6">
      {/* Top Banner / Engine Topology */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <Server className="w-5 h-5 text-emerald-400" />
              Scientific Computing Layer — Engine Status
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Deterministic Rust Simulation Engine (Rayon Parallel Execution) + R Statistical Analytics (grappleR) + Python Orchestration
            </p>
          </div>
          <button
            id="run-benchmark-btn"
            onClick={onBenchmark}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-4 py-2 rounded transition-colors shadow"
          >
            <Zap className="w-4 h-4" />
            Run Rust Rayon Benchmark (10k Runs)
          </button>
        </div>
      </div>

      {/* Grid of Engine Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* Rust Engine Card */}
        <div id="rust-engine-card" className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-orange-400" />
              <span className="font-semibold text-sm text-slate-200">RUST ENGINE (grapple-engine)</span>
            </div>
            <span className="px-2 py-0.5 text-[10px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800 rounded">
              ONLINE
            </span>
          </div>

          <div className="mt-4 space-y-3 font-mono text-xs">
            <div className="flex justify-between items-center text-slate-300">
              <span className="text-slate-400">CPU Utilisation</span>
              <span className="font-bold text-slate-100">{engineStats.rustCpuUsagePct}%</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-orange-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${engineStats.rustCpuUsagePct}%` }}
              ></div>
            </div>

            <div className="flex justify-between items-center text-slate-300 pt-1">
              <span className="text-slate-400">Rayon Worker Threads</span>
              <span className="font-bold text-slate-100">{engineStats.rustThreads} Cores</span>
            </div>

            <div className="flex justify-between items-center text-slate-300">
              <span className="text-slate-400">Simulation Throughput</span>
              <span className="font-bold text-emerald-400 text-sm">
                {engineStats.rustSimsPerSec.toLocaleString()} sims/sec
              </span>
            </div>

            <div className="flex justify-between items-center text-slate-300">
              <span className="text-slate-400">Active Job Queue</span>
              <span className="font-bold text-slate-100">{engineStats.rustActiveJobs}</span>
            </div>

            <div className="flex justify-between items-center text-slate-300">
              <span className="text-slate-400">Memory Allocation</span>
              <span className="font-bold text-slate-100">{engineStats.rustMemoryMb} MB</span>
            </div>
          </div>
        </div>

        {/* R Engine Card */}
        <div id="r-engine-card" className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              <span className="font-semibold text-sm text-slate-200">R ENGINE (grappleR)</span>
            </div>
            <span className="px-2 py-0.5 text-[10px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800 rounded">
              READY
            </span>
          </div>

          <div className="mt-4 space-y-3 font-mono text-xs">
            <div className="flex justify-between items-center text-slate-300">
              <span className="text-slate-400">Statistical Models Running</span>
              <span className="font-bold text-slate-100">{engineStats.rModelsRunning}</span>
            </div>

            <div className="flex justify-between items-center text-slate-300">
              <span className="text-slate-400">Registered Datasets</span>
              <span className="font-bold text-slate-100">{engineStats.rDatasets}</span>
            </div>

            <div className="flex justify-between items-center text-slate-300">
              <span className="text-slate-400">Active Forecast Horizon</span>
              <span className="font-bold text-cyan-400">{engineStats.rForecasts} (14-day & Vintage)</span>
            </div>

            <div className="flex justify-between items-center text-slate-300">
              <span className="text-slate-400">MCMC Convergence (R-hat)</span>
              <span className="font-bold text-emerald-400">1.01 (Optimal)</span>
            </div>

            <div className="flex justify-between items-center text-slate-300">
              <span className="text-slate-400">JIT Bytecode Compilation</span>
              <span className="font-bold text-slate-100">Enabled (Tier 3)</span>
            </div>
          </div>
        </div>

        {/* Data Architecture & Shared Memory */}
        <div id="shared-data-card" className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-emerald-400" />
              <span className="font-semibold text-sm text-slate-200">SHARED DATA LAYER</span>
            </div>
            <span className="px-2 py-0.5 text-[10px] font-mono bg-blue-950 text-blue-400 border border-blue-800 rounded">
              ARROW / PARQUET
            </span>
          </div>

          <div className="mt-4 space-y-3 font-mono text-xs">
            <div className="flex justify-between items-center text-slate-300">
              <span className="text-slate-400">IPC Inter-Process Latency</span>
              <span className="font-bold text-emerald-400">{engineStats.crossLangLatencyMs} ms</span>
            </div>

            <div className="flex justify-between items-center text-slate-300">
              <span className="text-slate-400">Parquet Buffer Pool</span>
              <span className="font-bold text-slate-100">{engineStats.parquetCacheMb} MB (Zero-Copy)</span>
            </div>

            <div className="flex justify-between items-center text-slate-300">
              <span className="text-slate-400">PostgreSQL Operational DB</span>
              <span className="font-bold text-slate-100">Connected (pg15)</span>
            </div>

            <div className="flex justify-between items-center text-slate-300">
              <span className="text-slate-400">Canonical Schemas Validated</span>
              <span className="font-bold text-emerald-400">7 / 7 OK</span>
            </div>

            <div className="flex justify-between items-center text-slate-300">
              <span className="text-slate-400">Reproducibility Seed Lock</span>
              <span className="font-bold text-slate-100">ACTIVE</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3-Language Architecture Workflow Diagram */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-4">
          Three-Language Execution Pipeline & Data Flow
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded border border-blue-900/60 bg-blue-950/20">
            <div className="text-blue-400 font-bold text-xs mb-1">1. Python Product Layer</div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              FastAPI orchestration, WebSockets telemetry dispatcher, interactive user controls, and data contract serialization.
            </p>
          </div>
          <div className="p-4 rounded border border-orange-900/60 bg-orange-950/20">
            <div className="text-orange-400 font-bold text-xs mb-1">2. Rust Simulation Engine</div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              Rayon multi-threaded physics execution: microclimate, multi-layer soil hydrology, grape ripening kinetics, and winery mass balance.
            </p>
          </div>
          <div className="p-4 rounded border border-cyan-900/60 bg-cyan-950/20">
            <div className="text-cyan-400 font-bold text-xs mb-1">3. R Scientific Analytics</div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              MCMC calibration, ARIMA ripening forecast envelopes, GLM mixed-effects yield curves, and model validation diagnostics.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
