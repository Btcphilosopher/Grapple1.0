import React, { useState } from 'react';
import { INITIAL_TANKS } from '../data/mockDigitalTwinData';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';
import { Activity, AlertTriangle, CheckCircle, Sparkles, FlaskRound } from 'lucide-react';

export const StatisticsDashboard: React.FC = () => {
  const [selectedTankId, setSelectedTankId] = useState<string>('T-01');
  const [tanks, setTanks] = useState(INITIAL_TANKS);
  const selectedTank = tanks.find((t) => t.id === selectedTankId) || tanks[0];

  // Fermentation kinetics time-series (Days 0 to 14)
  const fermentationCurveData = Array.from({ length: 15 }, (_, day) => {
    // Monod ODE kinetics simulation
    const isT6 = selectedTankId === 'T-06';
    let brix = 0;
    let ethanol = 0;
    let biomass = 0;

    if (isT6) {
      // Sluggish stuck curve
      brix = day < 3 ? 19.5 - day * 2.0 : (day < 6 ? 13.5 - (day - 3) * 1.0 : Math.max(9.8, 10.5 - (day - 6) * 0.15));
      ethanol = (19.5 - brix) * 0.55;
      biomass = day < 4 ? 0.5 + day * 0.4 : Math.max(0.6, 2.1 - (day - 4) * 0.25);
    } else {
      // Healthy primary fermentation
      brix = Math.max(0.0, 19.0 * Math.exp(-0.32 * day) - 0.2);
      ethanol = (19.0 - brix) * 0.58;
      biomass = day < 5 ? 0.5 + day * 0.8 : Math.max(0.4, 4.5 * Math.exp(-0.25 * (day - 5)));
    }

    return {
      day: `Day ${day}`,
      Sugar_Brix: +brix.toFixed(1),
      Ethanol_Pct: +ethanol.toFixed(1),
      Yeast_Biomass_gL: +biomass.toFixed(2),
      Temp_C: isT6 ? 19.5 : 16.0,
    };
  });

  const handleInterventionT06 = () => {
    setTanks((prev) =>
      prev.map((t) =>
        t.id === 'T-06'
          ? {
              ...t,
              stuck: false,
              yanMgL: 180,
              yeastBiomassGL: 3.2,
              stage: 'PrimaryFermentation',
            }
          : t
      )
    );
  };

  return (
    <div id="statistics-dashboard" className="space-y-6">
      {/* Tank Selector Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <label className="text-xs text-slate-400 font-medium">Cellar Fermentation Tank:</label>
          <div className="flex gap-2 flex-wrap">
            {tanks.map((t) => (
              <button
                key={t.id}
                onClick={() => setSelectedTankId(t.id)}
                className={`px-3 py-1.5 rounded text-xs font-mono transition-colors flex items-center gap-1.5 ${
                  selectedTankId === t.id
                    ? 'bg-cyan-600 text-white shadow-sm'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {t.stuck && <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />}
                {t.id} ({t.name.split('—')[1]?.trim() || t.name})
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-4 font-mono text-xs text-slate-300">
          <span>Volume: <strong>{selectedTank.volumeL.toLocaleString()} / {selectedTank.capacityL.toLocaleString()} L</strong></span>
          <span>Temp: <strong className="text-cyan-400">{selectedTank.tempC} °C</strong></span>
          <span>Ethanol: <strong className="text-emerald-400">{selectedTank.ethanolPct}%</strong></span>
          <span>YAN: <strong className="text-amber-400">{selectedTank.yanMgL} mg/L</strong></span>
        </div>
      </div>

      {/* Warning Banner if Stuck Fermentation */}
      {selectedTank.stuck && (
        <div className="p-4 bg-amber-950/40 border border-amber-800/80 rounded-lg flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
          <div className="flex items-center gap-3 text-amber-200">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <div className="font-bold text-sm text-amber-300">
                SLUGGISH / STUCK FERMENTATION DETECTED (Tank {selectedTank.id})
              </div>
              <div className="text-[11px] text-amber-300/80 mt-0.5">
                Residual Sugar: 9.8 °Brix | YAN depleted (18 mg/L) | Rate &lt; 0.05 °Bx/day
              </div>
            </div>
          </div>
          <button
            onClick={handleInterventionT06}
            className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-slate-900 font-bold rounded transition-colors shadow"
          >
            Deploy EC1118 Fructophilic Inoculation + 150 mg/L DAP
          </button>
        </div>
      )}

      {/* Kinetic Curves & Wine Chemistry */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Kinetic Curves Chart */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                Monod Growth & Substrate Depletion Kinetics ({selectedTank.name})
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                dS/dt = -(1/Y_xs) · μ · X (Sugar consumption & ethanol yield)
              </p>
            </div>
            <span className="text-xs font-mono text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
              Stage: {selectedTank.stage}
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={fermentationCurveData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="day" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Line type="monotone" dataKey="Sugar_Brix" stroke="#f59e0b" strokeWidth={2.5} name="Sugar (°Brix)" />
                <Line type="monotone" dataKey="Ethanol_Pct" stroke="#10b981" strokeWidth={2.5} name="Ethanol (% v/v)" />
                <Line type="monotone" dataKey="Yeast_Biomass_gL" stroke="#a855f7" strokeWidth={1.8} name="Yeast Biomass (g/L)" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Malolactic Conversion & Chemistry Balance */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 mb-4">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            English Sparkling Base Harmony & Malolactic Conversion
          </h3>

          <div className="space-y-4 font-mono text-xs">
            {/* Sparkling Wine Index Gauge */}
            <div className="p-3 bg-slate-800/80 rounded border border-slate-700">
              <div className="flex justify-between items-center mb-1">
                <span className="text-slate-300">Traditional Sparkling Wine Harmony Index:</span>
                <span className="text-emerald-400 font-bold text-sm">2.01 (Optimal: 1.80–2.10)</span>
              </div>
              <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden">
                <div className="bg-emerald-500 h-full rounded-full" style={{ width: '70%' }}></div>
              </div>
              <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                <span>1.50 (High Acid)</span>
                <span className="text-emerald-400 font-bold">1.95 (Chalk Terroir Target)</span>
                <span>2.50 (Warm Vintage Still)</span>
              </div>
            </div>

            {/* Malolactic Fermentation Completion */}
            <div className="p-3 bg-slate-800/80 rounded border border-slate-700">
              <div className="flex justify-between items-center mb-1">
                <span className="text-slate-300">Malolactic Fermentation (Oenococcus oeni):</span>
                <span className="text-cyan-400 font-bold">88.4% Converted</span>
              </div>
              <div className="text-[11px] text-slate-400">
                Malic Acid: <strong className="text-slate-200">0.45 g/L</strong> (Initial: 4.80 g/L) → Lactic Acid: <strong className="text-slate-200">2.95 g/L</strong>
              </div>
            </div>

            {/* Chemical Stability */}
            <div className="grid grid-cols-3 gap-3">
              <div className="p-2.5 bg-slate-800/50 rounded border border-slate-700/60 text-center">
                <div className="text-[10px] text-slate-400">Free SO₂</div>
                <div className="text-sm font-bold text-slate-100 mt-0.5">24 mg/L</div>
              </div>
              <div className="p-2.5 bg-slate-800/50 rounded border border-slate-700/60 text-center">
                <div className="text-[10px] text-slate-400">Volatile Acidity</div>
                <div className="text-sm font-bold text-emerald-400 mt-0.5">0.28 g/L</div>
              </div>
              <div className="p-2.5 bg-slate-800/50 rounded border border-slate-700/60 text-center">
                <div className="text-[10px] text-slate-400">Turbidity (NTU)</div>
                <div className="text-sm font-bold text-cyan-400 mt-0.5">18 NTU</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
