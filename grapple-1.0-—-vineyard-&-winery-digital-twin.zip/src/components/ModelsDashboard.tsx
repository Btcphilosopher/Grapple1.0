import React, { useState } from 'react';
import { BlockState } from '../types';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, Legend, CartesianGrid, AreaChart, Area } from 'recharts';
import { Layers, Droplets, Thermometer, ShieldAlert, Sparkles } from 'lucide-react';

interface Props {
  blocks: BlockState[];
}

export const ModelsDashboard: React.FC<Props> = ({ blocks }) => {
  const [selectedBlockId, setSelectedBlockId] = useState<string>(blocks[0].id);
  const selectedBlock = blocks.find((b) => b.id === selectedBlockId) || blocks[0];

  // Dynamic 14-day ripening projection data
  const ripeningProjectionData = Array.from({ length: 15 }, (_, i) => {
    const doy = 275 + i;
    const brix = +(selectedBlock.brix - 1.8 + i * 0.22).toFixed(1);
    const ta = +(selectedBlock.taGL + 2.2 - i * 0.28).toFixed(1);
    const ph = +(2.75 + 0.05 * brix - 0.04 * ta).toFixed(2);
    const malic = +(Math.max(2.0, selectedBlock.malicAcidGL + 1.2 - i * 0.20)).toFixed(1);
    return {
      day: `DOY ${doy}`,
      date: `${2 + i} Oct`,
      Brix: brix,
      TA_g_L: ta,
      pH: ph,
      Malic_Acid: malic,
      Sparkling_Index: +(brix / (ta * 0.1)).toFixed(2),
    };
  });

  // GDD Phenology Curve comparison across cultivars
  const gddCurveData = [
    { stage: 'Dormancy (DOY 60)', GDD: 0, Chardonnay: 0, PinotNoir: 0, Bacchus: 0 },
    { stage: 'Budbreak', GDD: 210, Chardonnay: 210, PinotNoir: 225, Bacchus: 175 },
    { stage: 'Flowering', GDD: 460, Chardonnay: 460, PinotNoir: 480, Bacchus: 400 },
    { stage: 'Fruit Set', GDD: 550, Chardonnay: 550, PinotNoir: 570, Bacchus: 480 },
    { stage: 'Veraison', GDD: 880, Chardonnay: 880, PinotNoir: 910, Bacchus: 790 },
    { stage: 'Harvest Ready', GDD: 1050, Chardonnay: 1050, PinotNoir: 1080, Bacchus: 950 },
  ];

  return (
    <div id="models-dashboard" className="space-y-6">
      {/* Block Selector */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <label className="text-xs text-slate-400 font-medium">Select Vineyard Block:</label>
          <div className="flex gap-2 flex-wrap">
            {blocks.map((b) => (
              <button
                key={b.id}
                onClick={() => setSelectedBlockId(b.id)}
                className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                  selectedBlockId === b.id
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {b.name} ({b.cultivar})
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-3 font-mono text-xs text-slate-300">
          <span>Elevation: <strong>{selectedBlock.elevationM}m</strong></span>
          <span>Slope: <strong>{selectedBlock.slopeDeg}°</strong></span>
          <span>Aspect: <strong>{selectedBlock.aspectDeg}° (S)</strong></span>
          <span>Area: <strong>{selectedBlock.areaHa} ha</strong></span>
        </div>
      </div>

      {/* Grid: Ripening Dynamics + Phenology Curves */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Ripening Chemistry Dynamics */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                Grape Ripening Dynamics (Brix & Acidity Trajectory)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Dynamic ODE kinetics with solar radiation & thermal respiration
              </p>
            </div>
            <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800">
              Current: {selectedBlock.brix}°Bx | {selectedBlock.taGL} g/L TA
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={ripeningProjectionData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="date" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Line type="monotone" dataKey="Brix" stroke="#f59e0b" strokeWidth={2.5} name="Sugar (°Brix)" />
                <Line type="monotone" dataKey="TA_g_L" stroke="#ef4444" strokeWidth={2.5} name="Total Acidity (g/L)" />
                <Line type="monotone" dataKey="Malic_Acid" stroke="#a855f7" strokeWidth={1.8} strokeDasharray="4 4" name="Malic Acid (g/L)" />
                <Line type="monotone" dataKey="pH" stroke="#06b6d4" strokeWidth={2} name="pH" yAxisId="right" />
                <YAxis yAxisId="right" orientation="right" domain={[2.5, 3.8]} stroke="#06b6d4" fontSize={11} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Cultivar Phenology GDD Model */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Thermometer className="w-4 h-4 text-orange-400" />
                Cultivar Thermal Time (GDD Base 10°C Accumulation)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Calibrated against 14 historical English vintages (MCMC)
              </p>
            </div>
            <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-blue-950 text-blue-400 border border-blue-800">
              Stage: {selectedBlock.stage}
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={gddCurveData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="stage" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Area type="monotone" dataKey="Chardonnay" stroke="#10b981" fill="#10b981" fillOpacity={0.2} name="Chardonnay GDD" />
                <Area type="monotone" dataKey="PinotNoir" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.15} name="Pinot Noir GDD" />
                <Area type="monotone" dataKey="Bacchus" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.15} name="Bacchus GDD" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Bottom Grid: 4-Layer Soil Water Model + Disease Pressure Models */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Multi-Layer Soil Water Model */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 mb-4">
            <Droplets className="w-4 h-4 text-cyan-400" />
            4-Layer Soil Hydrology & Water Stress Index
          </h3>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { depth: '0–20 cm', moist: 26.5, fc: 32.0, wp: 12.0, rootFrac: '35%' },
              { depth: '20–50 cm', moist: 28.0, fc: 34.0, wp: 14.0, rootFrac: '40%' },
              { depth: '50–100 cm', moist: 30.5, fc: 36.0, wp: 16.0, rootFrac: '20%' },
              { depth: '100–150 cm', moist: 31.0, fc: 38.0, wp: 18.0, rootFrac: '5%' },
            ].map((l) => (
              <div key={l.depth} className="p-3 bg-slate-800/80 rounded border border-slate-700/80 text-xs font-mono">
                <div className="text-slate-400 text-[11px]">{l.depth}</div>
                <div className="text-base font-bold text-cyan-400 my-1">{l.moist}%</div>
                <div className="text-[10px] text-slate-400">FC: {l.fc}% | WP: {l.wp}%</div>
                <div className="text-[10px] text-emerald-400 mt-1">Root Root: {l.rootFrac}</div>
              </div>
            ))}
          </div>

          <div className="mt-4 p-3 bg-slate-800/50 rounded flex items-center justify-between text-xs font-mono">
            <span className="text-slate-400">Integrated Water Stress Index (θ_stress):</span>
            <span className="font-bold text-emerald-400 text-sm">0.12 (Optimal Hydration / Mild Chalk Deficit)</span>
          </div>
        </div>

        {/* 3-Layer Disease Pressure */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 mb-4">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            Probabilistic Disease Risk Engine
          </h3>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-slate-300">Botrytis Cinerea (Grey Rot)</span>
                <span className="text-amber-400 font-bold">{selectedBlock.botrytisRiskPct}%</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div className="bg-amber-500 h-full rounded-full" style={{ width: `${selectedBlock.botrytisRiskPct}%` }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-slate-300">Plasmopara viticola (Downy Mildew)</span>
                <span className="text-emerald-400 font-bold">{selectedBlock.downyRiskPct}%</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${selectedBlock.downyRiskPct}%` }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-slate-300">Erysiphe necator (Powdery Mildew)</span>
                <span className="text-emerald-400 font-bold">{selectedBlock.powderyRiskPct}%</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${selectedBlock.powderyRiskPct}%` }}></div>
              </div>
            </div>
          </div>

          <div className="mt-4 p-2.5 bg-slate-800/40 rounded text-[11px] text-slate-400 leading-relaxed">
            Disease risk is continuously updated based on leaf wetness duration, humidity thresholds, rainfall events, and canopy leaf area index (LAI).
          </div>
        </div>
      </div>
    </div>
  );
};
