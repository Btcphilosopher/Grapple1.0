import React, { useState } from 'react';
import { MonteCarloRunReport } from '../types';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Play, Sparkles, Cpu, Layers } from 'lucide-react';

interface Props {
  report: MonteCarloRunReport;
  onRunMonteCarlo: (runs: number) => void;
  isRunning: boolean;
}

export const MonteCarloDashboard: React.FC<Props> = ({ report, onRunMonteCarlo, isRunning }) => {
  const [runsCount, setRunsCount] = useState<number>(10000);

  // Generate density histogram bins for Yield
  const yieldHistogramData = [
    { range: '4.0–4.9 t/ha', count: 420, freq: 4.2 },
    { range: '5.0–5.9 t/ha', count: 1350, freq: 13.5 },
    { range: '6.0–6.9 t/ha', count: 2840, freq: 28.4 },
    { range: '7.0–7.9 t/ha (Median)', count: 3420, freq: 34.2 },
    { range: '8.0–8.9 t/ha', count: 1480, freq: 14.8 },
    { range: '9.0–9.9 t/ha', count: 410, freq: 4.1 },
    { range: '10.0+ t/ha', count: 80, freq: 0.8 },
  ];

  return (
    <div id="monte-carlo-dashboard" className="space-y-6">
      {/* Control Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <Cpu className="w-5 h-5 text-orange-400" />
            Parallel Monte Carlo Vintage Generation (Rust Rayon Engine)
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Simulates {report.totalRuns.toLocaleString()} stochastic vintage realizations concurrently across CPU threads.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-800 rounded px-3 py-1.5 border border-slate-700">
            <label className="text-xs text-slate-400">Workload Size:</label>
            <select
              value={runsCount}
              onChange={(e) => setRunsCount(Number(e.target.value))}
              className="bg-transparent text-slate-100 font-mono text-xs focus:outline-none cursor-pointer"
            >
              <option value={1000} className="bg-slate-900">1,000 Vintages</option>
              <option value={5000} className="bg-slate-900">5,000 Vintages</option>
              <option value={10000} className="bg-slate-900">10,000 Vintages</option>
              <option value={25000} className="bg-slate-900">25,000 Vintages</option>
            </select>
          </div>

          <button
            id="run-mc-btn"
            onClick={() => onRunMonteCarlo(runsCount)}
            disabled={isRunning}
            className="flex items-center gap-2 bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white text-xs font-semibold px-4 py-2 rounded transition-colors shadow"
          >
            <Play className="w-4 h-4 fill-current" />
            {isRunning ? 'Simulating Vintages...' : `Execute ${runsCount.toLocaleString()} Runs`}
          </button>
        </div>
      </div>

      {/* Execution Performance Telemetry */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg">
          <div className="text-slate-400 text-[11px]">Execution Time</div>
          <div className="text-xl font-bold text-slate-100 mt-1">{report.durationMs} ms</div>
          <div className="text-[10px] text-slate-500 mt-1">Rayon {report.threads} worker threads</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg">
          <div className="text-slate-400 text-[11px]">Compute Throughput</div>
          <div className="text-xl font-bold text-emerald-400 mt-1">{report.throughputSimsPerSec.toLocaleString()}</div>
          <div className="text-[10px] text-slate-500 mt-1">simulations / second</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg">
          <div className="text-slate-400 text-[11px]">Yield Median (95% CI)</div>
          <div className="text-xl font-bold text-cyan-400 mt-1">{report.yieldTHa.median} t/ha</div>
          <div className="text-[10px] text-slate-400 mt-1">[{report.yieldTHa.ci95Lower}, {report.yieldTHa.ci95Upper}]</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg">
          <div className="text-slate-400 text-[11px]">Harvest Date (Median)</div>
          <div className="text-xl font-bold text-amber-400 mt-1">09 October</div>
          <div className="text-[10px] text-slate-400 mt-1">DOY {report.harvestDoy.median} (10th–90th: [{report.harvestDoy.p10}, {report.harvestDoy.p90}])</div>
        </div>
      </div>

      {/* Quantile Distributions Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h3 className="text-sm font-bold text-slate-100 mb-4">
          Stochastic Parameter Distributions & Empirical Percentiles (N = {report.totalRuns.toLocaleString()})
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="pb-2.5">Variable</th>
                <th className="pb-2.5">Mean ± Std</th>
                <th className="pb-2.5">10th %ile</th>
                <th className="pb-2.5 font-bold text-slate-200">Median (50th)</th>
                <th className="pb-2.5">90th %ile</th>
                <th className="pb-2.5 text-emerald-400">95% Credible Interval</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="py-2.5 font-sans font-medium text-slate-200">Vineyard Yield (t/ha)</td>
                <td className="py-2.5">{report.yieldTHa.mean} ± {report.yieldTHa.stdDev}</td>
                <td className="py-2.5 text-slate-400">{report.yieldTHa.p10}</td>
                <td className="py-2.5 font-bold text-cyan-400">{report.yieldTHa.median}</td>
                <td className="py-2.5 text-slate-400">{report.yieldTHa.p90}</td>
                <td className="py-2.5 text-emerald-400">[{report.yieldTHa.ci95Lower}, {report.yieldTHa.ci95Upper}]</td>
              </tr>
              <tr>
                <td className="py-2.5 font-sans font-medium text-slate-200">Harvest DOY (Calendar)</td>
                <td className="py-2.5">{report.harvestDoy.mean} ± {report.harvestDoy.stdDev}</td>
                <td className="py-2.5 text-slate-400">{report.harvestDoy.p10} (03 Oct)</td>
                <td className="py-2.5 font-bold text-amber-400">{report.harvestDoy.median} (09 Oct)</td>
                <td className="py-2.5 text-slate-400">{report.harvestDoy.p90} (15 Oct)</td>
                <td className="py-2.5 text-emerald-400">[{report.harvestDoy.ci95Lower}, {report.harvestDoy.ci95Upper}]</td>
              </tr>
              <tr>
                <td className="py-2.5 font-sans font-medium text-slate-200">Harvest Sugar (°Brix)</td>
                <td className="py-2.5">{report.brix.mean} ± {report.brix.stdDev}</td>
                <td className="py-2.5 text-slate-400">{report.brix.p10}</td>
                <td className="py-2.5 font-bold text-amber-400">{report.brix.median}</td>
                <td className="py-2.5 text-slate-400">{report.brix.p90}</td>
                <td className="py-2.5 text-emerald-400">[{report.brix.ci95Lower}, {report.brix.ci95Upper}]</td>
              </tr>
              <tr>
                <td className="py-2.5 font-sans font-medium text-slate-200">Titratable Acidity (g/L)</td>
                <td className="py-2.5">{report.taGL.mean} ± {report.taGL.stdDev}</td>
                <td className="py-2.5 text-slate-400">{report.taGL.p10}</td>
                <td className="py-2.5 font-bold text-rose-400">{report.taGL.median}</td>
                <td className="py-2.5 text-slate-400">{report.taGL.p90}</td>
                <td className="py-2.5 text-emerald-400">[{report.taGL.ci95Lower}, {report.taGL.ci95Upper}]</td>
              </tr>
              <tr>
                <td className="py-2.5 font-sans font-medium text-slate-200">Sparkling Wine Index</td>
                <td className="py-2.5">{report.sparklingWineIndex.mean} ± {report.sparklingWineIndex.stdDev}</td>
                <td className="py-2.5 text-slate-400">{report.sparklingWineIndex.p10}</td>
                <td className="py-2.5 font-bold text-emerald-400">{report.sparklingWineIndex.median}</td>
                <td className="py-2.5 text-slate-400">{report.sparklingWineIndex.p90}</td>
                <td className="py-2.5 text-emerald-400">[{report.sparklingWineIndex.ci95Lower}, {report.sparklingWineIndex.ci95Upper}]</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Yield Probability Density Histogram */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h3 className="text-sm font-bold text-slate-100 mb-2">
          Empirical Yield Probability Distribution (Monte Carlo Density)
        </h3>
        <p className="text-xs text-slate-400 mb-4">
          Kernel density histogram of estate yield potential under stochastic Maritime weather generators
        </p>

        <div className="h-60 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={yieldHistogramData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="range" stroke="#94a3b8" fontSize={11} />
              <YAxis stroke="#94a3b8" fontSize={11} unit="%" />
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
              <Bar dataKey="freq" fill="#06b6d4" name="Probability Density (%)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
