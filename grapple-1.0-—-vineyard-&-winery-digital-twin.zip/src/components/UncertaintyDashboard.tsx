import React from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';
import { HelpCircle, Layers, Activity, ShieldCheck } from 'lucide-react';

export const UncertaintyDashboard: React.FC = () => {
  // Fan chart data for forward ripening Brix trajectory
  const fanChartData = [
    { day: 'DOY 275 (02 Oct)', mean: 17.2, lower95: 16.8, lower80: 17.0, upper80: 17.4, upper95: 17.6 },
    { day: 'DOY 277 (04 Oct)', mean: 17.6, lower95: 17.0, lower80: 17.3, upper80: 17.9, upper95: 18.2 },
    { day: 'DOY 279 (06 Oct)', mean: 18.0, lower95: 17.2, lower80: 17.6, upper80: 18.4, upper95: 18.8 },
    { day: 'DOY 281 (08 Oct)', mean: 18.4, lower95: 17.4, lower80: 17.9, upper80: 18.9, upper95: 19.4 },
    { day: 'DOY 283 (10 Oct)', mean: 18.8, lower95: 17.6, lower80: 18.2, upper80: 19.4, upper95: 20.0 },
    { day: 'DOY 285 (12 Oct)', mean: 19.1, lower95: 17.7, lower80: 18.4, upper80: 19.8, upper95: 20.5 },
  ];

  return (
    <div id="uncertainty-dashboard" className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-cyan-400" />
          Uncertainty Quantification & Prediction Interval Envelopes
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Probabilistic envelope projections integrating stochastic weather ensembles and Bayesian parameter variance.
        </p>
      </div>

      {/* Fan Chart: Brix Ripening Trajectory */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-100">
              Chardonnay Sugar Ripening: 80% & 95% Confidence Fan Chart
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Confidence bounds widen over forecast horizon due to weather uncertainty
            </p>
          </div>
          <span className="text-xs font-mono text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
            R-Ensemble Model
          </span>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={fanChartData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="day" stroke="#94a3b8" fontSize={11} />
              <YAxis domain={[16.0, 21.0]} stroke="#94a3b8" fontSize={11} unit="°Bx" />
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
              <Legend wrapperStyle={{ fontSize: '11px' }} />
              <Area type="monotone" dataKey="upper95" stroke="none" fill="#06b6d4" fillOpacity={0.15} name="95% Prediction Interval" />
              <Area type="monotone" dataKey="upper80" stroke="none" fill="#06b6d4" fillOpacity={0.25} name="80% Prediction Interval" />
              <Area type="monotone" dataKey="mean" stroke="#f59e0b" strokeWidth={3} fill="none" name="Point Forecast (°Brix)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Sources of Uncertainty Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg">
          <div className="text-slate-400 text-[11px]">Maritime Weather Stochasticity</div>
          <div className="text-xl font-bold text-amber-400 mt-1">54.2%</div>
          <div className="text-[10px] text-slate-500 mt-1">Dominant uncertainty driver</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg">
          <div className="text-slate-400 text-[11px]">Canopy & Vine Heterogeneity</div>
          <div className="text-xl font-bold text-slate-100 mt-1">21.8%</div>
          <div className="text-[10px] text-slate-500 mt-1">Spatial variation within blocks</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg">
          <div className="text-slate-400 text-[11px]">Parameter Estimation Variance</div>
          <div className="text-xl font-bold text-cyan-400 mt-1">14.5%</div>
          <div className="text-[10px] text-slate-500 mt-1">Bayesian MCMC posterior spread</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg">
          <div className="text-slate-400 text-[11px]">Sampling & Sensor Noise</div>
          <div className="text-xl font-bold text-emerald-400 mt-1">9.5%</div>
          <div className="text-[10px] text-slate-500 mt-1">Lab refractometer / RTD drift</div>
        </div>
      </div>
    </div>
  );
};
