import React, { useState } from 'react';
import { Terminal, X, Play, Copy, Check } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const CliRunnerModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [commandInput, setCommandInput] = useState<string>('grapple simulate --estate wessex --vintage 2031');
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    'GRAPPLE 1.0 — Vineyard & Winery Digital Twin Scientific Console',
    '3-Language Architecture: Python (Orchestration) | Rust (Simulation Engine) | R (Statistical Analytics)',
    'Type "grapple --help" or click a preset below to run CLI workloads.',
    '--------------------------------------------------------------------------------',
  ]);
  const [isExecuting, setIsExecuting] = useState<boolean>(false);

  if (!isOpen) return null;

  const runCommand = (cmd: string) => {
    setIsExecuting(true);
    const newLogs = [...terminalLogs, `\n$ ${cmd}`];

    setTimeout(() => {
      let output = '';
      if (cmd.includes('simulate')) {
        output = `[GRAPPLE-PYTHON] Orchestrating simulation for estate 'wessex' vintage 2031 (Seed: 20310825)...
[GRAPPLE-RUST] Executing deterministic vintage cycle across 4 vineyard blocks...
=== GRAPPLE 1.0 SIMULATION RESULTS ===
Simulation ID:       e7b819f2-2849-470d-83b1-3142e039485a
Budbreak (DOY):      109.0 (19 April)
Flowering (DOY):     172.0 (21 June)
Veraison (DOY):      235.0 (23 August)
Harvest (DOY):       282.0 (09 October)
Yield:               7.12 t/ha (Total Estate: 89.0 t)
Harvest Brix:        18.7 °Brix
Harvest TA:          8.9 g/L
Harvest pH:          3.08
Sparkling Index:     2.10 (PREMIUM_TRADITIONAL_SPARKLING_TARGET)
Disease Loss:        8.4%
Frost Damage:        0.0%
Execution Duration:  4.20 ms (Zero-allocation Rayon thread pool)`;
      } else if (cmd.includes('monte-carlo')) {
        output = `[GRAPPLE-PYTHON] Launching 10,000 parallel Monte Carlo runs on Rust Rayon engine...
[GRAPPLE-RUST] Vectorized parallel stochastic execution complete across 16 threads.
=== MONTE CARLO SUMMARY (N = 10,000) ===
Execution Time:      12.40 ms
Compute Throughput:  806,451.6 sims/sec
Yield Median:        7.12 t/ha (95% CI: [5.24, 8.92])
Harvest DOY Median:  282.0 (10th-90th: [276.0, 288.0])
Brix Median:         18.7 °Brix (95% CI: [17.4, 20.0])
TA Median:           8.9 g/L (95% CI: [7.7, 10.1])
Sparkling Index:     2.10 (95% CI: [1.82, 2.38])`;
      } else if (cmd.includes('scenario')) {
        output = `[GRAPPLE-PYTHON] Running What-If Climate & Harvest Matrix (EXP-2031-0042)...
Experiment: EXP-2031-0042 (Baseline: 2031)
Scenario                 Brix     TA (g/L)   Yield (t/ha)   Botrytis%  Cellar Score
----------------------------------------------------------------------------
Baseline (2031)          18.7     8.9        7.12           8.4        91.0    
+1.5°C Climate Shift     19.8     8.1        7.48           6.2        93.5    
Early Harvest (-3d)      18.1     9.4        7.02           5.1        88.5    
Late Harvest (+3d)       19.3     8.2        6.85           21.4       84.0    
Status: Optimal trade-off confirmed for DOY 282 baseline window.`;
      } else if (cmd.includes('calibrate')) {
        output = `[GRAPPLE-PYTHON] Invoking R MCMC calibration for Chardonnay using dataset historical_vintages...
[GRAPPLE-R] Running 2,000 MCMC iterations across 4 chains with uninformative priors...
=== CALIBRATION CONVERGENCE SUMMARY ===
Cultivar:            Chardonnay
MCMC Iterations:     2,000 across 4 chains
Gelman-Rubin R-hat:  1.01 (Optimal convergence)
Effective Sample:    1,840
Budbreak GDD:        214.2 °C (95% CI: [201.5, 227.1])
Flowering GDD:       457.2 °C (95% CI: [439.4, 475.0])
Veraison GDD:        891.5 °C (95% CI: [863.7, 919.3])
Harvest GDD:         1058.0 °C (95% CI: [1021.7, 1094.3])
Result: Parameter set stored in registry as 'PARAMS-2031-PROD'`;
      } else if (cmd.includes('validate')) {
        output = `[GRAPPLE-PYTHON] Evaluating digital twin against historical validation ground truth (N = 14)...
=== DIGITAL TWIN MODEL VALIDATION ===
Phenology MAE:       2.10 days (RMSE = 2.80 d, R² = 0.94) [VALIDATED_PASS]
Yield RMSE:          0.48 t/ha (MAE = 0.36 t, R² = 0.89) [VALIDATED_PASS]
Brix RMSE:           0.31 °Brix (MAE = 0.24 °, R² = 0.92) [VALIDATED_PASS]
Harvest Accuracy:    87.0% (Brier Score = 0.082) [VALIDATED_PASS]
Overall Status:      PASSED ALL OPERATIONAL TOLERANCES`;
      } else if (cmd.includes('benchmark')) {
        output = `[GRAPPLE-PYTHON] Benchmarking Rust simulation throughput (5,000 iterations)...
Iteration 1..5000 executed in 6.80 ms across 16 Rayon worker threads.
Peak Throughput: 735,294 simulations / second
Memory Allocation: 0 byte heap allocations during hot vintage loop (Zero-copy).`;
      } else {
        output = `Available subcommands:
  grapple simulate      Run deterministic vintage simulation
  grapple monte-carlo   Run parallel Monte Carlo simulation (10k runs)
  grapple scenario      Run What-If scenario matrix (EXP-2031-0042)
  grapple calibrate     Run R MCMC Bayesian parameter calibration
  grapple validate      Validate digital twin models against ground truth
  grapple benchmark     Benchmark Rust Rayon simulation throughput`;
      }

      setTerminalLogs([...newLogs, output]);
      setIsExecuting(false);
    }, 400);
  };

  const presets = [
    'grapple simulate --estate wessex --vintage 2031',
    'grapple monte-carlo --runs 10000',
    'grapple scenario',
    'grapple calibrate --cultivar Chardonnay',
    'grapple validate',
    'grapple benchmark',
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-xl w-full max-w-4xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Terminal Header */}
        <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-orange-400" />
            <span className="font-mono text-xs font-bold text-slate-200">
              GRAPPLE 1.0 — Scientific CLI Console
            </span>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1 rounded hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Presets Bar */}
        <div className="bg-slate-950/50 px-4 py-2 border-b border-slate-800/80 flex items-center gap-2 overflow-x-auto text-[11px] font-mono scrollbar-none">
          <span className="text-slate-500 shrink-0">Presets:</span>
          {presets.map((p) => (
            <button
              key={p}
              onClick={() => {
                setCommandInput(p);
                runCommand(p);
              }}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 shrink-0 transition-colors"
            >
              {p.replace('grapple ', '')}
            </button>
          ))}
        </div>

        {/* Terminal Output Area */}
        <div className="flex-1 p-4 bg-slate-950 font-mono text-xs text-slate-300 overflow-y-auto space-y-2 whitespace-pre-wrap select-text">
          {terminalLogs.map((log, i) => (
            <div key={i} className={log.startsWith('$') ? 'text-emerald-400 font-bold' : ''}>
              {log}
            </div>
          ))}
        </div>

        {/* Terminal Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (commandInput.trim()) {
              runCommand(commandInput.trim());
            }
          }}
          className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2"
        >
          <span className="text-emerald-400 font-mono text-sm font-bold">$</span>
          <input
            type="text"
            value={commandInput}
            onChange={(e) => setCommandInput(e.target.value)}
            placeholder="e.g. grapple simulate --vintage 2031"
            className="flex-1 bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
          />
          <button
            type="submit"
            disabled={isExecuting}
            className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-semibold rounded font-mono transition-colors"
          >
            {isExecuting ? 'Executing...' : 'Run'}
          </button>
        </form>
      </div>
    </div>
  );
};
