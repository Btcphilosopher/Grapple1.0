import React, { useState } from 'react';
import { INITIAL_TANKS, INITIAL_SENSORS } from '../data/mockDigitalTwinData';
import { SensorTelemetry } from '../types';
import { Radio, AlertOctagon, CheckCircle2, RefreshCw, Gauge, Waves, ShieldAlert, Cpu } from 'lucide-react';

export const WineryTelemetryDashboard: React.FC = () => {
  const [sensors, setSensors] = useState<SensorTelemetry[]>(INITIAL_SENSORS);
  const [isFixingPump, setIsFixingPump] = useState<boolean>(false);

  const handleFixPump = () => {
    setIsFixingPump(true);
    setTimeout(() => {
      setSensors((prev) =>
        prev.map((s) =>
          s.id === 'S-03'
            ? {
                ...s,
                status: 'GOOD',
                value: 1.2,
                anomalyScore: 0.05,
                message: undefined,
              }
            : s
        )
      );
      setIsFixingPump(false);
    }, 1000);
  };

  const hasAnomaly = sensors.some((s) => s.status === 'ANOMALY_DETECTED');

  return (
    <div id="winery-telemetry-dashboard" className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-xs text-slate-400 font-mono">LIVE CELLAR & WINERY DIGITAL TWIN</span>
          </div>
          <h2 className="text-lg font-bold text-slate-100 mt-1 flex items-center gap-2">
            <Radio className="w-5 h-5 text-emerald-400" />
            IoT Sensor Telemetry Stream & Real-Time Anomaly Detection
          </h2>
        </div>

        {hasAnomaly ? (
          <div className="flex items-center gap-2 bg-rose-950/80 border border-rose-800 px-3 py-1.5 rounded text-rose-300 text-xs font-semibold">
            <AlertOctagon className="w-4 h-4 text-rose-400" />
            EQUIPMENT ANOMALY DETECTED
          </div>
        ) : (
          <div className="flex items-center gap-2 bg-emerald-950/60 border border-emerald-800 px-3 py-1.5 rounded text-emerald-400 text-xs font-semibold">
            <CheckCircle2 className="w-4 h-4" />
            ALL SENSORS & EQUIPMENT NOMINAL
          </div>
        )}
      </div>

      {/* Live Sensors Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sensors.map((s) => (
          <div
            key={s.id}
            className={`p-4 rounded-lg border font-mono text-xs transition-colors ${
              s.status === 'ANOMALY_DETECTED'
                ? 'bg-rose-950/30 border-rose-700/80'
                : 'bg-slate-900 border-slate-800'
            }`}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="font-bold text-slate-200">{s.sensorId}</span>
              <span
                className={`px-1.5 py-0.5 rounded text-[10px] ${
                  s.status === 'ANOMALY_DETECTED'
                    ? 'bg-rose-950 text-rose-400 border border-rose-800'
                    : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                }`}
              >
                {s.status}
              </span>
            </div>

            <div className="mt-3 space-y-1 text-slate-300">
              <div className="text-[11px] text-slate-400 font-sans">{s.location}</div>
              <div className="flex items-baseline gap-2 pt-1">
                <span className="text-xl font-bold text-slate-100">{s.value}</span>
                <span className="text-slate-400">{s.unit}</span>
              </div>
              <div className="text-[10px] text-slate-500">Anomaly Confidence: {(s.anomalyScore * 100).toFixed(0)}%</div>
            </div>

            {s.message && (
              <div className="mt-3 p-2 bg-rose-950/60 border border-rose-900 rounded text-[11px] text-rose-300 font-sans">
                {s.message}
                <button
                  onClick={handleFixPump}
                  disabled={isFixingPump}
                  className="mt-2 w-full py-1 bg-rose-700 hover:bg-rose-600 disabled:opacity-50 text-white font-semibold rounded text-xs transition-colors"
                >
                  {isFixingPump ? 'Executing Pump Flush Protocol...' : 'Run Auto-Degas & Impeller Cycle'}
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Cellar Tank Physical Twin Layout */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h3 className="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
          <Waves className="w-4 h-4 text-cyan-400" />
          Cellar Tank Fleet — Real-Time Volume & Cooling Jackets
        </h3>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {INITIAL_TANKS.map((t) => {
            const fillPct = Math.round((t.volumeL / t.capacityL) * 100);
            return (
              <div key={t.id} className="p-3 bg-slate-800/80 rounded-lg border border-slate-700 font-mono text-xs">
                <div className="flex justify-between items-center text-[11px] text-slate-300 font-bold mb-1">
                  <span>{t.id}</span>
                  <span className={t.coolingActive ? 'text-cyan-400' : 'text-slate-500'}>
                    {t.coolingActive ? '❄ Cooling' : 'Off'}
                  </span>
                </div>

                {/* Tank Visual Vessel */}
                <div className="h-28 bg-slate-950 rounded border border-slate-700 flex flex-col justify-end p-1 relative overflow-hidden my-2">
                  <div
                    className={`w-full rounded transition-all duration-500 ${
                      t.stuck ? 'bg-amber-600/80' : 'bg-emerald-600/80'
                    }`}
                    style={{ height: `${fillPct}%` }}
                  ></div>
                  <div className="absolute inset-0 flex items-center justify-center font-bold text-slate-100 text-xs drop-shadow">
                    {fillPct}%
                  </div>
                </div>

                <div className="text-[10px] text-slate-400 text-center">
                  {t.volumeL.toLocaleString()} / {t.capacityL.toLocaleString()} L
                </div>
                <div className="text-[10px] text-center text-slate-300 font-bold mt-0.5">
                  {t.tempC} °C | {t.ethanolPct}% ABV
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
