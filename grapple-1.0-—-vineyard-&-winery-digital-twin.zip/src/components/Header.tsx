import React from 'react';
import { ActiveTab, EngineStats } from '../types';
import { Cpu, FlaskConical, Layers, Activity, Play, Terminal, Database } from 'lucide-react';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  engineStats: EngineStats;
  vintage: number;
  setVintage: (v: number) => void;
  seed: number;
  setSeed: (s: number) => void;
  onOpenCli: () => void;
  onRunSimulation: () => void;
  isSimulating: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  engineStats,
  vintage,
  setVintage,
  seed,
  setSeed,
  onOpenCli,
  onRunSimulation,
  isSimulating,
}) => {
  const tabs: { id: ActiveTab; label: string }[] = [
    { id: 'COMPUTE', label: 'COMPUTE' },
    { id: 'MODELS', label: 'MODELS' },
    { id: 'EXPERIMENTS', label: 'EXPERIMENTS' },
    { id: 'MONTE_CARLO', label: 'MONTE CARLO' },
    { id: 'CALIBRATION', label: 'CALIBRATION' },
    { id: 'STATISTICS', label: 'STATISTICS' },
    { id: 'UNCERTAINTY', label: 'UNCERTAINTY' },
    { id: 'VALIDATION', label: 'VALIDATION' },
    { id: 'WINERY_TWIN', label: 'WINERY TWIN' },
  ];

  return (
    <header id="grapple-header" className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-50">
      {/* Top Telemetry Bar */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 text-xs">
        {/* Brand & Architecture */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="font-bold tracking-wider text-sm text-slate-100">GRAPPLE 1.0</span>
          </div>
          <span className="text-slate-500">|</span>
          <div className="flex items-center gap-2 text-slate-300 font-mono">
            <span className="px-1.5 py-0.5 rounded bg-blue-950/80 text-blue-400 border border-blue-800/50">Python (Orchestrator)</span>
            <span className="text-slate-600">→</span>
            <span className="px-1.5 py-0.5 rounded bg-orange-950/80 text-orange-400 border border-orange-800/50">Rust (Engine)</span>
            <span className="text-slate-600">→</span>
            <span className="px-1.5 py-0.5 rounded bg-cyan-950/80 text-cyan-400 border border-cyan-800/50">R (Analytics)</span>
          </div>
        </div>

        {/* Live Engine Throughput Metrics */}
        <div className="flex items-center gap-4 font-mono text-slate-400">
          <div className="flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-orange-400" />
            <span>Rust: <strong className="text-slate-200">{engineStats.rustSimsPerSec.toLocaleString()}</strong> sims/s</span>
          </div>
          <div className="flex items-center gap-1.5">
            <FlaskConical className="w-3.5 h-3.5 text-cyan-400" />
            <span>R: <strong className="text-slate-200">{engineStats.rModelsRunning}</strong> active models</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Database className="w-3.5 h-3.5 text-emerald-400" />
            <span>Parquet: <strong className="text-slate-200">{engineStats.parquetCacheMb}</strong> MB</span>
          </div>
        </div>

        {/* Quick Controls */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-slate-800/90 rounded px-2 py-1 border border-slate-700">
            <label className="text-slate-400 text-[11px]">Vintage:</label>
            <select
              id="vintage-select"
              value={vintage}
              onChange={(e) => setVintage(Number(e.target.value))}
              className="bg-transparent text-slate-100 font-mono text-xs focus:outline-none cursor-pointer"
            >
              <option value={2029} className="bg-slate-900">2029</option>
              <option value={2030} className="bg-slate-900">2030</option>
              <option value={2031} className="bg-slate-900">2031 (Current)</option>
              <option value={2032} className="bg-slate-900">2032 (Forecast)</option>
              <option value={2045} className="bg-slate-900">2045 (+1.5°C Climate)</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-800/90 rounded px-2 py-1 border border-slate-700">
            <label className="text-slate-400 text-[11px]">Seed:</label>
            <input
              id="seed-input"
              type="number"
              value={seed}
              onChange={(e) => setSeed(Number(e.target.value))}
              className="w-20 bg-transparent text-slate-100 font-mono text-xs focus:outline-none"
            />
          </div>

          <button
            id="run-sim-btn"
            onClick={onRunSimulation}
            disabled={isSimulating}
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-semibold px-3 py-1 rounded transition-colors"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            {isSimulating ? 'Computing...' : 'Run Simulation'}
          </button>

          <button
            id="cli-trigger-btn"
            onClick={onOpenCli}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-2.5 py-1 rounded border border-slate-700 transition-colors"
            title="Open Interactive GRAPPLE CLI Terminal"
          >
            <Terminal className="w-3.5 h-3.5 text-orange-400" />
            <span>CLI</span>
          </button>
        </div>
      </div>

      {/* Main Tab Navigation */}
      <div className="max-w-7xl mx-auto px-4 flex items-center gap-1 overflow-x-auto scrollbar-none py-1.5">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            id={`tab-btn-${tab.id.toLowerCase()}`}
            onClick={() => setActiveTab(tab.id)}
            className={`px-3.5 py-1.5 text-xs font-medium rounded transition-all whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-slate-800 text-emerald-400 border border-slate-700 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>
    </header>
  );
};
