import React, { useState } from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';
import { RefreshCw, CheckCircle2, SlidersHorizontal, BookOpen, Layers } from 'lucide-react';

export const CalibrationDashboard: React.FC = () => {
  const [activeVersion, setActiveVersion] = useState<string>('PARAMS-2031-PROD');
  const [isCalibrating, setIsCalibrating] = useState<boolean>(false);

  // MCMC Prior vs Posterior distribution curve for Chardonnay Harvest GDD
  const mcmcCurveData = [
    { gdd: 960, Prior: 0.005, Posterior: 0.001 },
    { gdd: 980, Prior: 0.012, Posterior: 0.004 },
    { gdd: 1000, Prior: 0.025, Posterior: 0.018 },
    { gdd: 1020, Prior: 0.038, Posterior: 0.045 },
    { gdd: 1040, Prior: 0.045, Posterior: 0.088 },
    { gdd: 1060, Prior: 0.042, Posterior: 0.095 }, // Peak posterior mean ~1058 GDD
    { gdd: 1080, Prior: 0.032, Posterior: 0.062 },
    { gdd: 1100, Prior: 0.020, Posterior: 0.022 },
    { gdd: 1120, Prior: 0.010, Posterior: 0.005 },
    { gdd: 1140, Prior: 0.004, Posterior: 0.001 },
  ];

  const handleRunMcmc = () => {
    setIsCalibrating(true);
    setTimeout(() => {
      setIsCalibrating(false);
      setActiveVersion('PARAMS-2032-MCMC-CANDIDATE');
    }, 1200);
  };

  return (
    <div id="calibration-dashboard" className="space-y-6">
      {/* Feedback Loop Explanation Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <RefreshCw className={`w-5 h-5 text-cyan-400 ${isCalibrating ? 'animate-spin' : ''}`} />
              Digital Twin Calibration Feedback Loop (Bayesian MCMC)
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Field observations are ingested by R (<code className="text-cyan-400">grappleR</code>) to compute Bayesian posterior parameter updates and re-seed the Rust engine.
            </p>
          </div>

          <button
            onClick={handleRunMcmc}
            disabled={isCalibrating}
            className="flex items-center gap-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-xs font-semibold px-4 py-2 rounded transition-colors shadow"
          >
            <SlidersHorizontal className="w-4 h-4" />
            {isCalibrating ? 'Sampling MCMC Chains (2,000 iters)...' : 'Run R Bayesian Calibration'}
          </button>
        </div>
      </div>

      {/* Prior vs Posterior GDD Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-100">
                Chardonnay Harvest GDD: Prior vs. MCMC Posterior Density
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Posterior Mean: 1058.0 °C (95% CI: [1021.7, 1094.3])
              </p>
            </div>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
              R-hat = 1.01
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mcmcCurveData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="gdd" stroke="#94a3b8" fontSize={11} unit="°C" />
                <YAxis stroke="#94a3b8" fontSize={11} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Line type="monotone" dataKey="Prior" stroke="#64748b" strokeDasharray="4 4" strokeWidth={2} name="Uninformative Prior" />
                <Line type="monotone" dataKey="Posterior" stroke="#06b6d4" strokeWidth={3} name="MCMC Posterior (Chardonnay)" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Diagnostics & Convergence Summary */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h3 className="text-sm font-bold text-slate-100 mb-4">
            MCMC Sampling Diagnostics & Chain Convergence
          </h3>

          <div className="grid grid-cols-2 gap-4 font-mono text-xs mb-4">
            <div className="p-3 bg-slate-800/80 rounded border border-slate-700">
              <div className="text-slate-400 text-[11px]">Gelman-Rubin R-hat</div>
              <div className="text-lg font-bold text-emerald-400 mt-1">1.01</div>
              <div className="text-[10px] text-slate-500">Target &lt; 1.05 (PASSED)</div>
            </div>

            <div className="p-3 bg-slate-800/80 rounded border border-slate-700">
              <div className="text-slate-400 text-[11px]">Effective Sample Size (ESS)</div>
              <div className="text-lg font-bold text-slate-100 mt-1">1,840</div>
              <div className="text-[10px] text-slate-500">Across 4 independent chains</div>
            </div>

            <div className="p-3 bg-slate-800/80 rounded border border-slate-700">
              <div className="text-slate-400 text-[11px]">Acceptance Rate</div>
              <div className="text-lg font-bold text-slate-100 mt-1">28.4%</div>
              <div className="text-[10px] text-slate-500">Target 23–35% (Optimal)</div>
            </div>

            <div className="p-3 bg-slate-800/80 rounded border border-slate-700">
              <div className="text-slate-400 text-[11px]">Historical Calibration Vintages</div>
              <div className="text-lg font-bold text-cyan-400 mt-1">14 Vintages</div>
              <div className="text-[10px] text-slate-500">2017–2030 English dataset</div>
            </div>
          </div>

          <div className="p-3 bg-slate-800/40 rounded text-[11px] text-slate-300 space-y-1">
            <div className="font-semibold text-slate-200">Cultivar GDD Posterior Thresholds:</div>
            <div>• Budbreak: <strong className="text-slate-100">214.2 °C</strong> (95% CI: [201.5, 227.1])</div>
            <div>• Flowering: <strong className="text-slate-100">457.2 °C</strong> (95% CI: [439.4, 475.0])</div>
            <div>• Veraison: <strong className="text-slate-100">891.5 °C</strong> (95% CI: [863.7, 919.3])</div>
            <div>• Harvest: <strong className="text-slate-100">1058.0 °C</strong> (95% CI: [1021.7, 1094.3])</div>
          </div>
        </div>
      </div>

      {/* Parameter Version Manager */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h3 className="text-sm font-bold text-slate-100 mb-3">
          Model Parameter Version Registry
        </h3>

        <div className="space-y-3 font-mono text-xs">
          {[
            {
              id: 'PARAMS-2032-MCMC-CANDIDATE',
              label: 'PARAMS-2032-MCMC-CANDIDATE (Proposed Post-MCMC Update)',
              date: 'Generated 2 mins ago',
              status: 'CANDIDATE',
              desc: 'Refined with latest warm September ripening observations',
            },
            {
              id: 'PARAMS-2031-PROD',
              label: 'PARAMS-2031-PROD (Authoritative Active Baseline)',
              date: 'Deployed 15 Aug 2031',
              status: 'ACTIVE_PROD',
              desc: 'Validated across Wessex Chalk terroir ground truth',
            },
            {
              id: 'PARAMS-2030-HISTORIC',
              label: 'PARAMS-2030-HISTORIC (Archival Standard)',
              date: 'Deployed 01 Oct 2030',
              status: 'ARCHIVED',
              desc: 'Cool wet maritime season calibration parameters',
            },
          ].map((v) => (
            <div
              key={v.id}
              className={`p-3 rounded border flex flex-wrap items-center justify-between gap-4 transition-colors ${
                activeVersion === v.id
                  ? 'bg-slate-800/90 border-cyan-500/80 shadow-sm'
                  : 'bg-slate-800/40 border-slate-700/60'
              }`}
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-100">{v.label}</span>
                  {activeVersion === v.id && (
                    <span className="px-2 py-0.5 text-[10px] bg-emerald-950 text-emerald-400 rounded border border-emerald-800">
                      CURRENT ENGINE STATE
                    </span>
                  )}
                </div>
                <div className="text-[11px] text-slate-400 font-sans mt-0.5">{v.desc} — {v.date}</div>
              </div>

              {activeVersion !== v.id ? (
                <button
                  onClick={() => setActiveVersion(v.id)}
                  className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs rounded transition-colors"
                >
                  Deploy to Rust Engine
                </button>
              ) : (
                <span className="flex items-center gap-1 text-emerald-400 text-xs font-semibold">
                  <CheckCircle2 className="w-4 h-4" /> Deployed
                </span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
