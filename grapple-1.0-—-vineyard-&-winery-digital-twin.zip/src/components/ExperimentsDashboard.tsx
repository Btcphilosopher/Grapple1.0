import React from 'react';
import { SCENARIOS_DATA } from '../data/mockDigitalTwinData';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';
import { GitBranch, Sliders, ArrowUpRight, ShieldCheck, Flame } from 'lucide-react';

export const ExperimentsDashboard: React.FC = () => {
  const sensitivityData = [
    { factor: 'Season Mean Temp (°C)', yieldImpact: 42, brixImpact: 51 },
    { factor: 'Spring Frost Occurrence', yieldImpact: 28, brixImpact: 6 },
    { factor: 'Canopy Shading Coeff', yieldImpact: 14, brixImpact: 22 },
    { factor: 'Soil Water Stress', yieldImpact: 18, brixImpact: 15 },
    { factor: 'August Rainfall (mm)', yieldImpact: 8, brixImpact: 12 },
  ];

  return (
    <div id="experiments-dashboard" className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 text-[10px] font-mono bg-blue-950 text-blue-400 border border-blue-800 rounded">
                EXPERIMENT EXP-2031-0042
              </span>
              <span className="text-xs text-slate-400">Baseline Vintage: 2031</span>
            </div>
            <h2 className="text-lg font-bold text-slate-100 mt-1 flex items-center gap-2">
              <GitBranch className="w-5 h-5 text-purple-400" />
              What-If Scenario Comparison & Climate Sensitivity Engine
            </h2>
          </div>
          <div className="text-right text-xs font-mono text-slate-400">
            <div>Engine: <strong>Rust Parallel State Branching</strong></div>
            <div>Evaluation: <strong>R Multi-Attribute Decision Model</strong></div>
          </div>
        </div>
      </div>

      {/* Scenario Comparison Table (Section 70 of prompt) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h3 className="text-sm font-bold text-slate-100 mb-4">
          Scenario Outcome Matrix: Baseline vs Climate vs Harvest Offsets
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="pb-3 font-sans">Scenario</th>
                <th className="pb-3 text-center">Harvest (DOY)</th>
                <th className="pb-3 text-center">Brix (°Bx)</th>
                <th className="pb-3 text-center">TA (g/L)</th>
                <th className="pb-3 text-center">Yield (t/ha)</th>
                <th className="pb-3 text-center">Botrytis Risk</th>
                <th className="pb-3 text-center">Sparkling Index</th>
                <th className="pb-3 text-right text-emerald-400">Cellar Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {SCENARIOS_DATA.map((s, idx) => (
                <tr key={s.name} className={idx === 0 ? 'bg-slate-800/30' : ''}>
                  <td className="py-3 font-sans">
                    <div className="font-semibold text-slate-100">{s.name}</div>
                    <div className="text-[10px] text-slate-400 font-normal">{s.description}</div>
                  </td>
                  <td className="py-3 text-center font-bold text-amber-400">DOY {s.harvestDoy}</td>
                  <td className="py-3 text-center text-slate-100">{s.harvestBrix}</td>
                  <td className="py-3 text-center text-slate-100">{s.harvestTaGL}</td>
                  <td className="py-3 text-center text-cyan-400 font-bold">{s.yieldTHa}</td>
                  <td className="py-3 text-center">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                      s.diseaseLossPct > 15
                        ? 'bg-rose-950 text-rose-400 border border-rose-800'
                        : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    }`}>
                      {s.diseaseLossPct}%
                    </span>
                  </td>
                  <td className="py-3 text-center text-emerald-400">{s.sparklingIndex}</td>
                  <td className="py-3 text-right">
                    <span className="px-2 py-1 bg-emerald-950 text-emerald-400 font-bold text-sm rounded border border-emerald-800">
                      {s.cellarScore} / 100
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Global Sensitivity Analysis (Tornado Ranking) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              Global Sensitivity Analysis (Sobol / Morris Variance Decomposition)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Identifies which physiological and climatic variables exert the highest impact on Yield and Ripening
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">Total Variance Explained: 94.2%</span>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={sensitivityData}
              layout="vertical"
              margin={{ top: 5, right: 20, bottom: 5, left: 100 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis type="number" stroke="#94a3b8" fontSize={11} unit="%" />
              <YAxis dataKey="factor" type="category" stroke="#94a3b8" fontSize={11} width={130} />
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
              <Legend wrapperStyle={{ fontSize: '11px' }} />
              <Bar dataKey="yieldImpact" fill="#06b6d4" name="Yield Variance Contribution (%)" />
              <Bar dataKey="brixImpact" fill="#f59e0b" name="Harvest Brix Variance Contribution (%)" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
