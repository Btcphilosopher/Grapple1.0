import React, { useState, useEffect } from 'react';
import { ActiveTab, EngineStats, BlockState, MonteCarloRunReport } from './types';
import { INITIAL_BLOCKS } from './data/mockDigitalTwinData';
import { Header } from './components/Header';
import { ComputeDashboard } from './components/ComputeDashboard';
import { ModelsDashboard } from './components/ModelsDashboard';
import { MonteCarloDashboard } from './components/MonteCarloDashboard';
import { ExperimentsDashboard } from './components/ExperimentsDashboard';
import { CalibrationDashboard } from './components/CalibrationDashboard';
import { StatisticsDashboard } from './components/StatisticsDashboard';
import { UncertaintyDashboard } from './components/UncertaintyDashboard';
import { ValidationDashboard } from './components/ValidationDashboard';
import { WineryTelemetryDashboard } from './components/WineryTelemetryDashboard';
import { CliRunnerModal } from './components/CliRunnerModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('COMPUTE');
  const [vintage, setVintage] = useState<number>(2031);
  const [seed, setSeed] = useState<number>(20310825);
  const [isCliOpen, setIsCliOpen] = useState<boolean>(false);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  // High-performance engine stats
  const [engineStats, setEngineStats] = useState<EngineStats>({
    rustCpuUsagePct: 14.5,
    rustThreads: 16,
    rustSimsPerSec: 742500,
    rustActiveJobs: 0,
    rustMemoryMb: 64.2,
    rModelsRunning: 4,
    rDatasets: 14,
    rForecasts: 14,
    crossLangLatencyMs: 0.12,
    parquetCacheMb: 128.5,
  });

  const [blocks, setBlocks] = useState<BlockState[]>(INITIAL_BLOCKS);

  // Initial Monte Carlo report
  const [mcReport, setMcReport] = useState<MonteCarloRunReport>({
    totalRuns: 10000,
    durationMs: 12.4,
    throughputSimsPerSec: 806451.6,
    threads: 16,
    yieldTHa: {
      mean: 7.12,
      median: 7.12,
      stdDev: 0.82,
      p10: 6.08,
      p25: 6.55,
      p75: 7.68,
      p90: 8.15,
      ci95Lower: 5.24,
      ci95Upper: 8.92,
    },
    harvestDoy: {
      mean: 282.0,
      median: 282.0,
      stdDev: 4.2,
      p10: 276.0,
      p25: 279.0,
      p75: 285.0,
      p90: 288.0,
      ci95Lower: 273.5,
      ci95Upper: 290.5,
    },
    brix: {
      mean: 18.7,
      median: 18.7,
      stdDev: 0.65,
      p10: 17.8,
      p25: 18.2,
      p75: 19.1,
      p90: 19.5,
      ci95Lower: 17.4,
      ci95Upper: 20.0,
    },
    taGL: {
      mean: 8.9,
      median: 8.9,
      stdDev: 0.58,
      p10: 8.1,
      p25: 8.5,
      p75: 9.3,
      p90: 9.6,
      ci95Lower: 7.7,
      ci95Upper: 10.1,
    },
    sparklingWineIndex: {
      mean: 2.10,
      median: 2.10,
      stdDev: 0.14,
      p10: 1.92,
      p25: 2.01,
      p75: 2.19,
      p90: 2.28,
      ci95Lower: 1.82,
      ci95Upper: 2.38,
    },
    distributionBins: [],
  });

  // Simulated live background clock fluctuation
  useEffect(() => {
    const interval = setInterval(() => {
      setEngineStats((prev) => ({
        ...prev,
        rustCpuUsagePct: +(12.0 + Math.random() * 8.0).toFixed(1),
        crossLangLatencyMs: +(0.10 + Math.random() * 0.05).toFixed(2),
      }));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleRunSimulation = () => {
    setIsSimulating(true);
    setEngineStats((prev) => ({ ...prev, rustCpuUsagePct: 88.0, rustActiveJobs: 1 }));

    setTimeout(() => {
      // Perturb block ripening slightly based on seed
      setBlocks((prev) =>
        prev.map((b) => {
          const deltaBrix = +((Math.random() - 0.5) * 0.4).toFixed(1);
          const newBrix = Math.max(16.0, +(b.brix + deltaBrix).toFixed(1));
          const newTa = Math.max(6.0, +(b.taGL - deltaBrix * 0.8).toFixed(1));
          return {
            ...b,
            brix: newBrix,
            taGL: newTa,
            ph: +(2.75 + 0.05 * newBrix - 0.04 * newTa).toFixed(2),
          };
        })
      );
      setIsSimulating(false);
      setEngineStats((prev) => ({ ...prev, rustCpuUsagePct: 15.0, rustActiveJobs: 0 }));
    }, 600);
  };

  const handleRunMonteCarlo = (runs: number) => {
    setIsSimulating(true);
    setEngineStats((prev) => ({ ...prev, rustCpuUsagePct: 96.0, rustActiveJobs: 1 }));

    setTimeout(() => {
      const dur = +(8.0 + (runs / 10000) * 4.5).toFixed(1);
      const tp = +((runs / (dur / 1000))).toFixed(1);

      setMcReport((prev) => ({
        ...prev,
        totalRuns: runs,
        durationMs: dur,
        throughputSimsPerSec: tp,
      }));

      setIsSimulating(false);
      setEngineStats((prev) => ({
        ...prev,
        rustCpuUsagePct: 14.0,
        rustActiveJobs: 0,
        rustSimsPerSec: tp,
      }));
    }, 800);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Global Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        engineStats={engineStats}
        vintage={vintage}
        setVintage={setVintage}
        seed={seed}
        setSeed={setSeed}
        onOpenCli={() => setIsCliOpen(true)}
        onRunSimulation={handleRunSimulation}
        isSimulating={isSimulating}
      />

      {/* Main Tab Content View */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        {activeTab === 'COMPUTE' && (
          <ComputeDashboard
            engineStats={engineStats}
            onBenchmark={() => handleRunMonteCarlo(10000)}
          />
        )}

        {activeTab === 'MODELS' && <ModelsDashboard blocks={blocks} />}

        {activeTab === 'MONTE_CARLO' && (
          <MonteCarloDashboard
            report={mcReport}
            onRunMonteCarlo={handleRunMonteCarlo}
            isRunning={isSimulating}
          />
        )}

        {activeTab === 'EXPERIMENTS' && <ExperimentsDashboard />}

        {activeTab === 'CALIBRATION' && <CalibrationDashboard />}

        {activeTab === 'STATISTICS' && <StatisticsDashboard />}

        {activeTab === 'UNCERTAINTY' && <UncertaintyDashboard />}

        {activeTab === 'VALIDATION' && <ValidationDashboard />}

        {activeTab === 'WINERY_TWIN' && <WineryTelemetryDashboard />}
      </main>

      {/* CLI Runner Modal */}
      <CliRunnerModal isOpen={isCliOpen} onClose={() => setIsCliOpen(false)} />

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-3 text-center text-xs text-slate-500 font-mono">
        GRAPPLE 1.0 — English Vineyard & Winery Digital Twin (Rust + R + Python) • Wessex Chalk Downland Estate
      </footer>
    </div>
  );
}
