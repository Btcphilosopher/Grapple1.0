#!/usr/bin/env bash
set -e

echo "=== GRAPPLE 1.0 SCIENTIFIC BENCHMARK SUITE ==="
echo "Testing Rust simulation engine parallel performance across Rayon threads..."

# 1. 100 Vintages
python3 -m grapple.cli.main benchmark --iterations 100

# 2. 1,000 Vintages
python3 -m grapple.cli.main benchmark --iterations 1000

# 3. 10,000 Vintages
python3 -m grapple.cli.main benchmark --iterations 10000

echo "=== BENCHMARKS COMPLETE ==="
