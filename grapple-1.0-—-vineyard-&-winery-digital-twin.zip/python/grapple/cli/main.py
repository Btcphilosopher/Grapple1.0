import argparse
import sys
import json
from grapple.core.engine_bridge import RustEngineBridge, RAnalyticsBridge
from grapple.core.orchestrator import GrappleOrchestrator

def main():
    parser = argparse.ArgumentParser(
        prog="grapple",
        description="GRAPPLE 1.0 — Vineyard & Winery Digital Twin Orchestrator CLI"
    )
    subparsers = parser.add_subparsers(dest="command", help="Available subcommands")

    # simulate
    sim_parser = subparsers.add_parser("simulate", help="Run deterministic simulation")
    sim_parser.add_argument("--estate", default="wessex", help="Estate identifier")
    sim_parser.add_argument("--vintage", type=int, default=2031, help="Vintage year")
    sim_parser.add_argument("--seed", type=int, default=20310825, help="Simulation seed")
    sim_parser.add_argument("--temp-delta", type=float, default=0.0, help="Temperature delta °C")

    # scenario
    scen_parser = subparsers.add_parser("scenario", help="Run What-If scenario matrix")
    scen_parser.add_argument("--seed", type=int, default=20310825, help="Simulation seed")

    # monte-carlo
    mc_parser = subparsers.add_parser("monte-carlo", help="Run parallel Monte Carlo simulation")
    mc_parser.add_argument("--runs", type=int, default=10000, help="Number of simulated vintages")
    mc_parser.add_argument("--seed", type=int, default=20310825, help="Simulation seed")

    # calibrate
    cal_parser = subparsers.add_parser("calibrate", help="Calibrate phenology parameters with R MCMC")
    cal_parser.add_argument("--dataset", default="historical_vintages", help="Calibration dataset")
    cal_parser.add_argument("--cultivar", default="Chardonnay", help="Cultivar to calibrate")

    # analyse
    an_parser = subparsers.add_parser("analyse", help="Run R statistical analysis on simulation")
    an_parser.add_argument("--dataset", default="simulation_result.json", help="Simulation result dataset")

    # benchmark
    bm_parser = subparsers.add_parser("benchmark", help="Benchmark Rust simulation engine throughput")
    bm_parser.add_argument("--iterations", type=int, default=5000, help="Benchmark iterations")

    # validate
    val_parser = subparsers.add_parser("validate", help="Validate digital twin models against ground truth")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)

    rust_bridge = RustEngineBridge()
    r_bridge = RAnalyticsBridge()
    orch = GrappleOrchestrator()

    if args.command == "simulate":
        print(f"[GRAPPLE-PYTHON] Orchestrating simulation for estate '{args.estate}' vintage {args.vintage} (Seed: {args.seed})...")
        res = rust_bridge.run_deterministic_simulation(args.estate, args.vintage, args.seed, args.temp_delta)
        print("\n=== GRAPPLE 1.0 SIMULATION RESULTS ===")
        print(f"Simulation ID:       {res['simulation_id']}")
        print(f"Budbreak (DOY):      {res['budbreak_doy']}")
        print(f"Flowering (DOY):     {res['flowering_doy']}")
        print(f"Veraison (DOY):      {res['veraison_doy']}")
        print(f"Harvest (DOY):       {res['harvest_doy']}")
        print(f"Yield:               {res['mean_yield_t_ha']} t/ha (Total: {res['total_yield_tonnes']} t)")
        print(f"Harvest Brix:        {res['mean_harvest_brix']} °Brix")
        print(f"Harvest TA:          {res['mean_harvest_ta_g_l']} g/L")
        print(f"Harvest pH:          {res['mean_harvest_ph']}")
        print(f"Sparkling Index:     {res['sparkling_wine_index']}")
        print(f"Execution Time:      {res['execution_duration_ms']} ms")

    elif args.command == "monte-carlo":
        print(f"[GRAPPLE-PYTHON] Launching {args.runs} parallel Monte Carlo runs on Rust Rayon engine...")
        report = rust_bridge.run_parallel_monte_carlo(args.runs, args.seed)
        print(f"\n=== MONTE CARLO SUMMARY (N = {report['total_runs']}) ===")
        print(f"Execution Time:      {report['execution_duration_ms']} ms")
        print(f"Throughput:          {report['throughput_sims_per_sec']} sims/sec")
        print(f"Yield Median:        {report['yield_t_ha']['median']} t/ha (95% CI: [{report['yield_t_ha']['ci_95_lower']}, {report['yield_t_ha']['ci_95_upper']}])")
        print(f"Harvest DOY Median:  {report['harvest_doy']['median']} (10th-90th: [{report['harvest_doy']['p10']}, {report['harvest_doy']['p90']}])")
        print(f"Brix Median:         {report['brix']['median']} °Brix (95% CI: [{report['brix']['ci_95_lower']}, {report['brix']['ci_95_upper']}])")
        print(f"TA Median:           {report['ta_g_l']['median']} g/L (95% CI: [{report['ta_g_l']['ci_95_lower']}, {report['ta_g_l']['ci_95_upper']}])")

    elif args.command == "scenario":
        print("[GRAPPLE-PYTHON] Running What-If Climate & Harvest Matrix (EXP-2031-0042)...")
        exp = orch.run_what_if_climate_experiment()
        print(f"\nExperiment: {exp['experiment_id']} (Baseline: {exp['baseline_vintage']})")
        print(f"{'Scenario':<24} {'Brix':<8} {'TA (g/L)':<10} {'Yield (t/ha)':<14} {'Botrytis%':<10} {'Cellar Score'}")
        print("-" * 76)
        for s in exp["scenarios"]:
            print(f"{s['name']:<24} {s['harvest_brix']:<8.1f} {s['harvest_ta_g_l']:<10.1f} {s['yield_t_ha']:<14.2f} {s['disease_loss_pct']:<10.1f} {s['cellar_score']:<8.1f}")

    elif args.command == "calibrate":
        print(f"[GRAPPLE-PYTHON] Invoking R MCMC calibration for {args.cultivar} using dataset {args.dataset}...")
        cal = r_bridge.calibrate_phenology(args.cultivar)
        print("\n=== CALIBRATION CONVERGENCE SUMMARY ===")
        print(f"Cultivar:            {cal['cultivar']}")
        print(f"MCMC Iterations:     {cal['mcmc_iterations']} across {cal['chains']} chains")
        print(f"Gelman-Rubin R-hat:  {cal['diagnostics']['r_hat']}")
        print(f"Effective Sample:    {cal['diagnostics']['effective_sample_size']}")
        print(f"Budbreak GDD:        {cal['posterior_estimates']['budbreak_gdd']['mean']} °C (95% CI: {cal['posterior_estimates']['budbreak_gdd']['ci_95']})")
        print(f"Harvest GDD:         {cal['posterior_estimates']['harvest_gdd']['mean']} °C (95% CI: {cal['posterior_estimates']['harvest_gdd']['ci_95']})")

    elif args.command == "benchmark":
        print(f"[GRAPPLE-PYTHON] Benchmarking Rust simulation throughput ({args.iterations} iterations)...")
        report = rust_bridge.run_parallel_monte_carlo(args.iterations, 20310825)
        print(f"Duration: {report['execution_duration_ms']} ms | Throughput: {report['throughput_sims_per_sec']} simulations/sec")

    elif args.command == "validate":
        print("[GRAPPLE-PYTHON] Evaluating digital twin against historical validation ground truth...")
        v = r_bridge.get_validation_metrics()
        print("\n=== DIGITAL TWIN MODEL VALIDATION ===")
        print(f"Phenology MAE:       {v['phenology_model']['mae']} {v['phenology_model']['unit']} (R² = {v['phenology_model']['r_squared']}) [{v['phenology_model']['status']}]")
        print(f"Yield RMSE:          {v['yield_model']['rmse']} {v['yield_model']['unit']} (R² = {v['yield_model']['r_squared']}) [{v['yield_model']['status']}]")
        print(f"Brix RMSE:           {v['ripening_brix_model']['rmse']} {v['ripening_brix_model']['unit']} (R² = {v['ripening_brix_model']['r_squared']}) [{v['ripening_brix_model']['status']}]")
        print(f"Harvest Accuracy:    {v['harvest_model']['accuracy_pct']}% (Brier = {v['harvest_model']['brier_score']}) [{v['harvest_model']['status']}]")

if __name__ == "__main__":
    main()
