import unittest
from grapple.core.engine_bridge import RustEngineBridge, RAnalyticsBridge
from grapple.core.orchestrator import GrappleOrchestrator

class TestGrappleCrossLanguageIntegration(unittest.TestCase):
    
    def setUp(self):
        self.rust_bridge = RustEngineBridge()
        self.r_bridge = RAnalyticsBridge()
        self.orchestrator = GrappleOrchestrator()

    def test_deterministic_simulation(self):
        seed = 20310825
        res1 = self.rust_bridge.run_deterministic_simulation("wessex", 2031, seed)
        res2 = self.rust_bridge.run_deterministic_simulation("wessex", 2031, seed)
        self.assertEqual(res1["budbreak_doy"], res2["budbreak_doy"])
        self.assertEqual(res1["mean_harvest_brix"], res2["mean_harvest_brix"])
        self.assertEqual(res1["mean_yield_t_ha"], res2["mean_yield_t_ha"])

    def test_monte_carlo_distribution(self):
        mc = self.rust_bridge.run_parallel_monte_carlo(1000, 20310825)
        self.assertEqual(mc["total_runs"], 1000)
        self.assertTrue(mc["throughput_sims_per_sec"] > 0)
        self.assertTrue(mc["yield_t_ha"]["ci_95_lower"] < mc["yield_t_ha"]["ci_95_upper"])

    def test_orchestration_harvest_optimization(self):
        result = self.orchestrator.run_harvest_optimization_pipeline("Block 04 — South Chalk Bench")
        self.assertEqual(result["evaluated_scenarios_count"], 15)
        self.assertTrue(result["optimal_window_score"] > 80.0)

    def test_r_validation_metrics(self):
        v = self.r_bridge.get_validation_metrics()
        self.assertEqual(v["phenology_model"]["mae"], 2.1)
        self.assertEqual(v["yield_model"]["rmse"], 0.48)
        self.assertEqual(v["ripening_brix_model"]["rmse"], 0.31)
        self.assertEqual(v["harvest_model"]["accuracy_pct"], 87.0)

if __name__ == "__main__":
    unittest.main()
