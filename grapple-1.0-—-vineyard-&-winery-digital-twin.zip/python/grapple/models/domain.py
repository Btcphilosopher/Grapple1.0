from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
from uuid import UUID, uuid4

class BerryState(BaseModel):
    brix: float = Field(..., ge=0.0, le=40.0)
    ph: float = Field(..., ge=2.5, le=4.5)
    ta_g_l: float = Field(..., ge=0.0, le=30.0)
    malic_acid_g_l: float = Field(..., ge=0.0, le=20.0)
    tartaric_acid_g_l: float = Field(..., ge=0.0, le=15.0)
    berry_weight_g: float = Field(..., ge=0.0, le=5.0)
    anthocyanins_mg_l: float = 0.0

class VineyardBlock(BaseModel):
    block_id: str
    block_name: str
    cultivar: str
    area_ha: float
    vine_count: int
    elevation_m: float
    slope_deg: float
    aspect_deg: float
    phenology_stage: str
    accumulated_gdd_c: float
    berry_state: BerryState
    downy_mildew_risk_pct: float
    powdery_mildew_risk_pct: float
    botrytis_risk_pct: float
    estimated_yield_kg_ha: float

class SimulationRequest(BaseModel):
    estate_name: str = "Wessex Chalk Downland Estate"
    vintage_year: int = 2031
    seed: int = 20310825
    warming_delta_c: float = 0.0
    rainfall_multiplier: float = 1.0
    model_version: str = "GRAPPLE Model v1.0"

class MonteCarloRequest(BaseModel):
    total_runs: int = 10000
    seed: int = 20310825
    warming_delta_c: float = 0.0

class HarvestOptimizationRequest(BaseModel):
    block_id: str
    target_style: str = "Traditional_Sparkling"
    forward_days: int = 14

class ScenarioOverride(BaseModel):
    name: str
    description: str
    weather_temperature_delta_c: float
    rainfall_multiplier: float
    harvest_offset_days: int
    yield_multiplier: float
