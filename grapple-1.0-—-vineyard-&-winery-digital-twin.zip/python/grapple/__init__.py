"""GRAPPLE 1.0 — Vineyard & Winery Digital Twin Orchestration Package"""
__version__ = "1.0.0"
