use uuid::Uuid;
use crate::state::{
    Cultivar, FermentationStage, FermentationTank, GrapeBatch, WineBatch, WineryState,
};

pub struct WineryEngine;

impl WineryEngine {
    /// Initialize standard English sparkling/still winery cellar infrastructure (Tanks T-01 through T-08)
    pub fn create_standard_winery() -> WineryState {
        let tanks = vec![
            FermentationTank {
                tank_id: "T-01".into(),
                capacity_l: 5000.0,
                current_volume_l: 4500.0,
                temperature_c: 16.5,
                target_temperature_c: 16.0,
                sugar_brix: 1.2,
                ethanol_pct_vol: 11.4,
                yeast_biomass_g_l: 1.1,
                nitrogen_yan_mg_l: 45.0,
                stage: FermentationStage::PrimaryFermentation,
                cooling_active: true,
                stuck_flag: false,
                co2_rate_g_l_h: 0.15,
            },
            FermentationTank {
                tank_id: "T-02".into(),
                capacity_l: 5000.0,
                current_volume_l: 4800.0,
                temperature_c: 15.8,
                target_temperature_c: 16.0,
                sugar_brix: 0.2,
                ethanol_pct_vol: 11.8,
                yeast_biomass_g_l: 0.4,
                nitrogen_yan_mg_l: 25.0,
                stage: FermentationStage::MalolacticFermentation,
                cooling_active: false,
                stuck_flag: false,
                co2_rate_g_l_h: 0.02,
            },
            FermentationTank {
                tank_id: "T-03".into(),
                capacity_l: 10000.0,
                current_volume_l: 9200.0,
                temperature_c: 14.2,
                target_temperature_c: 14.0,
                sugar_brix: 0.0,
                ethanol_pct_vol: 11.6,
                yeast_biomass_g_l: 0.1,
                nitrogen_yan_mg_l: 15.0,
                stage: FermentationStage::LeesAgeing,
                cooling_active: false,
                stuck_flag: false,
                co2_rate_g_l_h: 0.0,
            },
            FermentationTank {
                tank_id: "T-04".into(),
                capacity_l: 5000.0,
                current_volume_l: 3500.0,
                temperature_c: 18.2,
                target_temperature_c: 16.0,
                sugar_brix: 8.5,
                ethanol_pct_vol: 6.2,
                yeast_biomass_g_l: 3.8,
                nitrogen_yan_mg_l: 85.0,
                stage: FermentationStage::PrimaryFermentation,
                cooling_active: true,
                stuck_flag: false,
                co2_rate_g_l_h: 0.85,
            },
            FermentationTank {
                tank_id: "T-05".into(),
                capacity_l: 2500.0,
                current_volume_l: 0.0,
                temperature_c: 12.0,
                target_temperature_c: 12.0,
                sugar_brix: 0.0,
                ethanol_pct_vol: 0.0,
                yeast_biomass_g_l: 0.0,
                nitrogen_yan_mg_l: 0.0,
                stage: FermentationStage::ColdSettling,
                cooling_active: false,
                stuck_flag: false,
                co2_rate_g_l_h: 0.0,
            },
            FermentationTank {
                tank_id: "T-06".into(),
                capacity_l: 2500.0,
                current_volume_l: 2200.0,
                temperature_c: 19.5,
                target_temperature_c: 16.0,
                sugar_brix: 9.8,
                ethanol_pct_vol: 4.8,
                yeast_biomass_g_l: 0.8,
                nitrogen_yan_mg_l: 18.0,
                stage: FermentationStage::PrimaryFermentation,
                cooling_active: true,
                stuck_flag: true, // Sluggish/stuck fermentation test tank
                co2_rate_g_l_h: 0.04,
            },
        ];

        let equipment = vec![
            crate::state::EquipmentState {
                equipment_id: "PRESS-01".into(),
                name: "Pneumatic Membrane Press 50hL".into(),
                equipment_type: "Press".into(),
                operational: true,
                health_score_pct: 96.5,
                vibration_rms: 1.2,
                run_hours: 420.0,
                maintenance_due_hours: 580.0,
            },
            crate::state::EquipmentState {
                equipment_id: "CHILL-01".into(),
                name: "Glycol Chilling Plant 45kW".into(),
                equipment_type: "Chiller".into(),
                operational: true,
                health_score_pct: 92.0,
                vibration_rms: 2.1,
                run_hours: 1240.0,
                maintenance_due_hours: 260.0,
            },
            crate::state::EquipmentState {
                equipment_id: "PUMP-01".into(),
                name: "Peristaltic Must Pump".into(),
                equipment_type: "Pump".into(),
                operational: true,
                health_score_pct: 88.0,
                vibration_rms: 3.4,
                run_hours: 680.0,
                maintenance_due_hours: 120.0,
            },
            crate::state::EquipmentState {
                equipment_id: "LINE-01".into(),
                name: "Counter-Pressure Bottling Monoblock".into(),
                equipment_type: "Bottling".into(),
                operational: true,
                health_score_pct: 99.0,
                vibration_rms: 0.8,
                run_hours: 180.0,
                maintenance_due_hours: 820.0,
            },
        ];

        let wine_batches = vec![
            WineBatch {
                wine_batch_id: Uuid::new_v4(),
                tank_id: "T-03".into(),
                vintage_year: 2025,
                style: "Traditional_Sparkling_Base".into(),
                volume_l: 9200.0,
                ethanol_pct_vol: 11.6,
                residual_sugar_g_l: 0.8,
                ph: 3.08,
                ta_g_l: 8.8,
                malic_acid_g_l: 1.2,
                lactic_acid_g_l: 3.5,
                free_so2_mg_l: 22.0,
                total_so2_mg_l: 68.0,
                volatile_acidity_g_l: 0.32,
                dissolved_oxygen_mg_l: 0.18,
                stage: FermentationStage::LeesAgeing,
            }
        ];

        WineryState {
            tanks,
            wine_batches,
            equipment,
            total_grapes_processed_kg: 32500.0,
            total_juice_extracted_l: 22100.0,
            total_wine_bottled_l: 18400.0,
        }
    }

    /// Process grape intake batch: sorting -> pneumatic pressing (typically 68% juice yield for whole bunch pressing in sparkling)
    pub fn process_grape_intake(
        winery: &mut WineryState,
        batch: &GrapeBatch,
    ) -> Result<f64, String> {
        let clean_grapes_kg = batch.weight_kg * (1.0 - (batch.sorting_mogs_pct / 100.0));
        let juice_yield_ratio = match batch.cultivar {
            Cultivar::Chardonnay => 0.69,
            Cultivar::PinotNoir => 0.67,
            Cultivar::PinotMeunier => 0.68,
            Cultivar::Bacchus => 0.72,
            Cultivar::SeyvalBlanc => 0.73,
        };

        let juice_extracted_l = clean_grapes_kg * juice_yield_ratio;
        winery.total_grapes_processed_kg += batch.weight_kg;
        winery.total_juice_extracted_l += juice_extracted_l;

        // Find open tank
        if let Some(open_tank) = winery.tanks.iter_mut().find(|t| t.current_volume_l == 0.0) {
            let fill_volume = juice_extracted_l.min(open_tank.capacity_l);
            open_tank.current_volume_l = fill_volume;
            open_tank.sugar_brix = batch.sugar_brix;
            open_tank.ethanol_pct_vol = 0.0;
            open_tank.yeast_biomass_g_l = 0.1;
            open_tank.nitrogen_yan_mg_l = 160.0;
            open_tank.stage = FermentationStage::ColdSettling;
            open_tank.cooling_active = true;
            open_tank.target_temperature_c = 12.0;
            open_tank.temperature_c = 14.0;
            Ok(fill_volume)
        } else {
            Err("Cellar Capacity Full: No vacant tank available for juice reception".into())
        }
    }
}
