use chrono::{DateTime, Utc};
use rand::prelude::*;
use rand_distr::Normal;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SensorTelemetryPacket {
    pub timestamp_iso: DateTime<Utc>,
    pub sensor_id: String,
    pub sensor_type: String,
    pub location: String,
    pub value: f64,
    pub unit: String,
    pub quality_flag: String, // "GOOD", "UNCERTAIN", "BAD", "ANOMALY_DETECTED"
    pub anomaly_score: f64,
    pub message: Option<String>,
}

pub struct TelemetryAnomalyEngine;

impl TelemetryAnomalyEngine {
    /// Generate a stream of high-frequency sensor readings and run statistical anomaly detection
    pub fn generate_telemetry_batch<R: Rng>(
        timestamp: DateTime<Utc>,
        rng: &mut R,
        inject_anomaly: bool,
    ) -> Vec<SensorTelemetryPacket> {
        let mut packets = Vec::new();

        // 1. Weather Station Temperature Sensor
        let normal_temp = 14.8 + Normal::new(0.0, 0.4).unwrap().sample(rng);
        let temp_reading = if inject_anomaly && rng.gen_bool(0.3) {
            normal_temp + 8.5 // Sudden spike anomaly
        } else {
            normal_temp
        };
        let is_temp_anomaly = (temp_reading - 14.8).abs() > 4.5;
        packets.push(SensorTelemetryPacket {
            timestamp_iso: timestamp,
            sensor_id: "MET-01-TEMP".into(),
            sensor_type: "weather_station".into(),
            location: "North Slope Meteorological Mast".into(),
            value: (temp_reading * 100.0).round() / 100.0,
            unit: "celsius".into(),
            quality_flag: if is_temp_anomaly { "ANOMALY_DETECTED".into() } else { "GOOD".into() },
            anomaly_score: if is_temp_anomaly { 0.88 } else { 0.04 },
            message: if is_temp_anomaly { Some("Rapid temperature divergence from spatial neighbors".into()) } else { None },
        });

        // 2. Tank T-01 Fermentation Temperature Probe
        let tank_target = 16.0;
        let tank_drift = if inject_anomaly && rng.gen_bool(0.4) { 4.2 } else { 0.15 };
        let tank_temp = tank_target + tank_drift + Normal::new(0.0, 0.08).unwrap().sample(rng);
        let is_tank_anomaly = (tank_temp - tank_target).abs() > 2.0;
        packets.push(SensorTelemetryPacket {
            timestamp_iso: timestamp,
            sensor_id: "TANK-01-RTD".into(),
            sensor_type: "tank_temperature".into(),
            location: "Cellar Tank T-01 (Chardonnay Base)".into(),
            value: (tank_temp * 100.0).round() / 100.0,
            unit: "celsius".into(),
            quality_flag: if is_tank_anomaly { "ANOMALY_DETECTED".into() } else { "GOOD".into() },
            anomaly_score: if is_tank_anomaly { 0.94 } else { 0.02 },
            message: if is_tank_anomaly { Some("Cooling jacket solenoid underperforming: runaway thermal gradient".into()) } else { None },
        });

        // 3. Peristaltic Must Pump Vibration Sensor (RMS mm/s)
        let pump_base_vib = 1.4;
        let pump_vib = if inject_anomaly && rng.gen_bool(0.35) {
            5.8 + Normal::new(0.0, 0.4).unwrap().sample(rng) // Bearing wear anomaly
        } else {
            pump_base_vib + Normal::new(0.0, 0.12).unwrap().sample(rng)
        };
        let is_pump_anomaly = pump_vib > 4.0;
        packets.push(SensorTelemetryPacket {
            timestamp_iso: timestamp,
            sensor_id: "PUMP-01-VIB".into(),
            sensor_type: "pump_vibration".into(),
            location: "Reception Must Pump P-01".into(),
            value: (pump_vib * 100.0).round() / 100.0,
            unit: "mm_s_rms".into(),
            quality_flag: if is_pump_anomaly { "ANOMALY_DETECTED".into() } else { "GOOD".into() },
            anomaly_score: if is_pump_anomaly { 0.91 } else { 0.05 },
            message: if is_pump_anomaly { Some("Impeller cavitation & mechanical harmonic bearing warning".into()) } else { None },
        });

        // 4. Multi-depth Soil Moisture Sensor (Block 04, 20-50cm)
        let soil_moist = (28.4 + Normal::new(0.0, 0.25).unwrap().sample(rng)).max(5.0);
        packets.push(SensorTelemetryPacket {
            timestamp_iso: timestamp,
            sensor_id: "SOIL-B04-L2".into(),
            sensor_type: "soil_moisture".into(),
            location: "Block 04 Chalk Bench (20-50cm)".into(),
            value: (soil_moist * 100.0).round() / 100.0,
            unit: "moisture_pct".into(),
            quality_flag: "GOOD".into(),
            anomaly_score: 0.01,
            message: None,
        });

        packets
    }
}
