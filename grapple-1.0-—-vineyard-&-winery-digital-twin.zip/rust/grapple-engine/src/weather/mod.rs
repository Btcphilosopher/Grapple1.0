use rand::prelude::*;
use rand_distr::{Normal, Uniform};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WeatherGeneratorConfig {
    pub base_mean_temp_c: f64,
    pub seasonal_temp_amplitude_c: f64,
    pub annual_rainfall_mean_mm: f64,
    pub rainfall_frequency: f64,
    pub frost_sensitivity: f64,
    pub warming_delta_c: f64,
    pub rainfall_multiplier: f64,
}

impl Default for WeatherGeneratorConfig {
    fn default() -> Self {
        // English Chalk Downland (Hampshire/Sussex/Kent maritime climate profile)
        Self {
            base_mean_temp_c: 10.8,
            seasonal_temp_amplitude_c: 7.2,
            annual_rainfall_mean_mm: 720.0,
            rainfall_frequency: 0.38,
            frost_sensitivity: 1.0,
            warming_delta_c: 0.0,
            rainfall_multiplier: 1.0,
        }
    }
}

pub struct StochasticWeatherEngine {
    pub config: WeatherGeneratorConfig,
}

impl StochasticWeatherEngine {
    pub fn new(config: WeatherGeneratorConfig) -> Self {
        Self { config }
    }

    /// Generate daily weather condition for a given day-of-year (1..=365) and random generator
    pub fn generate_day<R: Rng>(&self, doy: u32, rng: &mut R) -> crate::state::WeatherState {
        let radians = (doy as f64 - 105.0) * (2.0 * std::f64::consts::PI / 365.0);
        let seasonal_mean = self.config.base_mean_temp_c
            + self.config.seasonal_temp_amplitude_c * radians.sin()
            + self.config.warming_delta_c;

        let temp_noise = Normal::new(0.0, 2.8).unwrap().sample(rng);
        let mean_t = seasonal_mean + temp_noise;

        let diurnal_range = Normal::new(7.5, 1.8).unwrap().sample(rng).max(3.0);
        let max_t = mean_t + diurnal_range * 0.55;
        let min_t = mean_t - diurnal_range * 0.45;

        // Rainfall probability
        let rain_chance = (self.config.rainfall_frequency * (1.0 - 0.25 * radians.sin())).clamp(0.15, 0.7);
        let is_rain = rng.gen_bool(rain_chance.clamp(0.0, 1.0));
        let rainfall_mm = if is_rain {
            let rain_dist = rand_distr::Exp::new(0.18).unwrap();
            (rain_dist.sample(rng) * self.config.rainfall_multiplier).min(65.0)
        } else {
            0.0
        };

        // Solar radiation W/m2
        let max_potential_rad = (650.0 + 350.0 * radians.sin()).max(80.0);
        let cloud_cover = if rainfall_mm > 0.0 {
            Uniform::new(0.65, 0.98).sample(rng)
        } else {
            Uniform::new(0.15, 0.70).sample(rng)
        };
        let solar_radiation_w_m2 = (max_potential_rad * (1.0 - 0.75 * cloud_cover)).max(40.0);

        // Humidity
        let base_humidity = 78.0 - 15.0 * (mean_t - 5.0).max(0.0) / 20.0;
        let relative_humidity_pct = if rainfall_mm > 0.0 {
            (base_humidity + 18.0 + Uniform::new(-5.0, 8.0).sample(rng)).clamp(65.0, 99.0)
        } else {
            (base_humidity + Uniform::new(-12.0, 12.0).sample(rng)).clamp(40.0, 92.0)
        };

        // Wind speed m/s
        let wind_speed_m_s = Normal::new(3.8, 1.4).unwrap().sample(rng).max(0.5);

        // Frost risk: higher in Spring (doy 90..140) if min_t <= 1.0 C
        let frost_risk_pct = if min_t < 0.0 {
            100.0
        } else if min_t <= 2.0 {
            ((2.0 - min_t) / 2.0 * 85.0 * self.config.frost_sensitivity).min(100.0)
        } else {
            0.0
        };

        let leaf_wetness_hours = if rainfall_mm > 0.5 {
            (rainfall_mm * 1.5 + 4.0).min(24.0)
        } else if relative_humidity_pct > 85.0 {
            (relative_humidity_pct - 85.0) * 0.4
        } else {
            0.5
        };

        crate::state::WeatherState {
            temperature_c: (mean_t * 10.0).round() / 10.0,
            min_temperature_c: (min_t * 10.0).round() / 10.0,
            max_temperature_c: (max_t * 10.0).round() / 10.0,
            relative_humidity_pct: (relative_humidity_pct * 10.0).round() / 10.0,
            solar_radiation_w_m2: (solar_radiation_w_m2 * 10.0).round() / 10.0,
            rainfall_mm: (rainfall_mm * 10.0).round() / 10.0,
            wind_speed_m_s: (wind_speed_m_s * 10.0).round() / 10.0,
            frost_risk_pct: (frost_risk_pct * 10.0).round() / 10.0,
            leaf_wetness_hours: (leaf_wetness_hours * 10.0).round() / 10.0,
        }
    }
}
