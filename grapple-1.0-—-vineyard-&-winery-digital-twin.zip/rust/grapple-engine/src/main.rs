use clap::{Parser, Subcommand};
use grapple_engine::monte_carlo::MonteCarloEngine;
use grapple_engine::optimisation::{ScenarioEngine, ScenarioOverride};
use grapple_engine::simulation::{DeterministicVintageSimulator, SimulationConfig};
use grapple_engine::telemetry::TelemetryAnomalyEngine;

#[derive(Parser)]
#[command(name = "grapple")]
#[command(about = "GRAPPLE 1.0 — High-Performance Scientific Computing Layer & Digital Twin Engine", long_about = None)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Run a deterministic vintage simulation for an English estate
    Simulate {
        #[arg(short, long, default_value = "wessex")]
        estate: String,
        #[arg(short, long, default_value_t = 2031)]
        vintage: i32,
        #[arg(short, long, default_value_t = 20310825)]
        seed: u64,
        #[arg(long, default_value_t = 0.0)]
        temp_delta: f64,
    },
    /// Run parallel Monte Carlo simulations across CPU cores
    MonteCarlo {
        #[arg(short, long, default_value_t = 10000)]
        runs: usize,
        #[arg(short, long, default_value_t = 20310825)]
        seed: u64,
    },
    /// Run what-if scenario comparison matrix
    Scenario {
        #[arg(short, long, default_value_t = 20310825)]
        seed: u64,
    },
    /// Run simulation engine benchmarks
    Benchmark {
        #[arg(short, long, default_value_t = 5000)]
        iterations: usize,
    },
    /// Stream synthetic sensor telemetry with anomaly detection
    Telemetry {
        #[arg(short, long, default_value_t = 10)]
        count: usize,
        #[arg(long)]
        inject_anomaly: bool,
    },
}

fn main() {
    let cli = Cli::parse();

    match cli.command {
        Commands::Simulate { estate, vintage, seed, temp_delta } => {
            println!("[GRAPPLE-RUST] Initializing deterministic vintage simulation...");
            let mut config = SimulationConfig::default();
            config.vintage_year = vintage;
            config.estate_name = format!("Estate: {}", estate);
            config.weather_config.warming_delta_c = temp_delta;

            let start = std::time::Instant::now();
            let sim = DeterministicVintageSimulator::new(config, seed);
            let metrics = sim.run_full_vintage();
            let dur = start.elapsed();

            println!("\n=== GRAPPLE 1.0 SIMULATION METRICS ===");
            println!("Simulation UUID:      {}", metrics.simulation_id);
            println!("Seed:                 {}", metrics.seed);
            println!("Vintage Year:         {}", metrics.vintage_year);
            println!("Budbreak (DOY):       {:.1}", metrics.budbreak_doy);
            println!("Flowering (DOY):      {:.1}", metrics.flowering_doy);
            println!("Veraison (DOY):       {:.1}", metrics.veraison_doy);
            println!("Harvest (DOY):        {:.1}", metrics.harvest_doy);
            println!("Mean Yield:           {:.2} t/ha (Total: {:.1} t)", metrics.mean_yield_t_ha, metrics.total_yield_tonnes);
            println!("Mean Harvest Brix:    {:.1} °Brix", metrics.mean_harvest_brix);
            println!("Mean Harvest TA:      {:.1} g/L", metrics.mean_harvest_ta_g_l);
            println!("Mean Harvest pH:      {:.2}", metrics.mean_harvest_ph);
            println!("Sparkling Wine Index: {:.2}", metrics.sparkling_wine_index);
            println!("Disease Loss:         {:.1}%", metrics.disease_loss_pct);
            println!("Frost Damage:         {:.1}%", metrics.frost_damage_pct);
            println!("Execution Time:       {:.2} ms", dur.as_secs_f64() * 1000.0);
        }
        Commands::MonteCarlo { runs, seed } => {
            println!("[GRAPPLE-RUST] Launching parallel Monte Carlo simulation ({} vintages) on {} Rayon threads...", runs, rayon::current_num_threads());
            let config = SimulationConfig::default();
            let report = MonteCarloEngine::run_parallel(&config, runs, seed);

            println!("\n=== MONTE CARLO RESULTS (N = {}) ===", report.total_runs);
            println!("Execution Duration:  {:.2} ms", report.execution_duration_ms);
            println!("Throughput:          {:.1} simulations/sec", report.throughput_sims_per_sec);
            println!("\nYield (t/ha):        Median: {:.2} | 95% CI: [{:.2}, {:.2}] | Std: {:.2}",
                report.yield_t_ha.median, report.yield_t_ha.ci_95_lower, report.yield_t_ha.ci_95_upper, report.yield_t_ha.std_dev);
            println!("Harvest DOY:         Median: {:.1} | 10th-90th: [{:.1}, {:.1}]",
                report.harvest_doy.median, report.harvest_doy.p10, report.harvest_doy.p90);
            println!("Harvest Brix:        Median: {:.1} °Brix | 95% CI: [{:.1}, {:.1}]",
                report.brix.median, report.brix.ci_95_lower, report.brix.ci_95_upper);
            println!("Harvest TA (g/L):    Median: {:.1} g/L | 95% CI: [{:.1}, {:.1}]",
                report.ta_g_l.median, report.ta_g_l.ci_95_lower, report.ta_g_l.ci_95_upper);
            println!("Sparkling Index:     Median: {:.2} | 95% CI: [{:.2}, {:.2}]",
                report.sparkling_wine_index.median, report.sparkling_wine_index.ci_95_lower, report.sparkling_wine_index.ci_95_upper);
        }
        Commands::Scenario { seed } => {
            println!("[GRAPPLE-RUST] Evaluating multi-scenario What-If matrix (EXP-2031-0042)...");
            let config = SimulationConfig::default();
            let scenarios = vec![
                ScenarioOverride {
                    name: "Baseline 2031".into(),
                    description: "Standard English Chalk Downland maritime profile".into(),
                    weather_temperature_delta_c: 0.0,
                    rainfall_multiplier: 1.0,
                    harvest_offset_days: 0,
                    yield_multiplier: 1.0,
                },
                ScenarioOverride {
                    name: "+1.5°C Climate Shift".into(),
                    description: "Projected 2045 warmer growing season profile".into(),
                    weather_temperature_delta_c: 1.5,
                    rainfall_multiplier: 0.92,
                    harvest_offset_days: -4,
                    yield_multiplier: 1.05,
                },
                ScenarioOverride {
                    name: "Early Harvest (-3d)".into(),
                    description: "High acidity traditional sparkling focus".into(),
                    weather_temperature_delta_c: 0.0,
                    rainfall_multiplier: 1.0,
                    harvest_offset_days: -3,
                    yield_multiplier: 0.98,
                },
                ScenarioOverride {
                    name: "Late Harvest (+3d)".into(),
                    description: "Aromatic still wine maturity focus".into(),
                    weather_temperature_delta_c: 0.0,
                    rainfall_multiplier: 1.0,
                    harvest_offset_days: 3,
                    yield_multiplier: 0.95,
                },
            ];

            let results = ScenarioEngine::run_scenario_matrix(&config, scenarios, seed);
            println!("\n{:<22} {:<10} {:<10} {:<10} {:<10} {:<10}", "Scenario", "Brix", "TA (g/L)", "Yield (t/ha)", "Botrytis%", "Cellar Score");
            println!("{:-<76}", "");
            for r in results {
                println!("{:<22} {:<10.1} {:<10.1} {:<10.2} {:<10.1} {:<10.1}",
                    r.scenario_name, r.harvest_brix, r.harvest_ta_g_l, r.yield_t_ha, r.disease_loss_pct, r.cellar_suitability_score);
            }
        }
        Commands::Benchmark { iterations } => {
            println!("[GRAPPLE-RUST] Benchmarking simulation engine across {} iterations...", iterations);
            let config = SimulationConfig::default();
            let start = std::time::Instant::now();
            let report = MonteCarloEngine::run_parallel(&config, iterations, 20310825);
            let dur = start.elapsed();

            println!("Completed in {:.3} s | Speed: {:.0} simulations/second", dur.as_secs_f64(), report.throughput_sims_per_sec);
        }
        Commands::Telemetry { count, inject_anomaly } => {
            let mut rng = rand::thread_rng();
            println!("[GRAPPLE-RUST] Generating {} synthetic telemetry packets (Anomaly Injection: {})...", count, inject_anomaly);
            for _ in 0..count {
                let packets = TelemetryAnomalyEngine::generate_telemetry_batch(chrono::Utc::now(), &mut rng, inject_anomaly);
                for p in packets {
                    println!("[{}] {:<16} | Value: {:>6.2} {:<12} | Status: {:<16} | Score: {:.2}",
                        p.timestamp_iso.format("%H:%M:%S"), p.sensor_id, p.value, p.unit, p.quality_flag, p.anomaly_score);
                }
            }
        }
    }
}
