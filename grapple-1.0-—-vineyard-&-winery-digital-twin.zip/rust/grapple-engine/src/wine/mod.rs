use crate::state::{FermentationStage, WineBatch};

pub struct WineChemistryEngine;

impl WineChemistryEngine {
    /// Perform malolactic fermentation (MLF) conversion step:
    /// Malic acid (dicarboxylic) -> Lactic acid (monocarboxylic) + CO2
    /// Theoretical conversion: 1.0 g/L malic acid yields ~0.67 g/L lactic acid
    pub fn step_mlf(batch: &mut WineBatch, conversion_pct: f64) {
        if batch.stage != FermentationStage::MalolacticFermentation {
            return;
        }

        let delta_malic = batch.malic_acid_g_l * (conversion_pct / 100.0);
        batch.malic_acid_g_l -= delta_malic;
        batch.lactic_acid_g_l += delta_malic * 0.671;

        // TA reduction due to loss of one carboxyl group (~0.56 g/L TA tartaric equivalent loss per 1 g/L malic degraded)
        batch.ta_g_l = (batch.ta_g_l - delta_malic * 0.56).max(5.0);
        // pH increase (typically +0.1 to +0.2 pH shift)
        batch.ph = (batch.ph + delta_malic * 0.08).min(3.8);

        if batch.malic_acid_g_l < 0.15 {
            batch.stage = FermentationStage::LeesAgeing;
        }
    }

    /// Sulphur dioxide SO2 addition and binding equilibrium
    pub fn add_so2(batch: &mut WineBatch, added_mg_l: f64) {
        batch.total_so2_mg_l += added_mg_l;
        // Molecular and free SO2 equilibrium based on pH: at pH 3.10 ~35-40% remains free
        let free_fraction = if batch.ph < 3.0 {
            0.50
        } else if batch.ph < 3.20 {
            0.38
        } else {
            0.25
        };
        batch.free_so2_mg_l = (batch.free_so2_mg_l + added_mg_l * free_fraction).min(batch.total_so2_mg_l);
    }
}
