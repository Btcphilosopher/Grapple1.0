use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Estate {
    pub estate_id: Uuid,
    pub estate_name: String,
    pub latitude: f64,
    pub longitude: f64,
    pub total_area_ha: f64,
    pub establishment_year: i32,
    pub region: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Cultivar {
    Chardonnay,
    PinotNoir,
    PinotMeunier,
    Bacchus,
    SeyvalBlanc,
}

impl Cultivar {
    pub fn as_str(&self) -> &'static str {
        match self {
            Cultivar::Chardonnay => "Chardonnay",
            Cultivar::PinotNoir => "Pinot Noir",
            Cultivar::PinotMeunier => "Pinot Meunier",
            Cultivar::Bacchus => "Bacchus",
            Cultivar::SeyvalBlanc => "Seyval Blanc",
        }
    }

    pub fn base_gdd_budbreak(&self) -> f64 {
        match self {
            Cultivar::Chardonnay => 210.0,
            Cultivar::PinotNoir => 225.0,
            Cultivar::PinotMeunier => 220.0,
            Cultivar::Bacchus => 175.0,
            Cultivar::SeyvalBlanc => 165.0,
        }
    }

    pub fn base_gdd_flowering(&self) -> f64 {
        match self {
            Cultivar::Chardonnay => 460.0,
            Cultivar::PinotNoir => 480.0,
            Cultivar::PinotMeunier => 470.0,
            Cultivar::Bacchus => 400.0,
            Cultivar::SeyvalBlanc => 390.0,
        }
    }

    pub fn base_gdd_veraison(&self) -> f64 {
        match self {
            Cultivar::Chardonnay => 880.0,
            Cultivar::PinotNoir => 910.0,
            Cultivar::PinotMeunier => 895.0,
            Cultivar::Bacchus => 790.0,
            Cultivar::SeyvalBlanc => 770.0,
        }
    }

    pub fn base_gdd_sparkling_harvest(&self) -> f64 {
        match self {
            Cultivar::Chardonnay => 1050.0,
            Cultivar::PinotNoir => 1080.0,
            Cultivar::PinotMeunier => 1060.0,
            Cultivar::Bacchus => 950.0,
            Cultivar::SeyvalBlanc => 920.0,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum PhenologyStage {
    Dormancy,
    Budbreak,
    Flowering,
    FruitSet,
    Veraison,
    Ripening,
    HarvestReady,
    Harvested,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BerryState {
    pub brix: f64,
    pub ph: f64,
    pub ta_g_l: f64,
    pub malic_acid_g_l: f64,
    pub tartaric_acid_g_l: f64,
    pub berry_weight_g: f64,
    pub anthocyanins_mg_l: f64,
    pub glu_fru_ratio: f64,
}

impl Default for BerryState {
    fn default() -> Self {
        Self {
            brix: 4.0,
            ph: 2.80,
            ta_g_l: 22.0,
            malic_acid_g_l: 14.0,
            tartaric_acid_g_l: 8.0,
            berry_weight_g: 0.15,
            anthocyanins_mg_l: 0.0,
            glu_fru_ratio: 0.85,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CanopyState {
    pub leaf_area_index: f64,
    pub shoot_density_per_m: f64,
    pub shading_coefficient: f64,
    pub pruned_flag: bool,
}

impl Default for CanopyState {
    fn default() -> Self {
        Self {
            leaf_area_index: 1.8,
            shoot_density_per_m: 14.0,
            shading_coefficient: 0.65,
            pruned_flag: true,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VineyardBlock {
    pub block_id: Uuid,
    pub block_name: String,
    pub cultivar: Cultivar,
    pub area_ha: f64,
    pub vine_count: u32,
    pub planting_year: i32,
    pub trellis_system: String,
    pub elevation_m: f64,
    pub slope_deg: f64,
    pub aspect_deg: f64,
    pub soil_type: String,
    pub phenology_stage: PhenologyStage,
    pub accumulated_gdd_c: f64,
    pub canopy: CanopyState,
    pub berry_state: BerryState,
    pub downy_mildew_risk_pct: f64,
    pub powdery_mildew_risk_pct: f64,
    pub botrytis_risk_pct: f64,
    pub estimated_yield_kg_ha: f64,
    pub harvested_flag: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WeatherState {
    pub temperature_c: f64,
    pub min_temperature_c: f64,
    pub max_temperature_c: f64,
    pub relative_humidity_pct: f64,
    pub solar_radiation_w_m2: f64,
    pub rainfall_mm: f64,
    pub wind_speed_m_s: f64,
    pub frost_risk_pct: f64,
    pub leaf_wetness_hours: f64,
}

impl Default for WeatherState {
    fn default() -> Self {
        Self {
            temperature_c: 14.5,
            min_temperature_c: 9.0,
            max_temperature_c: 19.5,
            relative_humidity_pct: 72.0,
            solar_radiation_w_m2: 450.0,
            rainfall_mm: 0.0,
            wind_speed_m_s: 3.8,
            frost_risk_pct: 0.0,
            leaf_wetness_hours: 2.5,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SoilLayer {
    pub depth_range_cm: String,
    pub moisture_pct: f64,
    pub field_capacity_pct: f64,
    pub wilting_point_pct: f64,
    pub hydraulic_conductivity_mm_h: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SoilState {
    pub layers: Vec<SoilLayer>,
    pub soil_temperature_c: f64,
    pub water_stress_index: f64,
}

impl Default for SoilState {
    fn default() -> Self {
        Self {
            soil_temperature_c: 13.2,
            water_stress_index: 0.12,
            layers: vec![
                SoilLayer {
                    depth_range_cm: "0-20".into(),
                    moisture_pct: 26.5,
                    field_capacity_pct: 32.0,
                    wilting_point_pct: 12.0,
                    hydraulic_conductivity_mm_h: 15.0,
                },
                SoilLayer {
                    depth_range_cm: "20-50".into(),
                    moisture_pct: 28.0,
                    field_capacity_pct: 34.0,
                    wilting_point_pct: 14.0,
                    hydraulic_conductivity_mm_h: 12.0,
                },
                SoilLayer {
                    depth_range_cm: "50-100".into(),
                    moisture_pct: 30.5,
                    field_capacity_pct: 36.0,
                    wilting_point_pct: 16.0,
                    hydraulic_conductivity_mm_h: 8.0,
                },
                SoilLayer {
                    depth_range_cm: "100-150".into(),
                    moisture_pct: 31.0,
                    field_capacity_pct: 38.0,
                    wilting_point_pct: 18.0,
                    hydraulic_conductivity_mm_h: 5.0,
                },
            ],
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GrapeBatch {
    pub batch_id: Uuid,
    pub block_id: Uuid,
    pub harvest_timestamp: DateTime<Utc>,
    pub cultivar: Cultivar,
    pub weight_kg: f64,
    pub sugar_brix: f64,
    pub ph: f64,
    pub titratable_acidity_ta_g_l: f64,
    pub malic_acid_g_l: f64,
    pub sorting_mogs_pct: f64,
    pub disease_incidence_pct: f64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum FermentationStage {
    ColdSettling,
    PrimaryFermentation,
    MalolacticFermentation,
    LeesAgeing,
    Stabilisation,
    Bottled,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FermentationTank {
    pub tank_id: String,
    pub capacity_l: f64,
    pub current_volume_l: f64,
    pub temperature_c: f64,
    pub target_temperature_c: f64,
    pub sugar_brix: f64,
    pub ethanol_pct_vol: f64,
    pub yeast_biomass_g_l: f64,
    pub nitrogen_yan_mg_l: f64,
    pub stage: FermentationStage,
    pub cooling_active: bool,
    pub stuck_flag: bool,
    pub co2_rate_g_l_h: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WineBatch {
    pub wine_batch_id: Uuid,
    pub tank_id: String,
    pub vintage_year: i32,
    pub style: String,
    pub volume_l: f64,
    pub ethanol_pct_vol: f64,
    pub residual_sugar_g_l: f64,
    pub ph: f64,
    pub ta_g_l: f64,
    pub malic_acid_g_l: f64,
    pub lactic_acid_g_l: f64,
    pub free_so2_mg_l: f64,
    pub total_so2_mg_l: f64,
    pub volatile_acidity_g_l: f64,
    pub dissolved_oxygen_mg_l: f64,
    pub stage: FermentationStage,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EquipmentState {
    pub equipment_id: String,
    pub name: String,
    pub equipment_type: String,
    pub operational: bool,
    pub health_score_pct: f64,
    pub vibration_rms: f64,
    pub run_hours: f64,
    pub maintenance_due_hours: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WineryState {
    pub tanks: Vec<FermentationTank>,
    pub wine_batches: Vec<WineBatch>,
    pub equipment: Vec<EquipmentState>,
    pub total_grapes_processed_kg: f64,
    pub total_juice_extracted_l: f64,
    pub total_wine_bottled_l: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VineyardState {
    pub estate_id: Uuid,
    pub estate_name: String,
    pub simulation_time: DateTime<Utc>,
    pub simulation_tick: u64,
    pub model_version: String,
    pub parameter_version: String,
    pub blocks: Vec<VineyardBlock>,
    pub weather: WeatherState,
    pub soil: SoilState,
    pub winery: WineryState,
}
