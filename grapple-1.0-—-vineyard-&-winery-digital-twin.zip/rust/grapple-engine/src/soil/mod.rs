use crate::state::SoilState;

pub struct SoilWaterEngine;

impl SoilWaterEngine {
    /// Update multi-layer soil moisture based on daily rainfall, evapotranspiration (ET0), and vine root extraction
    pub fn update_daily(
        soil: &mut SoilState,
        rainfall_mm: f64,
        temperature_c: f64,
        solar_rad_w_m2: f64,
        leaf_area_index: f64,
    ) {
        // Simplified Hargreaves-Samani reference evapotranspiration ET0 (mm/day)
        let et0 = (0.0023 * (temperature_c.max(0.0) + 17.8) * (solar_rad_w_m2 / 28.0)).max(0.2).min(7.5);
        // Crop coefficient Kc based on LAI
        let kc = (0.2 + 0.5 * (leaf_area_index / 2.5)).clamp(0.25, 0.85);
        let vine_water_demand_mm = et0 * kc;

        // Infiltration & Runoff
        let max_surface_infiltration_capacity = 35.0; // mm/day
        let surface_infiltration = rainfall_mm.min(max_surface_infiltration_capacity);
        let _surface_runoff = rainfall_mm - surface_infiltration;

        // Water entry into top layer (0-20cm: 200mm soil depth)
        let mut percolating_water_mm = surface_infiltration;

        // Root distribution across 4 layers: Layer 1 (0-20cm): 35%, Layer 2 (20-50cm): 40%, Layer 3 (50-100cm): 20%, Layer 4 (100-150cm): 5%
        let root_fractions = [0.35, 0.40, 0.20, 0.05];
        let layer_thicknesses_mm = [200.0, 300.0, 500.0, 500.0];

        let mut total_water_deficit_pct = 0.0;

        for (i, layer) in soil.layers.iter_mut().enumerate() {
            let thickness = layer_thicknesses_mm[i];
            let current_water_depth_mm = (layer.moisture_pct / 100.0) * thickness;
            let field_capacity_depth_mm = (layer.field_capacity_pct / 100.0) * thickness;
            let wilting_depth_mm = (layer.wilting_point_pct / 100.0) * thickness;

            // Inflow from upper layer
            let mut available_depth = current_water_depth_mm + percolating_water_mm;

            // Root water uptake from this layer
            let layer_demand = vine_water_demand_mm * root_fractions[i];
            let extractable_water = (available_depth - wilting_depth_mm).max(0.0);
            let actual_uptake = layer_demand.min(extractable_water * 0.7);
            available_depth -= actual_uptake;

            // Drainage to lower layer if exceeds field capacity
            if available_depth > field_capacity_depth_mm {
                let excess = available_depth - field_capacity_depth_mm;
                percolating_water_mm = excess * 0.65; // Drainage fraction
                available_depth = field_capacity_depth_mm + excess * 0.35;
            } else {
                percolating_water_mm = 0.0;
            }

            layer.moisture_pct = ((available_depth / thickness) * 100.0).clamp(5.0, 48.0);

            // Water deficit calculation relative to field capacity and wilting point
            let layer_stress = if layer.moisture_pct <= layer.wilting_point_pct {
                1.0
            } else if layer.moisture_pct >= layer.field_capacity_pct * 0.75 {
                0.0
            } else {
                (layer.field_capacity_pct * 0.75 - layer.moisture_pct)
                    / (layer.field_capacity_pct * 0.75 - layer.wilting_point_pct)
            };
            total_water_deficit_pct += layer_stress * root_fractions[i];
        }

        soil.water_stress_index = total_water_deficit_pct.clamp(0.0, 1.0);
        soil.soil_temperature_c = (soil.soil_temperature_c * 0.90 + temperature_c * 0.10).clamp(2.0, 26.0);
    }
}
