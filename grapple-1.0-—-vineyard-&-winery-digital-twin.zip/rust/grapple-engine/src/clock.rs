use chrono::{DateTime, Duration, Utc};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TimeSpeed {
    X1,
    X5,
    X10,
    X50,
    X100,
    X1000,
    X10000,
}

impl TimeSpeed {
    pub fn multiplier(&self) -> u64 {
        match self {
            TimeSpeed::X1 => 1,
            TimeSpeed::X5 => 5,
            TimeSpeed::X10 => 10,
            TimeSpeed::X50 => 50,
            TimeSpeed::X100 => 100,
            TimeSpeed::X1000 => 1000,
            TimeSpeed::X10000 => 10000,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum StepUnit {
    Hour,
    Day,
    Week,
    Month,
    Vintage,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationClock {
    pub current_time: DateTime<Utc>,
    pub start_time: DateTime<Utc>,
    pub end_time: DateTime<Utc>,
    pub speed: TimeSpeed,
    pub step_unit: StepUnit,
    pub tick_count: u64,
    pub is_running: bool,
}

impl SimulationClock {
    pub fn new(start_time: DateTime<Utc>, end_time: DateTime<Utc>) -> Self {
        Self {
            current_time: start_time,
            start_time,
            end_time,
            speed: TimeSpeed::X100,
            step_unit: StepUnit::Day,
            tick_count: 0,
            is_running: false,
        }
    }

    pub fn advance_day(&mut self) -> DateTime<Utc> {
        self.current_time = self.current_time + Duration::days(1);
        self.tick_count += 1;
        self.current_time
    }

    pub fn advance_hours(&mut self, hours: i64) -> DateTime<Utc> {
        self.current_time = self.current_time + Duration::hours(hours);
        self.tick_count += 1;
        self.current_time
    }

    pub fn is_finished(&self) -> bool {
        self.current_time >= self.end_time
    }

    pub fn progress_pct(&self) -> f64 {
        let total = (self.end_time - self.start_time).num_seconds() as f64;
        if total <= 0.0 {
            return 100.0;
        }
        let elapsed = (self.current_time - self.start_time).num_seconds() as f64;
        (elapsed / total * 100.0).clamp(0.0, 100.0)
    }
}
