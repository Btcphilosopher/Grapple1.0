use rayon::prelude::*;
use serde::{Deserialize, Serialize};
use crate::simulation::{DeterministicVintageSimulator, SimulationConfig};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonteCarloSummaryStat {
    pub mean: f64,
    pub median: f64,
    pub std_dev: f64,
    pub p10: f64,
    pub p25: f64,
    pub p75: f64,
    pub p90: f64,
    pub ci_95_lower: f64,
    pub ci_95_upper: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonteCarloVintageResult {
    pub run_id: u32,
    pub seed: u64,
    pub budbreak_doy: f64,
    pub flowering_doy: f64,
    pub veraison_doy: f64,
    pub harvest_doy: f64,
    pub total_yield_tonnes: f64,
    pub mean_yield_t_ha: f64,
    pub mean_harvest_brix: f64,
    pub mean_harvest_ta_g_l: f64,
    pub mean_harvest_ph: f64,
    pub botrytis_loss_pct: f64,
    pub frost_loss_pct: f64,
    pub sparkling_wine_index: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonteCarloReport {
    pub total_runs: usize,
    pub execution_duration_ms: f64,
    pub throughput_sims_per_sec: f64,
    pub threads_used: usize,
    pub yield_t_ha: MonteCarloSummaryStat,
    pub harvest_doy: MonteCarloSummaryStat,
    pub brix: MonteCarloSummaryStat,
    pub ta_g_l: MonteCarloSummaryStat,
    pub sparkling_wine_index: MonteCarloSummaryStat,
    pub sample_vintages: Vec<MonteCarloVintageResult>,
}

pub struct MonteCarloEngine;

impl MonteCarloEngine {
    /// Execute N parallel stochastic vintage simulations across Rayon CPU thread pool
    pub fn run_parallel(
        config: &SimulationConfig,
        num_runs: usize,
        base_seed: u64,
    ) -> MonteCarloReport {
        let start_time = std::time::Instant::now();
        let threads = rayon::current_num_threads();

        let results: Vec<MonteCarloVintageResult> = (0..num_runs)
            .into_par_iter()
            .map(|i| {
                let seed = base_seed.wrapping_add((i as u64) * 7919);
                let sim = DeterministicVintageSimulator::new(config.clone(), seed);
                let outcome = sim.run_full_vintage();

                MonteCarloVintageResult {
                    run_id: i as u32,
                    seed,
                    budbreak_doy: outcome.budbreak_doy,
                    flowering_doy: outcome.flowering_doy,
                    veraison_doy: outcome.veraison_doy,
                    harvest_doy: outcome.harvest_doy,
                    total_yield_tonnes: outcome.total_yield_tonnes,
                    mean_yield_t_ha: outcome.mean_yield_t_ha,
                    mean_harvest_brix: outcome.mean_harvest_brix,
                    mean_harvest_ta_g_l: outcome.mean_harvest_ta_g_l,
                    mean_harvest_ph: outcome.mean_harvest_ph,
                    botrytis_loss_pct: outcome.disease_loss_pct,
                    frost_loss_pct: outcome.frost_damage_pct,
                    sparkling_wine_index: outcome.sparkling_wine_index,
                }
            })
            .collect();

        let elapsed = start_time.elapsed();
        let duration_ms = elapsed.as_secs_f64() * 1000.0;
        let throughput = if duration_ms > 0.0 {
            (num_runs as f64 / duration_ms) * 1000.0
        } else {
            0.0
        };

        // Calculate distribution stats
        let yields: Vec<f64> = results.iter().map(|r| r.mean_yield_t_ha).collect();
        let harvest_doys: Vec<f64> = results.iter().map(|r| r.harvest_doy).collect();
        let brixes: Vec<f64> = results.iter().map(|r| r.mean_harvest_brix).collect();
        let tas: Vec<f64> = results.iter().map(|r| r.mean_harvest_ta_g_l).collect();
        let indices: Vec<f64> = results.iter().map(|r| r.sparkling_wine_index).collect();

        let sample_vintages = results.iter().take(50).cloned().collect();

        MonteCarloReport {
            total_runs: num_runs,
            execution_duration_ms: (duration_ms * 100.0).round() / 100.0,
            throughput_sims_per_sec: (throughput * 10.0).round() / 10.0,
            threads_used: threads,
            yield_t_ha: compute_summary_stat(&yields),
            harvest_doy: compute_summary_stat(&harvest_doys),
            brix: compute_summary_stat(&brixes),
            ta_g_l: compute_summary_stat(&tas),
            sparkling_wine_index: compute_summary_stat(&indices),
            sample_vintages,
        }
    }
}

fn compute_summary_stat(data: &[f64]) -> MonteCarloSummaryStat {
    if data.is_empty() {
        return MonteCarloSummaryStat {
            mean: 0.0,
            median: 0.0,
            std_dev: 0.0,
            p10: 0.0,
            p25: 0.0,
            p75: 0.0,
            p90: 0.0,
            ci_95_lower: 0.0,
            ci_95_upper: 0.0,
        };
    }

    let mut sorted = data.to_vec();
    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap());

    let n = sorted.len();
    let mean = sorted.iter().sum::<f64>() / n as f64;
    let variance = sorted.iter().map(|v| (v - mean).powi(2)).sum::<f64>() / n as f64;
    let std_dev = variance.sqrt();

    let p10 = sorted[(n as f64 * 0.10) as usize];
    let p25 = sorted[(n as f64 * 0.25) as usize];
    let median = sorted[(n as f64 * 0.50) as usize];
    let p75 = sorted[(n as f64 * 0.75) as usize];
    let p90 = sorted[((n as f64 * 0.90) as usize).min(n - 1)];

    let ci_95_lower = sorted[(n as f64 * 0.025) as usize];
    let ci_95_upper = sorted[((n as f64 * 0.975) as usize).min(n - 1)];

    MonteCarloSummaryStat {
        mean: (mean * 100.0).round() / 100.0,
        median: (median * 100.0).round() / 100.0,
        std_dev: (std_dev * 100.0).round() / 100.0,
        p10: (p10 * 100.0).round() / 100.0,
        p25: (p25 * 100.0).round() / 100.0,
        p75: (p75 * 100.0).round() / 100.0,
        p90: (p90 * 100.0).round() / 100.0,
        ci_95_lower: (ci_95_lower * 100.0).round() / 100.0,
        ci_95_upper: (ci_95_upper * 100.0).round() / 100.0,
    }
}
