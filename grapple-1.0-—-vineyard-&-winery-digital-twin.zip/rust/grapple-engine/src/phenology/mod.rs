use crate::state::{Cultivar, PhenologyStage, VineyardBlock, WeatherState};

#[derive(Debug, Clone)]
pub struct PhenologyEngine;

impl PhenologyEngine {
    /// Update vine phenology based on thermal time accumulation (Growing Degree Days, Base 10°C)
    pub fn update_daily(
        block: &mut VineyardBlock,
        weather: &WeatherState,
        doy: u32,
    ) -> Option<PhenologyStage> {
        if block.harvested_flag {
            return None;
        }

        // Only accumulate GDD starting from Day 60 (March 1st)
        if doy >= 60 {
            let daily_mean = (weather.min_temperature_c + weather.max_temperature_c) / 2.0;
            let daily_gdd = (daily_mean - 10.0).max(0.0);
            block.accumulated_gdd_c += daily_gdd;
        }

        let old_stage = block.phenology_stage;
        let c = block.cultivar;
        let gdd = block.accumulated_gdd_c;

        let new_stage = if gdd < c.base_gdd_budbreak() {
            PhenologyStage::Dormancy
        } else if gdd < c.base_gdd_flowering() {
            PhenologyStage::Budbreak
        } else if gdd < (c.base_gdd_flowering() + 90.0) {
            PhenologyStage::Flowering
        } else if gdd < c.base_gdd_veraison() {
            PhenologyStage::FruitSet
        } else if gdd < c.base_gdd_sparkling_harvest() {
            PhenologyStage::Veraison
        } else if gdd < (c.base_gdd_sparkling_harvest() + 180.0) {
            PhenologyStage::Ripening
        } else {
            PhenologyStage::HarvestReady
        };

        block.phenology_stage = new_stage;

        // Update canopy leaf area index (LAI) progressively with phenology
        block.canopy.leaf_area_index = match new_stage {
            PhenologyStage::Dormancy => 0.0,
            PhenologyStage::Budbreak => 0.4 + (gdd / c.base_gdd_flowering()) * 0.8,
            PhenologyStage::Flowering => 1.2 + ((gdd - c.base_gdd_flowering()) / 200.0) * 0.6,
            PhenologyStage::FruitSet => 1.8.min(2.4),
            PhenologyStage::Veraison | PhenologyStage::Ripening | PhenologyStage::HarvestReady => 2.2,
            PhenologyStage::Harvested => 1.5,
        };

        if new_stage != old_stage {
            Some(new_stage)
        } else {
            None
        }
    }
}
