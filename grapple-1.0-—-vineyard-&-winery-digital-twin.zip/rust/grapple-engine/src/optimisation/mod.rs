use rayon::prelude::*;
use serde::{Deserialize, Serialize};
use crate::simulation::{DeterministicVintageSimulator, SimulationConfig, VintageSimulationMetrics};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScenarioOverride {
    pub name: String,
    pub description: String,
    pub weather_temperature_delta_c: f64,
    pub rainfall_multiplier: f64,
    pub harvest_offset_days: i32,
    pub yield_multiplier: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScenarioComparisonRow {
    pub scenario_name: String,
    pub description: String,
    pub harvest_doy: f64,
    pub harvest_brix: f64,
    pub harvest_ta_g_l: f64,
    pub harvest_ph: f64,
    pub yield_t_ha: f64,
    pub disease_loss_pct: f64,
    pub frost_loss_pct: f64,
    pub sparkling_wine_index: f64,
    pub cellar_suitability_score: f64,
}

pub struct ScenarioEngine;

impl ScenarioEngine {
    /// Execute multiple parameter overrides concurrently and compile comparative matrix
    pub fn run_scenario_matrix(
        base_config: &SimulationConfig,
        scenarios: Vec<ScenarioOverride>,
        seed: u64,
    ) -> Vec<ScenarioComparisonRow> {
        scenarios
            .into_par_iter()
            .map(|sc| {
                let mut sc_config = base_config.clone();
                sc_config.weather_config.warming_delta_c += sc.weather_temperature_delta_c;
                sc_config.weather_config.rainfall_multiplier *= sc.rainfall_multiplier;

                let sim = DeterministicVintageSimulator::new(sc_config, seed);
                let metrics: VintageSimulationMetrics = sim.run_full_vintage();

                // Apply harvest offset adjustments
                let adj_harvest_doy = metrics.harvest_doy + sc.harvest_offset_days as f64;
                let adj_brix = (metrics.mean_harvest_brix + sc.harvest_offset_days as f64 * 0.18).clamp(14.0, 24.0);
                let adj_ta = (metrics.mean_harvest_ta_g_l - sc.harvest_offset_days as f64 * 0.22).clamp(6.0, 18.0);
                let adj_yield = metrics.mean_yield_t_ha * sc.yield_multiplier;
                let adj_sparkling_index = adj_brix / (adj_ta * 0.1 + 0.001);

                // Sparkling Cellar Suitability: 18.5 - 19.5 Brix, 9.5 - 11.0 TA
                let brix_score = (1.0 - ((adj_brix - 19.0) / 2.5).abs()).max(0.0) * 50.0;
                let acid_score = (1.0 - ((adj_ta - 10.0) / 3.0).abs()).max(0.0) * 50.0;
                let suit_score = (brix_score + acid_score - metrics.disease_loss_pct * 0.5).clamp(15.0, 99.0);

                ScenarioComparisonRow {
                    scenario_name: sc.name,
                    description: sc.description,
                    harvest_doy: adj_harvest_doy,
                    harvest_brix: (adj_brix * 10.0).round() / 10.0,
                    harvest_ta_g_l: (adj_ta * 10.0).round() / 10.0,
                    harvest_ph: metrics.mean_harvest_ph,
                    yield_t_ha: (adj_yield * 100.0).round() / 100.0,
                    disease_loss_pct: (metrics.disease_loss_pct * 10.0).round() / 10.0,
                    frost_loss_pct: (metrics.frost_damage_pct * 10.0).round() / 10.0,
                    sparkling_wine_index: (adj_sparkling_index * 100.0).round() / 100.0,
                    cellar_suitability_score: (suit_score * 10.0).round() / 10.0,
                }
            })
            .collect()
    }
}
