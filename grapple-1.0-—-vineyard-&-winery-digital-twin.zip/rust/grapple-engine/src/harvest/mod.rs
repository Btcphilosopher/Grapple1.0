use serde::{Deserialize, Serialize};
use crate::state::VineyardBlock;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HarvestScenarioEvaluation {
    pub day_offset: i32,
    pub harvest_date_doy: u32,
    pub projected_brix: f64,
    pub projected_ta_g_l: f64,
    pub projected_ph: f64,
    pub sparkling_wine_index: f64, // Optimal sparkling window: Brix ~18.5 - 19.5, TA ~9.0 - 11.0
    pub weather_frost_rain_risk_pct: f64,
    pub projected_botrytis_risk_pct: f64,
    pub winery_press_capacity_available_pct: f64,
    pub composite_score: f64, // 0 - 100 rank
    pub recommendation: String,
}

pub struct HarvestOptimiser;

impl HarvestOptimiser {
    /// Evaluate 14-day forward harvest window for a block targeting Traditional Sparkling Wine or Still Wine
    pub fn evaluate_window(
        block: &VineyardBlock,
        current_doy: u32,
        is_sparkling_target: bool,
    ) -> Vec<HarvestScenarioEvaluation> {
        let mut evaluations = Vec::new();

        for offset in 0..=14 {
            let eval_doy = current_doy + offset as u32;

            // Projected chemistry progression
            let brix_delta = offset as f64 * 0.18;
            let ta_delta = offset as f64 * -0.22;
            let proj_brix = (block.berry_state.brix + brix_delta).clamp(14.0, 23.0);
            let proj_ta = (block.berry_state.ta_g_l + ta_delta).clamp(6.5, 18.0);
            let proj_ph = (2.75 + 0.05 * proj_brix - 0.04 * proj_ta).clamp(2.90, 3.55);

            // Sparkling Index: ratio of sugar to acid balance (Target ~ 1.8 - 2.2 for Traditional Method UK Base)
            let sparkling_index = proj_brix / (proj_ta * 0.1 + 0.001);

            // Simulated increasing weather risk as autumn progresses in late October
            let weather_risk = (12.0 + offset as f64 * 3.5).min(85.0);
            let botrytis_risk = (block.botrytis_risk_pct + offset as f64 * 2.8).min(95.0);

            // Winery capacity constraint simulation
            let press_cap_available = match offset {
                3 | 4 | 5 => 95.0, // Peak optimal press opening
                7 | 8 => 45.0,     // Heavy estate intake
                _ => 80.0,
            };

            // Composite scoring algorithm
            let chemistry_score = if is_sparkling_target {
                // Ideal for UK Sparkling: 18.5 - 19.5 Brix, 9.5 - 11.0 TA, pH 2.95 - 3.15
                let brix_fit = (1.0 - ((proj_brix - 19.0) / 3.0).abs()).max(0.0) * 40.0;
                let ta_fit = (1.0 - ((proj_ta - 10.2) / 3.5).abs()).max(0.0) * 40.0;
                let ph_fit = (1.0 - ((proj_ph - 3.05) / 0.25).abs()).max(0.0) * 20.0;
                brix_fit + ta_fit + ph_fit
            } else {
                // Still wine target: 20.5 - 22.0 Brix, 7.5 - 8.5 TA
                let brix_fit = (1.0 - ((proj_brix - 21.0) / 3.0).abs()).max(0.0) * 50.0;
                let ta_fit = (1.0 - ((proj_ta - 8.0) / 3.0).abs()).max(0.0) * 50.0;
                brix_fit + ta_fit
            };

            let risk_penalty = (weather_risk * 0.25) + (botrytis_risk * 0.35);
            let logistics_score = press_cap_available * 0.20;

            let raw_composite = (chemistry_score * 0.65 + logistics_score) - (risk_penalty * 0.35);
            let composite_score = raw_composite.clamp(10.0, 99.5);

            let recommendation = if composite_score >= 88.0 {
                "OPTIMAL_WINDOW".to_string()
            } else if composite_score >= 72.0 {
                "ACCEPTABLE".to_string()
            } else if botrytis_risk > 50.0 {
                "HIGH_ROT_RISK".to_string()
            } else {
                "SUBOPTIMAL".to_string()
            };

            evaluations.push(HarvestScenarioEvaluation {
                day_offset: offset,
                harvest_date_doy: eval_doy,
                projected_brix: (proj_brix * 10.0).round() / 10.0,
                projected_ta_g_l: (proj_ta * 10.0).round() / 10.0,
                projected_ph: (proj_ph * 100.0).round() / 100.0,
                sparkling_wine_index: (sparkling_index * 100.0).round() / 100.0,
                weather_frost_rain_risk_pct: (weather_risk * 10.0).round() / 10.0,
                projected_botrytis_risk_pct: (botrytis_risk * 10.0).round() / 10.0,
                winery_press_capacity_available_pct: press_cap_available,
                composite_score: (composite_score * 10.0).round() / 10.0,
                recommendation,
            });
        }

        // Sort ranking by composite score descending
        evaluations.sort_by(|a, b| b.composite_score.partial_cmp(&a.composite_score).unwrap());
        evaluations
    }
}
