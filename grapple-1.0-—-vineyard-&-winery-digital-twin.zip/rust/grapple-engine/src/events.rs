use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BudbreakEvent {
    pub block_id: Uuid,
    pub block_name: String,
    pub cultivar: String,
    pub gdd_accumulated: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FloweringEvent {
    pub block_id: Uuid,
    pub block_name: String,
    pub gdd_accumulated: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FruitSetEvent {
    pub block_id: Uuid,
    pub berries_per_cluster_est: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VeraisonEvent {
    pub block_id: Uuid,
    pub starting_brix: f64,
    pub starting_ta: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FrostEvent {
    pub min_temp_c: f64,
    pub affected_blocks: Vec<String>,
    pub damage_pct: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DiseaseRiskEvent {
    pub disease_type: String,
    pub block_id: Uuid,
    pub risk_pct: f64,
    pub leaf_wetness_hours: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HarvestEvent {
    pub block_id: Uuid,
    pub block_name: String,
    pub cultivar: String,
    pub harvested_kg: f64,
    pub brix: f64,
    pub ta_g_l: f64,
    pub ph: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FermentationEvent {
    pub tank_id: String,
    pub current_brix: f64,
    pub current_ethanol: f64,
    pub status: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EquipmentFailureEvent {
    pub equipment_id: String,
    pub failure_mode: String,
    pub severity: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", content = "data")]
pub enum SimulationEvent {
    Budbreak(BudbreakEvent),
    Flowering(FloweringEvent),
    FruitSet(FruitSetEvent),
    Veraison(VeraisonEvent),
    Rainfall { mm: f64 },
    Frost(FrostEvent),
    DiseaseRiskIncrease(DiseaseRiskEvent),
    CanopyOperation { block_id: Uuid, operation: String },
    Harvest(HarvestEvent),
    GrapeReception { batch_id: Uuid, weight_kg: f64 },
    PressStart { press_id: String, load_kg: f64 },
    PressComplete { press_id: String, juice_l: f64, yield_pct: f64 },
    FermentationStart { tank_id: String, initial_brix: f64 },
    FermentationUpdate(FermentationEvent),
    FermentationComplete { tank_id: String, final_ethanol: f64, residual_sugar: f64 },
    TankTransfer { from_tank: String, to_tank: String, volume_l: f64 },
    Blending { blend_name: String, components: Vec<String>, total_volume_l: f64 },
    Bottling { batch_id: Uuid, bottle_count_750ml: u32 },
    EquipmentFailure(EquipmentFailureEvent),
    Maintenance { equipment_id: String, duration_h: f64 },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TimestampedEvent {
    pub timestamp_iso: DateTime<Utc>,
    pub simulation_tick: u64,
    pub event: SimulationEvent,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct EventLog {
    pub events: Vec<TimestampedEvent>,
}

impl EventLog {
    pub fn new() -> Self {
        Self { events: Vec::new() }
    }

    pub fn record(&mut self, timestamp: DateTime<Utc>, tick: u64, event: SimulationEvent) {
        self.events.push(TimestampedEvent {
            timestamp_iso: timestamp,
            simulation_tick: tick,
            event,
        });
    }

    pub fn len(&self) -> usize {
        self.events.len()
    }
}
