use chrono::{DateTime, Duration, TimeZone, Utc};
use rand::prelude::*;
use rand_chacha::ChaCha8Rng;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

use crate::disease::DiseaseEngine;
use crate::events::{BudbreakEvent, EventLog, FloweringEvent, FrostEvent, HarvestEvent, SimulationEvent, VeraisonEvent};
use crate::fermentation::{FermentationEngine, FermentationKinetics};
use crate::phenology::PhenologyEngine;
use crate::ripening::RipeningEngine;
use crate::soil::SoilWaterEngine;
use crate::state::{
    CanopyState, Cultivar, Estate, PhenologyStage, VineyardBlock, VineyardState, WeatherState,
};
use crate::vineyard::compute_block_microclimate;
use crate::weather::{StochasticWeatherEngine, WeatherGeneratorConfig};
use crate::winery::WineryEngine;
use crate::yield_model::YieldEngine;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationConfig {
    pub vintage_year: i32,
    pub estate_name: String,
    pub weather_config: WeatherGeneratorConfig,
    pub model_version: String,
    pub parameter_version: String,
}

impl Default for SimulationConfig {
    fn default() -> Self {
        Self {
            vintage_year: 2031,
            estate_name: "Wessex Chalk Downland Estate".into(),
            weather_config: WeatherGeneratorConfig::default(),
            model_version: "GRAPPLE Model v1.0".into(),
            parameter_version: "PARAMS-2031-PROD".into(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VintageSimulationMetrics {
    pub simulation_id: Uuid,
    pub seed: u64,
    pub vintage_year: i32,
    pub budbreak_doy: f64,
    pub flowering_doy: f64,
    pub veraison_doy: f64,
    pub harvest_doy: f64,
    pub total_yield_tonnes: f64,
    pub mean_yield_t_ha: f64,
    pub mean_harvest_brix: f64,
    pub mean_harvest_ta_g_l: f64,
    pub mean_harvest_ph: f64,
    pub sparkling_wine_index: f64,
    pub disease_loss_pct: f64,
    pub frost_damage_pct: f64,
    pub total_gdd_accumulated: f64,
    pub annual_rainfall_mm: f64,
}

pub struct DeterministicVintageSimulator {
    pub config: SimulationConfig,
    pub seed: u64,
    pub state: VineyardState,
    pub event_log: EventLog,
    rng: ChaCha8Rng,
}

impl DeterministicVintageSimulator {
    pub fn new(config: SimulationConfig, seed: u64) -> Self {
        let mut rng = ChaCha8Rng::seed_from_u64(seed);
        let estate_id = Uuid::new_v4();

        // Create standard vineyard blocks for the English Estate
        let blocks = vec![
            VineyardBlock {
                block_id: Uuid::new_v4(),
                block_name: "Block 04 — South Chalk Bench".into(),
                cultivar: Cultivar::Chardonnay,
                area_ha: 4.2,
                vine_count: 17640, // 4200 vines/ha
                planting_year: 2012,
                trellis_system: "Double Guyot".into(),
                elevation_m: 68.0,
                slope_deg: 8.5,
                aspect_deg: 185.0, // South facing
                soil_type: "Chalk / Rendzina".into(),
                phenology_stage: PhenologyStage::Dormancy,
                accumulated_gdd_c: 0.0,
                canopy: CanopyState::default(),
                berry_state: Default::default(),
                downy_mildew_risk_pct: 0.0,
                powdery_mildew_risk_pct: 0.0,
                botrytis_risk_pct: 0.0,
                estimated_yield_kg_ha: 7200.0,
                harvested_flag: false,
            },
            VineyardBlock {
                block_id: Uuid::new_v4(),
                block_name: "Block 12 — Middlecombe Slope".into(),
                cultivar: Cultivar::PinotNoir,
                area_ha: 3.8,
                vine_count: 15960,
                planting_year: 2014,
                trellis_system: "Double Guyot".into(),
                elevation_m: 54.0,
                slope_deg: 6.2,
                aspect_deg: 175.0,
                soil_type: "Chalky Silt Loam".into(),
                phenology_stage: PhenologyStage::Dormancy,
                accumulated_gdd_c: 0.0,
                canopy: CanopyState::default(),
                berry_state: Default::default(),
                downy_mildew_risk_pct: 0.0,
                powdery_mildew_risk_pct: 0.0,
                botrytis_risk_pct: 0.0,
                estimated_yield_kg_ha: 6800.0,
                harvested_flag: false,
            },
            VineyardBlock {
                block_id: Uuid::new_v4(),
                block_name: "Block 07 — Lower Valley Bottom".into(),
                cultivar: Cultivar::PinotMeunier,
                area_ha: 2.5,
                vine_count: 10500,
                planting_year: 2016,
                trellis_system: "Single Guyot".into(),
                elevation_m: 32.0,
                slope_deg: 1.5,
                aspect_deg: 160.0,
                soil_type: "Deep Alluvial Loam".into(),
                phenology_stage: PhenologyStage::Dormancy,
                accumulated_gdd_c: 0.0,
                canopy: CanopyState::default(),
                berry_state: Default::default(),
                downy_mildew_risk_pct: 0.0,
                powdery_mildew_risk_pct: 0.0,
                botrytis_risk_pct: 0.0,
                estimated_yield_kg_ha: 7500.0,
                harvested_flag: false,
            },
            VineyardBlock {
                block_id: Uuid::new_v4(),
                block_name: "Block 01 — Bacchus Plateau".into(),
                cultivar: Cultivar::Bacchus,
                area_ha: 2.0,
                vine_count: 8400,
                planting_year: 2018,
                trellis_system: "Double Guyot".into(),
                elevation_m: 82.0,
                slope_deg: 4.0,
                aspect_deg: 200.0,
                soil_type: "Greensand over Chalk".into(),
                phenology_stage: PhenologyStage::Dormancy,
                accumulated_gdd_c: 0.0,
                canopy: CanopyState::default(),
                berry_state: Default::default(),
                downy_mildew_risk_pct: 0.0,
                powdery_mildew_risk_pct: 0.0,
                botrytis_risk_pct: 0.0,
                estimated_yield_kg_ha: 8200.0,
                harvested_flag: false,
            },
        ];

        let start_time = Utc.with_ymd_and_hms(config.vintage_year, 1, 1, 0, 0, 0).unwrap();
        let winery = WineryEngine::create_standard_winery();

        let state = VineyardState {
            estate_id,
            estate_name: config.estate_name.clone(),
            simulation_time: start_time,
            simulation_tick: 0,
            model_version: config.model_version.clone(),
            parameter_version: config.parameter_version.clone(),
            blocks,
            weather: WeatherState::default(),
            soil: Default::default(),
            winery,
        };

        Self {
            config,
            seed,
            state,
            event_log: EventLog::new(),
            rng,
        }
    }

    /// Execute deterministic simulation for the complete 365-day vintage cycle
    pub fn run_full_vintage(mut self) -> VintageSimulationMetrics {
        let weather_engine = StochasticWeatherEngine::new(self.config.weather_config.clone());
        let kinetics = FermentationKinetics::default();

        let mut budbreak_doy = 0.0;
        let mut flowering_doy = 0.0;
        let mut veraison_doy = 0.0;
        let mut harvest_doy = 0.0;

        let mut total_rainfall_mm = 0.0;
        let mut max_gdd_recorded = 0.0;
        let mut total_frost_damage_pct = 0.0;

        for doy in 1..=365 {
            let base_weather = weather_engine.generate_day(doy, &mut self.rng);
            total_rainfall_mm += base_weather.rainfall_mm;

            self.state.weather = base_weather.clone();
            self.state.simulation_tick += 1;
            let current_date = Utc.with_ymd_and_hms(self.config.vintage_year, 1, 1, 0, 0, 0).unwrap()
                + Duration::days((doy - 1) as i64);
            self.state.simulation_time = current_date;

            // Soil update
            SoilWaterEngine::update_daily(
                &mut self.state.soil,
                base_weather.rainfall_mm,
                base_weather.temperature_c,
                base_weather.solar_radiation_w_m2,
                2.0,
            );

            // Update vineyard blocks
            for block in self.state.blocks.iter_mut() {
                let block_micro = compute_block_microclimate(block, &base_weather);

                // Spring frost event
                if doy >= 90 && doy <= 140 && block_micro.min_temperature_c < 0.0 {
                    let damage = (block_micro.min_temperature_c.abs() * 12.0).min(45.0);
                    total_frost_damage_pct = total_frost_damage_pct.max(damage);
                    self.event_log.record(
                        current_date,
                        self.state.simulation_tick,
                        SimulationEvent::Frost(FrostEvent {
                            min_temp_c: block_micro.min_temperature_c,
                            affected_blocks: vec![block.block_name.clone()],
                            damage_pct: damage,
                        }),
                    );
                }

                // Phenology step
                if let Some(new_stage) = PhenologyEngine::update_daily(block, &block_micro, doy) {
                    match new_stage {
                        PhenologyStage::Budbreak => {
                            if budbreak_doy == 0.0 {
                                budbreak_doy = doy as f64;
                            }
                            self.event_log.record(
                                current_date,
                                self.state.simulation_tick,
                                SimulationEvent::Budbreak(BudbreakEvent {
                                    block_id: block.block_id,
                                    block_name: block.block_name.clone(),
                                    cultivar: block.cultivar.as_str().into(),
                                    gdd_accumulated: block.accumulated_gdd_c,
                                }),
                            );
                        }
                        PhenologyStage::Flowering => {
                            if flowering_doy == 0.0 {
                                flowering_doy = doy as f64;
                            }
                            self.event_log.record(
                                current_date,
                                self.state.simulation_tick,
                                SimulationEvent::Flowering(FloweringEvent {
                                    block_id: block.block_id,
                                    block_name: block.block_name.clone(),
                                    gdd_accumulated: block.accumulated_gdd_c,
                                }),
                            );
                        }
                        PhenologyStage::Veraison => {
                            if veraison_doy == 0.0 {
                                veraison_doy = doy as f64;
                            }
                            self.event_log.record(
                                current_date,
                                self.state.simulation_tick,
                                SimulationEvent::Veraison(VeraisonEvent {
                                    block_id: block.block_id,
                                    starting_brix: block.berry_state.brix,
                                    starting_ta: block.berry_state.ta_g_l,
                                }),
                            );
                        }
                        PhenologyStage::HarvestReady => {
                            if harvest_doy == 0.0 {
                                harvest_doy = doy as f64;
                            }
                        }
                        _ => {}
                    }
                }

                // Ripening and Disease steps
                RipeningEngine::update_daily(block, &block_micro, self.state.soil.water_stress_index);
                DiseaseEngine::update_daily(block, &block_micro);

                // Yield computation
                let (kg_ha, _) = YieldEngine::calculate_block_yield(block, total_frost_damage_pct, 2.0);
                block.estimated_yield_kg_ha = kg_ha;
                max_gdd_recorded = max_gdd_recorded.max(block.accumulated_gdd_c);
            }

            // Cellar fermentation stepping (24 hours per simulation day)
            for tank in self.state.winery.tanks.iter_mut() {
                for _ in 0..24 {
                    FermentationEngine::step_tank_hourly(tank, 1.0, &kinetics);
                }
            }
        }

        // Aggregate vintage metrics
        let num_blocks = self.state.blocks.len() as f64;
        let mut total_tonnes = 0.0;
        let mut total_brix = 0.0;
        let mut total_ta = 0.0;
        let mut total_ph = 0.0;
        let mut total_botrytis = 0.0;

        for block in &self.state.blocks {
            let tonnes = (block.estimated_yield_kg_ha * block.area_ha) / 1000.0;
            total_tonnes += tonnes;
            total_brix += block.berry_state.brix;
            total_ta += block.berry_state.ta_g_l;
            total_ph += block.berry_state.ph;
            total_botrytis += block.botrytis_risk_pct;
        }

        let mean_brix = total_brix / num_blocks;
        let mean_ta = total_ta / num_blocks;
        let mean_ph = total_ph / num_blocks;
        let mean_botrytis = total_botrytis / num_blocks;
        let total_area: f64 = self.state.blocks.iter().map(|b| b.area_ha).sum();
        let mean_yield_t_ha = total_tonnes / total_area.max(0.1);

        let default_harvest = if harvest_doy > 0.0 { harvest_doy } else { 282.0 };
        let sparkling_index = mean_brix / (mean_ta * 0.1 + 0.001);

        VintageSimulationMetrics {
            simulation_id: Uuid::new_v4(),
            seed: self.seed,
            vintage_year: self.config.vintage_year,
            budbreak_doy: if budbreak_doy > 0.0 { budbreak_doy } else { 108.0 },
            flowering_doy: if flowering_doy > 0.0 { flowering_doy } else { 172.0 },
            veraison_doy: if veraison_doy > 0.0 { veraison_doy } else { 235.0 },
            harvest_doy: default_harvest,
            total_yield_tonnes: (total_tonnes * 100.0).round() / 100.0,
            mean_yield_t_ha: (mean_yield_t_ha * 100.0).round() / 100.0,
            mean_harvest_brix: (mean_brix * 10.0).round() / 10.0,
            mean_harvest_ta_g_l: (mean_ta * 10.0).round() / 10.0,
            mean_harvest_ph: (mean_ph * 100.0).round() / 100.0,
            sparkling_wine_index: (sparkling_index * 100.0).round() / 100.0,
            disease_loss_pct: (mean_botrytis * 0.35 * 10.0).round() / 10.0,
            frost_damage_pct: (total_frost_damage_pct * 10.0).round() / 10.0,
            total_gdd_accumulated: (max_gdd_recorded * 10.0).round() / 10.0,
            annual_rainfall_mm: (total_rainfall_mm * 10.0).round() / 10.0,
        }
    }
}
