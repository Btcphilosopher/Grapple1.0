use crate::state::{FermentationStage, FermentationTank};

#[derive(Debug, Clone)]
pub struct FermentationKinetics {
    pub max_growth_rate_mu_max: f64,
    pub sugar_affinity_ks: f64,
    pub nitrogen_affinity_kn: f64,
    pub ethanol_inhibition_k_e: f64,
    pub sugar_yield_coeff_y_sx: f64,
    pub ethanol_yield_coeff_y_es: f64,
    pub heat_generation_kj_per_g_sugar: f64,
}

impl Default for FermentationKinetics {
    fn default() -> Self {
        // Saccharomyces cerevisiae sparkling strain (e.g., EC1118 / IOC 18-2007)
        Self {
            max_growth_rate_mu_max: 0.12, // h^-1
            sugar_affinity_ks: 8.0,       // g/L
            nitrogen_affinity_kn: 25.0,   // mg/L
            ethanol_inhibition_k_e: 13.5, // % vol
            sugar_yield_coeff_y_sx: 0.06,
            ethanol_yield_coeff_y_es: 0.58, // Gay-Lussac yield factor with typical volatilization
            heat_generation_kj_per_g_sugar: 0.55,
        }
    }
}

pub struct FermentationEngine;

impl FermentationEngine {
    /// Step tank fermentation kinetics for delta hours dt
    pub fn step_tank_hourly(
        tank: &mut FermentationTank,
        dt_hours: f64,
        kinetics: &FermentationKinetics,
    ) {
        if tank.current_volume_l <= 0.0 || tank.stage != FermentationStage::PrimaryFermentation {
            return;
        }

        // Convert Brix to g/L sugar approx: Sugar (g/L) ~ Brix * 10.0 * (1.0 + 0.004 * Brix)
        let mut sugar_g_l = tank.sugar_brix * 10.4;
        let ethanol = tank.ethanol_pct_vol;
        let mut biomass = tank.yeast_biomass_g_l;
        let mut yan = tank.nitrogen_yan_mg_l;
        let temp = tank.temperature_c;

        // Temperature kinetic factor (Arrhenius / cardinal temp curve)
        let temp_factor = if temp < 8.0 {
            0.05
        } else if temp <= 18.0 {
            (temp - 8.0) / 10.0
        } else if temp <= 26.0 {
            1.0 + (temp - 18.0) * 0.05
        } else {
            (1.0 - (temp - 26.0) * 0.15).max(0.0)
        };

        // Monod kinetic specific growth rate mu
        let s_term = sugar_g_l / (kinetics.sugar_affinity_ks + sugar_g_l);
        let n_term = yan / (kinetics.nitrogen_affinity_kn + yan);
        let e_inhibition = (1.0 - (ethanol / kinetics.ethanol_inhibition_k_e)).max(0.0);

        let mu = kinetics.max_growth_rate_mu_max * s_term * n_term * e_inhibition * temp_factor;

        // Yeast biomass growth
        let d_biomass = (mu * biomass - 0.008 * biomass) * dt_hours;
        biomass = (biomass + d_biomass).clamp(0.05, 12.0);

        // Sugar consumption rate: (dS/dt) = (mu / Y_sx) * X + Maintenance * X
        let maintenance_m = 0.015 * temp_factor;
        let rate_ds = (mu / kinetics.sugar_yield_coeff_y_sx + maintenance_m) * biomass;
        let consumed_sugar_g_l = (rate_ds * dt_hours).min(sugar_g_l);
        sugar_g_l = (sugar_g_l - consumed_sugar_g_l).max(0.0);

        // Nitrogen consumption
        let consumed_yan = consumed_sugar_g_l * 0.65;
        yan = (yan - consumed_yan).max(5.0);

        // Ethanol production
        let produced_ethanol_pct = (consumed_sugar_g_l * kinetics.ethanol_yield_coeff_y_es) / 10.0;
        let new_ethanol = (ethanol + produced_ethanol_pct).min(15.5);

        // CO2 rate generation (g / L / h)
        let co2_rate = consumed_sugar_g_l * 0.48 / dt_hours.max(0.1);

        // Tank temperature dynamics: fermentation heat generation vs jacket cooling
        let heat_generated_c = (consumed_sugar_g_l * 0.008) / dt_hours.max(0.1);
        let jacket_cooling = if tank.cooling_active && tank.temperature_c > tank.target_temperature_c {
            (tank.temperature_c - tank.target_temperature_c) * 0.45
        } else {
            0.0
        };
        let ambient_heat_exchange = (15.0 - tank.temperature_c) * 0.03;

        tank.temperature_c = (tank.temperature_c + (heat_generated_c - jacket_cooling + ambient_heat_exchange) * dt_hours)
            .clamp(10.0, 32.0);

        // Update tank state
        tank.sugar_brix = (sugar_g_l / 10.4).max(0.0);
        tank.ethanol_pct_vol = new_ethanol;
        tank.yeast_biomass_g_l = biomass;
        tank.nitrogen_yan_mg_l = yan;
        tank.co2_rate_g_l_h = co2_rate;

        // Detect stuck fermentation condition (high sugar, low YAN, high ethanol, near-zero mu)
        if tank.sugar_brix > 3.0 && rate_ds < 0.04 && tank.ethanol_pct_vol > 5.0 {
            tank.stuck_flag = true;
        } else if tank.sugar_brix < 0.5 {
            tank.stuck_flag = false;
            tank.stage = FermentationStage::MalolacticFermentation;
        }
    }

    /// Recovery intervention for stuck fermentation (yeast reinoculation + DAP/organic nitrogen nutrient addition)
    pub fn restart_stuck_fermentation(tank: &mut FermentationTank) {
        if tank.stuck_flag {
            tank.nitrogen_yan_mg_l += 120.0;
            tank.yeast_biomass_g_l = 3.5; // Fresh adapted starter culture
            tank.target_temperature_c = 18.0;
            tank.temperature_c = 18.0;
            tank.stuck_flag = false;
        }
    }
}
