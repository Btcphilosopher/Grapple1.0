use crate::state::{VineyardBlock, WeatherState};

/// Compute topoclimatic microclimate modifiers for a specific block based on elevation, slope, and aspect
pub fn compute_block_microclimate(
    block: &VineyardBlock,
    base_weather: &WeatherState,
) -> WeatherState {
    let mut w = base_weather.clone();

    // Lapse rate: ~0.65 C per 100m elevation
    let elevation_delta = (block.elevation_m - 50.0) / 100.0 * 0.65;
    w.temperature_c -= elevation_delta;
    w.min_temperature_c -= elevation_delta;
    w.max_temperature_c -= elevation_delta;

    // Aspect and slope solar radiation adjustment (180 deg = south facing in Northern hemisphere)
    let aspect_rad = block.aspect_deg.to_radians();
    let slope_factor = (block.slope_deg / 45.0).clamp(0.0, 1.0);
    // South-facing slopes (180 deg) get highest solar boost; North-facing (0 deg) get least
    let solar_aspect_mod = 1.0 + (aspect_rad.cos() * -1.0) * slope_factor * 0.22;
    w.solar_radiation_w_m2 = (w.solar_radiation_w_m2 * solar_aspect_mod).max(20.0);

    // Frost pooling in low-lying flat areas (low elevation + low slope)
    if block.elevation_m < 35.0 && block.slope_deg < 2.0 && w.min_temperature_c <= 2.5 {
        w.min_temperature_c -= 1.8;
        w.frost_risk_pct = (w.frost_risk_pct + 35.0).min(100.0);
    }

    w
}
