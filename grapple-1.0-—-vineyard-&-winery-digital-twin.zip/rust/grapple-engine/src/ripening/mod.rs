use crate::state::{PhenologyStage, VineyardBlock, WeatherState};

pub struct RipeningEngine;

impl RipeningEngine {
    /// Update berry chemistry dynamics (Brix, pH, TA, Malic, Tartaric acid, Berry Weight) during Veraison & Ripening
    pub fn update_daily(
        block: &mut VineyardBlock,
        weather: &WeatherState,
        water_stress_index: f64,
    ) {
        if block.phenology_stage != PhenologyStage::Veraison
            && block.phenology_stage != PhenologyStage::Ripening
            && block.phenology_stage != PhenologyStage::HarvestReady
        {
            return;
        }

        let b = &mut block.berry_state;
        let temp = weather.temperature_c;
        let solar_mj = (weather.solar_radiation_w_m2 * 3600.0 * 8.0) / 1_000_000.0; // Daily approx MJ/m2

        // Brix accumulation: driven by photosynthesis (solar + temp), moderated by water stress & crop load
        // Moderate water stress (0.2-0.4) slightly enhances sugar concentration, high stress (>0.7) halts photosynthesis
        let stress_modifier = if water_stress_index < 0.35 {
            1.0 + (0.35 - water_stress_index) * 0.2
        } else {
            (1.0 - (water_stress_index - 0.35) * 1.5).max(0.1)
        };

        let temp_thermal_efficiency = if temp < 10.0 {
            0.0
        } else if temp <= 25.0 {
            (temp - 10.0) / 15.0
        } else if temp <= 32.0 {
            1.0
        } else {
            (1.0 - (temp - 32.0) * 0.1).max(0.2)
        };

        // Daily sugar increase (°Brix/day): typically 0.15 - 0.40 °Brix in English autumn
        let daily_brix_gain = (0.22 * temp_thermal_efficiency * (solar_mj / 14.0) * stress_modifier)
            .clamp(0.01, 0.48);

        // Maximum Brix achievable for English cool climate sparkling profile
        let max_brix_target = 22.5;
        if b.brix < max_brix_target {
            b.brix = (b.brix + daily_brix_gain).min(max_brix_target);
        }

        // Malic acid respiration: highly temperature-sensitive degradation at night/day (Q10 ~ 2.0)
        let malic_degradation_rate = if temp > 12.0 {
            0.018 * ((temp - 10.0) / 10.0).powf(1.4)
        } else {
            0.004
        };
        b.malic_acid_g_l = (b.malic_acid_g_l - malic_degradation_rate).max(2.8);

        // Tartaric acid: stable with minor dilution effect
        b.tartaric_acid_g_l = (b.tartaric_acid_g_l * 0.998).max(5.2);

        // Total Titratable Acidity TA (g/L as tartaric equivalent)
        b.ta_g_l = b.tartaric_acid_g_l + (b.malic_acid_g_l * 0.95);

        // pH model: inversely proportional to [H+] and log of TA, buffered by potassium accumulation
        let calculated_ph = 2.70 + 0.055 * b.brix - 0.045 * b.ta_g_l;
        b.ph = calculated_ph.clamp(2.85, 3.65);

        // Berry weight expansion with rainfall, shrinkage during prolonged drought
        let rain_boost = if weather.rainfall_mm > 5.0 {
            0.02 * (weather.rainfall_mm / 15.0).min(0.06)
        } else {
            -0.003
        };
        b.berry_weight_g = (b.berry_weight_g + rain_boost).clamp(0.95, 2.15);

        // Anthocyanins (for Pinot Noir / Meunier)
        if b.brix > 14.0 {
            b.anthocyanins_mg_l += (b.brix - 14.0) * 8.5 * temp_thermal_efficiency;
        }
    }
}
