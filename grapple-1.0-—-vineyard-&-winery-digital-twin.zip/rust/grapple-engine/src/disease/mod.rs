use crate::state::{PhenologyStage, VineyardBlock, WeatherState};

pub struct DiseaseEngine;

impl DiseaseEngine {
    /// Probabilistic disease pressure calculation for Plasmopara viticola (Downy mildew),
    /// Erysiphe necator (Powdery mildew), and Botrytis cinerea (Grey rot).
    pub fn update_daily(block: &mut VineyardBlock, weather: &WeatherState) {
        let temp = weather.temperature_c;
        let hum = weather.relative_humidity_pct;
        let rain = weather.rainfall_mm;
        let wet_hours = weather.leaf_wetness_hours;
        let lai = block.canopy.leaf_area_index;

        // 1. Downy Mildew (Plasmopara viticola): Requires 10-10-10 rule (10mm rain, 10°C temp, 24h) + prolonged leaf wetness
        let downy_primary_infection = if temp >= 10.0 && rain >= 5.0 && wet_hours >= 4.0 {
            let temp_factor = if temp <= 22.0 {
                (temp - 10.0) / 12.0
            } else {
                (1.0 - (temp - 22.0) / 10.0).max(0.0)
            };
            (wet_hours / 12.0 * temp_factor * (lai / 2.0) * 35.0).min(60.0)
        } else {
            -2.5 // Natural dry decay
        };
        block.downy_mildew_risk_pct = (block.downy_mildew_risk_pct + downy_primary_infection).clamp(0.0, 100.0);

        // 2. Powdery Mildew (Erysiphe necator): Thrives in high humidity (70-90%) with moderate temps (20-28°C), retarded by free rain washing
        let powdery_gain = if temp >= 15.0 && temp <= 29.0 && hum >= 65.0 {
            let rain_washing_reduction = if rain > 8.0 { 0.5 } else { 1.0 };
            let opt_temp_fac = 1.0 - ((temp - 24.0) / 10.0).powi(2).min(1.0);
            (opt_temp_fac * (hum / 100.0) * (lai / 1.8) * 18.0 * rain_washing_reduction).min(30.0)
        } else {
            -1.8
        };
        block.powdery_mildew_risk_pct = (block.powdery_mildew_risk_pct + powdery_gain).clamp(0.0, 100.0);

        // 3. Botrytis Cinerea (Grey Rot): Critical during Veraison & Ripening if rain and high humidity occur
        let botrytis_gain = if (block.phenology_stage == PhenologyStage::Veraison
            || block.phenology_stage == PhenologyStage::Ripening
            || block.phenology_stage == PhenologyStage::HarvestReady)
            && (rain > 2.0 || wet_hours > 6.0)
            && hum > 75.0
        {
            let sugar_susceptibility = (block.berry_state.brix / 16.0).clamp(0.8, 1.8);
            let wetness_severity = (wet_hours / 8.0).min(2.5);
            (wetness_severity * sugar_susceptibility * (lai / 1.8) * 16.5)
        } else {
            -3.0
        };
        block.botrytis_risk_pct = (block.botrytis_risk_pct + botrytis_gain).clamp(0.0, 100.0);
    }
}
