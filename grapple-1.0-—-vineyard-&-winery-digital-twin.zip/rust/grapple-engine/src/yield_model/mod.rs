use crate::state::VineyardBlock;

pub struct YieldEngine;

impl YieldEngine {
    /// Calculate current estimated block yield (kg/ha and total tonnes)
    /// based on vine density, clusters per vine, berry weight, fruit set, and frost/disease penalties
    pub fn calculate_block_yield(
        block: &VineyardBlock,
        frost_damage_pct: f64,
        wildlife_loss_pct: f64,
    ) -> (f64, f64) {
        let vines_per_ha = block.vine_count as f64 / block.area_ha.max(0.01);
        let clusters_per_vine = match block.cultivar {
            crate::state::Cultivar::Chardonnay => 14.5,
            crate::state::Cultivar::PinotNoir => 13.0,
            crate::state::Cultivar::PinotMeunier => 15.0,
            crate::state::Cultivar::Bacchus => 18.0,
            crate::state::Cultivar::SeyvalBlanc => 20.0,
        };

        let berries_per_cluster = 75.0; // Typical cool climate fruit set
        let berry_weight_kg = block.berry_state.berry_weight_g / 1000.0;

        // Potential theoretical yield in kg/vine
        let potential_kg_per_vine = clusters_per_vine * berries_per_cluster * berry_weight_kg;

        // Disease penalty
        let disease_penalty = (block.botrytis_risk_pct * 0.40 + block.downy_mildew_risk_pct * 0.25) / 100.0;
        let total_loss_factor = (1.0 - (frost_damage_pct / 100.0))
            * (1.0 - disease_penalty.min(0.70))
            * (1.0 - (wildlife_loss_pct / 100.0).min(0.20));

        let actual_kg_per_vine = potential_kg_per_vine * total_loss_factor.max(0.15);
        let yield_kg_ha = (actual_kg_per_vine * vines_per_ha).max(500.0);
        let total_tonnes_block = (yield_kg_ha * block.area_ha) / 1000.0;

        (yield_kg_ha, total_tonnes_block)
    }
}
