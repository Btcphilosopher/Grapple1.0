use crate::state::EquipmentState;

pub struct EquipmentEngine;

impl EquipmentEngine {
    /// Update equipment running hours, vibration telemetry, and degrade health score
    pub fn step_equipment(eq: &mut EquipmentState, dt_hours: f64) {
        if !eq.operational {
            return;
        }

        eq.run_hours += dt_hours;
        eq.maintenance_due_hours = (eq.maintenance_due_hours - dt_hours).max(0.0);

        // Health score degradation as maintenance approaches 0
        if eq.maintenance_due_hours < 50.0 {
            eq.health_score_pct = (eq.health_score_pct - 0.05 * dt_hours).max(40.0);
            eq.vibration_rms += 0.02 * dt_hours;
        }

        // Equipment failure trigger if health drops critically low
        if eq.health_score_pct < 45.0 && eq.vibration_rms > 5.5 {
            eq.operational = false;
        }
    }
}
