use grapple_engine::simulation::{DeterministicVintageSimulator, SimulationConfig};
use grapple_engine::monte_carlo::MonteCarloEngine;
use grapple_engine::harvest::HarvestOptimiser;
use grapple_engine::state::{Cultivar, VineyardBlock, CanopyState, PhenologyStage};
use uuid::Uuid;

#[test]
fn test_deterministic_reproducibility() {
    let config = SimulationConfig::default();
    let seed = 20310825;

    let sim1 = DeterministicVintageSimulator::new(config.clone(), seed);
    let res1 = sim1.run_full_vintage();

    let sim2 = DeterministicVintageSimulator::new(config.clone(), seed);
    let res2 = sim2.run_full_vintage();

    assert_eq!(res1.budbreak_doy, res2.budbreak_doy, "Budbreak DOY must be identical for identical seed");
    assert_eq!(res1.flowering_doy, res2.flowering_doy, "Flowering DOY must be identical");
    assert_eq!(res1.mean_harvest_brix, res2.mean_harvest_brix, "Harvest Brix must be identical");
    assert_eq!(res1.mean_yield_t_ha, res2.mean_yield_t_ha, "Yield must be identical");
    assert_eq!(res1.total_yield_tonnes, res2.total_yield_tonnes, "Total yield must be identical");
}

#[test]
fn test_monte_carlo_runs() {
    let config = SimulationConfig::default();
    let report = MonteCarloEngine::run_parallel(&config, 100, 42);

    assert_eq!(report.total_runs, 100);
    assert!(report.yield_t_ha.mean > 2.0 && report.yield_t_ha.mean < 15.0);
    assert!(report.brix.mean > 14.0 && report.brix.mean < 25.0);
    assert!(report.ta_g_l.mean > 5.0 && report.ta_g_l.mean < 18.0);
}

#[test]
fn test_harvest_window_optimiser() {
    let block = VineyardBlock {
        block_id: Uuid::new_v4(),
        block_name: "Test Block".into(),
        cultivar: Cultivar::Chardonnay,
        area_ha: 3.0,
        vine_count: 12000,
        planting_year: 2015,
        trellis_system: "Double Guyot".into(),
        elevation_m: 60.0,
        slope_deg: 5.0,
        aspect_deg: 180.0,
        soil_type: "Chalk".into(),
        phenology_stage: PhenologyStage::Ripening,
        accumulated_gdd_c: 1020.0,
        canopy: CanopyState::default(),
        berry_state: Default::default(),
        downy_mildew_risk_pct: 5.0,
        powdery_mildew_risk_pct: 2.0,
        botrytis_risk_pct: 10.0,
        estimated_yield_kg_ha: 7000.0,
        harvested_flag: false,
    };

    let scenarios = HarvestOptimiser::evaluate_window(&block, 275, true);
    assert_eq!(scenarios.len(), 15);
    assert!(scenarios[0].composite_score >= scenarios[14].composite_score, "Scenarios must be sorted by composite score");
}
