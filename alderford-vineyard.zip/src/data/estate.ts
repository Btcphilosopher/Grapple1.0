import { EstateHotspot, TerroirLayer, Experience, MemberTier } from '../types';
import { ASSETS } from './assets';

export const ESTATE_HOTSPOTS: EstateHotspot[] = [
  {
    id: 'vineyard-blocks',
    title: 'High Ridge Vineyard Blocks',
    subtitle: '120 Acres of South-Facing Chalk Slopes',
    category: 'Vineyard',
    x: 28,
    y: 38,
    description: 'Oriented towards the gentle Sussex sun on 15% gradients. Planted exclusively with Burgundian and Champagne clones trained in Guyot Double system for optimal sunlight absorption and ventilation.',
    architectureNotes: 'Planted along natural geological contours with underground drip sensor irrigation powered by on-site solar arrays.',
    image: ASSETS.vineyardRows
  },
  {
    id: 'anglo-futurist-winery',
    title: 'The Central Winery & Lab',
    subtitle: 'Gravity-Fed Anglo-Futurist Architecture',
    category: 'Winery',
    x: 62,
    y: 32,
    description: 'Designed as a subterranean sanctuary rising gracefully into sharp limestone and bronze spires. Utilizes 100% gravity movement from press deck down to fermentation vessels, eliminating mechanical pumping stress on the wine.',
    architectureNotes: 'Constructed using local Portland limestone, low-carbon glass, and recycled bronze cladding with sedum green roofs.',
    image: ASSETS.wineryGlassArchitecture
  },
  {
    id: 'subterranean-cellar',
    title: 'The Great Vault Cellar',
    subtitle: 'Naturally Temp-Controlled Aging Vaults',
    category: 'Cellar',
    x: 52,
    y: 58,
    description: 'Situated 12 meters beneath the chalk surface. Maintains a constant year-round temperature of 11°C and 80% relative humidity naturally, housing up to 500,000 bottles aging on lees.',
    architectureNotes: 'Features hand-carved chalk archways, custom oak barrel racks, and discreet low-frequency acoustics.',
    image: ASSETS.darkCellar
  },
  {
    id: 'glasshouse-restaurant',
    title: 'The Glasshouse & Pavilion',
    subtitle: 'Michelin-Calibre Estate Dining',
    category: 'Hospitality',
    x: 74,
    y: 48,
    description: 'A floating glass-walled sanctuary offering panoramic views across the vineyard valley. Serving hyper-seasonal British dishes crafted strictly from our kitchen gardens and local Sussex artisans.',
    architectureNotes: 'Triple-glazed cantilevered structure with automated solar shading fins that track sun angles.',
    image: ASSETS.tastingRoomGlasshouse
  },
  {
    id: 'eco-reservoir',
    title: 'Biodiversity Lake & Solar Park',
    subtitle: 'Closed-Loop Ecological Infrastructure',
    category: 'Ecosystem',
    x: 18,
    y: 68,
    description: 'A 2-acre natural rainwater capture lake supplying 100% of estate non-potable water needs, framed by native wildflower corridors and bee apiaries supporting over 200 species of flora and fauna.',
    architectureNotes: 'Floating solar panels generate 140% of the estate’s annual energy requirements, exporting clean energy back to the local grid.',
    image: ASSETS.vineyardGoldenHour
  }
];

export const TERROIR_LAYERS: TerroirLayer[] = [
  {
    id: 'chalk',
    name: 'Cretaceous White Chalk',
    subtitle: 'The 85-Million-Year Foundation',
    description: 'Identical geology to the Côte des Blancs in Champagne. Deep porous white chalk acts as a natural sponge, absorbing winter rains and feeding the vines with constant moisture and essential calcium during summer.',
    keyMetric: '85M Years',
    metricLabel: 'Geological Formation',
    details: {
      composition: 'Pure Calcium Carbonate with Marine Micro-fossils',
      drainage: 'Unmatched capillary moisture retention',
      mineralInfluence: 'Electric high-wire acidity and distinctive saline finish',
      rootDepth: 'Vine roots penetrate up to 12 meters into chalk fissures'
    }
  },
  {
    id: 'flint',
    name: 'Glacial Flint Inclusions',
    subtitle: 'Thermal Storage & Smoky Minerality',
    description: 'Dark, sharp flint nodules dispersed throughout topsoil. During sunny English days, these stones absorb heat and radiate warmth back up to the low-hanging grape clusters through chilly autumn nights.',
    keyMetric: '+2.4°C',
    metricLabel: 'Night Micro-climate Warmth',
    details: {
      composition: 'Cryptocrystalline Quartz Inclusions',
      drainage: 'Rapid surface runoff preventing root rot',
      mineralInfluence: 'Smoky, gunflint complexity on the palate',
      rootDepth: 'Surface heat trap encouraging early spring bud-break'
    }
  },
  {
    id: 'greensand',
    name: 'Lower Greensand Silt',
    subtitle: 'Iron-Rich Soil Depth',
    description: 'A warm, well-drained sandy loam belt providing exceptional drainage and essential micronutrients like iron and potassium, imparting rich aromatics to our Pinot Noir red and rosé cuvées.',
    keyMetric: '14.2%',
    metricLabel: 'Iron Mineral Concentration',
    details: {
      composition: 'Glauconite Marine Sands & Ferruginous Clay',
      drainage: 'High porosity with excellent aeration',
      mineralInfluence: 'Deep floral aromatics and supple tannin structure',
      rootDepth: 'Ideal for deep root branching and vigor control'
    }
  }
];

export const HOSPITALITY_EXPERIENCES: Experience[] = [
  {
    id: 'private-tasting',
    title: 'The Masterclass Tasting',
    subtitle: 'Guided Flight of Current & Library Vintages',
    duration: '90 Minutes',
    capacity: '2 - 8 Guests',
    priceGBP: 85,
    description: 'An intimate, guided exploration through Alderford’s flagship cuvées led by our Senior Sommelier in the Private Glass Pavilion.',
    includes: [
      'Welcome glass of Estate Blanc de Blancs 2020',
      'Flight of 5 current & rare library vintages',
      'Artisanal Sussex cheese & charcuterie board',
      'Private access to the Estate Gardens'
    ],
    availability: 'Wednesday – Sunday at 11:00 & 15:00',
    image: ASSETS.tastingRoomGlasshouse
  },
  {
    id: 'cellar-experience',
    title: 'The Subterranean Cellar Tour',
    subtitle: 'Vip Access to the Deep Chalk Vaults',
    duration: '2.5 Hours',
    capacity: '2 - 6 Guests',
    priceGBP: 160,
    description: 'Step 12 meters underground into our chalk aging vaults. Sample directly from oak barrels and taste disgorged base wines with our Winemaker.',
    includes: [
      'Barrique barrel tastings in the Underground Cellar',
      'Disgorgement demonstration & custom dosage mixing',
      'Exclusive tasting of Founders\' Cuvée 2018',
      '4-course pairing lunch at The Glasshouse Restaurant'
    ],
    availability: 'Friday & Saturday at 14:00',
    image: ASSETS.darkCellar
  },
  {
    id: 'estate-dining',
    title: 'Estate Feast at The Glasshouse',
    subtitle: 'Hyper-Seasonal British Culinary Pairing',
    duration: '3 Hours',
    capacity: '2 - 12 Guests',
    priceGBP: 195,
    description: 'A 7-course tasting menu crafted by Executive Chef James Sterling, highlighting ingredients harvested from our kitchen garden paired with rare Alderford back-vintages.',
    includes: [
      '7-course seasonal tasting menu',
      'Sommelier reserve wine pairing for every course',
      'Meet the Chef and Winemaker experience',
      'Complimentary bottle of Reserve Chardonnay to take home'
    ],
    availability: 'Thursday – Sunday Evenings',
    image: ASSETS.diningExperience
  }
];

export const MEMBERSHIP_TIERS: MemberTier[] = [
  {
    id: 'founders',
    name: 'FOUNDERS\' CLUB',
    tagline: 'The Ultimate Privileged Circle',
    annualAllocation: '24 Bottles (Including 4x Founders\' Cuvée)',
    priceGBP: 1850,
    period: 'per annum',
    benefits: [
      'Guaranteed allocation of limited-release Founders\' Cuvée',
      'Unlimited private cellar visits for member and 3 guests',
      'Access to The Alderford Private Lounge & Helipad',
      'Complimentary annual 7-course Glasshouse dinner for two',
      'Personal Winemaker liaison & bonded storage storage rates'
    ],
    exclusiveAccess: [
      'Invitation to the Harvest Gala Dinner',
      'Pre-market access to new vintage releases 30 days prior',
      'Custom engraved bottle wooden presentation cases'
    ],
    limitedSpots: 100,
    isPopular: true
  },
  {
    id: 'estate',
    name: 'ESTATE CLUB',
    tagline: 'For True Connoisseurs of Fine Wine',
    annualAllocation: '12 Bottles (Curated Seasonal Shipments)',
    priceGBP: 780,
    period: 'per annum',
    benefits: [
      '12 bottles delivered biannually (6 Spring / 6 Autumn)',
      'Complimentary annual Masterclass Tasting for 2',
      '15% privilege discount on all online and estate purchases',
      'Priority booking window for Glasshouse Restaurant'
    ],
    exclusiveAccess: [
      'Invitation to Annual Spring Bud-Break Harvest Festival',
      'Members-only online portal access'
    ],
    limitedSpots: 500
  },
  {
    id: 'reserve',
    name: 'RESERVE SOCIETY',
    tagline: 'Essential Access to England\'s Finest',
    annualAllocation: '6 Bottles (Hand-Selected Vintages)',
    priceGBP: 420,
    period: 'per annum',
    benefits: [
      '6 bottles delivered once per year',
      '10% privilege discount on estate purchases',
      'Complimentary estate vineyard tour for 2',
      'Access to virtual tasting sessions with winemakers'
    ],
    exclusiveAccess: [
      'Quarterly member journal & cellar updates'
    ],
    limitedSpots: 1000
  }
];

export const WINEMAKING_STEPS = [
  {
    step: '01',
    title: 'DAWN HARVEST',
    subtitle: 'Hand-Picking in Cool Morning Air',
    description: 'Grapes are selectively hand-picked at sunrise into small 15kg ventilated crates to prevent berry crushing and oxidation before arrival at the press deck.',
    metric: '15kg crates',
    detail: 'Temp maintained under 12°C'
  },
  {
    step: '02',
    title: 'GENTLE COQUARD PRESSING',
    subtitle: 'Fractionated Gentle Extraction',
    description: 'We utilize a classic French Coquard inclined press. Only the pristine "Cuvée" first juice (400L from 1500kg) is reserved for our top sparkling cuvées.',
    metric: '1.2 Bar',
    detail: 'First press Cuvée extraction'
  },
  {
    step: '03',
    title: 'GRAVITY FERMENTATION',
    subtitle: 'Wild & Temperature-Controlled Co-fermentation',
    description: 'Juice flows naturally by gravity into thermo-regulated stainless tanks and neutral oak foudres. Fermentation uses native vineyard micro-flora for maximum complexity.',
    metric: '16°C',
    detail: 'Cold fermentation over 21 days'
  },
  {
    step: '04',
    title: 'MATURATION ON LEES',
    subtitle: 'Subterranean Chalk Cellar Aging',
    description: 'Bottled with precise champagne yeast strains and stored in our dark underground vaults for up to 72 months, developing rich autolytic brioche and honey notes.',
    metric: '36-72 Mos',
    detail: 'Lees aging at constant 11°C'
  },
  {
    step: '05',
    title: 'HAND RIDDLING & DISGORGEMENT',
    subtitle: 'Precision Dosage & Corking',
    description: 'Bottles are hand-riddled on traditional wooden pupitres. Disgorgement is performed with minimal extra brut dosage to preserve the pure, electric English terroir.',
    metric: '3 - 5 g/l',
    detail: 'Extra Brut dosage philosophy'
  }
];
