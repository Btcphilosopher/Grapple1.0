// Assets repository combining local generated high-resolution images & fallback photography

export const ASSETS = {
  // Main Generated High-Res Assets
  heroEstate: '/src/assets/images/alderford_hero_estate_1787730864200.jpg',
  wineBottlesHero: '/src/assets/images/alderford_wine_bottles_1787730880806.jpg',
  darkCellar: '/src/assets/images/alderford_cellar_dark_1787730897628.jpg',

  // Curated Luxury British Photography URLs (Unsplash High-Res Fallbacks & Specific Modules)
  vineyardGoldenHour: 'https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?q=80&w=1920&auto=format&fit=crop',
  vineyardRows: 'https://images.unsplash.com/photo-1528823872057-9c018a7a70b3?q=80&w=1920&auto=format&fit=crop',
  wineryGlassArchitecture: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?q=80&w=1920&auto=format&fit=crop',
  oakBarrels: 'https://images.unsplash.com/photo-1516594915697-87eb3b1c14ea?q=80&w=1920&auto=format&fit=crop',
  tastingRoomGlasshouse: 'https://images.unsplash.com/photo-1527661591475-527312dd65f5?q=80&w=1920&auto=format&fit=crop',
  grapesCloseUp: 'https://images.unsplash.com/photo-1533616688419-b7a585564566?q=80&w=1920&auto=format&fit=crop',
  estateManor: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?q=80&w=1920&auto=format&fit=crop',
  diningExperience: 'https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?q=80&w=1920&auto=format&fit=crop',
  journalChalkSoil: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=1920&auto=format&fit=crop',
  journalArchitecture: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=1920&auto=format&fit=crop',
};

// Alderford Architectural Heraldic Crest SVG Data
export const ALDERFORD_CREST_SVG = `
<svg viewBox="0 0 100 120" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-full h-full text-[#C5A059]">
  <!-- Shield Frame -->
  <path d="M50 5 L90 25 V65 C90 90 50 115 50 115 C50 115 10 90 10 65 V25 L50 5 Z" stroke="currentColor" stroke-width="1.5" fill="none"/>
  <path d="M50 9 L86 27 V63 C86 86 50 110 50 110 C50 110 14 86 14 63 V27 L50 9 Z" stroke="currentColor" stroke-width="0.75" stroke-dasharray="2 1" fill="none"/>
  <!-- Central Architectural Spire & Vine Roots -->
  <path d="M50 18 V95" stroke="currentColor" stroke-width="1.2"/>
  <path d="M50 18 L38 42 L50 36 L62 42 Z" fill="currentColor"/>
  <!-- Gothic Architectural Arches -->
  <path d="M30 75 Q 50 50 70 75" stroke="currentColor" stroke-width="1" fill="none"/>
  <path d="M36 75 Q 50 56 64 75" stroke="currentColor" stroke-width="0.75" fill="none"/>
  <path d="M42 75 Q 50 62 58 75" stroke="currentColor" stroke-width="0.5" fill="none"/>
  <!-- Vineyard Symmetrical Furrows -->
  <path d="M18 68 L42 85" stroke="currentColor" stroke-width="0.75"/>
  <path d="M82 68 L58 85" stroke="currentColor" stroke-width="0.75"/>
  <path d="M14 55 L38 78" stroke="currentColor" stroke-width="0.75"/>
  <path d="M86 55 L62 78" stroke="currentColor" stroke-width="0.75"/>
  <!-- Crown / Star motif -->
  <circle cx="50" cy="22" r="2" fill="currentColor"/>
</svg>
`;
