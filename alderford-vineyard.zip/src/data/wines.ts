import { Wine } from '../types';
import { ASSETS } from './assets';

export const WINES: Wine[] = [
  {
    id: 'blanc-de-blancs-2020',
    name: 'Estate Blanc de Blancs',
    subtitle: '100% Chardonnay — Traditional Method',
    category: 'Sparkling',
    vintage: '2020',
    priceGBP: 65,
    alcohol: '12.5% ABV',
    bottleSize: '750ml',
    grapeVarieties: ['Chardonnay (100%)'],
    vineyardBlock: 'Block 1 — South Ridge Chalk Slope',
    soilType: 'Cretaceous Chalk & Flint Topsoil',
    dosage: '5.2 g/l (Extra Brut)',
    maturation: '42 months on lees in bottle, 6 months in oak foudres',
    servingTemp: '8°C - 10°C',
    ageingPotential: '15+ years (Optimal 2025–2038)',
    foodPairing: ['Dorset Native Oysters', 'Pan-Seared Cornish Turbot', 'Aged British Comté', 'Truffled Brioche'],
    tastingProfile: {
      citrus: 88,
      mineral: 95,
      floral: 72,
      oak: 35,
      acidity: 92,
      body: 60,
    },
    tastingNotes: {
      aroma: 'Precise electric chalk minerality, lemon verbena, green apple crispness, toasted brioche, and white hawthorn flower.',
      palate: 'Satin-like perlage with intense razor-sharp clarity. Layers of Meyer lemon curd, crushed flint, salted almond, and subtle honeysuckle.',
      finish: 'Extremely persistent saline finish with vibrating limestone tension and crystalline focus.'
    },
    winemakerNotes: 'Hand-picked at dawn on October 12, 2020. Whole-bunch pressed in our custom hydraulic press before temperature-controlled stainless steel fermentation and partial secondary malolactic conversion in seasoned French oak barrels.',
    technicalSpecs: {
      ph: 3.08,
      ta: '8.4 g/l',
      residualSugar: '5.2 g/l',
      productionCount: '6,400 numbered bottles'
    },
    image: ASSETS.wineBottlesHero,
    isReserve: true,
    award: 'Platinum Medal & 97 Pts — Decanter World Wine Awards'
  },
  {
    id: 'rose-cuvee-2021',
    name: 'Estate Rosé Cuvée',
    subtitle: 'Pinot Noir & Pinot Meunier — Traditional Method',
    category: 'Rosé',
    vintage: '2021',
    priceGBP: 72,
    alcohol: '12.0% ABV',
    bottleSize: '750ml',
    grapeVarieties: ['Pinot Noir (68%)', 'Pinot Meunier (22%)', 'Chardonnay (10%)'],
    vineyardBlock: 'Block 2 — East Valley Terraces',
    soilType: 'Glacial Silt over Lower Greensand',
    dosage: '4.8 g/l (Extra Brut)',
    maturation: '36 months on lees in bottle',
    servingTemp: '9°C - 11°C',
    ageingPotential: '10–12 years',
    foodPairing: ['Wild Scottish Salmon Carpaccio', 'Heritage Beetroot Tartare', 'Roasted Duck Breast with Cherry Glaze', 'Fresh Raspberries & Cream'],
    tastingProfile: {
      citrus: 65,
      mineral: 82,
      floral: 88,
      oak: 20,
      acidity: 85,
      body: 68,
    },
    tastingNotes: {
      aroma: 'Wild English strawberries, crushed cranberry, pomegranate blossom, pink grapefruit zest, and wet stone.',
      palate: 'Silky, vibrant texture with explicit red berry vitality, subtle rose petal nuance, and a spine of invigorating English acidity.',
      finish: 'Refreshing, elegant finish with lingering notes of wild redcurrant and delicate white pepper.'
    },
    winemakerNotes: 'A deliberate expression of English Pinot Noir vitality. Sourced from south-facing clay-limestone benches, macerated on skins for just 6 hours to extract delicate coral hues before pristine gravity-flow fermentation.',
    technicalSpecs: {
      ph: 3.12,
      ta: '7.9 g/l',
      residualSugar: '4.8 g/l',
      productionCount: '4,200 numbered bottles'
    },
    image: ASSETS.wineBottlesHero,
    award: 'Gold Medal — International Wine Challenge'
  },
  {
    id: 'pinot-noir-rouge-2022',
    name: 'Estate Pinot Noir Rouge',
    subtitle: '100% Pinot Noir — Still English Red',
    category: 'Red',
    vintage: '2022',
    priceGBP: 58,
    alcohol: '13.0% ABV',
    bottleSize: '750ml',
    grapeVarieties: ['Pinot Noir Clones 777 & 115 (100%)'],
    vineyardBlock: 'Block 4 — South Amphitheatre',
    soilType: 'Warm Iron-rich Clay over Kimmeridgian Limestone',
    maturation: '14 months in 228L French Burgundy Oak (30% new)',
    servingTemp: '14°C - 16°C',
    ageingPotential: '12+ years',
    foodPairing: ['Pan-Roasted English Venison', 'Morel Mushroom Risotto', 'Slow-Cooked Herdwick Lamb', 'Aged Montgomery Cheddar'],
    tastingProfile: {
      citrus: 20,
      mineral: 78,
      floral: 80,
      oak: 65,
      acidity: 75,
      body: 72,
    },
    tastingNotes: {
      aroma: 'Ripe black cherry, forest floor, damp English oak leaves, dark cocoa, clove, and subtle violet perfume.',
      palate: 'Medium-bodied with velvety, fine-grained tannins. Pure black plum, wild blackberry, savory truffle, and graphite structure.',
      finish: 'Sustained, noble finish with subtle cedar spice and refined Burgundian elegance.'
    },
    winemakerNotes: 'From the unprecedented micro-climate heat wave of 2022. Perfectly ripe whole clusters fermented in open-top wood fermenters before gentle basket pressing into selected Burgundian barrels.',
    technicalSpecs: {
      ph: 3.48,
      ta: '6.1 g/l',
      residualSugar: '0.8 g/l (Bone Dry)',
      productionCount: '2,800 numbered bottles'
    },
    image: ASSETS.wineBottlesHero,
    award: 'Best English Still Red — Great British Wine Awards'
  },
  {
    id: 'reserve-chardonnay-2021',
    name: 'Reserve Chardonnay',
    subtitle: '100% Single-Block Chardonnay — Still White',
    category: 'White',
    vintage: '2021',
    priceGBP: 48,
    alcohol: '12.5% ABV',
    bottleSize: '750ml',
    grapeVarieties: ['Chardonnay Clone 95 (100%)'],
    vineyardBlock: 'Block 3 — High Crest Slope',
    soilType: 'Deep Chalk with Flint Inclusions',
    maturation: '10 months in French Oak Punchions (20% new) with weekly batonnage',
    servingTemp: '10°C - 12°C',
    ageingPotential: '10+ years',
    foodPairing: ['Poached Native Lobster', 'Roasted Guinea Fowl with Herbs', 'Pan-Seared Scallops in Hazelnut Butter', 'Soft Goat Cheese'],
    tastingProfile: {
      citrus: 75,
      mineral: 92,
      floral: 60,
      oak: 55,
      acidity: 88,
      body: 65,
    },
    tastingNotes: {
      aroma: 'White peach, candied lemon peel, roasted hazelnut, crushed oyster shell, and subtle vanilla bean.',
      palate: 'Incisive and mouth-watering with a creamy, textured mid-palate balanced by chiseled chalky acidity.',
      finish: 'Long, aromatic finish reminiscent of Puligny-Montrachet with unmistakable English freshness.'
    },
    winemakerNotes: 'Selected from our oldest high-elevation Chardonnay vines. Indigenous yeast fermentation in large oak punchions followed by partial malolactic to preserve tension and pure varietal focus.',
    technicalSpecs: {
      ph: 3.18,
      ta: '7.2 g/l',
      residualSugar: '1.2 g/l',
      productionCount: '3,600 numbered bottles'
    },
    image: ASSETS.wineBottlesHero,
    award: '95 Points — Wine Spectator'
  },
  {
    id: 'founders-cuvee-2018',
    name: 'Founders\' Cuvée',
    subtitle: 'Flagship Prestige Late Disgorged Sparkling',
    category: 'Limited Edition',
    vintage: '2018',
    priceGBP: 140,
    alcohol: '12.5% ABV',
    bottleSize: '750ml (Custom Gift Box Included)',
    grapeVarieties: ['Chardonnay (60%)', 'Pinot Noir (40%)'],
    vineyardBlock: 'Block 1 & Block 4 Heritage Benches',
    soilType: 'Pure Cretaceous Chalk Reef',
    dosage: '3.0 g/l (Extra Brut)',
    maturation: '72 months on lees in bottle',
    servingTemp: '10°C - 12°C',
    ageingPotential: '25+ years',
    foodPairing: ['Caviar on Warm Blinis', 'Aged Turbot with Truffle Emulsion', 'Classic Beef Wellington', 'Mature Stichelton Blue'],
    tastingProfile: {
      citrus: 70,
      mineral: 98,
      floral: 65,
      oak: 48,
      acidity: 90,
      body: 82,
    },
    tastingNotes: {
      aroma: 'Opulent brioche, candied citrus peel, dried apricots, hazelnut paste, beeswax, and crushed chalk powder.',
      palate: 'A masterclass in concentration and weightless harmony. Creamy mousse, deeply layered autolytic depth, candied ginger, and saline mineral drive.',
      finish: 'A magnificent, endless finish that showcases the absolute pinnacle of English sparkling capability.'
    },
    winemakerNotes: 'Produced only in extraordinary vintages. The 2018 harvest was legendary in English winemaking history. Aged for six full years in our dark subterranean cellar before manual disgorgement.',
    technicalSpecs: {
      ph: 3.05,
      ta: '8.8 g/l',
      residualSugar: '3.0 g/l',
      productionCount: '1,200 individually numbered bottles'
    },
    image: ASSETS.wineBottlesHero,
    isReserve: true,
    award: 'World Champion Sparkling Wine — Champagne & Sparkling Wine World Championships'
  }
];
