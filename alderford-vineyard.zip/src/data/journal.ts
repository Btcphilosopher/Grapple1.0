import { Article } from '../types';
import { ASSETS } from './assets';

export const JOURNAL_ARTICLES: Article[] = [
  {
    id: 'geology-of-chalk',
    title: 'The Geology of Chalk: Why England Is World-Class Territory for Fine Wine',
    category: 'Terroir & Viticulture',
    readTime: '6 Min Read',
    date: '14 August 2026',
    author: 'Dr. Alistair Vance, Head of Viticulture',
    excerpt: 'Eighty-five million years ago, a warm tropical sea covered Sussex. Today, its Cretaceous chalk bed forms the exact geological match to Champagne\'s finest Grand Crus.',
    content: [
      'When standing atop the High Ridge block at Alderford Vineyard on an autumn morning, the ground beneath your feet is not merely soil. It is an ancient seabed composed of billions of microscopic marine coccoliths deposited during the Cretaceous period.',
      'For decades, critics wondered whether English wine could match the legendary sparkling wines of France. The answer lies directly in our earth. The identical chalk band that dips under the English Channel from Reims and Épernay re-emerges directly across Sussex, Hampshire, and Kent.',
      'Chalk provides two miraculous natural advantages: capillary water management and thermal regulation. In dry summers, chalk roots draw moisture from up to twelve meters down without waterlogging the vine. The result is electric, razor-sharp acidity paired with complex, salty mineral tension that cannot be artificially duplicated.'
    ],
    image: ASSETS.journalChalkSoil
  },
  {
    id: 'anglo-futurism-architecture',
    title: 'Anglo-Futurism: Architecture That Rises From the English Landscape',
    category: 'Architecture & Design',
    readTime: '8 Min Read',
    date: '28 July 2026',
    author: 'Eleanor Sterling, Lead Architect',
    excerpt: 'How we designed Alderford\'s winery to blend 18th-century Georgian symmetry with 2040 sustainable engineering.',
    content: [
      'Luxury architecture in the English countryside has too often defaulted to nostalgic pastiche — reproducing Victorian manors or fake rustic barns. At Alderford, we rejected both nostalgic imitation and cold industrial modernism.',
      'Our architectural philosophy, Anglo-Futurism, looks forward 50 years while respecting 500 years of English estate proportions. The central winery features soaring Portland limestone pillars with delicate bronze louvers that track the sun. The building is partially submerged into the hillside, using natural geothermal mass to cool our wine without energy expenditure.',
      'The result is a structure that feels as if it was planted rather than built — a seamless fusion of British stone, modern glass, and sustainable technology.'
    ],
    image: ASSETS.journalArchitecture
  },
  {
    id: '2022-vintage-retrospective',
    title: 'The 2022 Vintage: A Historic Chapter in English Pinot Noir',
    category: 'Winemaking',
    readTime: '5 Min Read',
    date: '12 June 2026',
    author: 'Marcus Holloway, Chef de Cave',
    excerpt: 'A look back at the record-breaking summer of 2022 and how it birthed our landmark Estate Pinot Noir Rouge.',
    content: [
      'Winemakers across Europe will remember the summer of 2022 for generations. In Sussex, we experienced warm, unbroken sunlight from June through September with zero disease pressure.',
      'For Pinot Noir, these conditions were transcendent. Small, concentrated berries yielded deep ruby juice with silky tannins and pure black cherry fruit. Our 2022 Estate Pinot Noir Rouge proved definitively that England is now capable of producing still red wines of Burgundian stature.'
    ],
    image: ASSETS.grapesCloseUp
  }
];
