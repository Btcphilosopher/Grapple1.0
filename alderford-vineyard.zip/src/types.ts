export type CurrencyCode = 'GBP' | 'EUR' | 'USD' | 'JPY';

export interface Currency {
  code: CurrencyCode;
  symbol: string;
  rate: number; // multiplier against GBP
}

export interface TastingProfile {
  citrus: number; // 0 - 100
  mineral: number;
  floral: number;
  oak: number;
  acidity: number;
  body: number;
}

export interface Wine {
  id: string;
  name: string;
  subtitle: string;
  category: 'Sparkling' | 'Red' | 'White' | 'Rosé' | 'Limited Edition';
  vintage: string;
  priceGBP: number;
  alcohol: string;
  bottleSize: string;
  grapeVarieties: string[];
  vineyardBlock: string;
  soilType: string;
  dosage?: string;
  maturation: string;
  servingTemp: string;
  ageingPotential: string;
  foodPairing: string[];
  tastingProfile: TastingProfile;
  tastingNotes: {
    aroma: string;
    palate: string;
    finish: string;
  };
  winemakerNotes: string;
  technicalSpecs: {
    ph: number;
    ta: string;
    residualSugar: string;
    productionCount: string;
  };
  image: string;
  isReserve?: boolean;
  award?: string;
}

export interface EstateHotspot {
  id: string;
  title: string;
  subtitle: string;
  category: 'Vineyard' | 'Winery' | 'Cellar' | 'Hospitality' | 'Ecosystem';
  x: number; // percentage on map
  y: number;
  description: string;
  architectureNotes: string;
  image: string;
}

export interface TerroirLayer {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  keyMetric: string;
  metricLabel: string;
  details: {
    composition: string;
    drainage: string;
    mineralInfluence: string;
    rootDepth: string;
  };
}

export interface Experience {
  id: string;
  title: string;
  subtitle: string;
  duration: string;
  capacity: string;
  priceGBP: number;
  description: string;
  includes: string[];
  availability: string;
  image: string;
}

export interface MemberTier {
  id: string;
  name: string;
  tagline: string;
  annualAllocation: string;
  priceGBP: number;
  period: string;
  benefits: string[];
  exclusiveAccess: string[];
  limitedSpots: number;
  isPopular?: boolean;
}

export interface Article {
  id: string;
  title: string;
  category: string;
  readTime: string;
  date: string;
  author: string;
  excerpt: string;
  content: string[];
  image: string;
}

export interface CartItem {
  wine: Wine;
  quantity: number;
  giftBox: boolean;
  bondedStorage: boolean;
}

export interface BookingState {
  experienceId: string | null;
  date: string;
  timeSlot: string;
  guests: number;
  dietaryNotes: string;
  specialRequests: string;
}
