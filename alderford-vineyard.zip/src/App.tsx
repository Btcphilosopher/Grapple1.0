import React, { useState, useEffect } from 'react';
import { CurrencyCode, Wine, CartItem } from './types';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { Introduction } from './components/Introduction';
import { EstateSection } from './components/EstateSection';
import { TerroirSection } from './components/TerroirSection';
import { WineCollection } from './components/WineCollection';
import { WineProductModal } from './components/WineProductModal';
import { WinemakingSection } from './components/WinemakingSection';
import { CellarSection } from './components/CellarSection';
import { SustainabilitySection } from './components/SustainabilitySection';
import { HospitalitySection } from './components/HospitalitySection';
import { MembershipSection } from './components/MembershipSection';
import { JournalSection } from './components/JournalSection';
import { ShopModal } from './components/ShopModal';
import { SearchModal } from './components/SearchModal';
import { Footer } from './components/Footer';
import { AudioAmbient } from './components/AudioAmbient';

export default function App() {
  const [currency, setCurrency] = useState<CurrencyCode>('GBP');
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('alderford_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [selectedWine, setSelectedWine] = useState<Wine | null>(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');

  useEffect(() => {
    try {
      localStorage.setItem('alderford_cart', JSON.stringify(cart));
    } catch (e) {
      console.warn('Cart persistence error', e);
    }
  }, [cart]);

  // Currency Conversion Rates (Base GBP £)
  const currencyRates: Record<CurrencyCode, { symbol: string; rate: number }> = {
    GBP: { symbol: '£', rate: 1.0 },
    EUR: { symbol: '€', rate: 1.18 },
    USD: { symbol: '$', rate: 1.29 },
    JPY: { symbol: '¥', rate: 192.5 }
  };

  const formatPrice = (priceGBP: number): string => {
    const { symbol, rate } = currencyRates[currency];
    const converted = priceGBP * rate;
    if (currency === 'JPY') {
      return `${symbol}${Math.round(converted).toLocaleString()}`;
    }
    return `${symbol}${converted.toFixed(2)}`;
  };

  const handleAddToCart = (wine: Wine, quantity: number = 1, giftBox: boolean = false, bondedStorage: boolean = false) => {
    setCart((prev) => {
      const existingIdx = prev.findIndex((item) => item.wine.id === wine.id);
      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx].quantity += quantity;
        updated[existingIdx].giftBox = giftBox || updated[existingIdx].giftBox;
        updated[existingIdx].bondedStorage = bondedStorage || updated[existingIdx].bondedStorage;
        return updated;
      }
      return [...prev, { wine, quantity, giftBox, bondedStorage }];
    });
  };

  const handleUpdateQuantity = (wineId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.wine.id === wineId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveItem = (wineId: string) => {
    setCart((prev) => prev.filter((item) => item.wine.id !== wineId));
  };

  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-[#242728] font-sans-modern selection:bg-[#C5A059] selection:text-[#111E16]">
      
      {/* Web Audio Countryside Ambience */}
      <AudioAmbient isPlaying={isAudioPlaying} />

      {/* Header Navigation */}
      <Navigation
        cartCount={cartCount}
        onOpenCart={() => setCartOpen(true)}
        onOpenSearch={() => setSearchOpen(true)}
        currentCurrency={currency}
        onSelectCurrency={setCurrency}
        isAudioPlaying={isAudioPlaying}
        onToggleAudio={() => setIsAudioPlaying(!isAudioPlaying)}
        activeSection={activeSection}
        onNavigate={handleNavigate}
      />

      {/* Core Page Content */}
      <main>
        {/* 1. Cinematic Hero */}
        <Hero
          onDiscover={() => handleNavigate('introduction')}
          onExploreWines={() => handleNavigate('wines')}
        />

        {/* 2. Brand Introduction & Philosophy */}
        <Introduction />

        {/* 3. The Wine Collection */}
        <WineCollection
          currentCurrency={currency}
          formatPrice={formatPrice}
          onSelectWine={(wine) => setSelectedWine(wine)}
          onAddToCart={(wine) => handleAddToCart(wine, 1)}
        />

        {/* 4. The Interactive Estate Masterplan */}
        <EstateSection />

        {/* 5. English Terroir Scientific Analyzer */}
        <TerroirSection />

        {/* 6. Precision Winemaking */}
        <WinemakingSection />

        {/* 7. Subterranean Dark Vault Cellar */}
        <CellarSection />

        {/* 8. Sustainability Ecosystem */}
        <SustainabilitySection />

        {/* 9. English Hospitality & Booking Engine */}
        <HospitalitySection formatPrice={formatPrice} />

        {/* 10. The Alderford Society Membership */}
        <MembershipSection formatPrice={formatPrice} />

        {/* 11. Editorial Journal */}
        <JournalSection />
      </main>

      {/* Footer */}
      <Footer onNavigate={handleNavigate} />

      {/* Modals & Overlays */}
      <WineProductModal
        wine={selectedWine}
        onClose={() => setSelectedWine(null)}
        formatPrice={formatPrice}
        onAddToCart={handleAddToCart}
      />

      <ShopModal
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        formatPrice={formatPrice}
        onClearCart={() => setCart([])}
      />

      <SearchModal
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        onSelectWine={(wine) => setSelectedWine(wine)}
        onNavigate={handleNavigate}
        formatPrice={formatPrice}
      />

    </div>
  );
}
