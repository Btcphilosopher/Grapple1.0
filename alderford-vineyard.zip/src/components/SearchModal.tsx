import React, { useState } from 'react';
import { Search, X, Wine as WineIcon, Compass, BookOpen } from 'lucide-react';
import { WINES } from '../data/wines';
import { JOURNAL_ARTICLES } from '../data/journal';
import { HOSPITALITY_EXPERIENCES } from '../data/estate';
import { Wine } from '../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectWine: (wine: Wine) => void;
  onNavigate: (sectionId: string) => void;
  formatPrice: (priceGBP: number) => string;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectWine,
  onNavigate,
  formatPrice
}) => {
  if (!isOpen) return null;

  const [query, setQuery] = useState('');

  const matchingWines = WINES.filter(w =>
    w.name.toLowerCase().includes(query.toLowerCase()) ||
    w.category.toLowerCase().includes(query.toLowerCase()) ||
    w.grapeVarieties.some(g => g.toLowerCase().includes(query.toLowerCase()))
  );

  const matchingArticles = JOURNAL_ARTICLES.filter(a =>
    a.title.toLowerCase().includes(query.toLowerCase()) ||
    a.category.toLowerCase().includes(query.toLowerCase())
  );

  const matchingExperiences = HOSPITALITY_EXPERIENCES.filter(e =>
    e.title.toLowerCase().includes(query.toLowerCase()) ||
    e.description.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-[#111E16] text-white max-w-2xl w-full p-6 sm:p-8 rounded-xs border border-[#C5A059] shadow-2xl relative space-y-6">
        
        {/* Search Header */}
        <div className="flex items-center gap-3 border-b border-stone-800 pb-4">
          <Search className="w-5 h-5 text-[#C5A059]" />
          <input
            type="text"
            autoFocus
            placeholder="Search wines, chalk terroir, experiences, journal..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-lg font-display text-stone-100 placeholder-stone-500 outline-none"
          />
          <button
            onClick={onClose}
            aria-label="Close search"
            className="p-1 text-stone-400 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Results */}
        <div className="max-h-[60vh] overflow-y-auto space-y-6 text-xs font-mono">
          
          {query.trim() === '' ? (
            <div className="text-center py-8 text-stone-500 space-y-2">
              <p>SUGGESTED SEARCHES:</p>
              <div className="flex flex-wrap justify-center gap-2 pt-2">
                {['Blanc de Blancs', 'Chalk Terroir', 'Subterranean Cellar', 'Glasshouse Dining', 'Pinot Noir'].map((s) => (
                  <button
                    key={s}
                    onClick={() => setQuery(s)}
                    className="px-3 py-1 bg-[#0D0F0E] border border-stone-800 rounded text-stone-300 hover:border-[#C5A059]"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <>
              {/* Wines */}
              {matchingWines.length > 0 && (
                <div className="space-y-2">
                  <span className="text-[#C5A059] uppercase tracking-widest font-bold block flex items-center gap-2">
                    <WineIcon className="w-4 h-4" />
                    WINE COLLECTION MATCHES ({matchingWines.length})
                  </span>
                  {matchingWines.map((w) => (
                    <div
                      key={w.id}
                      onClick={() => {
                        onSelectWine(w);
                        onClose();
                      }}
                      className="p-3 bg-[#0D0F0E] rounded border border-stone-800 hover:border-[#C5A059] flex items-center justify-between cursor-pointer"
                    >
                      <div>
                        <div className="font-display text-base text-stone-100">{w.name}</div>
                        <div className="text-stone-400">{w.vintage} • {w.category}</div>
                      </div>
                      <div className="text-[#C5A059] font-bold">{formatPrice(w.priceGBP)}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* Experiences */}
              {matchingExperiences.length > 0 && (
                <div className="space-y-2">
                  <span className="text-[#C5A059] uppercase tracking-widest font-bold block flex items-center gap-2">
                    <Compass className="w-4 h-4" />
                    EXPERIENCES ({matchingExperiences.length})
                  </span>
                  {matchingExperiences.map((e) => (
                    <div
                      key={e.id}
                      onClick={() => {
                        onNavigate('experiences');
                        onClose();
                      }}
                      className="p-3 bg-[#0D0F0E] rounded border border-stone-800 hover:border-[#C5A059] flex items-center justify-between cursor-pointer"
                    >
                      <div>
                        <div className="font-display text-base text-stone-100">{e.title}</div>
                        <div className="text-stone-400">{e.subtitle}</div>
                      </div>
                      <div className="text-[#C5A059] font-bold">{formatPrice(e.priceGBP)}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* Journal */}
              {matchingArticles.length > 0 && (
                <div className="space-y-2">
                  <span className="text-[#C5A059] uppercase tracking-widest font-bold block flex items-center gap-2">
                    <BookOpen className="w-4 h-4" />
                    JOURNAL ESSAYS ({matchingArticles.length})
                  </span>
                  {matchingArticles.map((a) => (
                    <div
                      key={a.id}
                      onClick={() => {
                        onNavigate('journal');
                        onClose();
                      }}
                      className="p-3 bg-[#0D0F0E] rounded border border-stone-800 hover:border-[#C5A059] cursor-pointer"
                    >
                      <div className="font-display text-base text-stone-100">{a.title}</div>
                      <div className="text-stone-400">{a.category} • {a.readTime}</div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

        </div>

      </div>
    </div>
  );
};
