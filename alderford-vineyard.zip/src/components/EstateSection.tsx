import React, { useState } from 'react';
import { MapPin, Info, ArrowRight, Layers, Compass } from 'lucide-react';
import { ESTATE_HOTSPOTS } from '../data/estate';
import { EstateHotspot } from '../types';

export const EstateSection: React.FC = () => {
  const [selectedHotspot, setSelectedHotspot] = useState<EstateHotspot>(ESTATE_HOTSPOTS[0]);
  const [activeFilter, setActiveFilter] = useState<'All' | 'Vineyard' | 'Winery' | 'Cellar' | 'Hospitality' | 'Ecosystem'>('All');

  const filteredHotspots = activeFilter === 'All'
    ? ESTATE_HOTSPOTS
    : ESTATE_HOTSPOTS.filter(h => h.category === activeFilter);

  return (
    <section id="estate" className="py-24 sm:py-32 bg-[#111E16] text-white relative overflow-hidden">
      
      {/* Background Architectural Grid Pattern */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#C5A059_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C5A059]/10 border border-[#C5A059]/30 text-xs font-mono text-[#E5C98B] uppercase tracking-[0.25em]">
            <Compass className="w-3.5 h-3.5" />
            <span>INTERACTIVE ESTATE MASTERPLAN</span>
          </div>
          <h2 className="font-display text-3xl sm:text-5xl tracking-wide uppercase font-light text-stone-100">
            THE ALDERFORD ESTATE
          </h2>
          <p className="font-sans-modern text-stone-300 text-sm sm:text-base font-light leading-relaxed">
            Alderford is not merely a vineyard. It is a living, self-sustaining estate designed around the rhythm of fine wine and British architectural grandeur.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-2 sm:gap-4 mb-12">
          {(['All', 'Vineyard', 'Winery', 'Cellar', 'Hospitality', 'Ecosystem'] as const).map((category) => (
            <button
              key={category}
              onClick={() => setActiveFilter(category)}
              className={`px-4 py-2 text-xs font-mono tracking-wider uppercase transition-all duration-300 rounded-xs cursor-pointer ${
                activeFilter === category
                  ? 'bg-[#C5A059] text-[#111E16] font-bold shadow-lg'
                  : 'bg-black/40 text-stone-300 border border-stone-700 hover:border-[#C5A059] hover:text-[#C5A059]'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Interactive Map & Detail Inspector Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Interactive Map Visualizer Canvas (8 Cols) */}
          <div className="lg:col-span-8 relative bg-[#0D0F0E] rounded-xs border border-[#C5A059]/40 p-4 sm:p-8 shadow-2xl overflow-hidden group">
            
            {/* Map Background Illustration Representation */}
            <div className="relative w-full aspect-[16/10] bg-[#142218] rounded-xs overflow-hidden border border-stone-800 flex items-center justify-center">
              
              <img
                src={selectedHotspot.image}
                alt={selectedHotspot.title}
                className="w-full h-full object-cover opacity-40 transition-opacity duration-700"
                referrerPolicy="no-referrer"
              />

              {/* Vector Architectural Contour Overlay */}
              <svg className="absolute inset-0 w-full h-full stroke-[#C5A059]/30 pointer-events-none" viewBox="0 0 800 500" fill="none">
                {/* Contours */}
                <path d="M50 400 C 200 350, 400 450, 750 380" strokeWidth="1" strokeDasharray="4 2" />
                <path d="M100 300 C 300 250, 500 350, 700 280" strokeWidth="0.8" />
                <path d="M150 200 C 350 150, 550 220, 680 180" strokeWidth="0.6" strokeDasharray="2 2" />
                
                {/* Compass Rose */}
                <circle cx="720" cy="80" r="25" strokeWidth="0.5" />
                <line x1="720" y1="45" x2="720" y2="115" strokeWidth="0.5" />
                <line x1="685" y1="80" x2="755" y2="80" strokeWidth="0.5" />
                <text x="716" y="40" fill="#C5A059" fontSize="10" fontFamily="monospace">N</text>
              </svg>

              {/* Hotspot Pins on Map */}
              {filteredHotspots.map((hotspot) => {
                const isSelected = selectedHotspot.id === hotspot.id;
                return (
                  <button
                    key={hotspot.id}
                    onClick={() => setSelectedHotspot(hotspot)}
                    style={{ left: `${hotspot.x}%`, top: `${hotspot.y}%` }}
                    className={`absolute -translate-x-1/2 -translate-y-1/2 z-20 group/pin cursor-pointer transition-transform duration-300 ${
                      isSelected ? 'scale-125 z-30' : 'hover:scale-110'
                    }`}
                  >
                    <div className="relative flex items-center justify-center">
                      <span className={`absolute w-8 h-8 rounded-full animate-ping ${isSelected ? 'bg-[#C5A059]/40' : 'bg-white/20'}`} />
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center border transition-colors shadow-2xl ${
                        isSelected
                          ? 'bg-[#C5A059] text-[#111E16] border-white font-bold'
                          : 'bg-[#111E16]/90 text-[#C5A059] border-[#C5A059] hover:bg-[#C5A059] hover:text-[#111E16]'
                      }`}>
                        <MapPin className="w-4 h-4" />
                      </div>
                      
                      {/* Label Tooltip */}
                      <div className="absolute top-10 left-1/2 -translate-x-1/2 whitespace-nowrap bg-black/90 backdrop-blur-md border border-[#C5A059]/40 px-2.5 py-1 rounded text-[10px] font-mono tracking-wider text-stone-200 pointer-events-none opacity-0 group-hover/pin:opacity-100 transition-opacity">
                        {hotspot.title}
                      </div>
                    </div>
                  </button>
                );
              })}

              {/* Legend Indicator */}
              <div className="absolute bottom-4 left-4 bg-black/70 backdrop-blur-md px-3 py-2 rounded border border-stone-800 text-[11px] font-mono text-stone-300">
                <span>SELECT MAP LOCATION TO INSPECT ARCHITECTURE</span>
              </div>

            </div>

          </div>

          {/* Hotspot Inspector Panel (4 Cols) */}
          <div className="lg:col-span-4 bg-[#0D0F0E] rounded-xs border border-[#C5A059]/40 p-6 sm:p-8 space-y-6 shadow-2xl flex flex-col justify-between">
            <div className="space-y-4">
              
              <div className="flex items-center justify-between border-b border-stone-800 pb-4">
                <span className="text-xs font-mono uppercase text-[#C5A059] tracking-widest">
                  {selectedHotspot.category} • LOCATION DATA
                </span>
                <span className="text-xs font-mono text-stone-500">
                  REF: {selectedHotspot.id.toUpperCase()}
                </span>
              </div>

              {/* Title & Subtitle */}
              <div>
                <h3 className="font-display text-2xl text-stone-100 mb-1">
                  {selectedHotspot.title}
                </h3>
                <p className="text-xs font-mono text-[#E5C98B] tracking-wide">
                  {selectedHotspot.subtitle}
                </p>
              </div>

              {/* Selected Hotspot Thumbnail Image */}
              <div className="relative rounded overflow-hidden h-40 border border-stone-800">
                <img
                  src={selectedHotspot.image}
                  alt={selectedHotspot.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              </div>

              {/* Description */}
              <p className="font-sans-modern text-stone-300 text-sm leading-relaxed font-light">
                {selectedHotspot.description}
              </p>

              {/* Architectural Notes */}
              <div className="p-4 bg-[#142218] border border-[#C5A059]/20 rounded-xs space-y-1">
                <div className="flex items-center gap-2 text-xs font-mono text-[#C5A059]">
                  <Info className="w-3.5 h-3.5" />
                  <span>ANGLO-FUTURIST ARCHITECTURE</span>
                </div>
                <p className="text-xs text-stone-300 leading-normal font-sans-modern">
                  {selectedHotspot.architectureNotes}
                </p>
              </div>

            </div>

            <div className="pt-4 border-t border-stone-800">
              <button
                onClick={() => {
                  const el = document.getElementById('experiences');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="w-full py-3 bg-[#C5A059] text-[#111E16] text-xs font-bold tracking-[0.2em] uppercase hover:bg-[#E5C98B] transition-colors rounded-xs cursor-pointer flex items-center justify-center gap-2"
              >
                <span>BOOK VISIT TO THIS LOCATION</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
