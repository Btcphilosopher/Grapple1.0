import React, { useState } from 'react';
import { CartItem, CurrencyCode } from '../types';
import { X, ShoppingBag, Trash2, Shield, Gift, ArrowRight, CheckCircle2, Lock } from 'lucide-react';

interface ShopModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (wineId: string, delta: number) => void;
  onRemoveItem: (wineId: string) => void;
  formatPrice: (priceGBP: number) => string;
  onClearCart: () => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  formatPrice,
  onClearCart
}) => {
  if (!isOpen) return null;

  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'shipping' | 'payment' | 'confirmed'>('cart');
  const [deliveryType, setDeliveryType] = useState<'UK_EXPRESS' | 'BONDED' | 'GLOBAL'>('UK_EXPRESS');
  const [giftNote, setGiftNote] = useState('');

  const subtotalGBP = cart.reduce((acc, item) => acc + (item.wine.priceGBP * item.quantity), 0);
  const deliveryFeeGBP = deliveryType === 'UK_EXPRESS' ? 15 : deliveryType === 'BONDED' ? 25 : 65;
  const grandTotalGBP = subtotalGBP + (cart.length > 0 ? deliveryFeeGBP : 0);

  const handleCompleteOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setCheckoutStep('confirmed');
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-md">
      <div className="bg-[#FDFBF7] text-[#242728] max-w-xl w-full h-full flex flex-col justify-between shadow-2xl relative border-l border-[#C5A059] overflow-y-auto">
        
        {/* Top Header */}
        <div className="p-6 border-b border-[#EAE5DB] flex items-center justify-between bg-[#111E16] text-white">
          <div className="flex items-center gap-3">
            <ShoppingBag className="w-5 h-5 text-[#C5A059]" />
            <div>
              <h2 className="font-display text-xl tracking-wider uppercase text-stone-100">
                WINE COLLECTION BAG
              </h2>
              <span className="text-[10px] font-mono text-[#E5C98B] uppercase">
                {cart.reduce((a, b) => a + b.quantity, 0)} BOTTLES IN ALLOCATION
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="Close Bag"
            className="p-2 text-stone-400 hover:text-white cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 flex-1 space-y-6 overflow-y-auto">
          
          {checkoutStep === 'cart' && (
            <>
              {cart.length === 0 ? (
                <div className="text-center py-16 space-y-4">
                  <ShoppingBag className="w-12 h-12 text-[#C5A059] mx-auto opacity-40" />
                  <p className="font-display text-xl text-stone-700">YOUR COLLECTION BAG IS EMPTY</p>
                  <p className="text-xs font-mono text-stone-500">Explore our estate vintages and add bottles to your allocation.</p>
                  <button
                    onClick={onClose}
                    className="px-6 py-2.5 bg-[#111E16] text-[#E5C98B] text-xs font-mono font-bold tracking-widest uppercase rounded cursor-pointer"
                  >
                    DISCOVER VINTAGES
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {cart.map((item) => (
                    <div
                      key={item.wine.id}
                      className="p-4 bg-[#F5F2EA] rounded border border-[#EAE5DB] flex items-center gap-4 justify-between"
                    >
                      <img
                        src={item.wine.image}
                        alt={item.wine.name}
                        className="w-12 h-20 object-contain"
                        referrerPolicy="no-referrer"
                      />

                      <div className="flex-1 space-y-1">
                        <div className="font-display text-base text-[#111E16]">{item.wine.name}</div>
                        <div className="text-[10px] font-mono text-stone-500">{item.wine.vintage} • {item.wine.bottleSize}</div>
                        <div className="font-mono text-xs font-bold text-[#111E16]">
                          {formatPrice(item.wine.priceGBP)} / bottle
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <div className="flex items-center border border-[#111E16] bg-white rounded text-xs font-mono">
                          <button
                            onClick={() => onUpdateQuantity(item.wine.id, -1)}
                            className="px-2 py-1 text-[#111E16] cursor-pointer"
                          >
                            -
                          </button>
                          <span className="px-2 font-bold">{item.quantity}</span>
                          <button
                            onClick={() => onUpdateQuantity(item.wine.id, 1)}
                            className="px-2 py-1 text-[#111E16] cursor-pointer"
                          >
                            +
                          </button>
                        </div>

                        <button
                          onClick={() => onRemoveItem(item.wine.id)}
                          aria-label="Remove item"
                          className="p-2 text-stone-400 hover:text-red-700 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}

                  {/* Delivery Mode Option */}
                  <div className="pt-4 border-t border-[#EAE5DB] space-y-2">
                    <span className="text-xs font-mono text-[#C5A059] uppercase tracking-widest font-bold">
                      DESPATCH / STORAGE OPTION
                    </span>

                    <div className="space-y-2 text-xs font-mono">
                      <label className="flex items-center justify-between p-3 bg-[#F5F2EA] rounded border border-[#EAE5DB] cursor-pointer">
                        <span className="flex items-center gap-2">
                          <input
                            type="radio"
                            name="del"
                            checked={deliveryType === 'UK_EXPRESS'}
                            onChange={() => setDeliveryType('UK_EXPRESS')}
                            className="accent-[#C5A059]"
                          />
                          <span>UK Temperature-Controlled Express (+£15)</span>
                        </span>
                        <span className="text-stone-500">1-2 Days</span>
                      </label>

                      <label className="flex items-center justify-between p-3 bg-[#F5F2EA] rounded border border-[#EAE5DB] cursor-pointer">
                        <span className="flex items-center gap-2">
                          <input
                            type="radio"
                            name="del"
                            checked={deliveryType === 'BONDED'}
                            onChange={() => setDeliveryType('BONDED')}
                            className="accent-[#C5A059]"
                          />
                          <span>UK Bonded Warehouse Vault Transfer (+£25)</span>
                        </span>
                        <span className="text-stone-500">Under Bond</span>
                      </label>

                      <label className="flex items-center justify-between p-3 bg-[#F5F2EA] rounded border border-[#EAE5DB] cursor-pointer">
                        <span className="flex items-center gap-2">
                          <input
                            type="radio"
                            name="del"
                            checked={deliveryType === 'GLOBAL'}
                            onChange={() => setDeliveryType('GLOBAL')}
                            className="accent-[#C5A059]"
                          />
                          <span>Global Air Freight Fine Wine Logistics (+£65)</span>
                        </span>
                        <span className="text-stone-500">3-5 Days</span>
                      </label>
                    </div>
                  </div>

                </div>
              )}
            </>
          )}

          {checkoutStep === 'shipping' && (
            <form onSubmit={handleCompleteOrder} className="space-y-4 text-xs font-mono">
              <div className="border-b border-[#EAE5DB] pb-3">
                <h3 className="font-display text-xl text-[#111E16]">DESPATCH ADDRESS DETAILS</h3>
                <span className="text-[10px] text-stone-500">Fine wine signature required upon delivery.</span>
              </div>

              <div>
                <label className="block text-stone-600 mb-1">RECIPIENT NAME</label>
                <input
                  type="text"
                  required
                  defaultValue="Lord Edward Vance"
                  className="w-full p-3 bg-[#F5F2EA] border border-[#EAE5DB] rounded outline-none focus:border-[#C5A059]"
                />
              </div>

              <div>
                <label className="block text-stone-600 mb-1">DELIVERY ADDRESS</label>
                <input
                  type="text"
                  required
                  defaultValue="Alderford Manor, Sussex Downs"
                  className="w-full p-3 bg-[#F5F2EA] border border-[#EAE5DB] rounded outline-none focus:border-[#C5A059]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-600 mb-1">POSTCODE / ZIP</label>
                  <input
                    type="text"
                    required
                    defaultValue="BN18 0AA"
                    className="w-full p-3 bg-[#F5F2EA] border border-[#EAE5DB] rounded outline-none focus:border-[#C5A059]"
                  />
                </div>
                <div>
                  <label className="block text-stone-600 mb-1">COUNTRY</label>
                  <input
                    type="text"
                    required
                    defaultValue="United Kingdom"
                    className="w-full p-3 bg-[#F5F2EA] border border-[#EAE5DB] rounded outline-none focus:border-[#C5A059]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-600 mb-1">OPTIONAL COMPLIMENTARY GIFT NOTE</label>
                <textarea
                  rows={2}
                  placeholder="Inscribed on Alderford wax-sealed vellum paper..."
                  value={giftNote}
                  onChange={(e) => setGiftNote(e.target.value)}
                  className="w-full p-3 bg-[#F5F2EA] border border-[#EAE5DB] rounded outline-none focus:border-[#C5A059]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-4 bg-[#C5A059] text-[#111E16] font-bold tracking-[0.2em] uppercase rounded cursor-pointer hover:bg-[#E5C98B] transition-colors shadow-xl"
              >
                PROCEED TO SECURE PAYMENT
              </button>
            </form>
          )}

          {checkoutStep === 'confirmed' && (
            <div className="text-center py-12 space-y-4">
              <div className="w-16 h-16 bg-[#C5A059] text-[#111E16] rounded-full flex items-center justify-center mx-auto shadow-2xl">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="font-display text-3xl text-[#111E16]">ORDER ALLOCATION CONFIRMED</h3>
              <p className="font-sans-modern text-stone-600 text-sm max-w-sm mx-auto">
                Thank you. Your bottles are being hand-packed in our Sussex temperature-controlled cellar.
              </p>
              <div className="p-4 bg-[#F5F2EA] border border-[#EAE5DB] rounded text-xs font-mono text-stone-600 space-y-1">
                <div>ALLOCATION ORDER NUMBER: <span className="font-bold text-[#111E16]">ALDERFORD-90218</span></div>
                <div>ESTIMATED ARRIVAL: <span className="text-[#C5A059] font-bold">48 Hours</span></div>
              </div>
              <button
                onClick={() => {
                  onClearCart();
                  setCheckoutStep('cart');
                  onClose();
                }}
                className="px-8 py-3 bg-[#111E16] text-[#E5C98B] text-xs font-mono uppercase tracking-widest rounded cursor-pointer"
              >
                RETURN TO ESTATE
              </button>
            </div>
          )}

        </div>

        {/* Footer Summary & Checkout Action */}
        {cart.length > 0 && checkoutStep === 'cart' && (
          <div className="p-6 bg-[#111E16] text-white border-t border-stone-800 space-y-4">
            <div className="space-y-1 text-xs font-mono">
              <div className="flex justify-between text-stone-400">
                <span>SUBTOTAL:</span>
                <span>{formatPrice(subtotalGBP)}</span>
              </div>
              <div className="flex justify-between text-stone-400">
                <span>ESTATE LOGISTICS / BONDED TRANSFER:</span>
                <span>{formatPrice(deliveryFeeGBP)}</span>
              </div>
              <div className="flex justify-between text-base font-bold text-[#E5C98B] pt-2 border-t border-stone-800">
                <span>TOTAL ALLOCATION:</span>
                <span>{formatPrice(grandTotalGBP)}</span>
              </div>
            </div>

            <button
              onClick={() => setCheckoutStep('shipping')}
              className="w-full py-4 bg-[#C5A059] text-[#111E16] font-mono text-xs font-bold tracking-[0.2em] uppercase hover:bg-[#E5C98B] transition-colors rounded cursor-pointer shadow-xl flex items-center justify-center gap-2"
            >
              <span>DESPATCH ALLOCATION</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
