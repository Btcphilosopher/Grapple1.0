import React, { useState } from 'react';
import { WINEMAKING_STEPS } from '../data/estate';
import { ASSETS } from '../data/assets';
import { Sliders, ArrowRight, CheckCircle } from 'lucide-react';

export const WinemakingSection: React.FC = () => {
  const [activeStepIndex, setActiveStepIndex] = useState(0);
  const currentStep = WINEMAKING_STEPS[activeStepIndex];

  return (
    <section id="winemaking" className="py-24 sm:py-32 bg-[#111E16] text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C5A059]/10 border border-[#C5A059]/30 text-xs font-mono text-[#E5C98B] uppercase tracking-[0.25em]">
            <Sliders className="w-3.5 h-3.5" />
            <span>METICULOUS PROCESS</span>
          </div>
          <h2 className="font-display text-3xl sm:text-5xl tracking-wide uppercase font-light text-stone-100">
            THE ART OF PRECISION
          </h2>
          <p className="font-sans-modern text-stone-300 text-sm sm:text-base font-light leading-relaxed">
            From sunrise hand-harvesting in small 15kg crates to gravity flow fermentation and multi-year chalk cellar aging. Every step is governed by technical precision.
          </p>
        </div>

        {/* Pipeline Step Progress Bar */}
        <div className="mb-12 overflow-x-auto pb-4">
          <div className="flex items-center justify-between min-w-[700px] border-b border-stone-800 pb-6">
            {WINEMAKING_STEPS.map((s, idx) => {
              const isActive = idx === activeStepIndex;
              const isPast = idx < activeStepIndex;
              return (
                <button
                  key={s.step}
                  onClick={() => setActiveStepIndex(idx)}
                  className={`flex flex-col items-center gap-2 cursor-pointer transition-all duration-300 ${
                    isActive ? 'scale-105' : 'opacity-60 hover:opacity-100'
                  }`}
                >
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center font-mono text-xs font-bold border transition-colors ${
                    isActive
                      ? 'bg-[#C5A059] text-[#111E16] border-white shadow-lg'
                      : isPast
                      ? 'bg-[#142218] text-[#C5A059] border-[#C5A059]'
                      : 'bg-black/60 text-stone-400 border-stone-700'
                  }`}>
                    {s.step}
                  </div>
                  <span className={`text-[10px] font-mono uppercase tracking-wider ${isActive ? 'text-[#E5C98B] font-bold' : 'text-stone-400'}`}>
                    {s.title}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step Inspector Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-[#0D0F0E] p-8 sm:p-12 rounded-xs border border-[#C5A059]/40 shadow-2xl">
          
          {/* Step Photo (6 Cols) */}
          <div className="lg:col-span-6 relative rounded overflow-hidden h-72 sm:h-96 border border-stone-800">
            <img
              src={activeStepIndex === 0 ? ASSETS.grapesCloseUp : activeStepIndex === 3 ? ASSETS.oakBarrels : ASSETS.darkCellar}
              alt={currentStep.title}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent flex items-end p-6">
              <div className="text-xs font-mono text-[#E5C98B]">
                PRECISION METRIC: <span className="font-bold text-white ml-2">{currentStep.metric}</span>
              </div>
            </div>
          </div>

          {/* Step Technical Description (6 Cols) */}
          <div className="lg:col-span-6 space-y-6">
            <div className="space-y-2">
              <span className="text-xs font-mono uppercase text-[#C5A059] tracking-widest">
                STAGE {currentStep.step} OF 05
              </span>
              <h3 className="font-display text-3xl sm:text-4xl text-stone-100">{currentStep.title}</h3>
              <p className="text-xs font-mono text-[#E5C98B] uppercase">{currentStep.subtitle}</p>
            </div>

            <p className="font-sans-modern text-stone-300 text-sm sm:text-base leading-relaxed font-light">
              {currentStep.description}
            </p>

            <div className="p-4 bg-[#142218] border border-stone-800 rounded text-xs font-mono text-stone-300 space-y-1">
              <span className="text-[#C5A059] block font-bold">TECHNICAL CONTROL PARAMETER:</span>
              <span>{currentStep.detail}</span>
            </div>

            {/* Next Step Controls */}
            <div className="flex items-center justify-between pt-4 border-t border-stone-800">
              <button
                onClick={() => setActiveStepIndex(Math.max(0, activeStepIndex - 1))}
                disabled={activeStepIndex === 0}
                className="px-4 py-2 border border-stone-700 text-xs font-mono text-stone-400 disabled:opacity-30 cursor-pointer rounded"
              >
                PREVIOUS
              </button>

              <button
                onClick={() => setActiveStepIndex(Math.min(WINEMAKING_STEPS.length - 1, activeStepIndex + 1))}
                disabled={activeStepIndex === WINEMAKING_STEPS.length - 1}
                className="px-6 py-2 bg-[#C5A059] text-[#111E16] text-xs font-mono font-bold tracking-widest uppercase hover:bg-[#E5C98B] disabled:opacity-30 cursor-pointer rounded flex items-center gap-2"
              >
                <span>NEXT STAGE</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
