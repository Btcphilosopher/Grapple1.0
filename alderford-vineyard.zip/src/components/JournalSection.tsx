import React, { useState } from 'react';
import { JOURNAL_ARTICLES } from '../data/journal';
import { Article } from '../types';
import { BookOpen, Clock, ArrowRight, X } from 'lucide-react';

export const JournalSection: React.FC = () => {
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  return (
    <section id="journal" className="py-24 sm:py-32 bg-[#FDFBF7] text-[#242728] border-b border-[#EAE5DB]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="flex items-center gap-3 justify-center">
            <span className="w-12 h-[1px] bg-[#C5A059]" />
            <span className="text-xs font-mono tracking-[0.3em] uppercase text-[#C5A059] font-medium">
              EDITORIAL PUBLISHING
            </span>
            <span className="w-12 h-[1px] bg-[#C5A059]" />
          </div>
          <h2 className="font-display text-3xl sm:text-5xl tracking-wide uppercase font-light text-[#111E16]">
            THE ALDERFORD JOURNAL
          </h2>
          <p className="font-sans-modern text-stone-600 text-sm sm:text-base font-light leading-relaxed">
            Essays and reflections on terroir, British architecture, viticultural science, and the evolving culture of fine wine in England.
          </p>
        </div>

        {/* Journal Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {JOURNAL_ARTICLES.map((article) => (
            <article
              key={article.id}
              onClick={() => setSelectedArticle(article)}
              className="bg-[#F5F2EA] rounded-xs border border-[#EAE5DB] hover:border-[#C5A059] transition-all duration-500 overflow-hidden flex flex-col justify-between shadow-sm hover:shadow-2xl cursor-pointer group"
            >
              <div>
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={article.image}
                    alt={article.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-4 left-4 bg-[#111E16] text-[#E5C98B] font-mono text-[10px] uppercase tracking-widest px-2.5 py-1 rounded">
                    {article.category}
                  </div>
                </div>

                <div className="p-6 space-y-3">
                  <div className="flex items-center gap-3 text-[10px] font-mono text-stone-500">
                    <span>{article.date}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-[#C5A059]" />
                      {article.readTime}
                    </span>
                  </div>

                  <h3 className="font-display text-xl text-[#111E16] group-hover:text-[#C5A059] transition-colors leading-snug">
                    {article.title}
                  </h3>

                  <p className="font-sans-modern text-stone-600 text-xs leading-relaxed line-clamp-3">
                    {article.excerpt}
                  </p>
                </div>
              </div>

              <div className="p-6 pt-0 border-t border-[#EAE5DB]/60 flex items-center justify-between text-xs font-mono text-[#C5A059] group-hover:text-[#111E16] transition-colors">
                <span>READ ESSAY</span>
                <ArrowRight className="w-4 h-4" />
              </div>

            </article>
          ))}
        </div>

      </div>

      {/* Article Reader Modal */}
      {selectedArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-[#FDFBF7] text-[#242728] max-w-3xl w-full p-8 sm:p-12 rounded-xs border border-[#C5A059] shadow-2xl relative my-auto max-h-[90vh] overflow-y-auto space-y-6">
            
            <button
              onClick={() => setSelectedArticle(null)}
              className="absolute top-6 right-6 text-stone-500 hover:text-[#111E16] cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="space-y-3 border-b border-[#EAE5DB] pb-6">
              <span className="text-xs font-mono uppercase text-[#C5A059] tracking-widest block">
                {selectedArticle.category} • {selectedArticle.date}
              </span>
              <h2 className="font-display text-3xl sm:text-4xl text-[#111E16]">
                {selectedArticle.title}
              </h2>
              <p className="text-xs font-mono text-stone-500">{selectedArticle.author}</p>
            </div>

            <div className="relative h-64 sm:h-80 rounded overflow-hidden">
              <img
                src={selectedArticle.image}
                alt={selectedArticle.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="space-y-4 font-sans-modern text-stone-700 text-sm sm:text-base leading-relaxed">
              {selectedArticle.content.map((p, idx) => (
                <p key={idx}>{p}</p>
              ))}
            </div>

            <div className="pt-6 border-t border-[#EAE5DB] flex justify-between items-center text-xs font-mono text-stone-500">
              <span>ALDERFORD EDITORIAL</span>
              <button
                onClick={() => setSelectedArticle(null)}
                className="px-4 py-2 bg-[#111E16] text-[#E5C98B] font-mono text-xs uppercase rounded cursor-pointer"
              >
                CLOSE ESSAY
              </button>
            </div>

          </div>
        </div>
      )}

    </section>
  );
};
