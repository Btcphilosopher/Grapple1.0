import React from 'react';
import { ASSETS } from '../data/assets';
import { Shield, Sparkles, Lock, Clock } from 'lucide-react';

export const CellarSection: React.FC = () => {
  return (
    <section id="cellar" className="py-24 sm:py-32 bg-[#0D0F0E] text-white relative overflow-hidden border-b border-stone-800">
      
      {/* Background Dark Mood Atmosphere */}
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <img
          src={ASSETS.darkCellar}
          alt="Cellar Background"
          className="w-full h-full object-cover blur-md"
          referrerPolicy="no-referrer"
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C5A059]/10 border border-[#C5A059]/30 text-xs font-mono text-[#E5C98B] uppercase tracking-[0.25em]">
            <Lock className="w-3.5 h-3.5" />
            <span>SUBTERRANEAN CHALK VAULT</span>
          </div>
          <h2 className="font-display text-4xl sm:text-6xl tracking-wide uppercase font-light text-stone-100">
            THE CELLAR
          </h2>
          <p className="font-sans-modern text-stone-300 text-sm sm:text-base font-light leading-relaxed">
            12 meters beneath the Sussex chalk surface sits our subterranean aging vault. A dark, quiet sanctuary where time and chalk work in silent alchemy.
          </p>
        </div>

        {/* Feature Hero Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-16">
          
          <div className="lg:col-span-7 relative rounded-xs overflow-hidden border border-[#C5A059]/40 shadow-2xl h-[400px] sm:h-[500px]">
            <img
              src={ASSETS.darkCellar}
              alt="Alderford Subterranean Cellar Vault"
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent flex items-end p-8">
              <div className="space-y-2">
                <span className="text-xs font-mono text-[#C5A059] uppercase tracking-widest">AGED ON LEES IN SILENCE</span>
                <p className="font-display text-2xl text-stone-100">500,000 Bottles Resting in Pure Chalk Archways</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 space-y-6 bg-[#111E16]/80 backdrop-blur-md p-8 rounded-xs border border-stone-800">
            <h3 className="font-display text-2xl text-[#E5C98B]">Subterranean Environment Control</h3>
            <p className="font-sans-modern text-stone-300 text-sm leading-relaxed font-light">
              By carving directly into Cretaceous white chalk, the cellar maintains an unyielding 11°C ambient temperature year-round without mechanical refrigeration. Humidity remains pinned at a natural 82%.
            </p>

            <div className="space-y-4 pt-4 border-t border-stone-800 text-xs font-mono">
              <div className="flex items-center gap-3 text-stone-300">
                <Clock className="w-4 h-4 text-[#C5A059]" />
                <span>Extended autolytic contact (36 to 72 months on lees)</span>
              </div>
              <div className="flex items-center gap-3 text-stone-300">
                <Shield className="w-4 h-4 text-[#C5A059]" />
                <span>Zero vibration, absolute darkness, low-frequency acoustics</span>
              </div>
              <div className="flex items-center gap-3 text-stone-300">
                <Sparkles className="w-4 h-4 text-[#C5A059]" />
                <span>Hand riddling on classic wooden pupitres</span>
              </div>
            </div>

            <div className="pt-4">
              <a
                href="#experiences"
                className="inline-block w-full text-center py-3 bg-[#C5A059] text-[#111E16] text-xs font-mono font-bold tracking-[0.2em] uppercase hover:bg-[#E5C98B] transition-colors rounded-xs"
              >
                REQUEST SUBTERRANEAN CELLAR TOUR
              </a>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
