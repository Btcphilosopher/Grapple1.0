import React, { useState } from 'react';
import { MEMBERSHIP_TIERS } from '../data/estate';
import { MemberTier } from '../types';
import { Crown, Check, ShieldCheck, X } from 'lucide-react';

interface MembershipSectionProps {
  formatPrice: (priceGBP: number) => string;
}

export const MembershipSection: React.FC<MembershipSectionProps> = ({ formatPrice }) => {
  const [selectedTier, setSelectedTier] = useState<MemberTier | null>(null);
  const [submitted, setSubmitted] = useState(false);

  return (
    <section id="society" className="py-24 sm:py-32 bg-[#111E16] text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C5A059]/10 border border-[#C5A059]/30 text-xs font-mono text-[#E5C98B] uppercase tracking-[0.25em]">
            <Crown className="w-3.5 h-3.5" />
            <span>PRIVATE WINE SOCIETY</span>
          </div>
          <h2 className="font-display text-3xl sm:text-5xl tracking-wide uppercase font-light text-stone-100">
            THE ALDERFORD SOCIETY
          </h2>
          <p className="font-sans-modern text-stone-300 text-sm sm:text-base font-light leading-relaxed">
            A private British institution dedicated to patronage of world-class English wine. Members receive guaranteed annual allocations, library cellaring access, and invitations to estate galas.
          </p>
        </div>

        {/* Tiers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
          {MEMBERSHIP_TIERS.map((tier) => (
            <div
              key={tier.id}
              className={`rounded-xs p-8 flex flex-col justify-between relative transition-all duration-500 shadow-2xl border ${
                tier.isPopular
                  ? 'bg-[#0D0F0E] border-[#C5A059] ring-1 ring-[#C5A059]/50 scale-102'
                  : 'bg-[#142218] border-stone-800 hover:border-[#C5A059]'
              }`}
            >
              
              {tier.isPopular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#C5A059] text-[#111E16] font-mono text-[10px] font-bold uppercase tracking-[0.2em] px-3 py-1 rounded">
                  MOST PRIVILEGED
                </span>
              )}

              <div className="space-y-6">
                
                <div className="border-b border-stone-800 pb-6 space-y-1">
                  <span className="text-[10px] font-mono text-[#C5A059] uppercase tracking-widest block">
                    LIMITED TO {tier.limitedSpots} MEMBERS
                  </span>
                  <h3 className="font-display text-2xl text-stone-100">{tier.name}</h3>
                  <p className="text-xs font-mono text-stone-400">{tier.tagline}</p>
                </div>

                <div className="space-y-1">
                  <div className="font-display text-3xl text-[#E5C98B]">
                    {formatPrice(tier.priceGBP)}
                  </div>
                  <div className="text-[10px] font-mono text-stone-400 uppercase">{tier.period}</div>
                </div>

                <div className="p-3 bg-black/40 rounded border border-stone-800 text-xs font-mono text-[#E5C98B]">
                  ALLOCATION: {tier.annualAllocation}
                </div>

                {/* Benefits */}
                <div className="space-y-2 text-xs font-sans-modern text-stone-300">
                  <span className="font-mono text-[10px] text-[#C5A059] uppercase tracking-wider block font-bold">
                    MEMBERSHIP PRIVILEGES:
                  </span>
                  {tier.benefits.map((b, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                      <span>{b}</span>
                    </div>
                  ))}
                </div>

              </div>

              <div className="pt-8 border-t border-stone-800">
                <button
                  onClick={() => {
                    setSelectedTier(tier);
                    setSubmitted(false);
                  }}
                  className={`w-full py-3.5 text-xs font-mono font-bold tracking-[0.2em] uppercase rounded-xs transition-colors cursor-pointer ${
                    tier.isPopular
                      ? 'bg-[#C5A059] text-[#111E16] hover:bg-[#E5C98B]'
                      : 'bg-stone-800 text-stone-200 hover:bg-[#C5A059] hover:text-[#111E16]'
                  }`}
                >
                  APPLY FOR {tier.name}
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>

      {/* Application Modal */}
      {selectedTier && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-[#111E16] text-white max-w-lg w-full p-8 rounded-xs border border-[#C5A059] shadow-2xl relative my-auto">
            
            <button
              onClick={() => setSelectedTier(null)}
              className="absolute top-6 right-6 text-stone-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {!submitted ? (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setSubmitted(true);
                }}
                className="space-y-4"
              >
                <div className="border-b border-stone-800 pb-4">
                  <span className="text-xs font-mono text-[#C5A059] uppercase tracking-widest">MEMBERSHIP PATRONAGE</span>
                  <h3 className="font-display text-2xl text-stone-100">{selectedTier.name} APPLICATION</h3>
                  <p className="text-xs font-mono text-stone-400">{formatPrice(selectedTier.priceGBP)} per annum</p>
                </div>

                <div className="space-y-3 text-xs font-mono">
                  <div>
                    <label className="block text-stone-400 mb-1">FULL NAME</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Lord Alexander Vance"
                      className="w-full p-3 bg-[#0D0F0E] border border-stone-800 rounded text-stone-100 focus:border-[#C5A059] outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-stone-400 mb-1">EMAIL ADDRESS</label>
                    <input
                      type="email"
                      required
                      placeholder="vance@estate.co.uk"
                      className="w-full p-3 bg-[#0D0F0E] border border-stone-800 rounded text-stone-100 focus:border-[#C5A059] outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-stone-400 mb-1">CELLAR STORAGE PREFERENCE</label>
                    <select className="w-full p-3 bg-[#0D0F0E] border border-stone-800 rounded text-stone-100 focus:border-[#C5A059] outline-none">
                      <option>Direct Annual Delivery to Private Residence</option>
                      <option>Alderford Subterranean Bonded Cellar Vault</option>
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-4 bg-[#C5A059] text-[#111E16] font-mono text-xs font-bold tracking-[0.2em] uppercase hover:bg-[#E5C98B] transition-colors rounded cursor-pointer mt-4"
                >
                  SUBMIT PATRON APPLICATION
                </button>
              </form>
            ) : (
              <div className="text-center py-6 space-y-4">
                <ShieldCheck className="w-12 h-12 text-[#C5A059] mx-auto" />
                <h3 className="font-display text-2xl text-stone-100">APPLICATION RECEIVED</h3>
                <p className="font-sans-modern text-stone-300 text-xs">
                  The Alderford Society Membership Committee will review your application for <span className="text-[#C5A059] font-bold">{selectedTier.name}</span> within 48 hours.
                </p>
                <button
                  onClick={() => setSelectedTier(null)}
                  className="px-6 py-2 bg-[#C5A059] text-[#111E16] font-mono text-xs font-bold uppercase rounded cursor-pointer"
                >
                  DONE
                </button>
              </div>
            )}

          </div>
        </div>
      )}

    </section>
  );
};
