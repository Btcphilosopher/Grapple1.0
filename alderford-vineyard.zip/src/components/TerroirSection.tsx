import React, { useState } from 'react';
import { Mountain, Thermometer, CloudRain, Sun, Activity, Droplets, Layers } from 'lucide-react';
import { TERROIR_LAYERS } from '../data/estate';

export const TerroirSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'soil' | 'elevation' | 'climate' | 'blocks'>('soil');
  const [selectedLayer, setSelectedLayer] = useState(TERROIR_LAYERS[0]);

  return (
    <section id="terroir" className="py-24 sm:py-32 bg-[#FDFBF7] text-[#242728] border-b border-[#EAE5DB]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#111E16]/5 border border-[#111E16]/10 text-xs font-mono text-[#C5A059] uppercase tracking-[0.25em]">
            <Activity className="w-3.5 h-3.5" />
            <span>SCIENTIFIC TERROIR ANALYSIS</span>
          </div>
          <h2 className="font-display text-3xl sm:text-5xl tracking-wide uppercase font-light text-[#111E16]">
            THE ENGLISH TERROIR
          </h2>
          <p className="font-sans-modern text-stone-600 text-sm sm:text-base font-light leading-relaxed">
            Alderford sits upon the same 85-million-year-old Cretaceous chalk band that defines Champagne’s legendary Côte des Blancs. Explore the scientific geology that shapes our wines.
          </p>
        </div>

        {/* Scientific Mode Tabs */}
        <div className="flex flex-wrap justify-center gap-2 sm:gap-4 mb-12">
          {[
            { id: 'soil', label: '01. GEOLOGICAL PROFILE', icon: Layers },
            { id: 'elevation', label: '02. ELEVATION & CONTOURS', icon: Mountain },
            { id: 'climate', label: '03. SOLAR & RAINFALL', icon: Sun },
            { id: 'blocks', label: '04. VINEYARD BLOCKS', icon: Droplets }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-5 py-3 text-xs font-mono tracking-wider uppercase transition-all duration-300 rounded-xs cursor-pointer ${
                  isActive
                    ? 'bg-[#111E16] text-[#E5C98B] font-bold shadow-xl border border-[#C5A059]'
                    : 'bg-[#EAE5DB]/60 text-stone-700 hover:bg-[#EAE5DB] hover:text-[#111E16]'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-[#C5A059]' : 'text-stone-500'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content Display */}
        {activeTab === 'soil' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-[#111E16] text-white p-8 sm:p-12 rounded-xs shadow-2xl border border-[#C5A059]/30">
            
            {/* Layer Selection Buttons (4 Cols) */}
            <div className="lg:col-span-4 space-y-4">
              <span className="text-xs font-mono uppercase text-[#C5A059] tracking-widest block">
                GEOLOGY DEPTH STRATA
              </span>
              {TERROIR_LAYERS.map((layer) => (
                <button
                  key={layer.id}
                  onClick={() => setSelectedLayer(layer)}
                  className={`w-full text-left p-4 rounded-xs border transition-all duration-300 cursor-pointer ${
                    selectedLayer.id === layer.id
                      ? 'bg-[#C5A059] text-[#111E16] border-white font-bold shadow-lg'
                      : 'bg-[#0D0F0E] text-stone-300 border-stone-800 hover:border-[#C5A059]'
                  }`}
                >
                  <div className="text-xs font-mono tracking-widest uppercase opacity-80 mb-1">
                    {layer.keyMetric} • {layer.metricLabel}
                  </div>
                  <div className="font-display text-lg">{layer.name}</div>
                  <div className="text-xs font-sans-modern opacity-80 mt-1">{layer.subtitle}</div>
                </button>
              ))}
            </div>

            {/* Geological Layer Scientific Inspector (8 Cols) */}
            <div className="lg:col-span-8 bg-[#0D0F0E] p-6 sm:p-8 rounded-xs border border-stone-800 space-y-6">
              
              <div className="flex justify-between items-center border-b border-stone-800 pb-4">
                <div>
                  <span className="text-xs font-mono text-[#C5A059] uppercase tracking-widest">
                    SELECTED STRATUM DATA
                  </span>
                  <h3 className="font-display text-3xl text-stone-100">{selectedLayer.name}</h3>
                </div>
                <div className="text-right">
                  <span className="font-mono text-2xl text-[#C5A059] block font-bold">{selectedLayer.keyMetric}</span>
                  <span className="text-[10px] font-mono text-stone-400 uppercase">{selectedLayer.metricLabel}</span>
                </div>
              </div>

              <p className="font-sans-modern text-stone-300 text-sm sm:text-base leading-relaxed">
                {selectedLayer.description}
              </p>

              {/* Data Specifications Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-stone-800 text-xs font-mono">
                <div className="p-3 bg-[#142218] rounded border border-stone-800">
                  <span className="text-stone-400 block mb-1">MINERAL COMPOSITION:</span>
                  <span className="text-[#E5C98B] font-bold">{selectedLayer.details.composition}</span>
                </div>
                <div className="p-3 bg-[#142218] rounded border border-stone-800">
                  <span className="text-stone-400 block mb-1">DRAINAGE EFFICIENCY:</span>
                  <span className="text-[#E5C98B] font-bold">{selectedLayer.details.drainage}</span>
                </div>
                <div className="p-3 bg-[#142218] rounded border border-stone-800">
                  <span className="text-stone-400 block mb-1">PALATE INFLUENCE:</span>
                  <span className="text-[#E5C98B] font-bold">{selectedLayer.details.mineralInfluence}</span>
                </div>
                <div className="p-3 bg-[#142218] rounded border border-stone-800">
                  <span className="text-stone-400 block mb-1">ROOT PENETRATION DEPTH:</span>
                  <span className="text-[#E5C98B] font-bold">{selectedLayer.details.rootDepth}</span>
                </div>
              </div>

            </div>

          </div>
        )}

        {activeTab === 'elevation' && (
          <div className="bg-[#111E16] text-white p-8 rounded-xs border border-[#C5A059]/30 space-y-6">
            <div className="flex justify-between items-center border-b border-stone-800 pb-4">
              <h3 className="font-display text-2xl">High Ridge Elevation Profile (85m - 145m Above Sea Level)</h3>
              <span className="text-xs font-mono text-[#C5A059]">SUSSEX DOWNS CONTOUR ANALYSIS</span>
            </div>
            
            {/* Topographic Visualizer Representation */}
            <div className="h-64 bg-[#0D0F0E] rounded p-6 flex flex-col justify-end relative overflow-hidden border border-stone-800">
              <svg className="w-full h-full stroke-[#C5A059] fill-[#C5A059]/10" viewBox="0 0 600 200" preserveAspectRatio="none">
                <path d="M0,180 Q120,140 240,60 T480,100 T600,160 L600,200 L0,200 Z" strokeWidth="2" />
                <line x1="240" y1="0" x2="240" y2="200" stroke="#E5C98B" strokeWidth="1" strokeDasharray="4 2" />
              </svg>
              <div className="absolute top-4 left-6 text-xs font-mono text-stone-300 space-y-1">
                <div>PEAK ELEVATION: 145m ASL (Block 1 Chardonnay)</div>
                <div>OPTIMAL GRADIENT: 14.5° South Facing</div>
                <div>FROST DRAINAGE: Natural gravity airflow into valley</div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
              <div className="p-4 bg-[#142218] border border-stone-800 rounded">
                <span className="text-[#C5A059] block font-bold mb-1">SOUTH-FACING ASPECT</span>
                <span className="text-stone-300">Captures 1,650 hours of direct solar radiation during growing season.</span>
              </div>
              <div className="p-4 bg-[#142218] border border-stone-800 rounded">
                <span className="text-[#C5A059] block font-bold mb-1">FROST RESILIENCE</span>
                <span className="text-stone-300">Continuous 12 knot downslope wind currents prevent stagnant cold air.</span>
              </div>
              <div className="p-4 bg-[#142218] border border-stone-800 rounded">
                <span className="text-[#C5A059] block font-bold mb-1">OPTIMAL DRAINAGE</span>
                <span className="text-stone-300">Zero standing rainwater even after heavy autumn rainfall.</span>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'climate' && (
          <div className="bg-[#111E16] text-white p-8 rounded-xs border border-[#C5A059]/30 space-y-6">
            <div className="flex justify-between items-center border-b border-stone-800 pb-4">
              <h3 className="font-display text-2xl">Annual Micro-Climate & Solar Tracker</h3>
              <span className="text-xs font-mono text-[#C5A059]">SUSSEX WEATHER METRICS</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-6">
              <div className="p-6 bg-[#0D0F0E] rounded border border-stone-800 text-center">
                <Sun className="w-8 h-8 text-[#C5A059] mx-auto mb-2" />
                <div className="font-mono text-2xl text-stone-100 font-bold">1,680 Hrs</div>
                <div className="text-[10px] font-mono text-stone-400 uppercase mt-1">Annual Solar Sunshine</div>
              </div>
              <div className="p-6 bg-[#0D0F0E] rounded border border-stone-800 text-center">
                <Thermometer className="w-8 h-8 text-[#C5A059] mx-auto mb-2" />
                <div className="font-mono text-2xl text-stone-100 font-bold">14.8°C</div>
                <div className="text-[10px] font-mono text-stone-400 uppercase mt-1">Mean Growing Temp</div>
              </div>
              <div className="p-6 bg-[#0D0F0E] rounded border border-stone-800 text-center">
                <CloudRain className="w-8 h-8 text-[#C5A059] mx-auto mb-2" />
                <div className="font-mono text-2xl text-stone-100 font-bold">620 mm</div>
                <div className="text-[10px] font-mono text-stone-400 uppercase mt-1">Balanced Rainfall</div>
              </div>
              <div className="p-6 bg-[#0D0F0E] rounded border border-stone-800 text-center">
                <Activity className="w-8 h-8 text-[#C5A059] mx-auto mb-2" />
                <div className="font-mono text-2xl text-stone-100 font-bold">115 Days</div>
                <div className="text-[10px] font-mono text-stone-400 uppercase mt-1">Slow Hang-Time</div>
              </div>
            </div>

            <p className="text-xs font-sans-modern text-stone-300 leading-relaxed bg-[#142218] p-4 rounded border border-stone-800">
              The long, cool English growing season allows grapes to hang on the vine 30 days longer than in southern Europe. This extended hang-time builds intense phenolic complexity and floral aromas while preserving sparkling wine’s essential energetic acidity.
            </p>
          </div>
        )}

        {activeTab === 'blocks' && (
          <div className="bg-[#111E16] text-white p-8 rounded-xs border border-[#C5A059]/30 space-y-6">
            <div className="flex justify-between items-center border-b border-stone-800 pb-4">
              <h3 className="font-display text-2xl">Block-By-Block Viticulture Division</h3>
              <span className="text-xs font-mono text-[#C5A059]">120 ACRE ESTATE MAP</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { name: 'BLOCK 1', grape: 'Chardonnay (Champagne Clone 95)', soil: 'Pure Chalk Reef', usage: 'Blanc de Blancs & Reserve' },
                { name: 'BLOCK 2', grape: 'Pinot Noir (Burgundy Clone 777)', soil: 'Glacial Silt over Chalk', usage: 'Estate Rosé & Pinot Rouge' },
                { name: 'BLOCK 3', grape: 'Pinot Meunier (Clone 817)', soil: 'Flint Topsoil', usage: 'Heritage Cuvée Blends' },
                { name: 'BLOCK 4', grape: 'Bacchus & Pinot Gris', soil: 'Greensand Loam', usage: 'Estate Aromatic Whites' }
              ].map((b, idx) => (
                <div key={idx} className="p-5 bg-[#0D0F0E] rounded border border-stone-800 space-y-3">
                  <div className="text-xs font-mono text-[#C5A059] font-bold">{b.name}</div>
                  <div className="font-display text-base text-stone-100">{b.grape}</div>
                  <div className="text-xs font-sans-modern text-stone-400">
                    <span className="text-stone-300 font-medium">Soils:</span> {b.soil}
                  </div>
                  <div className="text-xs font-mono text-[#E5C98B] bg-[#142218] p-2 rounded">
                    {b.usage}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
