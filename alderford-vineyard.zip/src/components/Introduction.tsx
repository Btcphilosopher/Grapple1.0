import React, { useState } from 'react';
import { Compass, BookOpen, Sparkles, CheckCircle2 } from 'lucide-react';
import { ASSETS } from '../data/assets';

export const Introduction: React.FC = () => {
  const [manifestoModalOpen, setManifestoModalOpen] = useState(false);

  return (
    <section id="introduction" className="py-24 sm:py-32 bg-[#FDFCF7] text-[#1A1A1A] border-b border-[#1A1A1A]/10 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Tag */}
        <div className="flex items-center gap-3 justify-center mb-12">
          <span className="w-12 h-[1px] bg-[#B08D57]" />
          <span className="text-xs font-mono tracking-[0.3em] uppercase text-[#B08D57] font-medium">
            OUR PHILOSOPHY
          </span>
          <span className="w-12 h-[1px] bg-[#B08D57]" />
        </div>

        {/* Split Screen Editorial Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Photography & Bottle Showcase */}
          <div className="lg:col-span-6 relative">
            <div className="relative z-10 rounded-xs overflow-hidden shadow-2xl border border-[#1A1A1A]/10 bg-[#1B3022]">
              <img
                src={ASSETS.wineBottlesHero}
                alt="Alderford Estate Wine Collection"
                className="w-full h-[480px] sm:h-[580px] object-cover object-center hover:scale-105 transition-transform duration-700 opacity-90"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1B3022]/95 via-transparent to-transparent flex items-end p-8">
                <div className="text-[#FDFCF7] space-y-1">
                  <p className="text-xs font-mono text-[#B08D57] tracking-widest uppercase">ESTATE BOTTLING • SUSSEX</p>
                  <p className="font-display text-xl text-[#FDFCF7]">The Benchmark for 21st Century English Wine</p>
                </div>
              </div>
            </div>

            {/* Decorative Background Accent Card */}
            <div className="absolute -bottom-6 -right-6 w-full h-full border border-[#B08D57]/40 -z-0 rounded-xs hidden sm:block" />
          </div>

          {/* Right Column: Typography & Restrained Copy */}
          <div className="lg:col-span-6 space-y-8">
            <div className="space-y-4">
              <span className="text-xs font-mono tracking-[0.25em] text-[#B08D57] uppercase block font-semibold">
                ANGLO-FUTURIST HERITAGE
              </span>
              <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-light leading-[1.1] text-[#1A1A1A]">
                Rooted in England. <br />
                <span className="italic font-serif text-[#1B3022]">Crafted for the Future.</span>
              </h2>
            </div>

            <p className="font-sans text-[#1A1A1A]/80 text-base sm:text-lg leading-relaxed font-light">
              Alderford is an English vineyard created around a simple belief: that England can produce wines of extraordinary distinction.
            </p>

            <p className="font-sans text-[#1A1A1A]/70 text-sm sm:text-base leading-relaxed">
              Our estate brings together exceptional Cretaceous chalk terroir, meticulous precision viticulture, advanced winemaking technology and a deep, enduring respect for the English landscape.
            </p>

            {/* Core Values Bullets */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-[#1A1A1A]/10">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#B08D57] shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-display text-sm font-semibold text-[#1A1A1A]">100% Estate Grown</h3>
                  <p className="text-xs text-[#1A1A1A]/60">Every berry harvested from our own Sussex hills.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#B08D57] shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-display text-sm font-semibold text-[#1A1A1A]">Low-Intervention Precision</h3>
                  <p className="text-xs text-[#1A1A1A]/60">Gravity flow and subterranean natural cellaring.</p>
                </div>
              </div>
            </div>

            {/* CTA */}
            <div className="pt-4 flex flex-wrap items-center gap-4">
              <button
                onClick={() => setManifestoModalOpen(true)}
                className="px-8 py-3.5 bg-[#1A1A1A] text-[#FDFCF7] text-xs font-bold tracking-[0.25em] uppercase hover:bg-[#1B3022] hover:text-[#B08D57] transition-all duration-300 shadow-md cursor-pointer flex items-center gap-3 border border-[#1A1A1A]"
              >
                <BookOpen className="w-4 h-4 text-[#B08D57]" />
                <span>OUR STORY & MANIFESTO</span>
              </button>
            </div>

          </div>

        </div>

      </div>

      {/* Manifesto Modal */}
      {manifestoModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-[#FDFBF7] text-[#242728] max-w-3xl w-full p-8 sm:p-12 rounded-xs border border-[#C5A059] max-h-[90vh] overflow-y-auto space-y-6 relative shadow-2xl">
            <button
              onClick={() => setManifestoModalOpen(false)}
              className="absolute top-6 right-6 text-stone-500 hover:text-[#111E16] font-mono text-sm cursor-pointer"
            >
              [CLOSE ✕]
            </button>

            <div className="text-center space-y-2 border-b border-[#EAE5DB] pb-6">
              <span className="text-xs font-mono uppercase text-[#C5A059] tracking-[0.3em]">
                ALDERFORD MANIFESTO
              </span>
              <h3 className="font-display text-3xl text-[#111E16]">The Emergence of English Fine Wine</h3>
              <p className="text-xs font-mono text-stone-500 uppercase">Sussex • England</p>
            </div>

            <div className="space-y-4 font-sans-modern text-stone-700 text-sm leading-relaxed">
              <p className="first-letter:text-4xl first-letter:font-editorial first-letter:font-bold first-letter:text-[#C5A059] first-letter:float-left first-letter:mr-3">
                For centuries, the world looked south for fine wine. Today, a seismic climatic and viticultural shift has turned all eyes to the Cretaceous chalk ridges of southern England.
              </p>
              <p>
                At Alderford, we do not imitate French châteaux or Californian estates. We celebrate the unique character of our English soils: the cool autumn mornings, the long gentle summer daylight, and the electric, saline minerality born of 85-million-year-old chalk seabed.
              </p>
              <p>
                Our winery is an Anglo-Futurist synthesis of architectural discipline, low-carbon engineering, and timeless craftsmanship. Every bottle of Alderford is a declaration of confidence in Britain’s agricultural future.
              </p>
            </div>

            <div className="pt-6 border-t border-[#EAE5DB] flex justify-between items-center text-xs font-mono text-stone-500">
              <span>ALDERFORD ESTATE TRUST</span>
              <span className="text-[#C5A059]">HERITAGE. INNOVATION. EXCELLENCE.</span>
            </div>
          </div>
        </div>
      )}

    </section>
  );
};
