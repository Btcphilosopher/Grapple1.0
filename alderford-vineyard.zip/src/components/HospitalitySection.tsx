import React, { useState } from 'react';
import { HOSPITALITY_EXPERIENCES } from '../data/estate';
import { Experience } from '../types';
import { Calendar, Clock, Users, CheckCircle2, ArrowRight, X } from 'lucide-react';

interface HospitalitySectionProps {
  formatPrice: (priceGBP: number) => string;
}

export const HospitalitySection: React.FC<HospitalitySectionProps> = ({ formatPrice }) => {
  const [selectedExperience, setSelectedExperience] = useState<Experience | null>(null);
  const [bookingConfirmed, setBookingConfirmed] = useState(false);
  
  // Booking Form State
  const [bookingDate, setBookingDate] = useState('2026-09-15');
  const [bookingTime, setBookingTime] = useState('11:00');
  const [guests, setGuests] = useState(2);
  const [dietary, setDietary] = useState('');

  const handleBookSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setBookingConfirmed(true);
  };

  return (
    <section id="experiences" className="py-24 sm:py-32 bg-[#FDFBF7] text-[#242728] border-b border-[#EAE5DB]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="flex items-center gap-3 justify-center">
            <span className="w-12 h-[1px] bg-[#C5A059]" />
            <span className="text-xs font-mono tracking-[0.3em] uppercase text-[#C5A059] font-medium">
              ESTATE HOSPITALITY
            </span>
            <span className="w-12 h-[1px] bg-[#C5A059]" />
          </div>
          <h2 className="font-display text-3xl sm:text-5xl tracking-wide uppercase font-light text-[#111E16]">
            COME TO ALDERFORD
          </h2>
          <p className="font-sans-modern text-stone-600 text-sm sm:text-base font-light leading-relaxed">
            Experience Britain’s most compelling wine sanctuary. From subterranean barrel tastings to glasshouse dining with panoramic Sussex views.
          </p>
        </div>

        {/* Experience Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {HOSPITALITY_EXPERIENCES.map((exp) => (
            <div
              key={exp.id}
              className="bg-[#F5F2EA] rounded-xs border border-[#EAE5DB] hover:border-[#C5A059] transition-all duration-500 overflow-hidden flex flex-col justify-between shadow-sm hover:shadow-2xl group"
            >
              
              <div>
                <div className="relative h-60 overflow-hidden">
                  <img
                    src={exp.image}
                    alt={exp.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-4">
                    <span className="text-xs font-mono text-[#E5C98B] bg-[#111E16] px-2.5 py-1 rounded">
                      {formatPrice(exp.priceGBP)} / GUEST
                    </span>
                  </div>
                </div>

                <div className="p-6 space-y-4">
                  <div>
                    <h3 className="font-display text-2xl text-[#111E16]">{exp.title}</h3>
                    <p className="text-xs font-mono text-[#C5A059] uppercase tracking-wide mt-1">{exp.subtitle}</p>
                  </div>

                  <p className="font-sans-modern text-stone-600 text-xs sm:text-sm leading-relaxed">
                    {exp.description}
                  </p>

                  <div className="space-y-1.5 pt-2 border-t border-[#EAE5DB] text-xs font-mono text-stone-500">
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-[#C5A059]" />
                      <span>{exp.duration}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-3.5 h-3.5 text-[#C5A059]" />
                      <span>{exp.capacity}</span>
                    </div>
                  </div>

                  <div className="space-y-1 pt-2 border-t border-[#EAE5DB] text-xs font-sans-modern text-stone-600">
                    {exp.includes.map((inc, idx) => (
                      <div key={idx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#C5A059] shrink-0 mt-0.5" />
                        <span>{inc}</span>
                      </div>
                    ))}
                  </div>

                </div>
              </div>

              <div className="p-6 pt-0">
                <button
                  onClick={() => {
                    setSelectedExperience(exp);
                    setBookingConfirmed(false);
                  }}
                  className="w-full py-3 bg-[#111E16] text-[#E5C98B] text-xs font-mono font-bold tracking-[0.2em] uppercase hover:bg-[#C5A059] hover:text-[#111E16] transition-colors rounded-xs cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>RESERVE EXPERIENCE</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>

      {/* Booking Modal Engine */}
      {selectedExperience && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-[#FDFBF7] text-[#242728] max-w-2xl w-full p-8 sm:p-10 rounded-xs border border-[#C5A059] shadow-2xl relative my-auto">
            
            <button
              onClick={() => setSelectedExperience(null)}
              className="absolute top-6 right-6 text-stone-500 hover:text-[#111E16] cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>

            {!bookingConfirmed ? (
              <form onSubmit={handleBookSubmit} className="space-y-6">
                
                <div className="border-b border-[#EAE5DB] pb-4">
                  <span className="text-xs font-mono uppercase text-[#C5A059] tracking-widest">ESTATE RESERVATION</span>
                  <h3 className="font-display text-2xl text-[#111E16]">{selectedExperience.title}</h3>
                  <p className="text-xs font-mono text-stone-500">{formatPrice(selectedExperience.priceGBP)} per guest</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
                  <div>
                    <label className="block text-stone-600 mb-1">PREFERRED DATE</label>
                    <input
                      type="date"
                      value={bookingDate}
                      onChange={(e) => setBookingDate(e.target.value)}
                      required
                      className="w-full p-3 bg-[#F5F2EA] border border-[#EAE5DB] rounded text-[#111E16] focus:border-[#C5A059] outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-stone-600 mb-1">TIME SLOT</label>
                    <select
                      value={bookingTime}
                      onChange={(e) => setBookingTime(e.target.value)}
                      className="w-full p-3 bg-[#F5F2EA] border border-[#EAE5DB] rounded text-[#111E16] focus:border-[#C5A059] outline-none"
                    >
                      <option value="11:00">11:00 Morning Session</option>
                      <option value="14:00">14:00 Afternoon Session</option>
                      <option value="18:30">18:30 Evening Session</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-stone-600 mb-1">NUMBER OF GUESTS</label>
                    <select
                      value={guests}
                      onChange={(e) => setGuests(Number(e.target.value))}
                      className="w-full p-3 bg-[#F5F2EA] border border-[#EAE5DB] rounded text-[#111E16] focus:border-[#C5A059] outline-none"
                    >
                      {[1,2,3,4,5,6,8,10,12].map(n => (
                        <option key={n} value={n}>{n} Guests</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-stone-600 mb-1">DIETARY / SPECIAL NOTES</label>
                    <input
                      type="text"
                      placeholder="e.g. Vegetarian, Allergy notes"
                      value={dietary}
                      onChange={(e) => setDietary(e.target.value)}
                      className="w-full p-3 bg-[#F5F2EA] border border-[#EAE5DB] rounded text-[#111E16] focus:border-[#C5A059] outline-none"
                    />
                  </div>
                </div>

                <div className="p-4 bg-[#111E16] text-white rounded text-xs font-mono space-y-1">
                  <div className="flex justify-between">
                    <span>ESTIMATE TOTAL ({guests} guests):</span>
                    <span className="text-[#C5A059] font-bold">{formatPrice(selectedExperience.priceGBP * guests)}</span>
                  </div>
                  <p className="text-[10px] text-stone-400">Includes private sommelier guide & Estate Gardens access.</p>
                </div>

                <button
                  type="submit"
                  className="w-full py-4 bg-[#C5A059] text-[#111E16] font-mono text-xs font-bold tracking-[0.2em] uppercase hover:bg-[#E5C98B] transition-colors rounded cursor-pointer shadow-xl"
                >
                  CONFIRM RESERVATION REQUEST
                </button>

              </form>
            ) : (
              <div className="text-center py-8 space-y-4">
                <div className="w-16 h-16 bg-[#C5A059] text-[#111E16] rounded-full flex items-center justify-center mx-auto shadow-xl">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="font-display text-3xl text-[#111E16]">RESERVATION CONFIRMED</h3>
                <p className="font-sans-modern text-stone-600 text-sm max-w-md mx-auto">
                  We look forward to welcoming you to Alderford Estate on <span className="font-bold text-[#111E16]">{bookingDate}</span> at <span className="font-bold text-[#111E16]">{bookingTime}</span> for <span className="font-bold text-[#111E16]">{guests} guests</span>.
                </p>
                <div className="p-4 bg-[#F5F2EA] border border-[#EAE5DB] rounded text-xs font-mono text-stone-500">
                  RESERVATION CODE: <span className="text-[#111E16] font-bold">ALD-2026-9812</span>
                </div>
                <button
                  onClick={() => setSelectedExperience(null)}
                  className="px-8 py-3 bg-[#111E16] text-[#E5C98B] text-xs font-mono uppercase tracking-widest rounded cursor-pointer"
                >
                  CLOSE
                </button>
              </div>
            )}

          </div>
        </div>
      )}

    </section>
  );
};
