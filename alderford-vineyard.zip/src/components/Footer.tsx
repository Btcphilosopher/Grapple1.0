import React, { useState } from 'react';
import { ALDERFORD_CREST_SVG } from '../data/assets';
import { Send, CheckCircle2 } from 'lucide-react';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
    }
  };

  return (
    <footer className="bg-[#1A1A1A] text-[#FDFCF7] pt-20 pb-12 border-t border-[#1A1A1A]/10 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* Top Footer Banner */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pb-16 border-b border-[#FDFCF7]/10 items-start">
          
          {/* Brand & Crest (5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-10 h-12">
                <div dangerouslySetInnerHTML={{ __html: ALDERFORD_CREST_SVG }} />
              </div>
              <div>
                <span className="font-display text-2xl tracking-[0.2em] font-light uppercase text-[#FDFCF7] block">
                  ALDERFORD
                </span>
                <span className="text-[10px] tracking-[0.3em] font-mono text-[#B08D57] uppercase">
                  VINEYARD • ENGLAND
                </span>
              </div>
            </div>

            <p className="font-sans text-xs text-[#FDFCF7]/70 max-w-sm leading-relaxed font-light">
              World-class English wine, grown and bottled at our 120-acre Cretaceous chalk estate in Sussex, England.
            </p>

            <div className="text-xs font-mono text-[#B08D57] tracking-widest uppercase">
              HERITAGE. INNOVATION. EXCELLENCE.
            </div>
          </div>

          {/* Quick Links (4 Cols) */}
          <div className="lg:col-span-4 grid grid-cols-2 gap-8 text-xs font-mono">
            <div className="space-y-3">
              <span className="text-[#B08D57] uppercase tracking-widest font-bold block">
                NAVIGATION
              </span>
              <ul className="space-y-2 text-[#FDFCF7]/70">
                <li><button onClick={() => onNavigate('introduction')} className="hover:text-[#B08D57] cursor-pointer">Our Story</button></li>
                <li><button onClick={() => onNavigate('wines')} className="hover:text-[#B08D57] cursor-pointer">The Wines</button></li>
                <li><button onClick={() => onNavigate('estate')} className="hover:text-[#B08D57] cursor-pointer">The Estate</button></li>
                <li><button onClick={() => onNavigate('terroir')} className="hover:text-[#B08D57] cursor-pointer">Chalk Terroir</button></li>
                <li><button onClick={() => onNavigate('winemaking')} className="hover:text-[#B08D57] cursor-pointer">Precision</button></li>
              </ul>
            </div>

            <div className="space-y-3">
              <span className="text-[#B08D57] uppercase tracking-widest font-bold block">
                EXPERIENCES
              </span>
              <ul className="space-y-2 text-[#FDFCF7]/70">
                <li><button onClick={() => onNavigate('cellar')} className="hover:text-[#B08D57] cursor-pointer">Chalk Vaults</button></li>
                <li><button onClick={() => onNavigate('experiences')} className="hover:text-[#B08D57] cursor-pointer">Tastings & Dining</button></li>
                <li><button onClick={() => onNavigate('society')} className="hover:text-[#B08D57] cursor-pointer">Alderford Society</button></li>
                <li><button onClick={() => onNavigate('journal')} className="hover:text-[#B08D57] cursor-pointer">Journal</button></li>
              </ul>
            </div>
          </div>

          {/* Newsletter Dispatch (3 Cols) */}
          <div className="lg:col-span-3 space-y-4">
            <span className="text-xs font-mono text-[#B08D57] uppercase tracking-widest font-bold block">
              PRIVATE ALLOCATION GAZETTE
            </span>
            <p className="text-xs font-sans text-[#FDFCF7]/70">
              Receive private notifications regarding vintage releases and members-only allocations.
            </p>

            {!subscribed ? (
              <form onSubmit={handleSubscribe} className="space-y-2">
                <div className="flex border border-[#FDFCF7]/20 rounded overflow-hidden bg-[#1B3022]">
                  <input
                    type="email"
                    required
                    placeholder="Enter email address..."
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="p-2.5 text-xs font-mono bg-transparent text-[#FDFCF7] outline-none flex-1 placeholder:text-[#FDFCF7]/40"
                  />
                  <button
                    type="submit"
                    aria-label="Subscribe"
                    className="bg-[#B08D57] text-[#111E16] p-2.5 hover:bg-[#C5A059] cursor-pointer transition-colors"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </form>
            ) : (
              <div className="p-3 bg-[#1B3022] border border-[#B08D57] rounded text-xs font-mono text-[#B08D57] flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#B08D57]" />
                <span>Subscribed to Alderford Gazette.</span>
              </div>
            )}
          </div>

        </div>

        {/* Responsible Drinking & Legal Notices */}
        <div className="pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-[10px] font-mono text-[#FDFCF7]/50 border-t border-[#FDFCF7]/10">
          <div>
            © 2026 ALDERFORD VINEYARD ESTATE LIMITED. ENGLAND. ALL RIGHTS RESERVED.
          </div>

          <div className="flex items-center gap-6">
            <span>DRINK RESPONSIBLY • DRINKAWARE.CO.UK</span>
            <span>PRIVACY POLICY</span>
            <span>TERMS OF ALLOCATION</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
