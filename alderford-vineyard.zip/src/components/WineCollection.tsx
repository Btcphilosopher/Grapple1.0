import React, { useState } from 'react';
import { Wine, CurrencyCode } from '../types';
import { WINES } from '../data/wines';
import { Award, Eye, Plus, Check } from 'lucide-react';

interface WineCollectionProps {
  currentCurrency: CurrencyCode;
  formatPrice: (priceGBP: number) => string;
  onSelectWine: (wine: Wine) => void;
  onAddToCart: (wine: Wine) => void;
}

export const WineCollection: React.FC<WineCollectionProps> = ({
  currentCurrency,
  formatPrice,
  onSelectWine,
  onAddToCart,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [addedWineId, setAddedWineId] = useState<string | null>(null);

  const categories = ['All', 'Sparkling', 'Red', 'White', 'Rosé', 'Limited Edition'];

  const filteredWines = selectedCategory === 'All'
    ? WINES
    : WINES.filter(w => w.category === selectedCategory);

  const handleAdd = (wine: Wine, e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(wine);
    setAddedWineId(wine.id);
    setTimeout(() => setAddedWineId(null), 1500);
  };

  return (
    <section id="wines" className="py-24 sm:py-32 bg-[#FDFCF7] text-[#1A1A1A] border-b border-[#1A1A1A]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="flex items-center gap-3 justify-center">
            <span className="w-12 h-[1px] bg-[#B08D57]" />
            <span className="text-xs font-mono tracking-[0.3em] uppercase text-[#B08D57] font-medium">
              ESTATE RELEASE VINTAGES
            </span>
            <span className="w-12 h-[1px] bg-[#B08D57]" />
          </div>
          <h2 className="font-display text-3xl sm:text-5xl tracking-wide uppercase font-light text-[#1A1A1A]">
            THE COLLECTION
          </h2>
          <p className="font-sans text-[#1A1A1A]/70 text-sm sm:text-base font-light leading-relaxed">
            Every bottle of Alderford is an uncompromised expression of our chalk terroir and English sunlight. Hand-crafted in limited allocations.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-2 sm:gap-4 mb-16">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-5 py-2.5 text-xs font-mono tracking-wider uppercase transition-all duration-300 rounded-xs cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#1B3022] text-[#B08D57] font-bold shadow-lg border border-[#B08D57]'
                  : 'bg-[#1A1A1A]/5 text-[#1A1A1A]/80 hover:bg-[#1A1A1A]/10 hover:text-[#1A1A1A]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Wine Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 xl:gap-10">
          {filteredWines.map((wine) => {
            const isJustAdded = addedWineId === wine.id;
            return (
              <div
                key={wine.id}
                onClick={() => onSelectWine(wine)}
                className="group bg-[#FDFCF7] rounded-xs border border-[#1A1A1A]/10 hover:border-[#B08D57] transition-all duration-500 p-6 sm:p-8 flex flex-col justify-between relative cursor-pointer shadow-xs hover:shadow-2xl"
              >
                
                {/* Top Badge Area */}
                <div className="flex justify-between items-start mb-6">
                  <span className="text-[10px] font-mono tracking-[0.2em] uppercase text-[#B08D57] bg-[#1B3022] px-2.5 py-1 rounded">
                    {wine.vintage} • {wine.category}
                  </span>
                  {wine.isReserve && (
                    <span className="text-[10px] font-mono tracking-[0.2em] uppercase bg-[#B08D57] text-[#111E16] font-bold px-2.5 py-1 rounded">
                      PRESTIGE
                    </span>
                  )}
                </div>

                {/* Bottle Render Showcase */}
                <div className="relative h-72 sm:h-80 flex items-center justify-center my-4 overflow-hidden rounded bg-[#1B3022]/5">
                  <img
                    src={wine.image}
                    alt={wine.name}
                    className="h-full object-contain group-hover:scale-108 transition-transform duration-700 drop-shadow-2xl"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Award Badge Pill */}
                  {wine.award && (
                    <div className="absolute bottom-3 left-3 right-3 bg-[#1B3022]/95 backdrop-blur-md p-2 rounded text-[10px] font-mono text-[#B08D57] flex items-center gap-2 border border-[#B08D57]/30">
                      <Award className="w-3.5 h-3.5 text-[#B08D57] shrink-0" />
                      <span className="truncate">{wine.award}</span>
                    </div>
                  )}
                </div>

                {/* Wine Name & Subtitle */}
                <div className="space-y-2 mt-4">
                  <div className="flex justify-between items-baseline">
                    <h3 className="font-display text-2xl text-[#1A1A1A] group-hover:text-[#B08D57] transition-colors">
                      {wine.name}
                    </h3>
                    <span className="font-mono text-lg font-bold text-[#1A1A1A]">
                      {formatPrice(wine.priceGBP)}
                    </span>
                  </div>
                  <p className="text-xs font-mono text-[#1A1A1A]/60 uppercase tracking-wide">
                    {wine.subtitle}
                  </p>
                </div>

                {/* Tasting Profile Metric Indicators */}
                <div className="mt-6 pt-4 border-t border-[#1A1A1A]/10 space-y-2 text-[10px] font-mono text-[#1A1A1A]/60">
                  <div className="flex justify-between items-center">
                    <span>MINERALITY</span>
                    <div className="w-24 h-1.5 bg-[#1A1A1A]/10 rounded-full overflow-hidden">
                      <div className="h-full bg-[#B08D57]" style={{ width: `${wine.tastingProfile.mineral}%` }} />
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>ACIDITY TENSION</span>
                    <div className="w-24 h-1.5 bg-[#1A1A1A]/10 rounded-full overflow-hidden">
                      <div className="h-full bg-[#1B3022]" style={{ width: `${wine.tastingProfile.acidity}%` }} />
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="mt-6 pt-4 flex items-center gap-3">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectWine(wine);
                    }}
                    className="flex-1 py-2.5 px-3 border border-[#1A1A1A] text-[#1A1A1A] text-[11px] font-bold tracking-[0.15em] uppercase hover:bg-[#1A1A1A] hover:text-[#FDFCF7] transition-colors flex items-center justify-center gap-1.5 cursor-pointer rounded-xs"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>INSPECT</span>
                  </button>

                  <button
                    onClick={(e) => handleAdd(wine, e)}
                    className={`flex-1 py-2.5 px-3 text-[11px] font-bold tracking-[0.15em] uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer rounded-xs ${
                      isJustAdded
                        ? 'bg-[#1B3022] text-[#B08D57]'
                        : 'bg-[#B08D57] text-[#111E16] hover:bg-[#C5A059]'
                    }`}
                  >
                    {isJustAdded ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>ADDED</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-3.5 h-3.5" />
                        <span>COLLECT</span>
                      </>
                    )}
                  </button>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
