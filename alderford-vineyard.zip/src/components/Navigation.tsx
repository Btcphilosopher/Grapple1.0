import React, { useState, useEffect } from 'react';
import { ShoppingBag, Search, Menu, X, Globe, ChevronDown, Volume2, VolumeX } from 'lucide-react';
import { CurrencyCode } from '../types';
import { ALDERFORD_CREST_SVG } from '../data/assets';

interface NavigationProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenSearch: () => void;
  currentCurrency: CurrencyCode;
  onSelectCurrency: (code: CurrencyCode) => void;
  isAudioPlaying: boolean;
  onToggleAudio: () => void;
  activeSection: string;
  onNavigate: (sectionId: string) => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  cartCount,
  onOpenCart,
  onOpenSearch,
  currentCurrency,
  onSelectCurrency,
  isAudioPlaying,
  onToggleAudio,
  activeSection,
  onNavigate
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currencyDropdownOpen, setCurrencyDropdownOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const currencies: CurrencyCode[] = ['GBP', 'EUR', 'USD', 'JPY'];

  const navLinks = [
    { id: 'introduction', label: 'Our Story' },
    { id: 'wines', label: 'Our Wines' },
    { id: 'estate', label: 'The Estate' },
    { id: 'terroir', label: 'Terroir' },
    { id: 'winemaking', label: 'Precision' },
    { id: 'cellar', label: 'The Cellar' },
    { id: 'sustainability', label: 'Ecosystem' },
    { id: 'experiences', label: 'Experiences' },
    { id: 'society', label: 'Membership' },
    { id: 'journal', label: 'Journal' },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-[#FDFCF7]/95 backdrop-blur-md border-b border-[#1A1A1A]/10 py-4 shadow-xs text-[#1A1A1A]'
            : 'bg-[#FDFCF7]/90 backdrop-blur-md border-b border-[#1A1A1A]/10 py-4 text-[#1A1A1A]'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            
            {/* Left: Brand Identity / Crest */}
            <button
              onClick={() => onNavigate('hero')}
              className="flex items-center gap-3 group text-left cursor-pointer focus:outline-none"
            >
              <div className="w-8 h-10 transition-transform duration-300 group-hover:scale-105">
                <div dangerouslySetInnerHTML={{ __html: ALDERFORD_CREST_SVG }} />
              </div>
              <div className="flex flex-col">
                <span className="font-display tracking-[0.35em] text-lg font-light uppercase leading-none text-[#1A1A1A]">
                  ALDERFORD
                </span>
                <span className="text-[9px] tracking-[0.3em] font-mono uppercase mt-1 text-[#1A1A1A]/60">
                  VINEYARD • ENGLAND
                </span>
              </div>
            </button>

            {/* Desktop Navigation Links matching Sophisticated Dark text-[11px] uppercase tracking-[0.2em] */}
            <nav className="hidden lg:flex items-center gap-6 xl:gap-7 text-[11px] tracking-[0.2em] uppercase font-sans font-medium">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => onNavigate(link.id)}
                  className={`relative py-1 cursor-pointer transition-opacity duration-200 ${
                    activeSection === link.id
                      ? 'text-[#1B3022] font-bold border-b border-[#1B3022]'
                      : 'text-[#1A1A1A] hover:opacity-50'
                  }`}
                >
                  {link.label}
                </button>
              ))}
            </nav>

            {/* Right Side Controls */}
            <div className="flex items-center gap-3 sm:gap-4">
              
              {/* Search Toggle */}
              <button
                onClick={onOpenSearch}
                aria-label="Search"
                className="p-2 rounded-full transition-colors duration-200 cursor-pointer text-[#1A1A1A] hover:bg-[#1A1A1A]/5"
              >
                <Search className="w-4 h-4" />
              </button>

              {/* Ambient Audio Toggle */}
              <button
                onClick={onToggleAudio}
                title={isAudioPlaying ? 'Mute Estate Ambience' : 'Play Estate Ambience'}
                aria-label="Toggle Estate Ambience"
                className={`hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-mono tracking-wider border transition-colors duration-200 cursor-pointer ${
                  isAudioPlaying
                    ? 'border-[#B08D57] text-[#B08D57] bg-[#B08D57]/10'
                    : 'border-[#1A1A1A]/20 text-[#1A1A1A]/70 hover:border-[#1A1A1A]'
                }`}
              >
                {isAudioPlaying ? <Volume2 className="w-3 h-3 text-[#B08D57] animate-pulse" /> : <VolumeX className="w-3 h-3" />}
                <span>{isAudioPlaying ? 'SOUND ON' : 'SOUND'}</span>
              </button>

              {/* Currency Selector */}
              <div className="relative">
                <button
                  onClick={() => setCurrencyDropdownOpen(!currencyDropdownOpen)}
                  className="flex items-center gap-1 text-xs font-mono tracking-wider py-1 px-2 rounded cursor-pointer transition-colors text-[#1A1A1A] hover:bg-[#1A1A1A]/5"
                >
                  <Globe className="w-3.5 h-3.5 text-[#B08D57]" />
                  <span>{currentCurrency}</span>
                  <ChevronDown className="w-3 h-3" />
                </button>

                {currencyDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-28 bg-[#1B3022] text-[#FDFCF7] border border-[#B08D57]/30 rounded shadow-2xl py-1 z-50 text-xs font-mono">
                    {currencies.map((code) => (
                      <button
                        key={code}
                        onClick={() => {
                          onSelectCurrency(code);
                          setCurrencyDropdownOpen(false);
                        }}
                        className={`w-full text-left px-3 py-1.5 hover:bg-[#B08D57] hover:text-[#111E16] cursor-pointer transition-colors ${
                          currentCurrency === code ? 'text-[#B08D57] font-bold' : ''
                        }`}
                      >
                        {code}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Shop CTA button matching Sophisticated Dark HTML */}
              <button
                onClick={() => onNavigate('wines')}
                className="hidden sm:flex h-10 px-5 border border-[#1A1A1A] items-center justify-center hover:bg-[#1A1A1A] hover:text-[#FDFCF7] cursor-pointer text-[11px] uppercase tracking-[0.2em] font-sans font-medium transition-all duration-300"
              >
                Shop Wines
              </button>

              {/* Shopping Bag Drawer Button */}
              <button
                onClick={onOpenCart}
                aria-label="Shopping Bag"
                className="relative p-2 rounded-full transition-colors cursor-pointer text-[#1A1A1A] hover:bg-[#1A1A1A]/5"
              >
                <ShoppingBag className="w-4 h-4 text-[#1B3022]" />
                {cartCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 bg-[#1B3022] text-[#FDFCF7] text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center font-mono">
                    {cartCount}
                  </span>
                )}
              </button>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label="Toggle Menu"
                className="lg:hidden p-2 rounded-md cursor-pointer text-[#1A1A1A] hover:bg-[#1A1A1A]/5"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>

            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-[#111E16]/98 backdrop-blur-2xl text-white pt-24 pb-12 px-6 flex flex-col justify-between overflow-y-auto lg:hidden">
          <div className="space-y-6">
            <div className="text-center mb-8">
              <span className="text-xs font-mono uppercase text-[#C5A059] tracking-[0.3em]">
                Alderford Estate Navigation
              </span>
            </div>
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => {
                  onNavigate(link.id);
                  setMobileMenuOpen(false);
                }}
                className="block w-full text-center py-2 text-xl font-display uppercase tracking-[0.15em] text-stone-200 hover:text-[#C5A059] transition-colors"
              >
                {link.label}
              </button>
            ))}
          </div>

          <div className="pt-8 border-t border-[#3A4E42] text-center space-y-4">
            <button
              onClick={() => {
                onNavigate('wines');
                setMobileMenuOpen(false);
              }}
              className="w-full py-3 bg-[#C5A059] text-[#111E16] text-xs font-bold tracking-[0.2em] uppercase rounded-xs"
            >
              Shop Wine Collection
            </button>
            <p className="text-xs text-stone-400 font-mono">
              Sussex, England • Heritage. Innovation. Excellence.
            </p>
          </div>
        </div>
      )}
    </>
  );
};
