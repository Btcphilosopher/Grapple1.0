import React, { useState } from 'react';
import { Wine, CurrencyCode } from '../types';
import { X, Award, Shield, Gift, RefreshCw, Check, Plus, Minus, GlassWater, Thermometer, Calendar } from 'lucide-react';

interface WineProductModalProps {
  wine: Wine | null;
  onClose: () => void;
  formatPrice: (priceGBP: number) => string;
  onAddToCart: (wine: Wine, quantity: number, giftBox: boolean, bondedStorage: boolean) => void;
}

export const WineProductModal: React.FC<WineProductModalProps> = ({
  wine,
  onClose,
  formatPrice,
  onAddToCart,
}) => {
  if (!wine) return null;

  const [quantity, setQuantity] = useState(1);
  const [giftBox, setGiftBox] = useState(false);
  const [bondedStorage, setBondedStorage] = useState(false);
  const [bottleAngle, setBottleAngle] = useState(0); // 0 to 360 degree rotation simulation
  const [added, setAdded] = useState(false);

  const handleAddToCart = () => {
    onAddToCart(wine, quantity, giftBox, bondedStorage);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-xl overflow-y-auto">
      <div className="bg-[#FDFBF7] text-[#242728] max-w-5xl w-full rounded-xs border border-[#C5A059] my-auto overflow-hidden shadow-2xl relative my-8">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close modal"
          className="absolute top-6 right-6 z-30 p-2.5 rounded-full bg-[#111E16] text-[#E5C98B] hover:bg-[#C5A059] hover:text-[#111E16] transition-colors cursor-pointer shadow-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-12">
          
          {/* Left Column: 360 Interactive Bottle Showcase (5 Cols) */}
          <div className="lg:col-span-5 bg-[#111E16] p-8 text-white flex flex-col justify-between relative overflow-hidden">
            
            {/* Top Vintage Badge */}
            <div className="flex items-center justify-between z-10">
              <span className="text-xs font-mono uppercase text-[#C5A059] tracking-[0.2em] bg-black/40 px-3 py-1 rounded border border-[#C5A059]/30">
                {wine.vintage} VINTAGE
              </span>
              <span className="text-xs font-mono text-stone-400">
                {wine.bottleSize}
              </span>
            </div>

            {/* Interactive Bottle Graphic with Rotation Simulation */}
            <div className="relative h-80 sm:h-96 my-8 flex items-center justify-center z-10">
              <img
                src={wine.image}
                alt={wine.name}
                style={{ transform: `rotate(${bottleAngle / 15}deg) scale(1.05)` }}
                className="h-full object-contain transition-transform duration-200 drop-shadow-[0_20px_40px_rgba(0,0,0,0.8)]"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Rotation Slider Control */}
            <div className="space-y-2 z-10 bg-black/40 p-4 rounded-xs border border-stone-800">
              <div className="flex justify-between items-center text-[10px] font-mono text-stone-300">
                <span className="flex items-center gap-1">
                  <RefreshCw className="w-3 h-3 text-[#C5A059]" />
                  <span>360° BOTTLE INSPECTION</span>
                </span>
                <span>{bottleAngle}°</span>
              </div>
              <input
                type="range"
                min="0"
                max="360"
                value={bottleAngle}
                onChange={(e) => setBottleAngle(Number(e.target.value))}
                className="w-full accent-[#C5A059] cursor-pointer"
              />
            </div>

          </div>

          {/* Right Column: Complete Specifications & Tasting Radar (7 Cols) */}
          <div className="lg:col-span-7 p-6 sm:p-10 space-y-8 max-h-[85vh] overflow-y-auto">
            
            {/* Title & Price */}
            <div className="border-b border-[#EAE5DB] pb-6 space-y-2">
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-xs font-mono text-[#C5A059] tracking-widest uppercase block">
                    {wine.category} • {wine.vineyardBlock}
                  </span>
                  <h2 className="font-display text-3xl sm:text-4xl text-[#111E16]">{wine.name}</h2>
                </div>
                <div className="font-mono text-2xl font-bold text-[#111E16]">
                  {formatPrice(wine.priceGBP)}
                </div>
              </div>
              <p className="text-xs font-mono text-stone-500 uppercase">{wine.subtitle}</p>
            </div>

            {/* Award Banner */}
            {wine.award && (
              <div className="p-3 bg-[#111E16] text-[#E5C98B] rounded-xs border border-[#C5A059]/40 flex items-center gap-3 text-xs font-mono">
                <Award className="w-5 h-5 text-[#C5A059] shrink-0" />
                <span>{wine.award}</span>
              </div>
            )}

            {/* Tasting Notes */}
            <div className="space-y-3">
              <h3 className="font-display text-lg text-[#111E16] border-b border-[#EAE5DB] pb-1">
                TASTING PROFILE & PALATE
              </h3>
              <div className="grid grid-cols-1 gap-2 text-xs font-sans-modern text-stone-700">
                <div><span className="font-bold text-[#111E16]">AROMA:</span> {wine.tastingNotes.aroma}</div>
                <div><span className="font-bold text-[#111E16]">PALATE:</span> {wine.tastingNotes.palate}</div>
                <div><span className="font-bold text-[#111E16]">FINISH:</span> {wine.tastingNotes.finish}</div>
              </div>
            </div>

            {/* Tasting Radar Metrics Bar Chart */}
            <div className="space-y-3 bg-[#F5F2EA] p-4 rounded-xs border border-[#EAE5DB]">
              <h4 className="text-xs font-mono text-[#C5A059] uppercase tracking-wider font-bold">
                SCIENTIFIC TASTING CHART
              </h4>
              <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-[11px] font-mono text-stone-700">
                <div>
                  <div className="flex justify-between"><span>CITRUS VITALITY</span><span>{wine.tastingProfile.citrus}%</span></div>
                  <div className="h-1.5 bg-stone-300 rounded overflow-hidden mt-1"><div className="h-full bg-[#C5A059]" style={{ width: `${wine.tastingProfile.citrus}%` }} /></div>
                </div>
                <div>
                  <div className="flex justify-between"><span>CHALK MINERALITY</span><span>{wine.tastingProfile.mineral}%</span></div>
                  <div className="h-1.5 bg-stone-300 rounded overflow-hidden mt-1"><div className="h-full bg-[#111E16]" style={{ width: `${wine.tastingProfile.mineral}%` }} /></div>
                </div>
                <div>
                  <div className="flex justify-between"><span>FLORAL COMPLEXITY</span><span>{wine.tastingProfile.floral}%</span></div>
                  <div className="h-1.5 bg-stone-300 rounded overflow-hidden mt-1"><div className="h-full bg-[#C5A059]" style={{ width: `${wine.tastingProfile.floral}%` }} /></div>
                </div>
                <div>
                  <div className="flex justify-between"><span>ACIDITY TENSION</span><span>{wine.tastingProfile.acidity}%</span></div>
                  <div className="h-1.5 bg-stone-300 rounded overflow-hidden mt-1"><div className="h-full bg-[#111E16]" style={{ width: `${wine.tastingProfile.acidity}%` }} /></div>
                </div>
              </div>
            </div>

            {/* Key Serving & Cellaring Data Grid */}
            <div className="grid grid-cols-3 gap-3 text-[11px] font-mono border-t border-b border-[#EAE5DB] py-3 text-stone-600">
              <div className="flex items-center gap-2">
                <Thermometer className="w-4 h-4 text-[#C5A059]" />
                <div>
                  <span className="block text-stone-400 text-[9px]">TEMP</span>
                  <span>{wine.servingTemp}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#C5A059]" />
                <div>
                  <span className="block text-stone-400 text-[9px]">CELLARING</span>
                  <span>{wine.ageingPotential}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <GlassWater className="w-4 h-4 text-[#C5A059]" />
                <div>
                  <span className="block text-stone-400 text-[9px]">ALCOHOL</span>
                  <span>{wine.alcohol}</span>
                </div>
              </div>
            </div>

            {/* E-Commerce Add Options */}
            <div className="space-y-4 pt-2">
              <div className="flex items-center gap-4">
                
                {/* Quantity Control */}
                <div className="flex items-center border border-[#111E16] rounded-xs bg-white">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    aria-label="Decrease quantity"
                    className="p-2.5 text-[#111E16] hover:bg-stone-100 cursor-pointer"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="px-4 font-mono font-bold text-sm text-[#111E16]">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    aria-label="Increase quantity"
                    className="p-2.5 text-[#111E16] hover:bg-stone-100 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>

                {/* Add to Cart Button */}
                <button
                  onClick={handleAddToCart}
                  className={`flex-1 py-3.5 px-6 font-mono text-xs font-bold tracking-[0.2em] uppercase transition-all duration-300 rounded-xs shadow-xl cursor-pointer flex items-center justify-center gap-2 ${
                    added
                      ? 'bg-emerald-800 text-white'
                      : 'bg-[#C5A059] text-[#111E16] hover:bg-[#E5C98B]'
                  }`}
                >
                  {added ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>ADDED TO COLLECTION</span>
                    </>
                  ) : (
                    <span>ADD TO COLLECTION • {formatPrice(wine.priceGBP * quantity)}</span>
                  )}
                </button>

              </div>

              {/* Toggles for Gift Box & Bonded Storage */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs font-mono">
                <label className="flex items-center gap-2 p-2.5 bg-[#F5F2EA] rounded border border-[#EAE5DB] cursor-pointer hover:border-[#C5A059]">
                  <input
                    type="checkbox"
                    checked={giftBox}
                    onChange={(e) => setGiftBox(e.target.checked)}
                    className="accent-[#C5A059]"
                  />
                  <Gift className="w-4 h-4 text-[#C5A059]" />
                  <span>Alderford Gift Wooden Box (+£12)</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 bg-[#F5F2EA] rounded border border-[#EAE5DB] cursor-pointer hover:border-[#C5A059]">
                  <input
                    type="checkbox"
                    checked={bondedStorage}
                    onChange={(e) => setBondedStorage(e.target.checked)}
                    className="accent-[#C5A059]"
                  />
                  <Shield className="w-4 h-4 text-[#C5A059]" />
                  <span>UK Bonded Storage Transfer</span>
                </label>
              </div>

            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
