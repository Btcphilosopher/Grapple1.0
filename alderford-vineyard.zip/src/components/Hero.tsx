import React, { useState } from 'react';
import { ArrowRight, Layers } from 'lucide-react';
import { ASSETS, ALDERFORD_CREST_SVG } from '../data/assets';

interface HeroProps {
  onDiscover: () => void;
  onExploreWines: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onDiscover, onExploreWines }) => {
  const [showWireframeOverlay, setShowWireframeOverlay] = useState(false);

  return (
    <section id="hero" className="relative w-full min-h-screen bg-[#FDFCF7] text-[#1A1A1A] flex flex-col justify-between pt-20 overflow-hidden">
      
      {/* Wireframe Architectural Toggle Control */}
      <button
        onClick={() => setShowWireframeOverlay(!showWireframeOverlay)}
        className="absolute top-24 right-6 sm:right-12 z-30 flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1A1A1A] text-[#FDFCF7] text-[10px] font-mono tracking-widest hover:bg-[#1B3022] hover:text-[#B08D57] transition-all duration-300 cursor-pointer shadow-lg border border-[#1A1A1A]/20"
      >
        <Layers className="w-3.5 h-3.5 text-[#B08D57]" />
        <span>{showWireframeOverlay ? 'HIDE ARCHITECTURE' : 'ANGLO-FUTURIST OVERLAY'}</span>
      </button>

      {/* Main Hero Grid Split */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-6 sm:px-12 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center py-12">
        
        {/* Left Editorial Section (7 cols on LG) */}
        <div className="lg:col-span-7 flex flex-col justify-center space-y-6 lg:pr-6">
          
          <div>
            <span className="text-[10px] uppercase tracking-[0.3em] font-sans text-[#1A1A1A]/60 font-medium">
              Established MMXXIV • Sussex, England
            </span>
          </div>

          <h1 className="font-display text-5xl sm:text-7xl lg:text-[90px] leading-[0.9] font-light tracking-tighter text-[#1A1A1A]">
            Heritage.<br />
            Innovation.<br />
            <span className="italic font-serif text-[#1B3022]">Excellence.</span>
          </h1>

          <p className="max-w-md text-base sm:text-lg leading-relaxed text-[#1A1A1A]/80 font-sans font-light">
            Rooted in England. Crafted for the future. Alderford represents the emergence of world-class English viticulture, where heritage meets architectural precision.
          </p>

          {/* Action Controls matching Sophisticated Dark design HTML */}
          <div className="flex flex-wrap gap-8 items-center pt-4">
            
            <button
              onClick={onDiscover}
              className="group cursor-pointer flex items-center gap-4 focus:outline-none"
            >
              <div className="w-12 h-12 rounded-full border border-[#1A1A1A] flex items-center justify-center group-hover:bg-[#1A1A1A] group-hover:text-white transition-all duration-300">
                <ArrowRight className="w-4 h-4 text-[#1A1A1A] group-hover:text-white" />
              </div>
              <span className="text-[11px] uppercase tracking-[0.2em] font-sans font-bold text-[#1A1A1A]">
                Discover Alderford
              </span>
            </button>

            <button
              onClick={onExploreWines}
              className="group cursor-pointer flex items-center gap-2 focus:outline-none"
            >
              <span className="text-[11px] uppercase tracking-[0.2em] font-sans font-bold text-[#1A1A1A]/40 group-hover:text-[#1A1A1A] transition-colors">
                Explore The Collection
              </span>
            </button>

          </div>

        </div>

        {/* Right Feature Display Card with Green #1B3022 Canvas & Gold Radial Gradient (5 cols on LG) */}
        <div className="lg:col-span-5 h-[420px] sm:h-[500px] relative rounded-xs overflow-hidden bg-[#1B3022] shadow-2xl flex flex-col justify-between p-8 sm:p-10 border border-[#1A1A1A]/10">
          
          {/* Subtle Image Backdrop */}
          <img
            src={ASSETS.heroEstate}
            alt="Alderford Vineyard Estate"
            className="absolute inset-0 w-full h-full object-cover mix-blend-overlay opacity-50 hover:scale-105 transition-transform duration-1000"
            referrerPolicy="no-referrer"
          />

          {/* Gold Radial Gradient Overlay */}
          <div
            className="absolute inset-0 opacity-50 pointer-events-none"
            style={{
              background: 'radial-gradient(circle at 70% 30%, #B08D57 0%, transparent 70%)'
            }}
          />

          {/* Wireframe Architectural Overlay if Toggled */}
          {showWireframeOverlay && (
            <div className="absolute inset-0 pointer-events-none opacity-40 transition-opacity duration-700 flex items-center justify-center">
              <svg className="w-full h-full stroke-[#B08D57]" viewBox="0 0 500 400" fill="none">
                <path d="M250 50 L270 250 L230 250 Z" strokeWidth="0.8" strokeDasharray="3 2" />
                <path d="M50 320 Q 250 250 450 320" strokeWidth="0.5" />
                <circle cx="250" cy="50" r="8" strokeWidth="0.5" />
                <line x1="250" y1="0" x2="250" y2="400" strokeWidth="0.3" strokeDasharray="2 2" />
              </svg>
            </div>
          )}

          {/* Top Crest & Label */}
          <div className="relative z-10 flex items-center justify-between">
            <div className="w-10 h-12">
              <div dangerouslySetInnerHTML={{ __html: ALDERFORD_CREST_SVG }} />
            </div>
            <span className="text-[10px] font-mono tracking-[0.3em] uppercase text-[#B08D57] bg-black/40 px-3 py-1 rounded-full border border-[#B08D57]/30">
              100% ESTATE GROWN
            </span>
          </div>

          {/* Bottom Card Copy */}
          <div className="relative z-10 space-y-3 text-white">
            <div className="flex items-end justify-between">
              <div className="space-y-1">
                <div className="text-[10px] uppercase tracking-[0.4em] font-sans opacity-70 text-[#B08D57]">
                  CURRENT VINTAGE ALLOCATION
                </div>
                <div className="text-3xl sm:text-4xl italic font-serif">
                  Estate Blanc de Blancs
                </div>
                <div className="text-[11px] font-mono opacity-80 uppercase tracking-widest text-stone-300">
                  Chardonnay / Pinot Noir / Meunier
                </div>
              </div>
              <div className="text-right">
                <div className="text-4xl sm:text-5xl font-light font-sans tracking-tighter text-[#B08D57]">
                  2024
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* Footer Bar matching Sophisticated Dark HTML */}
      <div className="w-full bg-[#1A1A1A] text-[#FDFCF7] px-6 sm:px-12 py-5 flex flex-col md:flex-row items-center justify-between font-sans text-xs gap-4 border-t border-[#1A1A1A]/10">
        
        <div className="flex flex-wrap gap-8 sm:gap-16">
          <div className="space-y-0.5">
            <div className="text-[9px] uppercase tracking-[0.2em] opacity-40">Terroir</div>
            <div className="text-[11px] tracking-wider uppercase font-medium text-stone-200">Chalk & Flint</div>
          </div>
          <div className="space-y-0.5">
            <div className="text-[9px] uppercase tracking-[0.2em] opacity-40">Elevation</div>
            <div className="text-[11px] tracking-wider uppercase font-medium text-stone-200">104m AMSL</div>
          </div>
          <div className="space-y-0.5">
            <div className="text-[9px] uppercase tracking-[0.2em] opacity-40">Coordinates</div>
            <div className="text-[11px] tracking-wider uppercase font-medium text-stone-200">51.17° N, 0.45° E</div>
          </div>
        </div>

        <div className="flex gap-4 sm:gap-8 items-center">
          <div className="hidden sm:block h-[1px] w-16 sm:w-24 bg-[#FDFCF7]/20" />
          <div className="text-[10px] uppercase tracking-[0.3em] font-light text-stone-300">
            Anglo-Futurism / Excellence in Viticulture
          </div>
          <div className="hidden sm:block h-[1px] w-16 sm:w-24 bg-[#FDFCF7]/20" />
        </div>

      </div>

    </section>
  );
};

