import React, { useState } from 'react';
import { Sun, CloudRain, RefreshCw, Leaf, Zap, ShieldCheck } from 'lucide-react';

export const SustainabilitySection: React.FC = () => {
  const [activeCycle, setActiveCycle] = useState<'energy' | 'water' | 'soil' | 'waste'>('energy');

  const cycleData = {
    energy: {
      title: 'SUN → ENERGY → WINERY',
      subtitle: '140% Renewable Electricity Generation',
      description: 'Floating solar arrays on our bio-lake generate more electricity than the entire estate consumes. Surplus energy is fed back into the Sussex regional power grid.',
      metric: '140% Net Energy',
      details: 'Off-grid battery storage powers night-harvest pressing operations.'
    },
    water: {
      title: 'RAIN → RESERVOIR → VINEYARD',
      subtitle: '100% Captured Rainwater Self-Sufficiency',
      description: 'Our 2-acre natural capture lake collects winter runoff. Closed-loop drip irrigation uses soil moisture tensiometers to deliver precise water only when vines need it.',
      metric: '0 Gallons Municipal',
      details: 'Subsurface drip lines reduce evaporative water loss by 90%.'
    },
    soil: {
      title: 'VINE → GRAPE → WINE',
      subtitle: 'Regenerative Soil Stewardship',
      description: 'We seed native clover and wildflower cover crops between vineyard rows to fix natural nitrogen, aerate the chalk topsoil, and eliminate chemical fertilizers.',
      metric: 'Zero Glyphosate',
      details: 'Over 120 species of beneficial insects and wild birds inhabit vine rows.'
    },
    waste: {
      title: 'WASTE → COMPOST → SOIL',
      subtitle: 'Zero-Waste Circular Winemaking',
      description: 'Grape pomace (skins & seeds) from pressing is composted on-site with oak sawdust and fed back into vineyard topsoil as rich organic humus every winter.',
      metric: '100% Circular',
      details: 'Recycled lightweight glass bottles manufactured in Great Britain.'
    }
  };

  const current = cycleData[activeCycle];

  return (
    <section id="sustainability" className="py-24 sm:py-32 bg-[#FDFBF7] text-[#242728] border-b border-[#EAE5DB]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#111E16]/5 border border-[#111E16]/10 text-xs font-mono text-[#C5A059] uppercase tracking-[0.25em]">
            <Leaf className="w-3.5 h-3.5" />
            <span>CIRCULAR ECOLOGICAL DESIGN</span>
          </div>
          <h2 className="font-display text-3xl sm:text-5xl tracking-wide uppercase font-light text-[#111E16]">
            THE ESTATE AS AN ECOSYSTEM
          </h2>
          <p className="font-sans-modern text-stone-600 text-sm sm:text-base font-light leading-relaxed">
            Sustainability at Alderford is not corporate marketing. It is a regenerative agricultural philosophy that views our 120 acres as a unified, living ecosystem.
          </p>
        </div>

        {/* Interactive Cycle Flow Buttons */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {[
            { id: 'energy', label: 'ENERGY CYCLE', icon: Zap },
            { id: 'water', label: 'WATER CYCLE', icon: CloudRain },
            { id: 'soil', label: 'REGENERATIVE SOIL', icon: Leaf },
            { id: 'waste', label: 'CIRCULAR WASTE', icon: RefreshCw }
          ].map((item) => {
            const Icon = item.icon;
            const isActive = activeCycle === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveCycle(item.id as any)}
                className={`p-4 rounded-xs text-left border transition-all duration-300 cursor-pointer ${
                  isActive
                    ? 'bg-[#111E16] text-[#E5C98B] border-[#C5A059] shadow-xl'
                    : 'bg-[#F5F2EA] text-stone-700 border-[#EAE5DB] hover:border-[#C5A059]'
                }`}
              >
                <Icon className={`w-5 h-5 mb-2 ${isActive ? 'text-[#C5A059]' : 'text-stone-500'}`} />
                <div className="text-xs font-mono font-bold tracking-wider">{item.label}</div>
              </button>
            );
          })}
        </div>

        {/* Cycle Display Card */}
        <div className="bg-[#111E16] text-white p-8 sm:p-12 rounded-xs border border-[#C5A059]/40 shadow-2xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          <div className="lg:col-span-8 space-y-6">
            <div className="space-y-2">
              <span className="text-xs font-mono text-[#C5A059] uppercase tracking-widest block">
                {current.subtitle}
              </span>
              <h3 className="font-display text-3xl sm:text-4xl text-stone-100">{current.title}</h3>
            </div>

            <p className="font-sans-modern text-stone-300 text-sm sm:text-base leading-relaxed font-light">
              {current.description}
            </p>

            <div className="p-4 bg-[#0D0F0E] rounded border border-stone-800 text-xs font-mono text-[#E5C98B] flex items-center gap-3">
              <ShieldCheck className="w-5 h-5 text-[#C5A059] shrink-0" />
              <span>{current.details}</span>
            </div>
          </div>

          <div className="lg:col-span-4 bg-[#0D0F0E] p-8 rounded-xs border border-stone-800 text-center space-y-2">
            <span className="text-xs font-mono text-stone-400 uppercase tracking-widest block">KEY ECOLOGICAL IMPACT</span>
            <div className="font-display text-4xl text-[#C5A059] font-bold">{current.metric}</div>
            <p className="text-[10px] font-mono text-stone-500 uppercase pt-2 border-t border-stone-800">
              Verified by Sustainable Wines of Great Britain
            </p>
          </div>

        </div>

      </div>
    </section>
  );
};
